import fs from 'node:fs';
import path from 'node:path';
import { writeJsonAtomic, writeJsonAtomicAsync } from './modules/atomic-write.mjs';

const MAX_DEDUP_ENTRIES = 10_000;
const MAX_DELETED_KEYS = 500;
const MAX_CONVERSATIONS = 50;
const MAX_MESSAGES_PER_CONV = 100;
const DEFAULT_SAVE_DEBOUNCE_MS = 150;

const PLATFORM_LABELS = Object.freeze({
  // Core (7)
  line: 'LINE',
  facebook: 'FB',
  fb: 'FB',
  whatsapp: 'WA',
  shopee: 'SHOPEE',
  tiktok: 'TIKTOK',
  lazada: 'LAZADA',
  email: 'EMAIL',
  // Wave 1 (4)
  instagram: 'INSTAGRAM',
  shopify: 'SHOPIFY',
  hubspot: 'HUBSPOT',
  wechat: 'WECHAT',
  // Wave 2 (4)
  discord: 'DISCORD',
  signal: 'SIGNAL',
  viber: 'VIBER',
  kakaotalk: 'KAKAOTALK',
  // Wave 3 (5)
  slack: 'SLACK',
  teams: 'TEAMS',
  'google-chat': 'GOOGLE_CHAT',
  google_chat: 'GOOGLE_CHAT',
  googlechat: 'GOOGLE_CHAT',
  lark: 'LARK',
  dingtalk: 'DINGTALK',
  // Wave 4 (3)
  'zoho-salesiq': 'ZOHO_SALESIQ',
  zoho_salesiq: 'ZOHO_SALESIQ',
  zoho: 'ZOHO_SALESIQ',
  crisp: 'CRISP',
  tidio: 'TIDIO',
  // Extra / Internal
  telegram: 'TELEGRAM',
  zalo: 'ZALO',
  webchat: 'WEBCHAT',
  sandbox: 'SANDBOX',
});

const activeStoreRefs = new Set();
let processHooksInstalled = false;

function formatPlatformLabel(rawPlatform = '') {
  const key = String(rawPlatform || '').trim().toLowerCase();
  if (!key) return 'UNKNOWN';
  if (Object.hasOwn(PLATFORM_LABELS, key)) {
    return PLATFORM_LABELS[key];
  }
  return key.toUpperCase();
}

function cloneChannelMeta(meta) {
  if (!meta || typeof meta !== 'object') return {};
  try {
    return structuredClone(meta);
  } catch {
    return { ...meta };
  }
}

function safeDecodeURIComponent(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function flushAllActiveStoresSync() {
  for (const ref of activeStoreRefs) {
    const store = ref.deref();
    if (!store) {
      activeStoreRefs.delete(ref);
      continue;
    }
    try {
      store.flushSaveSync({ onlyIfDirty: true });
    } catch {
      // Best-effort sync flush on process exit/signal
    }
  }
}

function flushStoresForPathSync(filePath, excludeStore = null) {
  if (!filePath) return;
  const resolvedTarget = path.resolve(filePath);
  for (const ref of activeStoreRefs) {
    const store = ref.deref();
    if (!store) {
      activeStoreRefs.delete(ref);
      continue;
    }
    if (store === excludeStore) continue;
    if (path.resolve(store.filePath) !== resolvedTarget) continue;
    if (store._dirty || store._resavePending || store._saveTimer || store._saving) {
      try {
        store.flushSaveSync({ onlyIfDirty: false });
      } catch {
        // Best-effort flush before peer instance reads the same state file
      }
    }
  }
}

function installProcessFlushHooks() {
  if (processHooksInstalled) return;
  processHooksInstalled = true;

  const makeSignalHandler = (signal) => {
    const handler = () => {
      flushAllActiveStoresSync();
      // Only re-raise default termination if no other graceful-shutdown handler is attached
      if (process.listenerCount(signal) <= 1) {
        process.off(signal, handler);
        try {
          process.kill(process.pid, signal);
        } catch {
          process.exit(signal === 'SIGINT' ? 130 : 143);
        }
      }
    };
    return handler;
  };

  process.on('SIGTERM', makeSignalHandler('SIGTERM'));
  process.on('SIGINT', makeSignalHandler('SIGINT'));
  process.on('exit', flushAllActiveStoresSync);
}

export class PersistentStateStore {
  constructor(filePath = '/app/data/gateway-state.json', options = {}) {
    this.filePath = filePath;
    this.saveDebounceMs =
      Number.isFinite(Number(options.saveDebounceMs)) && Number(options.saveDebounceMs) >= 0
        ? Math.floor(Number(options.saveDebounceMs))
        : DEFAULT_SAVE_DEBOUNCE_MS;
    this.maxDedupEntries =
      Number.isFinite(Number(options.maxDedupEntries)) && Number(options.maxDedupEntries) > 0
        ? Math.floor(Number(options.maxDedupEntries))
        : MAX_DEDUP_ENTRIES;
    this.maxDeletedKeys =
      Number.isFinite(Number(options.maxDeletedKeys)) && Number(options.maxDeletedKeys) > 0
        ? Math.floor(Number(options.maxDeletedKeys))
        : MAX_DELETED_KEYS;

    this.dedup = new Map();         // mid -> expiresAt
    this.takeover = new Map();      // userKey -> expiresAt
    this.imageMemory = new Map();   // userKey -> { expiresAt, savedAt, data }
    this.sessionLocks = new Map();  // userKey -> { expiresAt, savedAt, language, botPersona, personaLocked }
    this.conversations = new Map(); // userKey -> { userKey, platform, userId, customerName, updatedAt, unreadCount, messages: [], channelMeta?: {} }
    this.deletedKeys = new Set();   // userKeys deleted locally in Sandbox so read-only tap does not re-add them

    this._saveTimer = null;
    this._dirty = false;
    this._saving = false;
    this._resavePending = false;
    this._writePromise = Promise.resolve();
    this._lastDedupPruneAt = 0;

    installProcessFlushHooks();
    activeStoreRefs.add(new WeakRef(this));

    this._load();
  }

  _load() {
    flushStoresForPathSync(this.filePath, this);
    try {
      if (!fs.existsSync(this.filePath)) return;
      const raw = fs.readFileSync(this.filePath, 'utf8');
      const parsed = JSON.parse(raw);
      const now = Date.now();

      for (const [k, exp] of Object.entries(parsed.dedup || {})) {
        if (exp > now) this.dedup.set(k, exp);
      }
      this._enforceDedupCap(now);

      for (const [k, exp] of Object.entries(parsed.takeover || {})) {
        if (exp > now) this.takeover.set(k, exp);
      }
      for (const [k, entry] of Object.entries(parsed.imageMemory || {})) {
        if (entry && entry.expiresAt > now) this.imageMemory.set(k, entry);
      }
      for (const [k, lock] of Object.entries(parsed.sessionLocks || {})) {
        if (lock && lock.expiresAt > now) this.sessionLocks.set(k, lock);
      }
      for (const [k, conv] of Object.entries(parsed.conversations || {})) {
        if (conv && Array.isArray(conv.messages)) {
          this.conversations.set(k, conv);
        }
      }
      if (Array.isArray(parsed.deletedKeys)) {
        for (const k of parsed.deletedKeys) {
          if (k) this.deletedKeys.add(String(k));
        }
        this._enforceDeletedKeysCap();
      }
    } catch (err) {
      console.warn('[StateStore] Initial load skipped:', err.message);
    }
  }

  _enforceDedupCap(now = Date.now()) {
    if (this.dedup.size <= this.maxDedupEntries) return;
    if (now - this._lastDedupPruneAt >= 1000) {
      this._lastDedupPruneAt = now;
      for (const [k, exp] of this.dedup) {
        if (exp <= now) this.dedup.delete(k);
      }
    }
    while (this.dedup.size > this.maxDedupEntries) {
      const oldestKey = this.dedup.keys().next().value;
      if (oldestKey === undefined) break;
      this.dedup.delete(oldestKey);
    }
  }

  _enforceDeletedKeysCap() {
    while (this.deletedKeys.size > this.maxDeletedKeys) {
      const oldestKey = this.deletedKeys.values().next().value;
      if (oldestKey === undefined) break;
      this.deletedKeys.delete(oldestKey);
    }
  }

  _buildSnapshot(now = Date.now()) {
    this.prune(now);
    return {
      updatedAt: new Date(now).toISOString(),
      dedup: Object.fromEntries(this.dedup),
      takeover: Object.fromEntries(this.takeover),
      imageMemory: Object.fromEntries(this.imageMemory),
      sessionLocks: Object.fromEntries(this.sessionLocks),
      conversations: Object.fromEntries(this.conversations),
      deletedKeys: Array.from(this.deletedKeys),
    };
  }

  _drainAsyncSave() {
    if (this._saving) {
      this._resavePending = true;
      return this._writePromise;
    }
    this._saving = true;
    const run = async () => {
      try {
        while (this._dirty || this._resavePending) {
          this._dirty = false;
          this._resavePending = false;
          const payload = this._buildSnapshot();
          await writeJsonAtomicAsync(this.filePath, payload);
        }
      } catch (err) {
        console.error('[StateStore] Save error:', err.message);
      } finally {
        this._saving = false;
      }
    };
    this._writePromise = this._writePromise.then(run, run);
    return this._writePromise;
  }

  _save() {
    this._dirty = true;
    if (this._saving) {
      this._resavePending = true;
      return;
    }
    if (this._saveTimer) return;
    this._saveTimer = setTimeout(() => {
      this._saveTimer = null;
      this._drainAsyncSave();
    }, this.saveDebounceMs);
    if (typeof this._saveTimer.unref === 'function') {
      this._saveTimer.unref();
    }
  }

  async flushSave() {
    if (this._saveTimer) {
      clearTimeout(this._saveTimer);
      this._saveTimer = null;
    }
    if (!this._dirty && !this._resavePending) {
      await this._writePromise;
      return;
    }
    await this._drainAsyncSave();
  }

  flushSaveSync({ onlyIfDirty = false } = {}) {
    if (this._saveTimer) {
      clearTimeout(this._saveTimer);
      this._saveTimer = null;
    }
    if (onlyIfDirty && !this._dirty && !this._resavePending) {
      return false;
    }
    try {
      this._dirty = false;
      this._resavePending = this._saving;
      const payload = this._buildSnapshot();
      writeJsonAtomic(this.filePath, payload);
      return true;
    } catch (err) {
      console.error('[StateStore] Sync flush error:', err.message);
      return false;
    }
  }

  prune(now = Date.now()) {
    for (const [k, exp] of this.dedup) if (exp <= now) this.dedup.delete(k);
    for (const [k, exp] of this.takeover) if (exp <= now) this.takeover.delete(k);
    for (const [k, entry] of this.imageMemory) if (!entry || entry.expiresAt <= now) this.imageMemory.delete(k);
    for (const [k, lock] of this.sessionLocks) if (!lock || lock.expiresAt <= now) this.sessionLocks.delete(k);
    this._enforceDedupCap(now);
    this._enforceDeletedKeysCap();
  }

  isDuplicateAndMark(id, ttlMs = 86400000, now = Date.now()) {
    if (!id) return false;
    const key = String(id);
    const exp = this.dedup.get(key);
    if (exp && exp > now) return true;
    if (exp !== undefined) this.dedup.delete(key);
    this.dedup.set(key, now + ttlMs);
    this._enforceDedupCap(now);
    this._save();
    return false;
  }

  setTakeover(userKey, ttlMs = 1800000, now = Date.now()) {
    this.takeover.set(userKey, now + ttlMs);
    this._save();
  }

  clearTakeover(userKey) {
    const deleted = this.takeover.delete(userKey);
    if (deleted) this._save();
    return deleted;
  }

  isPausedByHuman(userKey, now = Date.now()) {
    const exp = this.takeover.get(userKey);
    if (!exp) return false;
    if (exp <= now) {
      this.takeover.delete(userKey);
      return false;
    }
    return true;
  }

  setImageMemory(userKey, data, ttlMs = 900000, now = Date.now()) {
    this.imageMemory.set(userKey, {
      expiresAt: now + ttlMs,
      savedAt: now,
      data,
    });
    this._save();
  }

  getImageMemory(userKey, now = Date.now()) {
    const entry = this.imageMemory.get(userKey);
    if (!entry) return null;
    if (entry.expiresAt <= now) {
      this.imageMemory.delete(userKey);
      this._save();
      return null;
    }
    return entry.data;
  }

  setSessionLock(userKey, lockData, ttlMs = 3600000, now = Date.now()) {
    const record = {
      language: lockData.language || 'TH',
      botPersona: lockData.botPersona || 'FEMALE_ADMIN',
      personaLocked: Boolean(lockData.personaLocked),
      savedAt: now,
      expiresAt: now + ttlMs,
    };
    this.sessionLocks.set(userKey, record);
    this._save();
    return record;
  }

  getSessionLock(userKey, now = Date.now()) {
    const lock = this.sessionLocks.get(userKey);
    if (!lock) return null;
    if (lock.expiresAt <= now) {
      this.sessionLocks.delete(userKey);
      this._save();
      return null;
    }
    return lock;
  }

  clearSessionLock(userKey) {
    const deleted = this.sessionLocks.delete(userKey);
    if (deleted) this._save();
    return deleted;
  }

  /** Append a chat message for a userKey, keeping up to 100 messages and 50 conversations. */
  appendChatMessage(userKey, msgObj, meta = {}) {
    if (!userKey) return null;
    const now = msgObj?.timestamp || Date.now();
    const parts = String(userKey).split(':');
    const platform = String(meta.platform || parts[0] || 'unknown').trim().toLowerCase();
    const userId = meta.userId || parts.slice(1).join(':') || userKey;
    const platformLabel = formatPlatformLabel(platform);

    let conv = this.conversations.get(userKey);
    if (!conv) {
      conv = {
        userKey,
        platform,
        userId,
        customerName: meta.customerName || `${platformLabel} (${String(userId).slice(-6)})`,
        updatedAt: now,
        unreadCount: 0,
        messages: [],
      };
    }

    if (meta.customerName) {
      conv.customerName = meta.customerName;
    }
    if (meta.channelMeta && typeof meta.channelMeta === 'object') {
      conv.channelMeta = { ...(conv.channelMeta || {}), ...meta.channelMeta };
    }

    const sender = msgObj?.sender || 'customer';
    const text = String(msgObj?.text || '').trim();
    const images = Array.isArray(msgObj?.images) ? msgObj.images.filter(Boolean) : [];
    if (!text && images.length === 0) return conv;

    conv.messages.push({
      id: `${now}_${Math.random().toString(36).slice(2, 7)}`,
      sender,
      text,
      images,
      timestamp: now,
      ...(msgObj?.messageId ? { messageId: String(msgObj.messageId) } : {}),
      ...(msgObj?.replyToText ? { replyToText: String(msgObj.replyToText) } : {}),
      ...(msgObj?.replyToMessageId ? { replyToMessageId: String(msgObj.replyToMessageId) } : {}),
    });

    if (conv.messages.length > MAX_MESSAGES_PER_CONV) {
      conv.messages = conv.messages.slice(-MAX_MESSAGES_PER_CONV);
    }

    conv.updatedAt = now;
    if (sender === 'customer') {
      conv.unreadCount = (conv.unreadCount || 0) + 1;
    } else if (sender === 'admin') {
      conv.unreadCount = 0;
    }

    this.conversations.set(userKey, conv);

    // Keep at most 50 most recently active conversations
    if (this.conversations.size > MAX_CONVERSATIONS) {
      const sortedKeys = Array.from(this.conversations.values())
        .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))
        .map((c) => c.userKey);
      for (const oldKey of sortedKeys.slice(MAX_CONVERSATIONS)) {
        this.conversations.delete(oldKey);
      }
    }

    this._save();
    return conv;
  }

  /** Update customer metadata (e.g. resolved display name from LINE profile or channelMeta). */
  updateConversationMeta(userKey, meta = {}) {
    const conv = this.conversations.get(userKey);
    if (!conv) return null;
    if (meta.customerName) conv.customerName = meta.customerName;
    if (meta.channelMeta && typeof meta.channelMeta === 'object') {
      conv.channelMeta = { ...(conv.channelMeta || {}), ...meta.channelMeta };
    }
    this.conversations.set(userKey, conv);
    this._save();
    return conv;
  }

  /** Reset unread counter when admin opens a conversation. */
  markConversationRead(userKey) {
    const conv = this.conversations.get(userKey);
    if (!conv || conv.unreadCount === 0) return false;
    conv.unreadCount = 0;
    this.conversations.set(userKey, conv);
    this._save();
    return true;
  }

  _syncFromProdReadOnly(prodFilePath = '/app/prod-data/gateway-state.json') {
    if (process.env.ENABLE_SANDBOX_PROD_TAP !== 'true') return;
    try {
      if (!fs.existsSync(prodFilePath)) return;
      const raw = fs.readFileSync(prodFilePath, 'utf8');
      const parsed = JSON.parse(raw);
      for (const [k, prodConv] of Object.entries(parsed.conversations || {})) {
        if (!prodConv || !Array.isArray(prodConv.messages)) continue;
        if (this.deletedKeys.has(k)) continue;
        const localConv = this.conversations.get(k);
        if (!localConv) {
          this.conversations.set(k, structuredClone(prodConv));
        } else if ((prodConv.updatedAt || 0) > (localConv.updatedAt || 0)) {
          const existingIds = new Set((localConv.messages || []).map((m) => m.id));
          for (const m of prodConv.messages) {
            if (m && !existingIds.has(m.id)) {
              localConv.messages.push(m);
            }
          }
          localConv.updatedAt = prodConv.updatedAt;
          localConv.customerName = prodConv.customerName || localConv.customerName;
          if (prodConv.channelMeta && typeof prodConv.channelMeta === 'object') {
            localConv.channelMeta = { ...(localConv.channelMeta || {}), ...prodConv.channelMeta };
          }
          this.conversations.set(k, localConv);
        }
      }
    } catch {
      // Read-only tap best effort
    }
  }

  /** Return conversations sorted newest first with live Human Takeover state. */
  getConversationsList(now = Date.now()) {
    this._syncFromProdReadOnly();
    this.prune(now);
    return Array.from(this.conversations.values())
      .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))
      .map((conv) => {
        const exp = this.takeover.get(conv.userKey) || 0;
        const isTakeover = exp > now;
        const lastMsg = conv.messages[conv.messages.length - 1] || null;
        return {
          ...conv,
          isTakeover,
          takeoverExpiresAt: isTakeover ? exp : null,
          lastMessageText: lastMsg?.text || (lastMsg?.images?.length ? '[รูปภาพ]' : ''),
          lastSender: lastMsg?.sender || null,
        };
      });
  }

  /** Return all currently active Human Takeover locks across all 23 omnichannel platforms. */
  getActiveTakeovers(now = Date.now()) {
    this._syncFromProdReadOnly();
    this.prune(now);
    const items = [];
    for (const [userKey, expiresAt] of this.takeover.entries()) {
      if (expiresAt <= now) continue;
      const conv = this.conversations.get(userKey);
      const [prefixRaw, ...rest] = String(userKey).split(':');
      const platformRaw = String(conv?.platform || prefixRaw || 'unknown').trim().toLowerCase();
      const platformLabel = formatPlatformLabel(platformRaw);
      const userId = String(conv?.userId || rest.join(':') || userKey);
      const lastMsg = conv?.messages?.[conv.messages.length - 1];
      items.push({
        userKey,
        platform: platformLabel,
        channelId: platformRaw,
        customerName: conv?.customerName || `${platformLabel} (${userId.slice(-6)})`,
        reason: lastMsg?.text ? `ข้อความล่าสุด: ${lastMsg.text.slice(0, 80)}` : 'แอดมินกำลังสนทนากับลูกค้า (พักบอท 30 นาที)',
        expiresAt,
      });
    }
    return items.sort((a, b) => a.expiresAt - b.expiresAt);
  }

  /**
   * Phase 8.1: Inspect conversation history for an unanswered trailing customer turn.
   * Returns a merged turn object if the latest message(s) are from 'customer', otherwise null.
   */
  getPendingCustomerTurn(userKey, maxAgeMs = 3600000) {
    const conv = this.conversations.get(userKey);
    if (!conv || !Array.isArray(conv.messages) || conv.messages.length === 0) {
      return null;
    }

    const lastMsg = conv.messages[conv.messages.length - 1];
    if (!lastMsg || lastMsg.sender !== 'customer') {
      return null;
    }
    if (lastMsg.timestamp && Date.now() - Number(lastMsg.timestamp) > maxAgeMs) {
      return null;
    }

    // Collect contiguous trailing messages sent by the customer
    const trailingCustomerMsgs = [];
    for (let i = conv.messages.length - 1; i >= 0; i--) {
      const m = conv.messages[i];
      if (m.sender !== 'customer') break;
      trailingCustomerMsgs.unshift(m);
    }

    const texts = [];
    const images = [];
    let isSticker = false;
    let unsupportedMediaType = '';
    let replyToText = '';
    let replyToMessageId = '';

    for (const m of trailingCustomerMsgs) {
      const t = String(m.text || '').trim();
      if (t === '[ส่งสติกเกอร์]') {
        isSticker = true;
      } else if (/^\[ลูกค้าส่งไฟล์แนบ/.test(t)) {
        unsupportedMediaType = 'file';
        texts.push(t);
      } else if (/^\[ลูกค้าส่งคลิปเสียง/.test(t)) {
        unsupportedMediaType = 'audio';
        texts.push(t);
      } else if (/^\[ลูกค้าส่งวิดีโอ/.test(t)) {
        unsupportedMediaType = 'video';
        texts.push(t);
      } else if (/^\[ลูกค้าแชร์ตำแหน่ง/.test(t)) {
        unsupportedMediaType = 'location';
        texts.push(t);
      } else if (t && t !== '[ลูกค้าส่งรูปภาพทาง LINE]' && !/^#(?:bot|บอท)(?=\s|$)/i.test(t)) {
        texts.push(t);
      }
      if (m.replyToText) replyToText = String(m.replyToText).trim();
      if (m.replyToMessageId) replyToMessageId = String(m.replyToMessageId).trim();

      if (Array.isArray(m.images)) {
        for (const imgUrl of m.images) {
          if (!imgUrl || /^\/api\/chat\/line-image\/?$/i.test(String(imgUrl).trim())) continue;
          const lineProxyMatch = String(imgUrl).match(/\/api\/chat\/line-image\/([^/?#]+)/);
          if (lineProxyMatch) {
            images.push({ platform: 'line', messageId: safeDecodeURIComponent(lineProxyMatch[1]), url: '' });
          } else {
            images.push({ platform: conv.platform || 'facebook', url: imgUrl });
          }
        }
      }
    }

    if (texts.length === 0 && images.length === 0 && !isSticker) {
      return null;
    }

    return {
      platform: conv.platform,
      userId: conv.userId,
      replyToken: null,
      replyToText,
      replyToMessageId,
      eventTimestamp: lastMsg.timestamp || Date.now(),
      texts,
      images,
      isSticker,
      unsupportedMediaType,
      channelMeta: cloneChannelMeta(conv.channelMeta),
    };
  }

  /** Phase 8.1+8.3: Find the most recent valid customer image URL in a user's conversation. */
  getLatestImageInConversation(userKey) {
    const conv = this.conversations.get(userKey);
    if (!conv || !Array.isArray(conv.messages)) return null;

    const isUsableImageUrl = (url) => {
      const s = String(url || '').trim();
      return Boolean(s) && !/^\/api\/chat\/line-image\/?$/i.test(s);
    };

    for (let i = conv.messages.length - 1; i >= 0; i--) {
      const msg = conv.messages[i];
      if (msg?.sender !== 'customer') continue;
      const imgs = Array.isArray(msg.images) ? msg.images.filter(isUsableImageUrl) : [];
      if (imgs.length > 0) {
        return imgs[imgs.length - 1];
      }
    }

    for (let i = conv.messages.length - 1; i >= 0; i--) {
      const imgs = Array.isArray(conv.messages[i]?.images)
        ? conv.messages[i].images.filter(isUsableImageUrl)
        : [];
      if (imgs.length > 0) {
        return imgs[imgs.length - 1];
      }
    }
    return null;
  }

  /** Rewind a Sandbox conversation from a specific message index and clear AI memories. */
  rewindConversation(userKey, fromIndex = 0) {
    if (!userKey) return { ok: false, error: 'Missing userKey' };
    const conv = this.conversations.get(userKey);
    if (!conv || !Array.isArray(conv.messages)) {
      return { ok: false, error: 'Conversation not found' };
    }
    const idx = Number(fromIndex);
    if (!Number.isInteger(idx) || idx < 0 || idx > conv.messages.length) {
      return { ok: false, error: 'Invalid message index' };
    }

    const removedCount = conv.messages.length - idx;
    conv.messages = conv.messages.slice(0, idx);
    conv.lastMatchedProduct = '';
    conv.lastMatchedProductAt = 0;
    conv.unreadCount = 0;
    conv.updatedAt =
      conv.messages.length > 0
        ? Number(conv.messages[conv.messages.length - 1]?.timestamp || Date.now())
        : Date.now();

    this.conversations.set(userKey, conv);
    this.imageMemory.delete(userKey);
    this.sessionLocks.delete(userKey);
    this.takeover.delete(userKey);
    this._save();

    return {
      ok: true,
      removedCount,
      remainingCount: conv.messages.length,
    };
  }

  /** Delete a conversation by userKey and persist to disk. */
  deleteConversation(userKey) {
    if (!userKey) return false;
    const key = String(userKey);
    this.deletedKeys.delete(key);
    this.deletedKeys.add(key);
    this._enforceDeletedKeysCap();
    const deleted = this.conversations.delete(key);
    this.takeover.delete(key);
    this.imageMemory.delete(key);
    this.sessionLocks.delete(key);
    this._save();
    return deleted;
  }
}
