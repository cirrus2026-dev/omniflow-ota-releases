﻿export function loadConfig(env = process.env) {
  const configGid = env.BOT_CONFIG_GID || '128469300';

  return {
    port: Number(env.PORT || 4000),
    shopName: env.SHOP_NAME || 'OmniFlow',
    contactLine: env.CONTACT_LINE || '',
    publicBaseUrl: (env.PUBLIC_BASE_URL || env.APP_BASE_URL || '').replace(/\/+$/, ''),

    // Flowise Dual-Cloud Auto-Failover
    flowiseBaseUrl: (env.FLOWISE_BASE_URL || 'http://flowise:3000').replace(/\/+$/, ''),
    flowiseFallbackBaseUrl: (env.FLOWISE_FALLBACK_BASE_URL || 'http://host.docker.internal:3000').replace(/\/+$/, ''),
    flowisePrimaryId: env.FLOWISE_PRIMARY_CHATFLOW_ID || '3aa31ef9-2e9f-43c9-82ea-8b888ac17ac8',
    flowiseFallbackId: env.FLOWISE_FALLBACK_CHATFLOW_ID || '18b1cfe5-dc9b-4882-aa90-5008d7b2759c',
    flowiseTimeoutMs: Number(env.FLOWISE_TIMEOUT_MS || 35000),

    // External Vision & Local Models
    openClipUrl: (env.OPENCLIP_URL || 'http://host.docker.internal:5055').replace(/\/+$/, ''),
    openClipThreshold: Number(env.OPENCLIP_THRESHOLD || 0.65),
    groqApiKey: env.GROQ_API_KEY || '',
    groqVisionModel: env.GROQ_VISION_MODEL || 'qwen/qwen3.8-27b',
    groqVisionFallbackModel: env.GROQ_VISION_FALLBACK_MODEL || 'meta-llama/llama-4-scout-17b-16e-instruct',
    ollamaBaseUrl: (env.OLLAMA_BASE_URL || 'http://host.docker.internal:11434').replace(/\/+$/, ''),
    ollamaVisionModel: env.OLLAMA_VISION_MODEL || 'llava:latest',

    // Facebook Messenger
    fbVerifyToken: env.FB_VERIFY_TOKEN || 'aether_verify_token',
    fbAppSecret: env.FB_APP_SECRET || '',
    fbPageAccessToken: env.FB_PAGE_ACCESS_TOKEN || '',
    fbGraphVersion: env.FB_GRAPH_VERSION || 'v27.0',

    // LINE Official Account
    lineChannelId: env.LINE_CHANNEL_ID || '',
    lineChannelSecret: env.LINE_CHANNEL_SECRET || '',
    lineChannelAccessToken: env.LINE_CHANNEL_ACCESS_TOKEN || '',
    lineDeliveryMode: env.LINE_DELIVERY_MODE || 'bundle',
    lineReplyTokenTtlMs: Number(env.LINE_REPLY_TOKEN_TTL_MS || 45000),

    // Plan A: Emergency BOT_STATUS Switch (Google Sheets Config Tab gid=128469300)
    botConfigGid: configGid,
    botConfigCsvUrl: (env.BOT_CONFIG_CSV_URL || '').trim(),
    botStatusCacheTtlMs: Number(env.BOT_STATUS_CACHE_TTL_MS || 15000), // 15 seconds cache
    botStatusFetchTimeoutMs: Number(env.BOT_STATUS_FETCH_TIMEOUT_MS || 5000),

    // Plan A: Canary Healthcheck & Owner Alerting
    canaryEnabled: String(env.CANARY_ENABLED ?? 'true').toLowerCase() !== 'false',
    canaryIntervalMs: Number(env.CANARY_INTERVAL_MS || 21600000), // Every 6 hours
    canaryAlertCooldownMs: Number(env.CANARY_ALERT_COOLDOWN_MS || 3600000), // 1 hour cooldown per alert
    adminLineUserId: (env.ADMIN_LINE_USER_ID || '').trim(),
    telegramBotToken: (env.TELEGRAM_BOT_TOKEN || '').trim(),
    telegramChatId: (env.TELEGRAM_CHAT_ID || '').trim(),
    alertWebhookUrl: (env.ALERT_WEBHOOK_URL || '').trim(),

    // Plan B & State Timers
    stateFilePath: env.STATE_FILE_PATH || '/app/data/gateway-state.json',
    debounceWindowMs: Number(env.DEBOUNCE_WINDOW_MS || 2500),
    imageMemoryTtlMs: Number(env.IMAGE_MEMORY_TTL_MS || 2700000),   // 45 minutes
    productMemoryTtlMs: Number(env.PRODUCT_MEMORY_TTL_MS || 2700000), // 45 minutes
    takeoverTtlMs: Number(env.TAKEOVER_TTL_MS || 1800000),        // 30 minutes
    dedupTtlMs: Number(env.DEDUP_TTL_MS || 86400000),             // 24 hours
    sessionLockTtlMs: Number(env.SESSION_LOCK_TTL_MS || 3600000), // 60 minutes (Plan B)
    typingDelayMs: Number(env.TYPING_DELAY_MS || 300),
    maxImages: Number(env.MAX_IMAGES || 3),
    allowedImageHosts: (env.ALLOWED_IMAGE_HOSTS || 'cdn.jsdelivr.net,raw.githubusercontent.com')
      .split(',')
      .map((h) => h.trim().toLowerCase())
      .filter(Boolean),
  };
}
