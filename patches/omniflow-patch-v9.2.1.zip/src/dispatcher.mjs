// gateway/src/dispatcher.mjs
// Omnichannel Outbound Dispatcher Router (Facebook, LINE, WhatsApp & Registry Adapters)

import { getChannelAdapter } from './modules/channels/channel-registry.mjs';
import { getRuntimeConfig } from './modules/settings-vault.mjs';
import { sendWhatsAppReply } from './modules/channels/whatsapp-adapter.mjs';
import { resolvePublicImageWithReason } from './dispatch-utils.mjs';
import {
  sendFacebookTypingIndicator,
  dispatchFacebook,
  sendFacebookAdminReply,
} from './dispatch-facebook.mjs';
import {
  sendLineTypingIndicator,
  dispatchLine,
  sendLineAdminReply,
} from './dispatch-line.mjs';

function readRuntimeConfigSafe() {
  try {
    return getRuntimeConfig() || {};
  } catch {
    return {};
  }
}

export async function sendTypingIndicator(ctx, config) {
  try {
    const runtimeCfg = readRuntimeConfigSafe();
    const fbToken = String(
      runtimeCfg?.channels?.facebook?.pageAccessToken || config?.fbPageAccessToken || ''
    ).trim();
    const lineToken = String(
      runtimeCfg?.channels?.line?.channelAccessToken || config?.lineChannelAccessToken || ''
    ).trim();

    if (ctx?.platform === 'facebook' && fbToken && ctx.userId) {
      await sendFacebookTypingIndicator(ctx.userId, config);
    } else if (ctx?.platform === 'line' && lineToken && ctx.userId) {
      await sendLineTypingIndicator(ctx.userId, config);
    }
  } catch {
    // Non-blocking UI feedback only
  }
}

function preparePublicImages(images = [], config = {}) {
  const validImages = [];
  const skippedImages = [];
  for (const img of Array.isArray(images) ? images : []) {
    const rawUrl = typeof img === 'string' ? img.trim() : String(img?.url || '').trim();
    const mirrorUrl = typeof img === 'object' && img ? String(img.mirrorUrl || '').trim() : '';
    const caption = typeof img === 'object' && img ? String(img.caption || '').trim() : '';
    if (!rawUrl && !mirrorUrl) continue;

    const primary = resolvePublicImageWithReason(rawUrl, config);
    const mirror = !primary.url && mirrorUrl ? resolvePublicImageWithReason(mirrorUrl, config) : { url: '', reason: '' };
    const resolved = primary.url || mirror.url;
    if (!resolved) {
      skippedImages.push({
        url: rawUrl || mirrorUrl,
        reason: primary.reason || mirror.reason || 'Image URL must be a public HTTPS URL',
      });
      continue;
    }
    validImages.push(caption ? { url: resolved, caption } : { url: resolved });
  }
  return { validImages, skippedImages };
}

async function dispatchWhatsApp(userId, text, images = [], config = {}) {
  const cleanUserId = String(userId || '').trim();
  const cleanText = String(text || '').trim();
  const { validImages, skippedImages } = preparePublicImages(images, config);

  if (!cleanUserId) {
    return { ok: false, platform: 'whatsapp', messageId: '', textSent: false, imagesSent: [], error: 'Missing WhatsApp recipient userId' };
  }
  if (!cleanText && validImages.length === 0) {
    return {
      ok: false,
      platform: 'whatsapp',
      messageId: '',
      textSent: false,
      imagesSent: [],
      ...(skippedImages.length > 0 ? { skippedImages } : {}),
      error: skippedImages[0]?.reason || 'WhatsApp reply text and images are both empty',
    };
  }

  const runtimeCfg = readRuntimeConfigSafe();
  const waCfg = runtimeCfg?.channels?.whatsapp || {};
  const phoneNumberId = String(
    waCfg.phoneNumberId || config?.whatsappPhoneNumberId || process.env.WHATSAPP_PHONE_NUMBER_ID || ''
  ).trim();
  const accessToken = String(
    waCfg.accessToken || config?.whatsappAccessToken || process.env.WHATSAPP_ACCESS_TOKEN || ''
  ).trim();

  if (!phoneNumberId || !accessToken) {
    return {
      ok: false,
      platform: 'whatsapp',
      messageId: '',
      textSent: false,
      imagesSent: [],
      ...(skippedImages.length > 0 ? { skippedImages } : {}),
      error: 'Missing WhatsApp phoneNumberId or accessToken',
    };
  }

  try {
    const res = await sendWhatsAppReply({
      to: cleanUserId,
      text: cleanText,
      images: validImages,
      phoneNumberId,
      accessToken,
    });
    const allSkipped = [...skippedImages, ...(Array.isArray(res?.skippedImages) ? res.skippedImages : [])];
    const failedImages = Array.isArray(res?.failedImages) ? res.failedImages : [];
    const messageId = res?.messageId || res?.data?.messages?.[0]?.id || '';
    const allOk = Boolean(res?.ok) && allSkipped.length === 0 && failedImages.length === 0;
    const errorParts = [res?.error, ...skippedImages.map((s) => s.reason)].filter(Boolean);
    return {
      ok: allOk,
      platform: 'whatsapp',
      messageId,
      textSent: Boolean(res?.textSent),
      imagesSent: Array.isArray(res?.imagesSent) ? res.imagesSent : [],
      ...(failedImages.length > 0 ? { failedImages } : {}),
      ...(allSkipped.length > 0 ? { skippedImages: allSkipped } : {}),
      ...(errorParts.length > 0 ? { error: errorParts.join('; ') } : {}),
    };
  } catch (err) {
    console.error('[Dispatcher:WA] Send failed:', err?.message || err);
    return {
      ok: false,
      platform: 'whatsapp',
      messageId: '',
      textSent: false,
      imagesSent: [],
      ...(skippedImages.length > 0 ? { skippedImages } : {}),
      error: err?.message || 'WhatsApp send failed',
    };
  }
}

export async function dispatchDualMessage(ctx, parsedReply, config) {
  const reply = parsedReply || {};
  if (ctx.platform === 'facebook') {
    return dispatchFacebook(ctx, reply, config);
  }
  if (ctx.platform === 'line') {
    return dispatchLine(ctx, reply, config);
  }
  if (ctx.platform === 'whatsapp') {
    return dispatchWhatsApp(ctx.userId, reply.text || '', reply.images || [], config);
  }
  const adapter = getChannelAdapter(ctx.platform);
  if (adapter) {
    const runtimeCfg = readRuntimeConfigSafe();
    const channelCfg = runtimeCfg?.channels?.[ctx.platform] || {};
    const businessName = runtimeCfg?.business?.businessName || config?.shopName || 'OmniFlow';
    const cleanText = String(reply.text || '').trim();
    const { validImages, skippedImages } = preparePublicImages(reply.images || [], config);
    if (!cleanText && validImages.length === 0 && skippedImages.length > 0) {
      return {
        ok: false,
        platform: ctx.platform,
        messageId: '',
        textSent: false,
        imagesSent: [],
        skippedImages,
        error: skippedImages[0]?.reason || 'No valid text or public image URL to send',
      };
    }
    const res = await adapter.sendReply({
      to: ctx.userId,
      text: reply.text || '',
      images: validImages,
      replyToken: ctx.replyToken || '',
      channelCfg,
      businessName,
      meta: ctx.channelMeta || {},
    });
    if (skippedImages.length > 0 && res && typeof res === 'object') {
      const mergedSkipped = [...skippedImages, ...(Array.isArray(res.skippedImages) ? res.skippedImages : [])];
      return { ...res, skippedImages: mergedSkipped };
    }
    return res;
  }
  throw new Error(`Unsupported platform: ${ctx.platform}`);
}

/**
 * Send a direct reply from an admin via Dashboard Live Inbox to LINE OA, Facebook Messenger, WhatsApp, or any registered channel.
 */
export async function sendAdminReply(platform, userId, text, config, extra = {}) {
  const cleanText = String(text || '').trim();
  const images = Array.isArray(extra?.images) ? extra.images : [];
  if (!cleanText && images.length === 0) {
    throw new Error('Reply text or images cannot be empty');
  }

  if (platform === 'facebook') {
    return sendFacebookAdminReply(userId, cleanText, images, config);
  }
  if (platform === 'line') {
    return sendLineAdminReply(userId, cleanText, images, config);
  }
  if (platform === 'whatsapp') {
    const res = await dispatchWhatsApp(userId, cleanText, images, config);
    if (!res.ok && !res.textSent && (!Array.isArray(res.imagesSent) || res.imagesSent.length === 0)) {
      throw new Error(res.error || 'WhatsApp send failed');
    }
    return res;
  }

  const adapter = getChannelAdapter(platform);
  if (adapter) {
    const runtimeCfg = readRuntimeConfigSafe();
    const channelCfg = runtimeCfg?.channels?.[platform] || {};
    const businessName = runtimeCfg?.business?.businessName || config?.shopName || 'OmniFlow';
    const { validImages, skippedImages } = preparePublicImages(images, config);
    if (!cleanText && validImages.length === 0) {
      throw new Error(skippedImages[0]?.reason || 'No valid text or public image URL to send');
    }
    const res = await adapter.sendReply({
      to: userId,
      text: cleanText,
      images: validImages,
      replyToken: extra.replyToken || '',
      channelCfg,
      businessName,
      meta: extra.channelMeta || {},
    });
    if (!res?.ok) {
      throw new Error(res?.error || `${platform} sendReply failed`);
    }
    if (skippedImages.length > 0) {
      const mergedSkipped = [...skippedImages, ...(Array.isArray(res.skippedImages) ? res.skippedImages : [])];
      return { ...res, skippedImages: mergedSkipped };
    }
    return res;
  }

  throw new Error(`Unsupported platform: ${platform}`);
}
