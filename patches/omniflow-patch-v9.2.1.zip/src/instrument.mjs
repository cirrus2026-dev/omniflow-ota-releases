const dsn = String(process.env.SENTRY_DSN || '').trim();
const environment = process.env.SENTRY_ENVIRONMENT || process.env.NODE_ENV || 'sandbox';

function scrubPiiText(input = '') {
  return String(input || '')
    .replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, '[REDACTED_EMAIL]')
    .replace(/(?:\+?\d{1,3}[-.\s]?)?(?:0\d{1,2}|\d{2,3})[-.\s]?\d{3}[-.\s]?\d{4}/g, '[REDACTED_PHONE]')
    .replace(/(Bearer\s+|xoxb-|shpat_|pat-[a-z0-9-]+|EAA)[A-Za-z0-9._-]+/gi, '[REDACTED_TOKEN]');
}

if (dsn) {
  try {
    const Sentry = await import('@sentry/node');
    Sentry.init({
      dsn,
      enabled: true,
      environment,
      sendDefaultPii: false,
      tracesSampleRate: 0.1,
      ignoreErrors: ['ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'AbortError'],
      beforeBreadcrumb(breadcrumb) {
        if (breadcrumb?.category?.startsWith('http') && breadcrumb.data) {
          delete breadcrumb.data.body;
          delete breadcrumb.data.headers;
        }
        if (typeof breadcrumb?.message === 'string') {
          breadcrumb.message = scrubPiiText(breadcrumb.message);
        }
        return breadcrumb;
      },
      beforeSend(event) {
        if (event.user) delete event.user;
        if (event.request) {
          delete event.request.data;
          delete event.request.cookies;
          delete event.request.headers;
          if (event.request.query_string) event.request.query_string = '[REDACTED_QUERY]';
        }
        if (event.message) event.message = scrubPiiText(event.message);
        for (const ex of event.exception?.values || []) {
          if (ex.value) ex.value = scrubPiiText(ex.value);
        }
        return event;
      }
    });
  } catch (err) {
    console.warn('[instrument] Optional @sentry/node unavailable, running in Air-Gapped mode:', err.message);
  }
}