export async function askFlowiseWithFailover(question, sessionId, config) {
  const targets = [
    {
      name: 'Primary_Cloud_Groq',
      url: `${config.flowiseBaseUrl}/api/v1/prediction/${config.flowisePrimaryId}`,
    },
    {
      name: 'Primary_Cloud_HostFallback',
      url: `${config.flowiseFallbackBaseUrl}/api/v1/prediction/${config.flowisePrimaryId}`,
    },
    {
      name: 'Fallback_Secondary_Chatflow',
      url: `${config.flowiseBaseUrl}/api/v1/prediction/${config.flowiseFallbackId}`,
    },
    {
      name: 'Fallback_Secondary_HostFallback',
      url: `${config.flowiseFallbackBaseUrl}/api/v1/prediction/${config.flowiseFallbackId}`,
    },
  ];

  const uniqueTargets = [];
  const seen = new Set();
  for (const t of targets) {
    if (!seen.has(t.url)) {
      seen.add(t.url);
      uniqueTargets.push(t);
    }
  }

  let lastError = null;
  for (const target of uniqueTargets) {
    try {
      const res = await fetch(target.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question,
          overrideConfig: { sessionId },
        }),
        signal: AbortSignal.timeout(config.flowiseTimeoutMs),
      });

      if (!res.ok) {
        const errBody = await res.text().catch(() => '');
        throw new Error(`HTTP ${res.status}: ${errBody.slice(0, 160)}`);
      }

      const data = await res.json();
      const text = data?.text || data?.answer || data?.output || '';
      if (!text || !text.trim()) {
        throw new Error('Empty response text from Flowise');
      }

      return {
        text,
        raw: data,
        usedTarget: target.name,
      };
    } catch (err) {
      lastError = err;
      console.warn(`[FlowiseClient] ${target.name} failed (${err.message}) -> switching to next failover target...`);
    }
  }

  throw lastError || new Error('All Flowise targets failed');
}