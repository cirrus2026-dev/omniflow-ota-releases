// gateway/src/dispatch-facebook.mjs
// Facebook Messenger Outbound Dispatcher (Bearer Header Auth, Shared HTTPS Validator, Hot-Reload & Real Status Reporting)

import { getGithubImageMirrors } from './ai-reply-parser.mjs';
import { getRuntimeConfig } from './modules/settings-vault.mjs';
import {
  normalizePublicHttpsUrl,
  resolvePublicImageWithReason,
  dedupePublicHttpsUrls,
} from './dispatch-utils.mjs';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const FB_TEXT_LIMIT = 2000;

function resolveFbPageAccessToken(config = {}) {
  let runtimeCfg = {};
  try {
    runtimeCfg = getRuntimeConfig() || {};
  } catch {
    runtimeCfg = {};
  }
  return String(
    runtimeCfg?.channels?.facebook?.pageAccessToken || config?.fbPageAccessToken || ''
  ).trim();
}

export function collectFacebookImageCandidates(img, config = {}) {
  const rawUrl = typeof img === 'string' ? img.trim() : String(img?.url || '').trim();
  const mirrorUrl = typeof img === 'object' && img ? String(img.mirrorUrl || '').trim() : '';
  const primary = resolvePublicImageWithReason(rawUrl, config);
  const mirror = mirrorUrl ? resolvePublicImageWithReason(mirrorUrl, config) : { url: '', reason: '' };
  const ghMirrors = rawUrl ? getGithubImageMirrors(rawUrl).map((m) => normalizePublicHttpsUrl(m)).filter(Boolean) : [];
  const candidates = dedupePublicHttpsUrls([primary.url, mirror.url, ...ghMirrors]);
  return {
    rawUrl: rawUrl || mirrorUrl,
    candidates,
    reason: candidates.length > 0 ? '' : (primary.reason || mirror.reason || 'Image URL must be a public HTTPS URL'),
  };
}

function buildFacebookEndpoint(config) {
  const version = String(config?.fbGraphVersion || 'v21.0').trim();
  return `https://graph.facebook.com/${encodeURIComponent(version)}/me/messages`;
}

function buildFacebookHeaders(token) {
  return {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
}

export async function sendFacebookTypingIndicator(userId, config) {
  const token = resolveFbPageAccessToken(config);
  if (!token || !userId) return;
  await fetch(buildFacebookEndpoint(config), {
    method: 'POST',
    headers: buildFacebookHeaders(token),
    body: JSON.stringify({ recipient: { id: userId }, sender_action: 'typing_on' }),
    signal: AbortSignal.timeout(3000),
  }).catch(() => {});
}

async function sendFacebookText(endpoint, headers, userId, text, metadata, extraBody = {}) {
  let payloadText = text;
  if (payloadText.length > FB_TEXT_LIMIT) {
    console.warn(`[Dispatcher:FB] Truncating text from ${payloadText.length} to ${FB_TEXT_LIMIT} chars`);
    payloadText = payloadText.slice(0, FB_TEXT_LIMIT);
  }
  const res = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      recipient: { id: userId },
      ...extraBody,
      message: {
        text: payloadText,
        metadata,
      },
    }),
    signal: AbortSignal.timeout(15000),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errMsg = json?.error?.message || JSON.stringify(json?.error || {}).slice(0, 200) || `HTTP ${res.status}`;
    return { ok: false, status: res.status, messageId: '', error: `Facebook Send API HTTP ${res.status}: ${errMsg}` };
  }
  return { ok: true, status: res.status, messageId: String(json?.message_id || ''), error: '' };
}

async function sendFacebookImageCandidates(endpoint, headers, userId, candidates, metadata, extraBody = {}) {
  let lastError = 'No resolvable public image URL';
  for (const candidateUrl of candidates) {
    try {
      const res = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          recipient: { id: userId },
          ...extraBody,
          message: {
            attachment: {
              type: 'image',
              payload: { url: candidateUrl, is_reusable: true },
            },
            metadata,
          },
        }),
        signal: AbortSignal.timeout(20000),
      });
      const json = await res.json().catch(() => ({}));
      if (res.ok) {
        return { ok: true, url: candidateUrl, messageId: String(json?.message_id || ''), error: '' };
      }
      lastError = `HTTP ${res.status}: ${json?.error?.message || ''}`.trim();
      console.warn(`[Dispatcher:FB] Image send failed for ${candidateUrl} (${lastError}), trying mirror...`);
    } catch (err) {
      lastError = err?.message || 'Network error';
      console.warn(`[Dispatcher:FB] Image send error for ${candidateUrl}: ${lastError}`);
    }
  }
  return { ok: false, url: '', messageId: '', error: lastError };
}

export async function dispatchFacebook(ctx, parsedReply = {}, config = {}) {
  const token = resolveFbPageAccessToken(config);
  if (!token) {
    return { ok: false, platform: 'facebook', messageId: '', textSent: false, imagesSent: [], error: 'Missing FB_PAGE_ACCESS_TOKEN' };
  }

  const cleanText = String(parsedReply.text || '').trim();
  const images = Array.isArray(parsedReply.images) ? parsedReply.images : [];
  if (!cleanText && images.length === 0) {
    return { ok: false, platform: 'facebook', messageId: '', textSent: false, imagesSent: [], error: 'Facebook reply text and images are both empty' };
  }

  const endpoint = buildFacebookEndpoint(config);
  const headers = buildFacebookHeaders(token);
  let messageId = '';
  let textSentOk = false;
  const errors = [];

  if (cleanText) {
    try {
      const textResult = await sendFacebookText(endpoint, headers, ctx.userId, cleanText, 'AI_BOT_REPLY');
      textSentOk = textResult.ok;
      if (textResult.messageId) messageId = textResult.messageId;
      if (!textResult.ok) {
        console.error(`[Dispatcher:FB] Text send failed: ${textResult.error}`);
        errors.push(textResult.error);
      }
    } catch (err) {
      const msg = err?.message || 'Facebook text send failed';
      console.error(`[Dispatcher:FB] Text send exception: ${msg}`);
      errors.push(msg);
    }
  }

  const sentImages = [];
  const failedImages = [];
  const skippedImages = [];
  for (const img of images) {
    if (config.typingDelayMs > 0) await sleep(config.typingDelayMs);
    const { rawUrl, candidates, reason } = collectFacebookImageCandidates(img, config);
    if (candidates.length === 0) {
      console.warn(`[Dispatcher:FB] Skipping image (${reason}): ${rawUrl}`);
      skippedImages.push({ url: rawUrl, reason });
      continue;
    }
    const imgResult = await sendFacebookImageCandidates(endpoint, headers, ctx.userId, candidates, 'AI_BOT_REPLY');
    if (imgResult.ok) {
      if (!messageId && imgResult.messageId) messageId = imgResult.messageId;
      sentImages.push(imgResult.url);
    } else {
      failedImages.push({ url: candidates[0], error: imgResult.error });
      errors.push(imgResult.error);
    }
  }

  if (!textSentOk && sentImages.length === 0 && errors.length === 0 && skippedImages.length > 0) {
    errors.push(skippedImages[0].reason);
  }

  const allOk = (!cleanText || textSentOk) && failedImages.length === 0 && skippedImages.length === 0;
  return {
    ok: allOk,
    platform: 'facebook',
    messageId,
    textSent: textSentOk,
    imagesSent: sentImages,
    ...(failedImages.length > 0 ? { failedImages } : {}),
    ...(skippedImages.length > 0 ? { skippedImages } : {}),
    ...(errors.length > 0 ? { error: errors.join('; ') } : {}),
  };
}

export async function sendFacebookAdminReply(userId, text, images = [], config = {}) {
  const token = resolveFbPageAccessToken(config);
  if (!token) throw new Error('Missing FB_PAGE_ACCESS_TOKEN');

  const cleanText = String(text || '').trim();
  const imgList = Array.isArray(images) ? images : [];
  if (!cleanText && imgList.length === 0) throw new Error('Facebook reply text or images cannot be empty');

  const endpoint = buildFacebookEndpoint(config);
  const headers = buildFacebookHeaders(token);
  const extraBody = { messaging_type: 'RESPONSE' };

  let messageId = '';
  let textSent = false;
  let textError = '';

  if (cleanText) {
    const textResult = await sendFacebookText(endpoint, headers, userId, cleanText, 'ADMIN_DASHBOARD_REPLY', extraBody);
    textSent = textResult.ok;
    if (textResult.messageId) messageId = textResult.messageId;
    if (!textResult.ok) textError = textResult.error;
  }

  const sentImages = [];
  const failedImages = [];
  const skippedImages = [];
  for (const img of imgList) {
    const { rawUrl, candidates, reason } = collectFacebookImageCandidates(img, config);
    if (candidates.length === 0) {
      skippedImages.push({ url: rawUrl, reason });
      continue;
    }
    const imgResult = await sendFacebookImageCandidates(endpoint, headers, userId, candidates, 'ADMIN_DASHBOARD_REPLY', extraBody);
    if (imgResult.ok) {
      if (!messageId && imgResult.messageId) messageId = imgResult.messageId;
      sentImages.push(imgResult.url);
    } else {
      failedImages.push({ url: candidates[0], error: imgResult.error });
    }
  }

  if (!textSent && sentImages.length === 0) {
    throw new Error(textError || failedImages[0]?.error || skippedImages[0]?.reason || 'Facebook Send API failed');
  }

  return {
    ok: (!cleanText || textSent) && failedImages.length === 0 && skippedImages.length === 0,
    platform: 'facebook',
    messageId,
    textSent,
    imagesSent: sentImages,
    ...(failedImages.length > 0 ? { failedImages } : {}),
    ...(skippedImages.length > 0 ? { skippedImages } : {}),
    ...(textError ? { error: textError } : {}),
  };
}
