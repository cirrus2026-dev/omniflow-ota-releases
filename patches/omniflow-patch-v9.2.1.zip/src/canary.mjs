import { getRuntimeConfig } from './modules/settings-vault.mjs';
import { getAllCatalogItems } from './modules/local-db-manager.mjs';
import { getPublicChannelRegistryPayload } from './modules/channels/channel-registry.mjs';
import { fetchSafe, redactUrlSecrets } from './modules/fetch-safe.mjs';

function scrubErrorSecret(rawMsg, secret = '') {
  let msg = redactUrlSecrets(String(rawMsg || 'Request failed'));
  const cleanSecret = String(secret || '').trim();
  if (cleanSecret) {
    msg = msg.replaceAll(cleanSecret, 'REDACTED');
  }
  return msg;
}

export async function runCanaryCheck(config, botStatusController) {
  const startedAt = Date.now();
  const checks = {};
  const cfg = getRuntimeConfig() || {};

  // 1. BOT_STATUS Switch
  try {
    const sheetStatus = await botStatusController.checkStatus(true);
    checks.botSwitch = {
      ok: !sheetStatus.error,
      enabled: sheetStatus.enabled,
      rawValue: sheetStatus.rawValue,
      source: sheetStatus.source,
      error: sheetStatus.error || null,
    };
  } catch (err) {
    checks.botSwitch = { ok: false, enabled: true, error: err.message };
  }

  // 2. Built-in AI Brain Engine Check (Standalone)
  const brainProviders = Array.isArray(cfg.brain?.providers) ? cfg.brain.providers : [];
  const activeProviders = brainProviders.filter((p) => p.enabled !== false);
  const hasLocal = activeProviders.some((p) => p.type === 'local' && p.model);
  const hasCloudKey = activeProviders.some((p) => p.type !== 'local' && p.apiKey && p.apiKey.trim().length > 0);
  const legacyGroqKey = cfg.brain?.groqApiKey || config.groqApiKey || '';
  const legacyGeminiKey = cfg.brain?.geminiApiKey || process.env.GEMINI_API_KEY || '';
  const hasAiKey = Boolean(hasLocal || hasCloudKey || legacyGroqKey || legacyGeminiKey);
  const activeProvName = hasLocal
    ? `Local AI (${activeProviders.find((p) => p.type === 'local')?.model || 'Ollama'})`
    : (activeProviders[0]?.customName || cfg.brain?.primaryProvider || 'AI Provider');

  checks.flowise = {
    ok: hasAiKey,
    hasKey: hasAiKey,
    status: hasAiKey ? 200 : 503,
    detail: hasAiKey ? `${activeProvName} พร้อมใช้งาน` : 'ยังไม่กรอก Key / Model',
  };

  // 3. Local Catalog DB Check (Standalone Zero Cloud Depend)
  try {
    const items = await getAllCatalogItems();
    checks.openClip = { ok: true, hasKey: true, indexedImages: items.length };
  } catch (err) {
    checks.openClip = { ok: false, hasKey: false, error: err.message };
  }

  // 4. Groq Cloud API & Vision Model Check
  const groqKey = cfg.brain?.groqApiKey || config.groqApiKey || activeProviders.find((p) => p.baseUrl?.includes('groq'))?.apiKey || '';
  const hasGroqKey = Boolean(groqKey && groqKey.trim().length > 0);
  checks.groq = {
    ok: hasGroqKey,
    hasKey: hasGroqKey,
    optional: true,
    visionModel: hasGroqKey ? (config.groqVisionModel || 'Visual Grounding') : 'ยังไม่กรอก Groq Key',
  };

  // 5. Facebook Page Access Token Check
  const fbToken = cfg.channels?.facebook?.pageAccessToken || config.fbPageAccessToken || '';
  const hasFbToken = Boolean(fbToken && fbToken.trim().length > 0);
  checks.facebook = {
    ok: hasFbToken,
    hasKey: hasFbToken,
    optional: true,
    pageName: hasFbToken ? (cfg.channels?.facebook?.pageName || 'Graph API v27.0') : 'ยังไม่กรอก Key / Token',
  };

  // 6. LINE OA Channel Access Token Check
  const lineToken = cfg.channels?.line?.channelAccessToken || config.lineChannelAccessToken || '';
  const hasLineToken = Boolean(lineToken && lineToken.trim().length > 0);
  checks.line = {
    ok: hasLineToken,
    hasKey: hasLineToken,
    optional: true,
    displayName: hasLineToken ? (cfg.channels?.line?.displayName || 'Messaging API') : 'ยังไม่กรอก Key / Token',
  };

  // 7. TikTok Shop Open Platform Check
  const tiktokKey = cfg.channels?.tiktok?.appKey || '';
  const tiktokSecret = cfg.channels?.tiktok?.appSecret || '';
  const hasTiktokKey = Boolean(tiktokKey && tiktokKey.trim().length > 0 && tiktokSecret && tiktokSecret.trim().length > 0);
  checks.tiktok = {
    ok: hasTiktokKey,
    hasKey: hasTiktokKey,
    optional: true,
    displayName: hasTiktokKey ? 'TikTok Shop พร้อมใช้' : 'ยังไม่กรอก Key / Secret',
  };

  // 8. Shopee Open Platform Check
  const shopeePartnerId = cfg.channels?.shopee?.partnerId || '';
  const shopeePartnerKey = cfg.channels?.shopee?.partnerKey || '';
  const hasShopeeKey = Boolean(shopeePartnerId && shopeePartnerId.trim().length > 0 && shopeePartnerKey && shopeePartnerKey.trim().length > 0);
  checks.shopee = {
    ok: hasShopeeKey,
    hasKey: hasShopeeKey,
    optional: true,
    displayName: hasShopeeKey ? 'Shopee Platform พร้อมใช้' : 'ยังไม่กรอก Key / Partner ID',
  };

  // 9. Lazada Open Platform Check
  const lazadaAppKey = cfg.channels?.lazada?.appKey || '';
  const lazadaAccessToken = cfg.channels?.lazada?.accessToken || '';
  const hasLazadaKey = Boolean(lazadaAppKey && lazadaAppKey.trim().length > 0 && lazadaAccessToken && lazadaAccessToken.trim().length > 0);
  checks.lazada = {
    ok: hasLazadaKey,
    hasKey: hasLazadaKey,
    optional: true,
    displayName: hasLazadaKey ? 'Lazada Platform พร้อมใช้' : 'ยังไม่กรอก Key / Token',
  };

  // 10. WhatsApp Business Cloud Check
  const waPhoneId = String(cfg.channels?.whatsapp?.phoneNumberId || '').trim();
  const waToken = String(cfg.channels?.whatsapp?.accessToken || '').trim();
  if (waPhoneId && waToken) {
    try {
      const waRes = await fetch(
        `https://graph.facebook.com/v21.0/${encodeURIComponent(waPhoneId)}?fields=display_phone_number,verified_name`,
        {
          headers: { Authorization: `Bearer ${waToken}` },
          signal: AbortSignal.timeout(5000),
        }
      );
      const waJson = await waRes.json().catch(() => ({}));
      checks.whatsapp = {
        ok: waRes.ok && !waJson.error,
        hasKey: true,
        optional: true,
        displayName: waRes.ok ? (waJson.display_phone_number || waJson.verified_name || 'WhatsApp พร้อมใช้') : (waJson.error?.message || `HTTP ${waRes.status}`),
      };
    } catch (err) {
      checks.whatsapp = { ok: false, hasKey: true, optional: true, displayName: err.message };
    }
  } else {
    checks.whatsapp = { ok: false, hasKey: false, optional: true, displayName: 'ยังไม่กรอก Phone ID / Token' };
  }

  // 11. Registry Omnichannel Adapters (Email + Wave 1-4 = all 23 channels)
  const regPayload = getPublicChannelRegistryPayload(cfg);
  for (const ch of regPayload.channels || []) {
    if (!checks[ch.id]) {
      checks[ch.id] = {
        ok: Boolean(ch.configured),
        hasKey: Boolean(ch.configured),
        optional: true,
        label: ch.label || ch.shortLabel,
        displayName: ch.configured ? `${ch.label || ch.shortLabel} พร้อมใช้` : 'ยังไม่กรอก Key / Token',
      };
    }
  }

  const criticalHealthy = Object.values(checks)
    .filter((c) => !c.optional)
    .every((c) => c.ok);
  return {
    ok: criticalHealthy,
    checkedAt: new Date().toISOString(),
    elapsedMs: Date.now() - startedAt,
    checks,
  };
}

export function formatCanaryReportThai(report, config, requesterUserId = '') {
  const c = report.checks || {};
  const icon = (ok) => (ok ? '✅' : '❌');
  const botStateIcon = c.botSwitch?.enabled ? '🟢 ON (เปิดรับลูกค้า)' : '🔴 OFF (ปิดบอทชั่วคราว)';

  const lines = [
    `🩺 [Canary Healthcheck — ${config.shopName}]`,
    `สถานะรวม: ${report.ok ? '✅ ปกติพร้อมใช้งาน 100%' : '⚠️ พบจุดที่ต้องตรวจสอบ'}`,
    `• สวิตช์ BOT_STATUS: ${botStateIcon} (${c.botSwitch?.rawValue || '-'})`,
    `• สมองกล AI Brain: ${icon(c.flowise?.ok)} ${c.flowise?.ok ? c.flowise.detail || 'ออนไลน์' : c.flowise?.error || c.flowise?.status}`,
    `• คลังสินค้าในเครื่อง (Local DB): ${c.openClip?.ok ? `✅ พร้อมใช้งาน (${c.openClip.indexedImages} รายการ)` : '⚠️ ตรวจสอบฐานข้อมูล'}`,
    `• Groq Cloud API: ${icon(c.groq?.ok)} ${c.groq?.ok ? (c.groq.visionModelActive ? `${c.groq.visionModel} พร้อมใช้` : c.groq.visionModel || 'พร้อมใช้งาน') : c.groq?.error || c.groq?.status}`,
    `• Facebook Token: ${icon(c.facebook?.ok)} ${c.facebook?.ok ? `ปกติ (${c.facebook.pageName})` : c.facebook?.error || 'หมดอายุ/ผิดปกติ'}`,
    `• LINE OA Token: ${icon(c.line?.ok)} ${c.line?.ok ? `ปกติ (${c.line.displayName})` : c.line?.error || 'หมดอายุ/ผิดปกติ'}`,
    `• TikTok Shop: ${icon(c.tiktok?.ok)} ${c.tiktok?.displayName || '-'}`,
    `• Shopee Platform: ${icon(c.shopee?.ok)} ${c.shopee?.displayName || '-'}`,
    `• Lazada Platform: ${icon(c.lazada?.ok)} ${c.lazada?.displayName || '-'}`,
  ];

  if (requesterUserId) {
    lines.push(`• รหัส User ID ของคุณ: ${requesterUserId}`);
  }
  return lines.join('\n');
}

export async function sendCanaryAlert(report, config, reason = 'scheduled') {
  const messageText = formatCanaryReportThai(report, config);
  const deliveries = [];
  let runtimeCfg = {};
  try {
    runtimeCfg = getRuntimeConfig() || {};
  } catch {
    runtimeCfg = {};
  }

  // 1. Send to Owner's Personal LINE via LINE OA Push API (hot-reload token from vault first)
  const lineToken = String(
    runtimeCfg?.channels?.line?.channelAccessToken || config?.lineChannelAccessToken || ''
  ).trim();
  if (config?.adminLineUserId && lineToken) {
    try {
      const res = await fetch('https://api.line.me/v2/bot/message/push', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${lineToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: config.adminLineUserId,
          messages: [{ type: 'text', text: messageText }],
        }),
        signal: AbortSignal.timeout(10000),
      });
      deliveries.push({ channel: 'line_admin', ok: res.ok, status: res.status });
    } catch (err) {
      deliveries.push({
        channel: 'line_admin',
        ok: false,
        error: scrubErrorSecret(err?.message || 'LINE alert failed', lineToken),
      });
    }
  }

  // 2. Send to Telegram Bot (scrub telegramBotToken from any error string)
  const tgToken = String(config?.telegramBotToken || '').trim();
  if (tgToken && config?.telegramChatId) {
    try {
      const tgUrl = `https://api.telegram.org/bot${tgToken}/sendMessage`;
      const res = await fetch(tgUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: config.telegramChatId,
          text: messageText,
        }),
        signal: AbortSignal.timeout(10000),
      });
      deliveries.push({ channel: 'telegram', ok: res.ok, status: res.status });
    } catch (err) {
      deliveries.push({
        channel: 'telegram',
        ok: false,
        error: scrubErrorSecret(err?.message || 'Telegram alert failed', tgToken),
      });
    }
  }

  // 3. Optional Webhook Alert via SSRF-safe fetchSafe()
  if (config?.alertWebhookUrl) {
    try {
      const res = await fetchSafe(config.alertWebhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reason, report, messageText }),
        timeoutMs: 10000,
      });
      deliveries.push({ channel: 'webhook', ok: res.ok, status: res.status });
    } catch (err) {
      deliveries.push({
        channel: 'webhook',
        ok: false,
        error: redactUrlSecrets(err?.message || 'Webhook alert failed'),
      });
    }
  }

  return deliveries;
}

export function startCanaryScheduler(config, botStatusController) {
  if (!config.canaryEnabled || config.canaryIntervalMs <= 0) return null;

  let lastAlertAt = 0;
  const runCycle = async () => {
    try {
      const report = await runCanaryCheck(config, botStatusController);
      const now = Date.now();
      if (!report.ok && now - lastAlertAt >= config.canaryAlertCooldownMs) {
        lastAlertAt = now;
        await sendCanaryAlert(report, config, 'unhealthy_detected');
        console.warn('[Canary] Unhealthy service detected -> alert dispatched');
      } else {
        console.log(`[Canary] Periodic check completed: ok=${report.ok}, botEnabled=${report.checks?.botSwitch?.enabled}`);
      }
    } catch (err) {
      console.error('[Canary] Scheduler error:', err.message);
    }
  };

  const timer = setInterval(runCycle, config.canaryIntervalMs);
  if (typeof timer.unref === 'function') timer.unref();
  return timer;
}
