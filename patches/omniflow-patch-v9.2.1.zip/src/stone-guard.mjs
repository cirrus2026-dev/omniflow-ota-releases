export const DEFAULT_STONE_ALIASES = [
  'แบล็คแฟนตาซีเอ็กโซติก', 'black fantasy exotic', 'คลาสสิกพาราดิโซ', 'classic paradiso',
  'นิวหิมาลายันบลู', 'new himalayan blue', 'นิวอิมพีเรียลเรด', 'new imperial red',
  'กาแล็คซี่พรีเมี่ยม', 'galaxy premium', 'ซิลเวอร์พาราดิโซ', 'silver paradiso',
  'เวอร์เดแลปโปเนีย', 'verde lapponia', 'โกลเด้นเอ็กโซติก', 'golden exotic',
  'เอเมอรัลด์เพิร์ล', 'emerald pearl', 'ไททาเนียมแบล็ค', 'titanium black',
  'คลาสสิคอลไวท์', 'classical white', 'ไททาเนียมโกลด์', 'titanium gold',
  'อิมพีเรียลโกลด์', 'imperial gold', 'โคโลเนียลไวท์', 'colonial white',
  'แบล็คพาราไดซ์', 'black paradise', 'ชมพูจูปารานา', 'pink juparana',
  'แอฟริกันแบล็ค', 'ดำอัฟริกา', 'ดำแอฟริกา', 'african black', 'black africa',
  'แคชเมียร์ไวท์', 'kashmir white', 'อาร์มานี่โกลด์', 'armani gold',
  'ไวท์กาแล็คซี่', 'white galaxy', 'แบล็คฟอเรสต์', 'black forest',
  'กรีนปิกัสโซ่', 'กรีนปิกัสโซ', 'green picasso', 'หิมาลายันบลู', 'himalayan blue',
  'เลมูเรียนบลู', 'lemurian blue', 'คาร์เมนบราวน์', 'carmen brown',
  'แบล็คคอสมิค', 'black cosmic', 'ออยสเตอร์บลู', 'oyster blue',
  'แอนทีคไวท์', 'antique white', 'แบชพาราดิโซ', 'bash paradiso',
  'เชอร์รี่บราวน์', 'cherry brown', 'เดเสิร์ตบราวน์', 'desert brown',
  'โกลเด้นแบล็ค', 'golden black', 'เบียนโค่แบล็ค', 'bianco black',
  'บอลติกบราวน์', 'baltic brown', 'บลูเพิร์ล #3', 'blue pearl #3',
  'บลูเพิร์ล #2', 'blue pearl #2', 'บลูเพิร์ล #1', 'blue pearl #1',
  'บลูเพิร์ล', 'blue pearl', 'เมทริกซ์ #2', 'matrix #2', 'เมทริกซ์', 'matrix',
  'ชมพูจีน 731', 'china pink 731', 'ชมพูจีน 735', 'china pink 735', 'ชมพูจีน',
  'ขาวจีน 601', 'china white 601', 'ขาวจีน 602', 'china white 602',
  'ขาวจีน 603', 'china white 603', 'ขาวจีน', 'เทาจีน 623', 'china grey 623', 'เทาจีน',
  'เขียวอิตาลี', 'italian green', 'ไอวอรี่ครีม', 'ivory cream',
  'วิสคอนไวท์', 'viscon white', 'สตรีมไวท์', 'stream white',
  'เวียดนามเรด', 'vietnam red', 'ริเวอร์ไวท์', 'river white',
  'ริเวอร์แบล็ค', 'river black', 'ไวท์ฟอเรสต์', 'white forest',
  'เมจิกแบล็ค', 'magic black', 'ดอนน่าเกรย์', 'donna grey',
  'ซีบราแบล็ค', 'zebra black', 'แบล็คเพิร์ล', 'black pearl',
  'ปราด้าโกลด์', 'prada gold', 'ริเวอร์โกลด์', 'river gold',
  'สตีลเกรย์', 'steel grey', 'ฟิวชั่นโกลด์', 'fusion gold',
  'มิสติกไฟร์', 'mystique fire', 'อาซูลบาเฮีย', 'azul bahia',
  'แคนยอนโกลด์', 'canyon gold', 'ไอคอนไวท์', 'icon white',
  'โอเชี่ยนแบล็ค', 'โอเชียนแบล็ค', 'ocean black', 'อลันทิไวท์', 'alenti white',
  'ไวท์คาราร่า', 'ขาวคาร์ราร่า', 'ขาวคาราร่า', 'white carrara', 'คาราร่า', 'คารารา', 'carrara',
  'ดำเกล็ดทอง', 'ดำเกร็ดทอง', 'black galaxy', 'วอลก้าบลู', 'volga blue',
  'อาซูลไวท์', 'azul white', 'ซิลค์บลู', 'silk blue', 'แองโกลาดำ', 'angola black',
  'แทนบราวน์', 'tan brown', 'ลาบราดอร์', 'labrador', 'แดงอินเดีย', 'indian red',
  'ดำอินเดีย', 'โมนาลิซา', 'monalisa', 'เมทัลลิก', 'metallic', 'อีคลิปส์', 'eclipse',
  'มัลติเรด', 'multi red', 'นิวพิงค์', 'new pink', 'แซนด์ดูน', 'sand dune',
  'บลูดูน', 'blue dune', 'แคทอาย', 'cat eye', 'ดำไทย', 'thai black',
  'ทรายล้างเทาดำ', 'ทรายล้างเหลืองทอง', 'ทรายล้างขาว', 'ทรายล้างแดง',
  'กรวดแม่น้ำ', 'ทรายล้าง', 'กรวดล้าง', 'หินแกรนิต', 'หินอ่อน'
];

const SHORT_NEUTRAL_RE =
  /^(?:ok|okay|k|kk|yes|no|yep|thank|thanks|thx|hi|hello|line|tel|cm|m|sqm|sq\.?m\.?|[0-9\s.,xX*×+\-/:()#]+)$/i;

function isNeutralOrCodeOnlyMessage(text = '') {
  const trimmed = String(text || '').slice(0, 4000).replace(/https?:\/\/\S+/gi, ' ').trim();
  if (!trimmed) return true;
  if (SHORT_NEUTRAL_RE.test(trimmed)) return true;

  // Strip known stone names, units, and numbers to see if genuine English conversation remains
  let remainder = trimmed.toLowerCase();
  for (const alias of DEFAULT_STONE_ALIASES) {
    if (/^[a-z0-9\s#.-]+$/i.test(alias)) {
      remainder = remainder.replaceAll(alias.toLowerCase(), ' ');
    }
  }
  remainder = remainder
    .replace(/\b(?:cm|mm|m|sqm|sq\.m|size|block|sku|ok|okay|yes|no|thanks|thank|you|slab)\b/gi, ' ')
    .replace(/[^a-z]/gi, ' ')
    .trim();

  const englishWords = remainder.split(/\s+/).filter(Boolean);
  return englishWords.length < 3;
}

export function buildLanguageInstruction(language = 'TH', botPersona = 'FEMALE_ADMIN') {
  if (language === 'CJK') {
    return '(LANGUAGE: ลูกค้าใช้ภาษาจีน/ญี่ปุ่น/เกาหลี ให้ตอบเป็นภาษาไทยอย่างสุภาพ และขอให้ลูกค้าพิมพ์ภาษาไทยหรืออังกฤษ ห้ามเดาภาษาอื่น)';
  }
  if (language === 'EN') {
    return '(LANGUAGE: Session language is locked to ENGLISH. Reply in English only. Translate stone units to sq.m., bag, and THB accurately.)';
  }
  if (botPersona === 'MALE_ADMIN') {
    return '(LANGUAGE: ตอบภาษาไทยเท่านั้น ใช้บุคลิกพนักงานผู้ชาย ลงท้ายด้วย "ครับ" ทุกประโยค ห้ามปน ค่ะ/คะ/นะคะ เด็ดขาด)';
  }
  return '(LANGUAGE: ตอบภาษาไทยเท่านั้น ใช้บุคลิกพนักงานผู้หญิง ลงท้ายด้วย "ค่ะ" หรือ "นะคะ" ทุกประโยค ห้ามปน ครับ เด็ดขาด)';
}

export function resolveSessionLanguageAndPersona(text = '', existingLock = null) {
  const source = String(text || '').slice(0, 4000).trim();
  const sourceWithoutUrls = source.replace(/https?:\/\/\S+/gi, ' ').trim();
  const hasThai = /[\u0E00-\u0E7F]/.test(sourceWithoutUrls);
  const hasCJK = /[\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]/.test(sourceWithoutUrls);
  const hasLatin = /[A-Za-z]/.test(sourceWithoutUrls);

  const isFemaleCustomer =
    /(ค่ะ|นะคะ|นะค่ะ|ไหมคะ|มั้ยคะ|เท่าไหร่คะ|เท่าไรคะ|หน่อยคะ|ด้วยคะ|หรอคะ|เหรอคะ|จ้า|จ๋า|ดิฉัน|(?:^|\s)หนู(?=\s|อยาก|ขอ|สนใจ|ต้องการ|จะ|ได้|มี|$))|((คะ|ค่า)\s*[?!~😊🙏]*$)/.test(
      source
    );
  const isMaleCustomer =
    /(ครับ|คราบ|ค้าบ|ครัช|นะคับ|ไหมคับ|มั้ยคับ|หน่อยคับ|สวัสดีคับ|ขอบคุณคับ|(?:^|\s)ผม(?=\s|อยาก|ขอ|สนใจ|ต้องการ|จะ|ได้|มี|$))|((คับ|ฮะ)\s*[?!~😊🙏]*$)/.test(
      source
    );

  // 1. Resolve Language (Sticky 60-minute Session Lock)
  let language = existingLock?.language || 'TH';
  if (hasThai) {
    language = 'TH';
  } else if (hasCJK) {
    language = 'CJK';
  } else if (hasLatin) {
    const neutral = isNeutralOrCodeOnlyMessage(source);
    if (!neutral) {
      // Genuine multi-word English sentence
      language = 'EN';
    } else if (!existingLock) {
      // First message is short/neutral (e.g. "ok" or "30x60") -> default to Thai for OmniFlow
      language = 'TH';
    }
  }

  // 2. Resolve Bot Persona (Opposite-Gender Lock: Male Customer -> FEMALE_ADMIN, Female Customer -> MALE_ADMIN)
  let botPersona = existingLock?.botPersona || 'FEMALE_ADMIN';
  let personaLocked = Boolean(existingLock?.personaLocked);

  if (isFemaleCustomer && !isMaleCustomer) {
    botPersona = 'MALE_ADMIN';
    personaLocked = true;
  } else if (isMaleCustomer && !isFemaleCustomer) {
    botPersona = 'FEMALE_ADMIN';
    personaLocked = true;
  }

  return {
    language,
    botPersona,
    personaLocked,
    instruction: buildLanguageInstruction(language, botPersona),
  };
}

export function detectPersonaInstruction(text = '', existingLock = null) {
  return resolveSessionLanguageAndPersona(text, existingLock).instruction;
}

const BAG_UNIT_PRODUCT_RE = /(ทรายล้าง|กรวดล้าง|กรวดแม่น้ำ|หินเกล็ด|หินกรวด|ปูนกาว|กาวซีเมนต์|ยาแนว)/i;
const WHITE_LABEL_PRODUCT_RE =
  /(ผ้าม่าน|วอลเปเปอร์|หญ้าเทียม|กระเบื้องยาง|ลามิเนต|กระจก|อลูมิเนียม|กันสาด|หลังคา|โซล่าเซลล์|พรม|บิ้วอิน|เฟอร์นิเจอร์|สติ๊กเกอร์|ป้ายไวนิล|\bspc\b|curtain|wallpaper|vinyl|laminate|carpet|awning|solar)/i;

function roundSqmValue(val) {
  if (!Number.isFinite(val) || val <= 0) return 0;
  return val < 0.01 ? +val.toFixed(4) : +val.toFixed(2);
}

function convertDimSideToMeters(rawVal, ownUnit, peerUnit, cmMode) {
  const isMm = (u) => /มม|มิล|mm/.test(u);
  const isCm = (u) => /ซม|เซน|cm/.test(u);
  const isM = (u) => /เมตร|ม\.?$|^m$/.test(u) && !isMm(u) && !isCm(u);

  let meters = rawVal;
  if (isMm(ownUnit)) {
    meters = rawVal / 1000;
  } else if (isCm(ownUnit)) {
    meters = rawVal / 100;
  } else if (isM(ownUnit)) {
    meters = rawVal;
  } else if (isMm(peerUnit)) {
    meters = rawVal >= 1 ? rawVal / 1000 : rawVal;
  } else if (isCm(peerUnit)) {
    meters = rawVal >= 1 ? rawVal / 100 : rawVal;
  } else if (isM(peerUnit)) {
    meters = rawVal;
  } else if (cmMode) {
    meters = rawVal / 100;
  }
  return +meters.toFixed(4);
}

export function normalizeStoneDimensionText(text = '') {
  let out = String(text || '').slice(0, 4000);
  const thaiDigits = { '๐': '0', '๑': '1', '๒': '2', '๓': '3', '๔': '4', '๕': '5', '๖': '6', '๗': '7', '๘': '8', '๙': '9' };
  out = out.replace(/[๐-๙]/g, (d) => thaiDigits[d] || d);
  const thWords = {
    หนึ่ง: '1', สอง: '2', สาม: '3', สี่: '4', ห้า: '5',
    หก: '6', เจ็ด: '7', แปด: '8', เก้า: '9', สิบ: '10',
  };
  out = out.replace(
    /(?<![ก-ฮะ-์a-zA-Z0-9])(หนึ่ง|สอง|สาม|สี่|ห้า|หก|เจ็ด|แปด|เก้า|สิบ)(?=\s*(?:คูณ|เมตร|ม\.|ซม|เซน|เซ็น|ตร\.?ม|ตารางเมตร|แผ่น|ชิ้น|ห้อง|ขั้น|บาน|จุด|ชุด|ตัว|ถุง|[xX*×]))/gi,
    (_, w) => thWords[w] || w
  );
  out = out.replace(/(\d+)\s*(?:เมตร|ม\.?)\s*ครึ่ง/gi, (_, n) => `${Number(n) + 0.5} เมตร`);
  out = out.replace(/(?<![\dก-ฮะ-์a-zA-Z])(?:เมตร|ม\.?)\s*ครึ่ง/gi, '1.5 เมตร');
  out = out.replace(/(\d+)\s*(?:ซม\.?|เซนติเมตร|เซ็นติเมตร|เซน|เซ็น)\s*ครึ่ง/gi, (_, n) => `${Number(n) + 0.5} ซม.`);
  out = out.replace(/\s*คูณ\s*/gi, ' x ');
  out = out.replace(/(?<=\d\s*)(?:เซนติเมตร|เซ็นติเมตร|เซนฯ?|เซ็นฯ?)(?![ก-ฮะ-์a-zA-Z])/gi, 'ซม.');
  return out;
}

export function sanitizeCustomerPromptText(text = '') {
  return String(text || '')
    .slice(0, 8000)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '')
    .replace(/\[/g, '［')
    .replace(/\]/g, '］')
    .replace(/</g, '＜')
    .replace(/>/g, '＞')
    .replace(/\(\s*(LANGUAGE\s*:)/gi, '（$1')
    .replace(/\(\s*(SYSTEM_DIRECTIVE|CALCULATION_GUARD|SYSTEM\s*:)/gi, '（$1');
}

export function inferCmMode(rawW, rawL, unit1 = '', unit2 = '') {
  const w = Number(rawW);
  const l = Number(rawL);
  if (!Number.isFinite(w) || !Number.isFinite(l) || w <= 0 || l <= 0) return false;
  const u1 = String(unit1 || '').trim().toLowerCase();
  const u2 = String(unit2 || '').trim().toLowerCase();
  if (u1 || u2) return false;
  const maxVal = Math.max(w, l);
  const minVal = Math.min(w, l);
  if (minVal >= 15 && maxVal >= 20) return true;
  if (maxVal >= 25 && minVal >= 10) return true;
  if (maxVal >= 60 && minVal >= 5) return true;
  return false;
}

export function parseCalculationRequest(
  text = '',
  rememberedStone = '',
  sessionLanguage = 'TH',
  botPersona = 'FEMALE_ADMIN',
  options = {}
) {
  const safeInput = String(text || '').slice(0, 4000).replace(/https?:\/\/\S+/gi, ' ');
  const normalized = normalizeStoneDimensionText(safeInput).replace(/,/g, '').trim();
  const dimRegex =
    /(\d+(?:\.\d+)?)\s*(มม\.?|มิลลิเมตร|mm(?![a-wyzA-WYZ])|ซม\.?|เซนติเมตร|cm(?![a-wyzA-WYZ])|เมตร|ม\.|ม(?![\u0E01-\u0E4E])|m(?![a-wyzA-WYZ]))?\s*[xX*×]\s*(\d+(?:\.\d+)?)\s*(มม\.?|มิลลิเมตร|mm(?![a-zA-Z])|ซม\.?|เซนติเมตร|cm(?![a-zA-Z])|เมตร|ม\.|ม(?![\u0E01-\u0E4E])|m(?![a-zA-Z]))?/i;
  const thaiDimRegex =
    /(?:กว้าง|หน้ากว้าง|ขนาด)\s*(\d+(?:\.\d+)?)\s*(มม\.?|มิลลิเมตร|mm(?![a-zA-Z])|ซม\.?|เซนติเมตร|cm(?![a-zA-Z])|เมตร|ม\.|ม(?![\u0E01-\u0E4E])|m(?![a-zA-Z]))?\s*(?:และ|กับ)?\s*(?:ยาว|สูง|ลึก)\s*(\d+(?:\.\d+)?)\s*(มม\.?|มิลลิเมตร|mm(?![a-zA-Z])|ซม\.?|เซนติเมตร|cm(?![a-zA-Z])|เมตร|ม\.|ม(?![\u0E01-\u0E4E])|m(?![a-zA-Z]))?/i;
  const areaRegex = /(\d+(?:\.\d+)?)\s*(ตร\.?ม\.?|ตารางเมตร|sqm|sq\.?\s*m(?![a-zA-Z]))/i;

  const rawDimMatch = normalized.match(dimRegex) || normalized.match(thaiDimRegex);
  const rawAreaMatch = normalized.match(areaRegex);

  let dimInfo = null;
  if (rawDimMatch) {
    const rawW = parseFloat(rawDimMatch[1]);
    const unit1 = (rawDimMatch[2] || '').toLowerCase();
    const rawL = parseFloat(rawDimMatch[3]);
    const unit2 = (rawDimMatch[4] || '').toLowerCase();
    if (Number.isFinite(rawW) && Number.isFinite(rawL) && rawW > 0 && rawL > 0) {
      const cmMode = inferCmMode(rawW, rawL, unit1, unit2);
      const wM = convertDimSideToMeters(rawW, unit1, unit2, cmMode);
      const lM = convertDimSideToMeters(rawL, unit2, unit1, cmMode);
      const singleSqm = +(wM * lM).toFixed(4);
      if (Number.isFinite(singleSqm) && singleSqm > 0) {
        dimInfo = { wM, lM, singleSqm };
      }
    }
  }

  let areaVal = null;
  if (rawAreaMatch) {
    const parsedArea = parseFloat(rawAreaMatch[1]);
    if (Number.isFinite(parsedArea) && parsedArea > 0) {
      areaVal = parsedArea;
    }
  }

  if (!dimInfo && areaVal === null) {
    return { isCalc: false };
  }

  const opts = options && typeof options === 'object' ? options : {};
  const isWhiteLabel =
    opts.whiteLabel === true ||
    opts.requireStone === false ||
    String(process.env.WHITE_LABEL_MODE || '').trim().toLowerCase() === 'true';
  const customAliases = Array.isArray(opts.productAliases) ? opts.productAliases : [];

  const lower = normalized.toLowerCase();
  const hasStoneInText =
    DEFAULT_STONE_ALIASES.some((alias) => lower.includes(alias.toLowerCase())) ||
    customAliases.some((alias) => alias && lower.includes(String(alias).toLowerCase())) ||
    /(หิน|แกรนิต|อ่อน|คาร์ราร่า|กาแล็คซี่|อัฟริกา|อินเดีย|จีน|เทา|ดำ|ขาว|แดง|เขียว|ชมพู|เหลือง)/.test(normalized) ||
    WHITE_LABEL_PRODUCT_RE.test(normalized);

  const effectiveStone = hasStoneInText ? null : (rememberedStone || null);

  if (!isWhiteLabel && !hasStoneInText && !effectiveStone) {
    const politeParticle = botPersona === 'MALE_ADMIN' ? 'ครับ' : 'ค่ะ';
    const replyText =
      sessionLanguage === 'EN'
        ? 'To calculate an accurate quotation, please let us know which stone model or color you are interested in (or send us a reference photo).'
        : `เพื่อคำนวณราคาได้อย่างแม่นยำ รบกวนแจ้งชื่อรุ่นหินหรือสีหินที่ต้องการ (เช่น หินแกรนิตดำอินเดีย, ขาวจีน หรือส่งรูปตัวอย่างหิน) เพิ่มเติมได้เลย${politeParticle}`;

    return {
      isCalc: true,
      hardStop: true,
      replyText,
    };
  }

  const multMatch = normalized.match(/(\d+(?:\.\d+)?)\s*(แผ่น|ชิ้น|ห้อง|ขั้น|บาน|จุด|ชุด|ตัว)/i);
  const multNum = multMatch ? parseFloat(multMatch[1]) : NaN;
  const pieces =
    Number.isFinite(multNum) && multNum >= 1 && multNum <= 100000 && Number.isInteger(multNum)
      ? multNum
      : 1;
  const pieceUnit = multMatch ? multMatch[2] : '';

  const hasExplicitPerUnitArea =
    /(?:แผ่น|ชิ้น|ห้อง|ขั้น|บาน|จุด|ชุด|ตัว)ละ\s*\d+(?:\.\d+)?\s*(?:ตร\.?ม\.?|ตารางเมตร|sqm|sq\.?\s*m)/i.test(normalized) ||
    /(?:ตร\.?ม\.?|ตารางเมตร|sqm|sq\.?\s*m)\s*ต่อ\s*(?:แผ่น|ชิ้น|ห้อง|ขั้น|บาน|จุด|ชุด|ตัว)/i.test(normalized);

  const isBagProduct = BAG_UNIT_PRODUCT_RE.test(`${normalized} ${String(effectiveStone || '')}`);
  const bagUnitWarning = isBagProduct
    ? ' หมายเหตุหน่วยสินค้า: สินค้ากลุ่มทรายล้าง/กรวดล้างจำหน่ายเป็น "ถุง" ไม่ใช่ ตร.ม. ห้ามนำตัวเลข ตร.ม. ไปคูณราคาต่อถุงโดยตรง ต้องแจ้งราคาต่อถุงและประเมินจำนวนถุงแยกตามความหนา'
    : '';

  let netSqm = 0;
  let grossSqm = 0;
  let calcSummary = '';

  if (areaVal !== null) {
    // Explicit total area takes precedence over tile dimensions (e.g., "60x60 ซม. ใช้ 10 ตร.ม.")
    // and never double-multiplies by pieces unless explicitly stated per unit (e.g., "2 ห้อง ห้องละ 10 ตร.ม.")
    const effectiveArea = hasExplicitPerUnitArea && pieces > 1 ? areaVal * pieces : areaVal;
    netSqm = roundSqmValue(effectiveArea);
    grossSqm = roundSqmValue(netSqm * 1.1);
    const refNotes = [];
    if (dimInfo) refNotes.push(`ขนาดแผ่นอ้างอิง ${dimInfo.wM} x ${dimInfo.lM} เมตร`);
    if (pieces > 1 && !hasExplicitPerUnitArea) refNotes.push(`จำนวน ${pieces} ${pieceUnit}`);
    const multText = hasExplicitPerUnitArea && pieces > 1 ? ` (${areaVal} ตร.ม. × ${pieces} ${pieceUnit})` : '';
    const refPrefix = refNotes.length > 0 ? `${refNotes.join(', ')}; ` : '';
    calcSummary = `[CALCULATION_GUARD: พื้นที่สุทธิ ${netSqm} ตร.ม.${multText} (${refPrefix}ข้อมูลประกอบกรณีเผื่อเศษติดตั้ง 10% = ${grossSqm} ตร.ม.) ยอดเงินเสนอราคาต้องใช้ผลลัพธ์จาก calc_quote เท่านั้น ห้ามนำพื้นที่เผื่อเศษไปคูณราคาซ้ำเอง${bagUnitWarning}]`;
  } else if (dimInfo) {
    netSqm = roundSqmValue(dimInfo.singleSqm * pieces);
    grossSqm = roundSqmValue(netSqm * 1.1);
    const multText = pieces > 1 ? ` × ${pieces} ${pieceUnit}` : '';
    calcSummary = `[CALCULATION_GUARD: ขนาด ${dimInfo.wM} x ${dimInfo.lM} เมตร${multText} = พื้นที่สุทธิ ${netSqm} ตร.ม. (ข้อมูลประกอบกรณีเผื่อเศษติดตั้ง 10% = ${grossSqm} ตร.ม.) ยอดเงินเสนอราคาต้องใช้ผลลัพธ์จาก calc_quote เท่านั้น ห้ามนำพื้นที่เผื่อเศษไปคูณราคาซ้ำเอง${bagUnitWarning}]`;
  }

  return {
    isCalc: true,
    hardStop: false,
    calcSummary,
    inferredStone: effectiveStone,
    netSqm,
    grossSqm,
    isBagProduct,
    unitMismatchAreaSqm: isBagProduct,
  };
}

export function cleanFlowiseReply(rawText = '', shopName = 'ทางร้าน', contactLine = 'ทีมงานแอดมิน') {
  if (!rawText || typeof rawText !== 'string') {
    return `ขออภัยค่ะ ระบบกำลังประมวลผลข้อมูลหิน กรุณาสอบถามอีกครั้งหรือติดต่อ LINE ${contactLine} ค่ะ`;
  }

  const trimmed = rawText.trim();
  if (
    !trimmed ||
    /Agent stopped due to max iterations/i.test(trimmed) ||
    /sourceMapping:/i.test(trimmed) ||
    /Error:\s*HTTP/i.test(trimmed)
  ) {
    return `ขออภัยค่ะ ขณะนี้มีผู้สอบถามเข้ามาจำนวนมาก รบกวนแจ้งชื่อรุ่นหินหรือขนาดที่ต้องการอีกครั้ง หรือติดต่อแอดมินที่ LINE ${contactLine} ได้เลยค่ะ`;
  }

  return trimmed
    .replace(/\[SYSTEM_DIRECTIVE[^\]]*\]/gi, '')
    .replace(/\(LANGUAGE:[^\)]*\)/gi, '')
    .replace(/\[CALCULATION_GUARD:[^\]]*\]/gi, '')
    .replace(/\[VISION_FALLBACK[^\]]*\]/gi, '')
    .replace(/<\/?customer_message>/gi, '')
    .trim();
}
