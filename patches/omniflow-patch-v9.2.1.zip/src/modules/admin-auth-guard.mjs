// gateway/src/modules/admin-auth-guard.mjs
// Zero-Dependency Direct Localhost/Docker-Bridge Guard, PIN Rate Limiter & Bounded Admin Session Store

import net from 'node:net';
import crypto from 'node:crypto';

const PROXY_HEADER_KEYS = [
  'x-forwarded-for',
  'forwarded',
  'cf-connecting-ip',
  'x-real-ip',
  'x-forwarded-host',
  'true-client-ip'
];

const DEFAULT_PIN_MAX_ATTEMPTS = 5;
const DEFAULT_PIN_WINDOW_MS = 15 * 60 * 1000;
const DEFAULT_PIN_LOCKOUT_MS = 15 * 60 * 1000;
const DEFAULT_MAX_TRACKED_KEYS = 500;

function normalizeHeadersLower(headers = {}) {
  const out = {};
  for (const [k, v] of Object.entries(headers || {})) {
    out[String(k).toLowerCase()] = Array.isArray(v) ? v.join(',').trim() : String(v ?? '').trim();
  }
  return out;
}

export function normalizeRemoteIp(rawIp) {
  let ip = String(rawIp || '').trim().split('%')[0].toLowerCase();
  if (ip.startsWith('::ffff:')) {
    const mapped = ip.slice(7);
    if (net.isIP(mapped) === 4) ip = mapped;
  }
  return ip;
}

export function isLoopbackIp(rawIp) {
  const ip = normalizeRemoteIp(rawIp);
  return ip === '127.0.0.1' || ip === '::1';
}

export function isDockerBridgeIp(rawIp) {
  const ip = normalizeRemoteIp(rawIp);
  if (net.isIP(ip) !== 4) return false;
  const parts = ip.split('.').map(Number);
  return parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31;
}

function extractSafeHostHostname(rawHost) {
  const host = String(rawHost || '').trim().toLowerCase();
  if (!host || /[\s/\\@?]/.test(host)) return '';
  if (host.startsWith('[')) {
    const closeIdx = host.indexOf(']');
    if (closeIdx === -1) return '';
    const v6 = host.slice(1, closeIdx);
    const rest = host.slice(closeIdx + 1);
    if (rest && !/^:\d{1,5}$/.test(rest)) return '';
    return v6;
  }
  const colonIdx = host.indexOf(':');
  if (colonIdx !== -1) {
    const portPart = host.slice(colonIdx + 1);
    if (!/^\d{1,5}$/.test(portPart)) return '';
    return host.slice(0, colonIdx);
  }
  return host;
}

export function isDirectLocalHostRequest(req, { allowDockerBridge = true } = {}) {
  if (!req || typeof req !== 'object') return false;
  const headers = normalizeHeadersLower(req.headers);

  // Reject immediately if any reverse-proxy / tunnel forwarding header is present
  for (const key of PROXY_HEADER_KEYS) {
    if (headers[key]) return false;
  }

  const rawRemote = req.socket?.remoteAddress || req.connection?.remoteAddress || '';
  if (!rawRemote) return false;
  const remoteIp = normalizeRemoteIp(rawRemote);

  // Only trust Loopback (127.0.0.1 / ::1) or RFC1918 Docker Bridge (172.16.0.0/12)
  // Explicitly blocks Public 172.* (e.g. 172.64.x.x), 192.168.*, and 10.*
  const isTrustedSocket = isLoopbackIp(remoteIp) || (allowDockerBridge && isDockerBridgeIp(remoteIp));
  if (!isTrustedSocket) return false;

  // Validate Host header when present to prevent DNS Rebinding / Host spoofing
  const hostHeader = headers.host || '';
  if (hostHeader) {
    const hostname = extractSafeHostHostname(hostHeader);
    if (!hostname) return false;
    const isAllowedHost =
      hostname === 'localhost' ||
      hostname === '127.0.0.1' ||
      hostname === '::1' ||
      (allowDockerBridge && isDockerBridgeIp(hostname));
    if (!isAllowedHost) return false;
  }

  return true;
}

export function getRateLimitClientKey(req) {
  const headers = normalizeHeadersLower(req?.headers);
  const remote = normalizeRemoteIp(req?.socket?.remoteAddress || req?.connection?.remoteAddress || 'unknown');
  const forwarded = (headers['cf-connecting-ip'] || headers['x-real-ip'] || headers['x-forwarded-for'] || '')
    .split(',')[0]
    .trim()
    .slice(0, 64);
  return forwarded ? `${remote}|${forwarded}` : remote;
}

export function createPinRateLimiter({
  maxAttempts = DEFAULT_PIN_MAX_ATTEMPTS,
  windowMs = DEFAULT_PIN_WINDOW_MS,
  lockoutMs = DEFAULT_PIN_LOCKOUT_MS,
  maxTrackedKeys = DEFAULT_MAX_TRACKED_KEYS
} = {}) {
  const attemptsMap = new Map();

  function pruneExpired(now) {
    for (const [key, entry] of attemptsMap.entries()) {
      const lockExpired = !entry.lockedUntil || entry.lockedUntil <= now;
      const windowExpired = now - entry.firstAttemptAt >= windowMs;
      if (lockExpired && windowExpired) attemptsMap.delete(key);
    }
  }

  function normalizeKey(clientKey) {
    return String(clientKey || 'global').trim().slice(0, 128) || 'global';
  }

  function checkPinRateLimit(clientKey, now = Date.now()) {
    const key = normalizeKey(clientKey);
    const entry = attemptsMap.get(key);
    if (!entry) {
      return { allowed: true, locked: false, attempts: 0, remainingAttempts: maxAttempts, retryAfterSec: 0, lockedUntil: 0 };
    }
    if (entry.lockedUntil > now) {
      return {
        allowed: false,
        locked: true,
        attempts: entry.count,
        remainingAttempts: 0,
        retryAfterSec: Math.max(1, Math.ceil((entry.lockedUntil - now) / 1000)),
        lockedUntil: entry.lockedUntil
      };
    }
    if (now - entry.firstAttemptAt >= windowMs || (entry.lockedUntil > 0 && entry.lockedUntil <= now)) {
      attemptsMap.delete(key);
      return { allowed: true, locked: false, attempts: 0, remainingAttempts: maxAttempts, retryAfterSec: 0, lockedUntil: 0 };
    }
    return {
      allowed: true,
      locked: false,
      attempts: entry.count,
      remainingAttempts: Math.max(0, maxAttempts - entry.count),
      retryAfterSec: 0,
      lockedUntil: 0
    };
  }

  function recordPinFailure(clientKey, now = Date.now()) {
    const key = normalizeKey(clientKey);
    pruneExpired(now);
    let entry = attemptsMap.get(key);
    if (!entry || now - entry.firstAttemptAt >= windowMs || (entry.lockedUntil > 0 && entry.lockedUntil <= now)) {
      if (!attemptsMap.has(key) && attemptsMap.size >= maxTrackedKeys) {
        const oldestKey = attemptsMap.keys().next().value;
        if (oldestKey !== undefined) attemptsMap.delete(oldestKey);
      }
      entry = { count: 0, firstAttemptAt: now, lockedUntil: 0 };
    }
    entry.count += 1;
    if (entry.count >= maxAttempts) {
      entry.lockedUntil = now + lockoutMs;
    }
    attemptsMap.set(key, entry);
    const locked = entry.lockedUntil > now;
    return {
      allowed: !locked,
      locked,
      attempts: entry.count,
      remainingAttempts: Math.max(0, maxAttempts - entry.count),
      retryAfterSec: locked ? Math.max(1, Math.ceil((entry.lockedUntil - now) / 1000)) : 0,
      lockedUntil: entry.lockedUntil
    };
  }

  function clearPinFailures(clientKey) {
    return attemptsMap.delete(normalizeKey(clientKey));
  }

  return {
    checkPinRateLimit,
    recordPinFailure,
    clearPinFailures,
    resetAll: () => attemptsMap.clear(),
    get size() {
      return attemptsMap.size;
    }
  };
}

const defaultPinLimiter = createPinRateLimiter();
export const checkPinRateLimit = defaultPinLimiter.checkPinRateLimit;
export const recordPinFailure = defaultPinLimiter.recordPinFailure;
export const clearPinFailures = defaultPinLimiter.clearPinFailures;

export function createAdminSessionStore({ maxSessions = 100, ttlMs = 12 * 3600 * 1000 } = {}) {
  const cap = Math.max(1, Number(maxSessions) || 100);
  const sessionTtl = Math.max(60_000, Number(ttlMs) || 12 * 3600 * 1000);
  const sessions = new Map();

  function prune(now = Date.now()) {
    let removed = 0;
    for (const [token, rec] of sessions.entries()) {
      if (!rec || rec.expiresAt <= now) {
        sessions.delete(token);
        removed += 1;
      }
    }
    return removed;
  }

  function create(meta = {}, now = Date.now()) {
    prune(now);
    while (sessions.size >= cap) {
      const oldestToken = sessions.keys().next().value;
      if (oldestToken === undefined) break;
      sessions.delete(oldestToken);
    }
    const token = crypto.randomBytes(32).toString('hex');
    const record = { token, createdAt: now, lastSeenAt: now, expiresAt: now + sessionTtl, meta: meta || {} };
    sessions.set(token, record);
    return { token, createdAt: record.createdAt, expiresAt: record.expiresAt };
  }

  function verify(token, { touch = false, now = Date.now() } = {}) {
    const key = String(token || '').trim();
    if (!key) return null;
    const rec = sessions.get(key);
    if (!rec) return null;
    if (rec.expiresAt <= now) {
      sessions.delete(key);
      return null;
    }
    if (touch) rec.lastSeenAt = now;
    return rec;
  }

  function isValid(token, now = Date.now()) {
    return verify(token, { now }) !== null;
  }

  function revoke(token) {
    return sessions.delete(String(token || '').trim());
  }

  function clear() {
    sessions.clear();
  }

  return {
    create,
    verify,
    isValid,
    revoke,
    clear,
    prune,
    get size() {
      return sessions.size;
    }
  };
}
