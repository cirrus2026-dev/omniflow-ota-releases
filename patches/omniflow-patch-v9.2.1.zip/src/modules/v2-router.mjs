// gateway/src/modules/v2-router.mjs
// V2 Plugin Router — keeps server.mjs frozen while new features register under /api/v2/*
//
// How to add a new feature:
//   1. Create `src/modules/v2/<feature>.mjs` exporting `export function register(registerV2Route) { ... }`.
//   2. Add one import line and append the module to the `FEATURES` array at the bottom of this file.
//   IMPORTANT: Feature modules MUST NOT import `v2-router.mjs` directly (circular import hits `routes` TDZ).

import { requireAdminJson } from './server-security-guard.mjs';
import { hasValidAdminSession } from './settings-vault.mjs';
import { checkPinRateLimit, getRateLimitClientKey } from './admin-auth-guard.mjs';
import * as v2DbFeature from './v2/v2-db.mjs';
import * as rbacRoutes from './v2/rbac.routes.mjs';
import * as saasRoutes from './v2/saas.routes.mjs';
import * as analyticsRoutes from './v2/analytics.routes.mjs';
import * as broadcastRoutes from './v2/broadcast.routes.mjs';
import * as marketingRoutes from './v2/marketing.routes.mjs';
import * as erpRoutes from './v2/erp/erp.routes.mjs';
import * as phase1aRoutes from './v2/phase1a.routes.mjs';
import * as flowRoutes from './v2/flow/flow.routes.mjs';
import { extractSessionToken, verifyPersistentSession } from './v2/auth-session.service.mjs';

const V2_PREFIX = '/api/v2/';
const VALID_AUTH_MODES = new Set(['admin', 'strict', 'public']);
const routes = [];

function normalizeV2Path(rawPath) {
  const trimmed = String(rawPath || '').trim();
  return trimmed.length > V2_PREFIX.length ? trimmed.replace(/\/+$/, '') : trimmed;
}

/**
 * Register a route under `/api/v2/*`. Rejects bad paths, non-function handlers, or duplicates.
 * `auth` defaults to `'admin'` (fail-closed: local direct or valid admin session; `'strict'` requires PIN session).
 */
export function registerV2Route({ method = 'GET', path, auth = 'admin', handler }) {
  const normalizedMethod = String(method || 'GET').trim().toUpperCase();
  const normalizedPath = normalizeV2Path(path);
  if (!normalizedPath.startsWith(V2_PREFIX) || normalizedPath === V2_PREFIX) {
    throw new Error(`Invalid v2 route path: "${normalizedPath}" (must start with ${V2_PREFIX})`);
  }
  if (!VALID_AUTH_MODES.has(auth)) {
    throw new Error(`Invalid v2 route auth mode "${auth}" for ${normalizedMethod} ${normalizedPath}`);
  }
  if (typeof handler !== 'function') {
    throw new Error(`Invalid v2 route handler for ${normalizedMethod} ${normalizedPath}`);
  }
  const duplicate = routes.some((r) => r.method === normalizedMethod && r.path === normalizedPath);
  if (duplicate) {
    throw new Error(`Duplicate v2 route: ${normalizedMethod} ${normalizedPath}`);
  }
  routes.push({ method: normalizedMethod, path: normalizedPath, auth, handler });
}

/**
 * List all registered `/api/v2/*` routes (method & path only).
 */
export function listV2Routes() {
  return routes.map(({ method, path }) => ({ method, path }));
}

function sendJson(res, status, obj, corsHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...corsHeaders,
  });
  res.end(JSON.stringify(obj));
}

function hasValidV2PersistentSession(req) {
  if (!extractSessionToken(req)) return false;
  try {
    const verified = verifyPersistentSession(req);
    if (!verified.ok) return false;
    req.v2Session = verified.session;
    if (!req.v2User) req.v2User = { id: verified.session.accountId, role: 'owner' };
    return true;
  } catch {
    return false;
  }
}

function enforceV2Auth(req, res, authMode, corsHeaders = {}) {
  if (authMode === 'public') return true;
  if (hasValidV2PersistentSession(req)) return true;
  if (authMode === 'strict') {
    if (hasValidAdminSession(req)) return true;
    const rl = checkPinRateLimit(getRateLimitClientKey(req));
    if (!rl.allowed) {
      sendJson(
        res,
        429,
        {
          ok: false,
          locked: true,
          retryAfterSec: rl.retryAfterSec,
          code: 'ADMIN_SESSION_REQUIRED',
          requirePin: true,
          error: `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${rl.retryAfterSec} วินาที`,
        },
        { 'Retry-After': String(rl.retryAfterSec), ...corsHeaders }
      );
      return false;
    }
    sendJson(
      res,
      401,
      {
        ok: false,
        code: 'ADMIN_SESSION_REQUIRED',
        requirePin: true,
        error: 'ต้องยืนยัน Admin PIN ก่อนใช้งานฟังก์ชันนี้',
      },
      corsHeaders
    );
    return false;
  }
  return requireAdminJson(req, res, corsHeaders);
}

/**
 * Handle `/api/v2/*` HTTP requests. Returns false if pathname is outside `/api/v2/`.
 */
export async function handleV2Route(req, res, ctx = {}) {
  const rawPathname = String(ctx.parsedUrl?.pathname || '');
  if (!rawPathname.startsWith(V2_PREFIX)) return false;
  const pathname = normalizeV2Path(rawPathname);

  const reqMethod = String(req.method || 'GET').toUpperCase();
  const matchingPathRoutes = routes.filter((r) => r.path === pathname);
  if (matchingPathRoutes.length === 0) {
    sendJson(res, 404, { ok: false, error: 'Not Found' }, ctx.corsHeaders);
    return true;
  }

  const exactRoute = matchingPathRoutes.find((r) => r.method === reqMethod);
  if (!exactRoute) {
    const allow = matchingPathRoutes.map((r) => r.method).join(', ');
    sendJson(res, 405, { ok: false, error: 'Method Not Allowed' }, { Allow: allow, ...ctx.corsHeaders });
    return true;
  }

  if (!enforceV2Auth(req, res, exactRoute.auth, ctx.corsHeaders)) {
    return true;
  }

  try {
    await exactRoute.handler(req, res, { ...ctx, sendJson });
  } catch (err) {
    console.error('[v2-router]', err);
    if (!res.headersSent) {
      const hasStatus = Number.isInteger(err?.statusCode) && err.statusCode >= 400 && err.statusCode < 600;
      const status = hasStatus ? err.statusCode : 500;
      const isClientError = status >= 400 && status < 500;
      const message = isClientError ? String(err.message || 'Request Error') : 'Internal Server Error';
      sendJson(res, status, { ok: false, error: message }, ctx.corsHeaders);
    }
  }
  return true;
}

registerV2Route({
  method: 'GET',
  path: '/api/v2/health',
  handler: (_req, res, { corsHeaders, sendJson: replyJson }) => {
    replyJson(res, 200, { ok: true, router: 'v2', routes: listV2Routes() }, corsHeaders);
  },
});

const FEATURES = [
  v2DbFeature,
  rbacRoutes,
  saasRoutes,
  analyticsRoutes,
  broadcastRoutes,
  marketingRoutes,
  erpRoutes,
  phase1aRoutes,
  flowRoutes,
];
for (const f of FEATURES) {
  f.register(registerV2Route);
}
