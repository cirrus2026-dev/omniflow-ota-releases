// gateway/src/modules/settings-vault.mjs
// Hardened Business Profile, Channel Keys Vault & AI Providers Store (Modular Core <= 300 lines)

import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as channelRegistry from './channels/channel-registry.mjs';
import { isDirectLocalHostRequest } from './admin-auth-guard.mjs';
import {
  registerTokenCacheClearer,
  clearCachedToken,
  applyRuntimeEnvHotReload
} from './settings-env-sync.mjs';
import {
  timingSafePinEquals,
  clearAllAdminSessions,
  getConfiguredAdminPin,
  verifyAdminPinAndIssueSession,
  parseAdminSessionToken,
  hasValidAdminSession,
  revokeAdminSession,
  hasValidAdminPinHeader,
  isLocalAdminRequest,
  registerSettingsRoutes
} from './settings-admin-session.mjs';
import { sendAdminLeadNotification } from './settings-lead-notifier.mjs';

export {
  isDirectLocalHostRequest,
  registerTokenCacheClearer,
  clearCachedToken,
  applyRuntimeEnvHotReload,
  getConfiguredAdminPin,
  verifyAdminPinAndIssueSession,
  parseAdminSessionToken,
  hasValidAdminSession,
  revokeAdminSession,
  hasValidAdminPinHeader,
  isLocalAdminRequest,
  registerSettingsRoutes,
  sendAdminLeadNotification
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEFAULT_CONFIG_PATH = path.resolve(__dirname, '../../data/gateway-config.json');
const FORBIDDEN_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
const MASK_BULLETS = '\u2022'.repeat(8);
const LEGACY_MOJIBAKE_BULLETS = '\u00e2\u20ac\u00a2'.repeat(8);

const SECRET_FIELDS = {
  line: ['channelSecret', 'channelAccessToken'],
  facebook: ['pageAccessToken', 'appSecret', 'verifyToken'],
  whatsapp: ['accessToken', 'appSecret', 'verifyToken'],
  tiktok: ['appSecret'],
  shopee: ['partnerKey'],
  lazada: ['appSecret', 'accessToken'],
  ...(channelRegistry.getRegistrySecretFieldsMap?.() || {})
};

const DEFAULT_CONFIG = {
  version: '10.5.0',
  updatedAt: null,
  business: {
    businessName: process.env.BUSINESS_NAME || 'Aether AI Commerce',
    businessTagline: process.env.BUSINESS_TAGLINE || 'Omnichannel AI Sales & Smart Operations',
    adminNotifyWebhookUrl: process.env.ADMIN_NOTIFY_WEBHOOK_URL || ''
  },
  publicBaseUrl: process.env.PUBLIC_BASE_URL || 'http://127.0.0.1:4003',
  channels: {
    line: {
      enabled: true,
      channelId: process.env.LINE_CHANNEL_ID || '',
      channelSecret: process.env.LINE_CHANNEL_SECRET || '',
      channelAccessToken: process.env.LINE_CHANNEL_ACCESS_TOKEN || ''
    },
    facebook: {
      enabled: true,
      pageAccessToken: process.env.FB_PAGE_ACCESS_TOKEN || '',
      appSecret: process.env.FB_APP_SECRET || '',
      verifyToken: process.env.FB_VERIFY_TOKEN || ''
    },
    whatsapp: {
      enabled: false,
      phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
      accessToken: process.env.WHATSAPP_ACCESS_TOKEN || '',
      appSecret: process.env.WHATSAPP_APP_SECRET || '',
      verifyToken: process.env.WHATSAPP_VERIFY_TOKEN || ''
    },
    tiktok: {
      enabled: false,
      appKey: process.env.TIKTOK_APP_KEY || '',
      appSecret: process.env.TIKTOK_APP_SECRET || '',
      shopId: process.env.TIKTOK_SHOP_ID || ''
    },
    shopee: {
      enabled: false,
      partnerId: process.env.SHOPEE_PARTNER_ID || '',
      partnerKey: process.env.SHOPEE_PARTNER_KEY || '',
      shopId: process.env.SHOPEE_SHOP_ID || ''
    },
    lazada: {
      enabled: false,
      appKey: process.env.LAZADA_APP_KEY || '',
      appSecret: process.env.LAZADA_APP_SECRET || '',
      accessToken: process.env.LAZADA_ACCESS_TOKEN || ''
    },
    ...(channelRegistry.getRegistryDefaultChannelsConfig?.() || {})
  },
  brain: {
    useBuiltInBrain: true,
    greetingMessage:
      'สวัสดีค่ะ ยินดีต้อนรับ สนใจสอบถามข้อมูลสินค้า ราคา หรือสั่งซื้อ แจ้งรายละเอียดเข้ามาได้เลยนะคะ',
    systemPrompt: '',
    providers: []
  },
  security: { adminPin: process.env.ADMIN_PIN || '123456' }
};

let runtimeConfig = structuredClone(DEFAULT_CONFIG);
let writeQueue = Promise.resolve();

export function maskSecret(value) {
  if (!value || typeof value !== 'string') return '';
  if (value.startsWith(MASK_BULLETS)) return value;
  if (value.startsWith(LEGACY_MOJIBAKE_BULLETS)) return `${MASK_BULLETS}${value.slice(LEGACY_MOJIBAKE_BULLETS.length).slice(-4)}`;
  if (value.length <= 4) return MASK_BULLETS;
  return `${MASK_BULLETS}${value.slice(-4)}`;
}

export function isMaskedPlaceholder(value) {
  return typeof value === 'string' && (value.startsWith(MASK_BULLETS) || value.startsWith(LEGACY_MOJIBAKE_BULLETS));
}

function deepMerge(target, source) {
  const output = { ...target };
  for (const key of Object.keys(source || {})) {
    if (FORBIDDEN_KEYS.has(key)) continue;
    if (
      source[key] && typeof source[key] === 'object' && !Array.isArray(source[key]) &&
      target?.[key] && typeof target[key] === 'object' && !Array.isArray(target[key])
    ) {
      output[key] = deepMerge(target[key], source[key]);
    } else if (source[key] !== undefined) {
      output[key] = source[key];
    }
  }
  return output;
}

function migrateLegacyBrainConfig(cfg) {
  if (!cfg.brain) cfg.brain = structuredClone(DEFAULT_CONFIG.brain);
  if (!Array.isArray(cfg.brain.providers)) cfg.brain.providers = [];
  if (cfg.brain.providers.length === 0) {
    const legacyGemini = cfg.brain.geminiApiKey || process.env.GEMINI_API_KEY || '';
    const legacyGroq = cfg.brain.groqApiKey || process.env.GROQ_API_KEY || '';
    const legacyPrimary = String(cfg.brain.primaryProvider || 'gemini').toLowerCase();
    if (legacyGemini) {
      cfg.brain.providers.push({
        id: 'prov_gemini_migrated', customName: 'Google Gemini (Primary)', type: 'gemini',
        baseUrl: 'https://generativelanguage.googleapis.com/v1beta', apiKey: legacyGemini,
        model: 'gemini-2.5-flash', isPrimary: legacyPrimary !== 'groq' || !legacyGroq, enabled: true
      });
    }
    if (legacyGroq) {
      cfg.brain.providers.push({
        id: 'prov_groq_migrated', customName: 'Groq Cloud Fast AI', type: 'openai_compat',
        baseUrl: 'https://api.groq.com/openai/v1', apiKey: legacyGroq,
        model: 'llama-3.3-70b-versatile', isPrimary: legacyPrimary === 'groq' || !legacyGemini, enabled: true
      });
    }
  }
  delete cfg.brain.geminiApiKey;
  delete cfg.brain.groqApiKey;
  delete cfg.brain.primaryProvider;
  return cfg;
}

export async function loadVaultConfig(configPath = DEFAULT_CONFIG_PATH) {
  try {
    await fs.mkdir(path.dirname(configPath), { recursive: true });
    const raw = await fs.readFile(configPath, 'utf8');
    runtimeConfig = migrateLegacyBrainConfig(deepMerge(structuredClone(DEFAULT_CONFIG), JSON.parse(raw)));
    applyRuntimeEnvHotReload(runtimeConfig);
  } catch (err) {
    if (err.code === 'ENOENT') {
      runtimeConfig = migrateLegacyBrainConfig(structuredClone(DEFAULT_CONFIG));
      runtimeConfig.updatedAt = new Date().toISOString();
      await saveVaultConfig(runtimeConfig, configPath);
    } else {
      console.error('[settings-vault] Failed to load config:', err.message);
    }
  }
  return runtimeConfig;
}

export async function saveVaultConfig(nextConfig, configPath = DEFAULT_CONFIG_PATH) {
  nextConfig.updatedAt = new Date().toISOString();
  runtimeConfig = nextConfig;
  const serialized = JSON.stringify(runtimeConfig, null, 2);
  const writeTask = async () => {
    await fs.mkdir(path.dirname(configPath), { recursive: true });
    const tmpPath = `${configPath}.${process.pid}.${Date.now()}.${crypto.randomBytes(3).toString('hex')}.tmp`;
    try {
      await fs.writeFile(tmpPath, serialized, 'utf8');
      await fs.rename(tmpPath, configPath);
    } catch (err) {
      await fs.unlink(tmpPath).catch(() => {});
      throw err;
    }
  };
  const pending = writeQueue.then(writeTask, writeTask);
  writeQueue = pending.catch(() => {});
  await pending;
  applyRuntimeEnvHotReload(runtimeConfig);
  await clearCachedToken();
  return runtimeConfig;
}

export function getRuntimeConfig() {
  return runtimeConfig;
}

export function getMaskedChannelsView() {
  const masked = structuredClone(runtimeConfig.channels || {});
  for (const [chId, fields] of Object.entries(SECRET_FIELDS)) {
    if (!masked[chId]) continue;
    for (const f of fields) {
      if (masked[chId][f]) masked[chId][f] = maskSecret(masked[chId][f]);
    }
  }
  const business = structuredClone(runtimeConfig.business || DEFAULT_CONFIG.business);
  if (business.adminNotifyWebhookUrl) business.adminNotifyWebhookUrl = maskSecret(business.adminNotifyWebhookUrl);
  return {
    business,
    publicBaseUrl: runtimeConfig.publicBaseUrl,
    updatedAt: runtimeConfig.updatedAt,
    security: { adminPin: maskSecret(getConfiguredAdminPin()) },
    channels: masked
  };
}

export async function updateChannelsSettings(incoming = {}, configPath = DEFAULT_CONFIG_PATH) {
  const next = structuredClone(runtimeConfig);
  let pinRotated = false;
  if (incoming.business && typeof incoming.business === 'object') {
    if (!next.business) next.business = {};
    if (typeof incoming.business.businessName === 'string') {
      next.business.businessName = incoming.business.businessName.trim() || 'Aether AI Commerce';
    }
    if (typeof incoming.business.businessTagline === 'string') {
      next.business.businessTagline = incoming.business.businessTagline.trim();
    }
    if (typeof incoming.business.adminNotifyWebhookUrl === 'string') {
      const hookUrl = incoming.business.adminNotifyWebhookUrl.trim();
      if (!isMaskedPlaceholder(hookUrl)) next.business.adminNotifyWebhookUrl = hookUrl;
    }
  }
  if (typeof incoming.publicBaseUrl === 'string' && incoming.publicBaseUrl.trim()) {
    next.publicBaseUrl = incoming.publicBaseUrl.trim().replace(/\/+$/, '');
  }
  if (incoming.security && typeof incoming.security === 'object') {
    if (!next.security) next.security = { adminPin: process.env.ADMIN_PIN || '123456' };
    const rawPin = String(incoming.security.adminPin || '').trim();
    if (rawPin && !isMaskedPlaceholder(rawPin)) {
      const currentPinInput = String(incoming.security.currentPin || '').trim();
      const configuredPin = getConfiguredAdminPin();
      if (!currentPinInput || !timingSafePinEquals(currentPinInput, configuredPin)) {
        throw Object.assign(new Error('กรุณายืนยันรหัส PIN ปัจจุบันให้ถูกต้องก่อนเปลี่ยนรหัส PIN ใหม่'), { statusCode: 403 });
      }
      if (rawPin !== configuredPin) {
        next.security.adminPin = rawPin;
        pinRotated = true;
      }
    }
  }
  const incomingChannels = incoming.channels || {};
  for (const [chId, chPayload] of Object.entries(incomingChannels)) {
    if (FORBIDDEN_KEYS.has(chId) || !chPayload || typeof chPayload !== 'object') continue;
    if (!next.channels[chId]) next.channels[chId] = {};
    const secretList = SECRET_FIELDS[chId] || [];
    for (const [k, v] of Object.entries(chPayload)) {
      if (FORBIDDEN_KEYS.has(k) || v === undefined || v === null) continue;
      if (k === 'enabled') { next.channels[chId].enabled = Boolean(v); continue; }
      const strVal = typeof v === 'string' ? v.trim() : String(v).trim();
      if (secretList.includes(k) && isMaskedPlaceholder(strVal)) continue;
      next.channels[chId][k] = strVal;
    }
  }
  await saveVaultConfig(next, configPath);
  if (pinRotated) clearAllAdminSessions();
  return getMaskedChannelsView();
}

export function getBrainProvidersMasked() {
  const brainView = structuredClone(runtimeConfig.brain || DEFAULT_CONFIG.brain);
  const providers = Array.isArray(brainView.providers) ? brainView.providers : [];
  brainView.providers = providers.map((p) => ({ ...p, apiKey: p.apiKey ? maskSecret(p.apiKey) : '' }));
  return { useBuiltInBrain: brainView.useBuiltInBrain !== false, brain: brainView };
}

export async function updateBrainProvidersSettings(incoming = {}, configPath = DEFAULT_CONFIG_PATH) {
  const next = structuredClone(runtimeConfig);
  if (!next.brain) next.brain = structuredClone(DEFAULT_CONFIG.brain);
  const existingById = new Map((Array.isArray(next.brain.providers) ? next.brain.providers : []).map((p) => [p.id, p]));
  if (typeof incoming.useBuiltInBrain === 'boolean') next.brain.useBuiltInBrain = incoming.useBuiltInBrain;
  if (typeof incoming.greetingMessage === 'string') next.brain.greetingMessage = incoming.greetingMessage;
  if (typeof incoming.systemPrompt === 'string') next.brain.systemPrompt = incoming.systemPrompt;
  if (Array.isArray(incoming.providers)) {
    let primaryFound = false;
    const sanitized = incoming.providers
      .map((item, idx) => {
        const id = String(item.id || `prov_${Date.now()}_${idx}`).trim();
        const prev = existingById.get(id);
        const type = ['openai_compat', 'gemini', 'local'].includes(item.type) ? item.type : 'openai_compat';
        const defaultBase = type === 'gemini' ? 'https://generativelanguage.googleapis.com/v1beta'
          : type === 'local' ? 'http://host.docker.internal:11434/v1' : 'https://api.groq.com/openai/v1';
        const normalizedBaseUrl = String(item.baseUrl || defaultBase).trim().replace(/\/+$/, '');
        const prevBaseUrl = String(prev?.baseUrl || '').trim().replace(/\/+$/, '');
        let apiKey = '';
        if (type !== 'local') {
          const submittedKey = String(item.apiKey || '').trim();
          apiKey = isMaskedPlaceholder(submittedKey)
            ? (prev && type === prev.type && normalizedBaseUrl === prevBaseUrl ? prev.apiKey || '' : '')
            : submittedKey;
        }
        return {
          id, customName: String(item.customName || `AI Provider #${idx + 1}`).trim(),
          type, baseUrl: normalizedBaseUrl, apiKey, model: String(item.model || '').trim(),
          isPrimary: Boolean(item.isPrimary), enabled: item.enabled !== false
        };
      })
      .filter((p) => p.model.length > 0 || p.customName.length > 0)
      .map((p) => (p.isPrimary && p.enabled && !primaryFound ? ((primaryFound = true), p) : { ...p, isPrimary: false }));
    if (!primaryFound && sanitized.length > 0) {
      const firstEnabledIdx = sanitized.findIndex((p) => p.enabled);
      if (firstEnabledIdx >= 0) sanitized[firstEnabledIdx].isPrimary = true;
    }
    next.brain.providers = sanitized;
  }
  await saveVaultConfig(next, configPath);
  return getBrainProvidersMasked();
}
