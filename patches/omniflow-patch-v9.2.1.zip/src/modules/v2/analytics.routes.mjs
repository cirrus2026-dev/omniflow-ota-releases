// gateway/src/modules/v2/analytics.routes.mjs
// Category 1: Deep Analytics, FRT, Cohort & Executive PDF Export Routes

import {
  getOverviewAnalytics,
  getAiResolutionStats,
  getFrtByChannel,
  getCohortMatrix,
  buildExecutiveSummaryPdfBuffer,
} from './analytics.service.mjs';

export function register(registerV2Route) {
  registerV2Route({
    method: 'GET',
    path: '/api/v2/analytics/overview',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson, stateStore }) => {
      sendJson(res, 200, { ok: true, ...getOverviewAnalytics({ stateStore }) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/analytics/ai-resolution',
    auth: 'admin',
    handler: (_req, res, { parsedUrl, corsHeaders, sendJson }) => {
      const from = parsedUrl.searchParams.get('from') || null;
      const to = parsedUrl.searchParams.get('to') || null;
      sendJson(res, 200, { ok: true, ...getAiResolutionStats({ from, to }) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/analytics/frt-by-channel',
    auth: 'admin',
    handler: (_req, res, { parsedUrl, corsHeaders, sendJson }) => {
      const from = parsedUrl.searchParams.get('from') || null;
      const to = parsedUrl.searchParams.get('to') || null;
      sendJson(res, 200, { ok: true, channels: getFrtByChannel({ from, to }) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/analytics/cohorts',
    auth: 'admin',
    handler: (_req, res, { parsedUrl, corsHeaders, sendJson }) => {
      const months = Number(parsedUrl.searchParams.get('months') || 6);
      sendJson(res, 200, { ok: true, cohorts: getCohortMatrix({ months }) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/analytics/export-pdf',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, stateStore }) => {
      const pdfBuf = buildExecutiveSummaryPdfBuffer({
        overview: getOverviewAnalytics({ stateStore }),
        aiStats: getAiResolutionStats(),
        frt: getFrtByChannel(),
      });
      res.writeHead(200, {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'attachment; filename="omniflow-executive-report.pdf"',
        'Content-Length': String(pdfBuf.length),
        'Cache-Control': 'no-store',
        ...corsHeaders,
      });
      res.end(pdfBuf);
    },
  });
}
