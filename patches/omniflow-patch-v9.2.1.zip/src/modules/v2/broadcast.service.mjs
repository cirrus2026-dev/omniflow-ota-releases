// gateway/src/modules/v2/broadcast.service.mjs
// Category 3: Kanban Segment Broadcast, Smart Follow-up Drip & Rate-Limit Safe Queue

import { getV2Db, withV2Transaction } from './v2-db.mjs';
import { getDynamicChannelsList, makeHttpError, newId } from './v2-http.mjs';

const VALID_STAGES = new Set(['LEAD', 'QUOTED', 'DEPOSIT_PAID', 'WON', 'LOST']);

export function listCampaigns() {
  return getV2Db().prepare('SELECT * FROM v2_campaigns ORDER BY created_at DESC LIMIT 50').all();
}

export function createCampaign({ name, type = 'broadcast', targetStages = ['LEAD'], channels = ['line'], messageText, createdBy = null }) {
  const cleanName = String(name || '').trim();
  const cleanMsg = String(messageText || '').trim();
  if (!cleanName || !cleanMsg) throw makeHttpError(400, 'กรุณาระบุชื่อแคมเปญและข้อความ');
  if (!['broadcast', 'drip_quote'].includes(type)) throw makeHttpError(400, 'ประเภทแคมเปญไม่ถูกต้อง');

  const stages = (Array.isArray(targetStages) ? targetStages : []).filter((s) => VALID_STAGES.has(s));
  const allowedChannelIds = new Set(getDynamicChannelsList().map((c) => c.id));
  const selectedChannels = (Array.isArray(channels) ? channels : []).filter((c) => allowedChannelIds.has(c) || c === 'line' || c === 'facebook');
  if (!stages.length || !selectedChannels.length) {
    throw makeHttpError(400, 'กรุณาเลือก Kanban Stage และช่องทางอย่างน้อย 1 รายการ');
  }

  const id = newId('CMP');
  getV2Db()
    .prepare(
      `INSERT INTO v2_campaigns (id, name, type, target_stages_json, channels_json, message_payload_json, status, created_by)
       VALUES (?, ?, ?, ?, ?, ?, 'draft', ?)`
    )
    .run(id, cleanName, type, JSON.stringify(stages), JSON.stringify(selectedChannels), JSON.stringify({ text: cleanMsg }), createdBy);

  return getV2Db().prepare('SELECT * FROM v2_campaigns WHERE id = ?').get(id);
}

export function syncConsentFromStateStore(stateStore = null) {
  const getList = stateStore?.getConversationsList || stateStore?.listConversations;
  if (typeof getList !== 'function') return;
  const convs = getList.call(stateStore) || [];
  if (!convs.length) return;
  const db = getV2Db();
  const stageMap = { lead: 'LEAD', quoted: 'QUOTED', deposit_paid: 'DEPOSIT_PAID', completed: 'WON', lost: 'LOST' };
  const upsert = db.prepare(
    `INSERT INTO v2_customer_consent (customer_id, channel, kanban_stage, last_inbound_at, opt_out)
     VALUES (?, ?, ?, ?, 0)
     ON CONFLICT(customer_id, channel) DO UPDATE SET
       kanban_stage = excluded.kanban_stage,
       last_inbound_at = COALESCE(excluded.last_inbound_at, v2_customer_consent.last_inbound_at)`
  );
  for (const c of convs) {
    const cid = String(c.userKey || c.userId || '').trim();
    if (!cid) continue;
    const ch = String(c.platform || c.channel || 'line').trim().toLowerCase();
    const st = stageMap[String(c.statusTag || 'lead').toLowerCase()] || 'LEAD';
    const ts = c.updatedAt ? new Date(c.updatedAt).toISOString() : null;
    upsert.run(cid, ch, st, ts);
  }
}

export function previewPolicyAudience({ targetStages = ['LEAD', 'QUOTED'], channels = ['line', 'facebook'], stateStore = null } = {}) {
  if (!Array.isArray(targetStages) || !Array.isArray(channels)) {
    throw makeHttpError(400, 'targetStages และ channels ต้องเป็น Array');
  }
  syncConsentFromStateStore(stateStore);
  const db = getV2Db();
  const rows = db.prepare('SELECT customer_id, channel, kanban_stage, last_inbound_at, opt_out FROM v2_customer_consent').all();
  const stageSet = new Set(targetStages);
  const chanSet = new Set(channels);
  const cutoff24h = Date.now() - 86400000;

  let totalMatched = 0;
  let skippedOptOut = 0;
  let skipped24hWindow = 0;
  const eligible = [];

  for (const r of rows) {
    if (!stageSet.has(r.kanban_stage) || !chanSet.has(r.channel)) continue;
    totalMatched += 1;
    if (Number(r.opt_out) === 1) {
      skippedOptOut += 1;
      continue;
    }
    if (r.channel === 'facebook') {
      const lastInboundMs = Date.parse(r.last_inbound_at || '');
      if (!Number.isFinite(lastInboundMs) || lastInboundMs < cutoff24h) {
        skipped24hWindow += 1;
        continue;
      }
    }
    eligible.push(r);
  }

  return { totalMatched, skippedOptOut, skipped24hWindow, eligibleCount: eligible.length, eligible };
}

export function enqueueCampaignBroadcast({ campaignId, stateStore = null } = {}) {
  if (!campaignId) throw makeHttpError(400, 'ต้องระบุ campaignId');
  return withV2Transaction((db) => {
    const camp = db.prepare('SELECT * FROM v2_campaigns WHERE id = ?').get(campaignId);
    if (!camp) throw makeHttpError(404, 'ไม่พบแคมเปญ');
    if (camp.status === 'running' || camp.status === 'completed') {
      throw makeHttpError(409, 'แคมเปญนี้ถูกส่งเข้าคิวแล้ว');
    }

    const stages = JSON.parse(camp.target_stages_json || '[]');
    const channels = JSON.parse(camp.channels_json || '[]');
    const preview = previewPolicyAudience({ targetStages: stages, channels, stateStore });

    const nowIso = new Date().toISOString();
    const insertQ = db.prepare(
      `INSERT INTO v2_outbound_queue (id, source_type, source_id, customer_id, channel, payload_json, status, scheduled_for)
       VALUES (?, 'broadcast', ?, ?, ?, ?, 'queued', ?)`
    );
    for (const target of preview.eligible) {
      insertQ.run(newId('QUE'), camp.id, target.customer_id, target.channel, camp.message_payload_json, nowIso);
    }

    db.prepare("UPDATE v2_campaigns SET status = 'running' WHERE id = ?").run(camp.id);
    return { campaignId: camp.id, queuedCount: preview.eligible.length, skippedOptOut: preview.skippedOptOut, skipped24hWindow: preview.skipped24hWindow };
  });
}

export function listDripSteps() {
  return getV2Db().prepare('SELECT * FROM v2_drip_steps ORDER BY step_order ASC').all();
}

export function upsertDripStep({ id = null, stepOrder, delayMinutes, messageTemplate, isActive = true }) {
  const orderNum = Number(stepOrder);
  const delayNum = Number(delayMinutes);
  const msg = String(messageTemplate || '').trim();
  if (!Number.isFinite(orderNum) || !Number.isFinite(delayNum) || delayNum < 1 || !msg) {
    throw makeHttpError(400, 'ข้อมูล Drip Step ไม่ถูกต้อง');
  }
  const db = getV2Db();
  const stepId = id || newId('DRPS');
  db.prepare(
    `INSERT INTO v2_drip_steps (id, step_order, delay_minutes, message_template, is_active)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(id) DO UPDATE SET
       step_order = excluded.step_order,
       delay_minutes = excluded.delay_minutes,
       message_template = excluded.message_template,
       is_active = excluded.is_active`
  ).run(stepId, orderNum, delayNum, msg, isActive ? 1 : 0);
  return db.prepare('SELECT * FROM v2_drip_steps WHERE id = ?').get(stepId);
}

export function getQueueStats() {
  const rows = getV2Db()
    .prepare('SELECT status, COUNT(*) AS cnt FROM v2_outbound_queue GROUP BY status')
    .all();
  const counts = { queued: 0, processing: 0, sent: 0, failed: 0, skipped_policy: 0, cancelled_paid: 0 };
  for (const r of rows) {
    counts[r.status] = Number(r.cnt || 0);
  }
  return { counts, availableChannels: getDynamicChannelsList() };
}
