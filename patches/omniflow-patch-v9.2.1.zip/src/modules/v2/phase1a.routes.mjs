// gateway/src/modules/v2/phase1a.routes.mjs
// OmniFlow Enterprise v2 — Phase 1A Auth Bootstrap, Persistent Login & Settings Suite Routes
// IMPORTANT: Must NOT import v2-router.mjs directly (registered via FEATURES array).

import { getV2Db } from './v2-db.mjs';
import { makeHttpError, readJsonBody } from './v2-http.mjs';
import { hasValidAdminSession } from '../settings-vault.mjs';
import { assertAuthAttemptAllowed, clearAuthFailures, recordAuthFailure } from './auth-rate-limit.mjs';
import {
  getBootstrapStatus,
  loginWithPassword,
  logoutPersistentSession,
  verifyPersistentSession,
} from './auth-session.service.mjs';
import {
  changeAccountPassword,
  generateWindowsStartupScript,
  getDiagnosticsReport,
  getWorkspaceSettingsSuite,
  updateWorkspaceSettingsSuite,
} from './settings-suite.service.mjs';

function getUrl(req, ctx) {
  return ctx?.parsedUrl instanceof URL ? ctx.parsedUrl : new URL(req?.url || '/', 'http://127.0.0.1');
}

function getActor(req) {
  const verified = verifyPersistentSession(req);
  const actorId = String(
    verified.session?.accountId || req?.v2User?.id || req?.adminUser?.id || 'owner_pin'
  ).trim();
  const actorRole = String(req?.v2User?.role || req?.adminUser?.role || 'owner').trim().toLowerCase();
  const rawFwd = String(req?.headers?.['x-forwarded-for'] || '').split(',')[0].trim();
  const ip = rawFwd || String(req?.socket?.remoteAddress || '');
  return { actorId, actorRole, ip, session: verified.session };
}

function resolveTargetAccountId(body, actor) {
  const explicit = String(body?.accountId || '').trim();
  if (explicit) return explicit;
  if (actor.session?.accountId) return actor.session.accountId;
  const db = getV2Db();
  const latest = db.prepare('SELECT id FROM v2_saas_accounts ORDER BY created_at DESC LIMIT 1').get();
  if (!latest?.id) throw makeHttpError(404, 'ไม่พบบัญชีผู้ใช้ในระบบ');
  return latest.id;
}

export function register(registerV2Route) {
  registerV2Route({
    method: 'GET',
    path: '/api/v2/auth/bootstrap-status',
    auth: 'public',
    handler: (req, res, ctx) => {
      let trustedAdmin = false;
      try {
        trustedAdmin = hasValidAdminSession(req);
      } catch {
        trustedAdmin = false;
      }
      const status = getBootstrapStatus(req, undefined, { trustedAdmin });
      ctx.sendJson(res, 200, { ok: true, ...status }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/auth/login',
    auth: 'public',
    handler: async (req, res, ctx) => {
      assertAuthAttemptAllowed(req);
      const body = await readJsonBody(req);
      let result;
      try {
        result = loginWithPassword({
          email: body.email,
          password: body.password,
          deviceLabel: body.deviceLabel,
          req,
        });
      } catch (err) {
        if (err?.statusCode === 401) recordAuthFailure(req);
        if (err?.code === 'OTP_REQUIRED') {
          ctx.sendJson(
            res,
            409,
            { ok: false, code: 'OTP_REQUIRED', accountId: err.accountId, error: err.message },
            ctx.corsHeaders
          );
          return;
        }
        throw err;
      }
      clearAuthFailures(req);
      const { setCookieHeader, ...publicPayload } = result;
      ctx.sendJson(
        res,
        200,
        { ok: true, ...publicPayload },
        { 'Set-Cookie': setCookieHeader, ...(ctx.corsHeaders || {}) }
      );
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/auth/logout',
    auth: 'public',
    handler: (req, res, ctx) => {
      const result = logoutPersistentSession(req);
      const { clearCookieHeader, ...publicPayload } = result;
      ctx.sendJson(
        res,
        200,
        { ok: true, ...publicPayload },
        { 'Set-Cookie': clearCookieHeader, ...(ctx.corsHeaders || {}) }
      );
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/auth/change-password',
    auth: 'admin',
    handler: async (req, res, ctx) => {
      const actor = getActor(req);
      const body = await readJsonBody(req);
      const accountId = resolveTargetAccountId(body, actor);
      const result = changeAccountPassword({
        accountId,
        currentPassword: body.currentPassword,
        newPassword: body.newPassword,
        actor,
      });
      ctx.sendJson(res, 200, { ok: true, ...result }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/settings-suite',
    auth: 'admin',
    handler: (req, res, ctx) => {
      const wsId = getUrl(req, ctx).searchParams.get('workspaceId') || verifyPersistentSession(req).session?.workspaceId || null;
      const settings = getWorkspaceSettingsSuite(wsId);
      ctx.sendJson(res, 200, { ok: true, settings }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'PUT',
    path: '/api/v2/settings-suite',
    auth: 'admin',
    handler: async (req, res, ctx) => {
      const actor = getActor(req);
      const body = await readJsonBody(req);
      const wsId = body.workspaceId || actor.session?.workspaceId || null;
      const settings = updateWorkspaceSettingsSuite(wsId, body, actor);
      ctx.sendJson(res, 200, { ok: true, settings }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/settings-suite/startup-script',
    auth: 'admin',
    handler: (req, res, ctx) => {
      const q = getUrl(req, ctx).searchParams;
      const wsId = q.get('workspaceId') || verifyPersistentSession(req).session?.workspaceId || null;
      const saved = getWorkspaceSettingsSuite(wsId);
      const script = generateWindowsStartupScript({
        port: q.get('port') || saved.gatewayPort,
        appUrl: q.get('appUrl') || '',
      });
      res.writeHead(200, {
        'Content-Type': script.contentType,
        'Content-Disposition': `attachment; filename="${script.filename}"`,
        'Cache-Control': 'no-store',
        ...(ctx.corsHeaders || {}),
      });
      res.end(script.content);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/settings-suite/diagnostics',
    auth: 'admin',
    handler: (_req, res, ctx) => {
      const diagnostics = getDiagnosticsReport();
      ctx.sendJson(res, 200, { ok: true, diagnostics }, ctx.corsHeaders);
    },
  });
}
