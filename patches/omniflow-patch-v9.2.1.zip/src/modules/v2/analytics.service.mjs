// gateway/src/modules/v2/analytics.service.mjs
// Category 1: Deep Analytics, FRT by Dynamic Channel, Cohorts & Pure Node PDF Export

import { getV2Db } from './v2-db.mjs';

function buildMonthLabels(count = 12) {
  const labels = [];
  const now = new Date();
  for (let i = count - 1; i >= 0; i -= 1) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1));
    labels.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`);
  }
  return labels;
}

function normalizeToBound(to) {
  const s = String(to || '').trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? `${s}T23:59:59Z` : s;
}

function getLiveConversations(stateStore) {
  const getList = stateStore?.getConversationsList || stateStore?.listConversations;
  return typeof getList === 'function' ? getList.call(stateStore) || [] : [];
}

export function syncFactFromStateStore(stateStore = null) {
  const convs = getLiveConversations(stateStore);
  if (!convs.length) return convs;
  const db = getV2Db();
  const insert = db.prepare(
    `INSERT OR IGNORE INTO v2_chat_sessions_fact
     (session_id, customer_id, channel, first_inbound_at, frt_seconds, human_takeover, is_converted, order_value_satang, cohort_month)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );
  for (const c of convs) {
    const cid = String(c.userKey || c.userId || '').trim();
    if (!cid) continue;
    const ch = String(c.platform || c.channel || 'line').trim().toLowerCase();
    const tsIso = c.updatedAt ? new Date(c.updatedAt).toISOString() : new Date().toISOString();
    const ym = tsIso.slice(0, 7);
    const isConv = ['deposit_paid', 'completed'].includes(String(c.statusTag || '').toLowerCase()) ? 1 : 0;
    insert.run(`live_${cid}`, cid, ch, tsIso, 10, c.isTakeover ? 1 : 0, isConv, 0, ym);
  }
  return convs;
}

export function getOverviewAnalytics({ stateStore = null } = {}) {
  const liveConvs = syncFactFromStateStore(stateStore);
  const db = getV2Db();
  const months = buildMonthLabels(12);
  const rows = db
    .prepare(
      `SELECT substr(first_inbound_at, 1, 7) AS ym,
              COUNT(*) AS chats,
              SUM(CASE WHEN is_converted = 1 THEN order_value_satang ELSE 0 END) AS revenue_satang
       FROM v2_chat_sessions_fact
       GROUP BY ym`
    )
    .all();

  const rowMap = new Map(rows.map((r) => [r.ym, r]));
  const monthlySeries = months.map((ym) => {
    const r = rowMap.get(ym);
    return {
      month: ym,
      chats: Number(r?.chats || 0),
      revenueBaht: Math.round(Number(r?.revenue_satang || 0) / 100),
    };
  });

  const dailyRows = db
    .prepare(
      `SELECT substr(first_inbound_at, 1, 10) AS day, channel, COUNT(*) AS chats
       FROM v2_chat_sessions_fact
       WHERE first_inbound_at >= date('now', '-7 days')
       GROUP BY day, channel
       ORDER BY day ASC`
    )
    .all();

  const kanbanCounts = { lead: 0, quoted: 0, deposit_paid: 0, completed: 0 };
  for (const c of liveConvs) {
    const tag = String(c.statusTag || 'lead').toLowerCase();
    if (Object.hasOwn(kanbanCounts, tag)) kanbanCounts[tag] += 1;
    else kanbanCounts.lead += 1;
  }

  return { monthlySeries, daily7d: dailyRows, liveConversationCount: liveConvs.length, kanbanCounts };
}

export function getAiResolutionStats({ from = null, to = null } = {}) {
  const db = getV2Db();
  const where = [];
  const params = [];
  if (from) { where.push('first_inbound_at >= ?'); params.push(from); }
  if (to) { where.push('first_inbound_at <= ?'); params.push(normalizeToBound(to)); }
  const sqlWhere = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const row = db
    .prepare(
      `SELECT COUNT(*) AS total_sessions,
              SUM(CASE WHEN is_converted = 1 THEN 1 ELSE 0 END) AS total_converted,
              SUM(CASE WHEN human_takeover = 0 AND is_converted = 1 THEN 1 ELSE 0 END) AS ai_converted,
              SUM(CASE WHEN is_converted = 1 THEN order_value_satang ELSE 0 END) AS total_revenue_satang
       FROM v2_chat_sessions_fact ${sqlWhere}`
    )
    .get(...params);

  const totalConverted = Number(row?.total_converted || 0);
  const aiConverted = Number(row?.ai_converted || 0);
  const aiResolutionPct = totalConverted > 0 ? Math.round((aiConverted / totalConverted) * 1000) / 10 : 0;

  return {
    totalSessions: Number(row?.total_sessions || 0),
    totalConverted,
    aiConverted,
    aiResolutionPct,
    totalRevenueBaht: Math.round(Number(row?.total_revenue_satang || 0) / 100),
  };
}

function percentile(sortedNums, p) {
  if (!sortedNums.length) return 0;
  const idx = Math.min(sortedNums.length - 1, Math.max(0, Math.ceil((p / 100) * sortedNums.length) - 1));
  return sortedNums[idx];
}

export function getFrtByChannel({ from = null, to = null } = {}) {
  const db = getV2Db();
  const where = ['frt_seconds IS NOT NULL'];
  const params = [];
  if (from) { where.push('first_inbound_at >= ?'); params.push(from); }
  if (to) { where.push('first_inbound_at <= ?'); params.push(normalizeToBound(to)); }

  const rows = db
    .prepare(`SELECT channel, frt_seconds FROM v2_chat_sessions_fact WHERE ${where.join(' AND ')} ORDER BY frt_seconds ASC`)
    .all(...params);

  const byChannel = new Map();
  for (const r of rows) {
    if (!byChannel.has(r.channel)) byChannel.set(r.channel, []);
    byChannel.get(r.channel).push(Number(r.frt_seconds));
  }

  return Array.from(byChannel.entries()).map(([channel, vals]) => {
    const sum = vals.reduce((a, b) => a + b, 0);
    return {
      channel,
      sampleCount: vals.length,
      avgSeconds: Math.round(sum / vals.length),
      p50Seconds: percentile(vals, 50),
      p90Seconds: percentile(vals, 90),
    };
  });
}

export function getCohortMatrix({ months = 6 } = {}) {
  const db = getV2Db();
  return db
    .prepare(
      `SELECT cohort_month,
              COUNT(DISTINCT customer_id) AS new_customers,
              SUM(CASE WHEN is_converted = 1 THEN 1 ELSE 0 END) AS converted_orders,
              ROUND(SUM(order_value_satang) / 100.0) AS total_revenue_baht
       FROM v2_chat_sessions_fact
       GROUP BY cohort_month
       ORDER BY cohort_month DESC
       LIMIT ?`
    )
    .all(Math.max(1, Math.min(24, Number(months) || 6)));
}

export function buildExecutiveSummaryPdfBuffer(summary) {
  const lines = [
    'OmniFlow Enterprise v2 - Executive Analytics Report',
    `Generated: ${new Date().toISOString()}`,
    `Total Sessions: ${summary.aiStats.totalSessions}`,
    `AI Auto-Resolution Rate: ${summary.aiStats.aiResolutionPct}%`,
    `Total Converted Revenue: THB ${summary.aiStats.totalRevenueBaht}`,
    `Active Live Conversations: ${summary.overview.liveConversationCount}`,
    `Channels Tracked: ${summary.frt.map((c) => `${c.channel}=${c.avgSeconds}s`).join(', ') || 'none'}`,
  ];
  const escaped = lines.map((l) => String(l).replace(/[\r\n]+/g, ' ').replace(/[()\\]/g, '\\$&'));
  const streamBody = ['BT', '/F1 12 Tf', '50 760 Td', '18 TL', ...escaped.map((t) => `(${t}) Tj T*`), 'ET'].join('\n');

  const objects = [
    '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n',
    '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n',
    '3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj\n',
    `4 0 obj << /Length ${Buffer.byteLength(streamBody, 'utf8')} >> stream\n${streamBody}\nendstream\nendobj\n`,
    '5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n',
  ];

  let pdf = '%PDF-1.4\n';
  const offsets = [0];
  for (const obj of objects) {
    offsets.push(Buffer.byteLength(pdf, 'utf8'));
    pdf += obj;
  }
  const xrefPos = Buffer.byteLength(pdf, 'utf8');
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i += 1) {
    pdf += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
  }
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`;
  return Buffer.from(pdf, 'utf8');
}
