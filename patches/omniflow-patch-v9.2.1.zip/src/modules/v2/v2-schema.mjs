// gateway/src/modules/v2/v2-schema.mjs
// OmniFlow Enterprise v2 — SQLite Schema DDL (16 Tables + 8 Indexes across Categories 1-5)

export const V2_EXPECTED_TABLES = Object.freeze([
  'v2_chat_sessions_fact',
  'v2_users',
  'v2_chat_assignments',
  'v2_shift_handovers',
  'v2_customer_consent',
  'v2_campaigns',
  'v2_drip_steps',
  'v2_outbound_queue',
  'v2_saas_accounts',
  'v2_workspaces',
  'v2_subscriptions',
  'v2_onboarding_milestones',
  'v2_saas_attribution_events',
  'v2_saas_ad_spend',
  'v2_saas_onboarding_drips',
  'v2_consent_logs',
]);

export const V2_SCHEMA_DDL = `
-- Category 2: Multi-User RBAC & Shift Management (created before FK dependents)
CREATE TABLE IF NOT EXISTS v2_users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('owner', 'sales_morning', 'sales_night', 'accounting')),
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_chat_assignments (
  chat_id TEXT PRIMARY KEY,
  channel TEXT NOT NULL,
  assigned_to TEXT REFERENCES v2_users(id) ON DELETE SET NULL,
  assigned_by TEXT REFERENCES v2_users(id) ON DELETE SET NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open', 'pending_deposit', 'resolved_ai', 'resolved_human')),
  first_response_ms INTEGER,
  assigned_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at TEXT
);

CREATE TABLE IF NOT EXISTS v2_shift_handovers (
  id TEXT PRIMARY KEY,
  from_shift TEXT NOT NULL CHECK(from_shift IN ('morning', 'night')),
  to_shift TEXT NOT NULL CHECK(to_shift IN ('morning', 'night')),
  handover_by TEXT REFERENCES v2_users(id) ON DELETE SET NULL,
  open_chats_count INTEGER NOT NULL DEFAULT 0,
  pending_quotes_count INTEGER NOT NULL DEFAULT 0,
  pinned_notes TEXT NOT NULL DEFAULT '',
  snapshot_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Category 1: Deep Analytics & Time-Series Funnel (Dynamic 23+ channels, Satang integer math)
CREATE TABLE IF NOT EXISTS v2_chat_sessions_fact (
  session_id TEXT PRIMARY KEY,
  customer_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  first_inbound_at TEXT NOT NULL,
  first_reply_at TEXT,
  frt_seconds INTEGER,
  human_takeover INTEGER NOT NULL DEFAULT 0,
  is_converted INTEGER NOT NULL DEFAULT 0,
  order_value_satang INTEGER NOT NULL DEFAULT 0,
  cohort_month TEXT NOT NULL
);

-- Category 3: Kanban Broadcast, Smart Drip & Rate-Limit Safe Queue
CREATE TABLE IF NOT EXISTS v2_customer_consent (
  customer_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  kanban_stage TEXT NOT NULL DEFAULT 'LEAD',
  quote_issued_at TEXT,
  last_inbound_at TEXT,
  opt_out INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (customer_id, channel)
);

CREATE TABLE IF NOT EXISTS v2_campaigns (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL CHECK(type IN ('broadcast', 'drip_quote')),
  target_stages_json TEXT NOT NULL DEFAULT '[]',
  channels_json TEXT NOT NULL DEFAULT '[]',
  message_payload_json TEXT NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft', 'scheduled', 'running', 'completed', 'paused')),
  created_by TEXT REFERENCES v2_users(id) ON DELETE SET NULL,
  scheduled_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_drip_steps (
  id TEXT PRIMARY KEY,
  step_order INTEGER NOT NULL,
  delay_minutes INTEGER NOT NULL,
  message_template TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS v2_outbound_queue (
  id TEXT PRIMARY KEY,
  source_type TEXT NOT NULL CHECK(source_type IN ('broadcast', 'drip', 'abandoned_quote')),
  source_id TEXT NOT NULL,
  customer_id TEXT NOT NULL,
  channel TEXT NOT NULL,
  variant_key TEXT NOT NULL DEFAULT 'A',
  payload_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued', 'processing', 'sent', 'failed', 'skipped_policy', 'cancelled_paid')),
  scheduled_for TEXT NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error TEXT,
  sent_at TEXT
);

-- Category 4: B2B SaaS Signup, Workspaces & Subscriptions
CREATE TABLE IF NOT EXISTS v2_saas_accounts (
  id TEXT PRIMARY KEY,
  email_hash TEXT UNIQUE NOT NULL,
  email_encrypted TEXT NOT NULL,
  phone_hash TEXT UNIQUE,
  phone_encrypted TEXT,
  password_hash TEXT NOT NULL,
  full_name TEXT NOT NULL,
  company_name TEXT NOT NULL,
  business_industry TEXT NOT NULL,
  team_size_bucket TEXT NOT NULL,
  primary_goal TEXT,
  email_verified_at TEXT,
  phone_verified_at TEXT,
  platform_role TEXT NOT NULL DEFAULT 'subscriber' CHECK(platform_role IN ('platform_superadmin', 'subscriber')),
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('pending_otp', 'active', 'suspended', 'anonymized')),
  last_login_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_workspaces (
  id TEXT PRIMARY KEY,
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  owner_account_id TEXT NOT NULL REFERENCES v2_saas_accounts(id) ON DELETE CASCADE,
  connected_channels_count INTEGER NOT NULL DEFAULT 0,
  ai_quota_monthly INTEGER NOT NULL DEFAULT 1000,
  ai_quota_used INTEGER NOT NULL DEFAULT 0,
  seat_limit INTEGER NOT NULL DEFAULT 2,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_subscriptions (
  id TEXT PRIMARY KEY,
  workspace_id TEXT UNIQUE NOT NULL REFERENCES v2_workspaces(id) ON DELETE CASCADE,
  plan_code TEXT NOT NULL CHECK(plan_code IN ('free_trial', 'free_6m', 'starter', 'pro', 'enterprise')),
  billing_cycle TEXT NOT NULL CHECK(billing_cycle IN ('trial', 'monthly', 'yearly')),
  status TEXT NOT NULL CHECK(status IN ('trialing', 'active', 'past_due', 'churned', 'cancelled')),
  mrr_satang INTEGER NOT NULL DEFAULT 0,
  trial_starts_at TEXT,
  trial_ends_at TEXT,
  current_period_start TEXT,
  current_period_end TEXT,
  converted_from_trial_at TEXT,
  churned_at TEXT,
  cancel_reason TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_onboarding_milestones (
  workspace_id TEXT PRIMARY KEY REFERENCES v2_workspaces(id) ON DELETE CASCADE,
  step_account_verifiedAt TEXT,
  step_profile_completedAt TEXT,
  step_first_channel_connectedAt TEXT,
  first_connected_channel TEXT,
  step_catalog_uploadedAt TEXT,
  step_first_ai_replyAt TEXT,
  onboarding_score INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Category 5: SaaS Growth Marketing, Attribution & PDPA Audit
CREATE TABLE IF NOT EXISTS v2_saas_attribution_events (
  id TEXT PRIMARY KEY,
  visitor_anon_id TEXT NOT NULL,
  account_id TEXT REFERENCES v2_saas_accounts(id) ON DELETE SET NULL,
  workspace_id TEXT REFERENCES v2_workspaces(id) ON DELETE SET NULL,
  stage_event TEXT NOT NULL CHECK(stage_event IN ('landing_view', 'signup_started', 'trial_created', 'channel_linked', 'aha_moment', 'subscription_paid', 'plan_upgraded')),
  utm_source TEXT,
  utm_medium TEXT,
  utm_campaign TEXT,
  utm_content TEXT,
  utm_term TEXT,
  fbclid TEXT,
  gclid TEXT,
  ttclid TEXT,
  referrer_url TEXT,
  revenue_satang INTEGER NOT NULL DEFAULT 0,
  capi_sync_status TEXT NOT NULL DEFAULT 'pending' CHECK(capi_sync_status IN ('pending', 'sent', 'failed', 'skipped_no_consent')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_saas_ad_spend (
  spend_date TEXT NOT NULL,
  ad_platform TEXT NOT NULL,
  utm_campaign TEXT NOT NULL,
  spend_satang INTEGER NOT NULL DEFAULT 0,
  impressions INTEGER NOT NULL DEFAULT 0,
  clicks INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (spend_date, ad_platform, utm_campaign)
);

CREATE TABLE IF NOT EXISTS v2_saas_onboarding_drips (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES v2_saas_accounts(id) ON DELETE CASCADE,
  workspace_id TEXT NOT NULL REFERENCES v2_workspaces(id) ON DELETE CASCADE,
  trigger_rule TEXT NOT NULL,
  delivery_channel TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled' CHECK(status IN ('scheduled', 'sent', 'cancelled_completed', 'skipped_opt_out', 'failed')),
  scheduled_for TEXT NOT NULL,
  sent_at TEXT
);

CREATE TABLE IF NOT EXISTS v2_consent_logs (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  purpose_code TEXT NOT NULL CHECK(purpose_code IN ('saas_tos_dpa', 'product_onboarding_comms', 'saas_marketing_promo', 'ad_conversion_capi')),
  action TEXT NOT NULL CHECK(action IN ('opt_in', 'opt_out')),
  policy_version TEXT NOT NULL,
  proof_source TEXT NOT NULL,
  trace_hash TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_v2_fact_inbound_ch ON v2_chat_sessions_fact(first_inbound_at, channel);
CREATE INDEX IF NOT EXISTS idx_v2_fact_cohort ON v2_chat_sessions_fact(cohort_month, customer_id);
CREATE INDEX IF NOT EXISTS idx_v2_assign_agent ON v2_chat_assignments(assigned_to, status);
CREATE INDEX IF NOT EXISTS idx_v2_queue_poll ON v2_outbound_queue(status, channel, scheduled_for);
CREATE INDEX IF NOT EXISTS idx_v2_attr_funnel ON v2_saas_attribution_events(stage_event, utm_source, utm_campaign, created_at);
CREATE INDEX IF NOT EXISTS idx_v2_attr_account ON v2_saas_attribution_events(account_id, created_at);
CREATE INDEX IF NOT EXISTS idx_v2_drip_sched ON v2_saas_onboarding_drips(status, scheduled_for);
CREATE INDEX IF NOT EXISTS idx_v2_consent_acc ON v2_consent_logs(account_id, purpose_code, created_at DESC);
`;
