// gateway/src/modules/v2/v2-http.mjs
// Shared HTTP, Crypto, PII Encryption & Dynamic Channel Helpers for OmniFlow v2

import crypto from 'node:crypto';
import { getPublicChannelRegistryPayload } from '../channels/channel-registry.mjs';

const DEFAULT_FALLBACK_KEY = crypto.createHash('sha256').update('omniflow-v2-dev-key-do-not-use-in-prod').digest();
let warnedFallbackSecrets = false;

function warnOrFailMissingSecret(name) {
  if (process.env.NODE_ENV === 'production') {
    throw new Error(`Missing required security secret in production: ${name}`);
  }
  if (!warnedFallbackSecrets) {
    warnedFallbackSecrets = true;
    console.warn(`[v2-http] Using dev fallback for ${name} (set ${name} in production)`);
  }
}

export function makeHttpError(statusCode, message) {
  const err = new Error(message);
  err.statusCode = statusCode;
  return err;
}

export async function readJsonBody(req, maxBytes = 262144) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    total += buf.length;
    if (total > maxBytes) {
      throw makeHttpError(413, 'Payload Too Large');
    }
    chunks.push(buf);
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    throw makeHttpError(400, 'Invalid JSON body');
  }
}

export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(String(password), salt, 32).toString('hex');
  return `${salt}:${derived}`;
}

export function verifyPassword(password, storedHash) {
  const [salt, expectedHex] = String(storedHash || '').split(':');
  if (!salt || !expectedHex) return false;
  const actual = crypto.scryptSync(String(password), salt, 32);
  const expected = Buffer.from(expectedHex, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

export function hmacLookupHash(value) {
  const rawPepper = String(process.env.OMNIFLOW_V2_HASH_PEPPER || '').trim();
  if (!rawPepper) warnOrFailMissingSecret('OMNIFLOW_V2_HASH_PEPPER');
  const pepper = rawPepper || 'omniflow-v2-pepper';
  return crypto.createHmac('sha256', pepper).update(String(value || '').trim().toLowerCase()).digest('hex');
}

function getAesKey() {
  const raw = String(process.env.OMNIFLOW_V2_PII_KEY || '').trim();
  if (!raw) warnOrFailMissingSecret('OMNIFLOW_V2_PII_KEY');
  return raw ? crypto.createHash('sha256').update(raw).digest() : DEFAULT_FALLBACK_KEY;
}

export function encryptPii(plaintext) {
  const text = String(plaintext ?? '').trim();
  if (!text) return '';
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getAesKey(), iv);
  const enc = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString('base64')}:${tag.toString('base64')}:${enc.toString('base64')}`;
}

export function decryptPii(ciphertext) {
  const raw = String(ciphertext || '').trim();
  if (!raw) return '';
  const parts = raw.split(':');
  if (parts.length !== 3) throw makeHttpError(500, 'Corrupted encrypted secret');
  const [ivB64, tagB64, encB64] = parts;
  const decipher = crypto.createDecipheriv('aes-256-gcm', getAesKey(), Buffer.from(ivB64, 'base64'));
  decipher.setAuthTag(Buffer.from(tagB64, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(encB64, 'base64')), decipher.final()]).toString('utf8');
}

export function maskPhone(phone) {
  const digits = String(phone || '').replace(/\D/g, '');
  if (digits.length < 7) return '***';
  return `${digits.slice(0, 3)}-XXX-${digits.slice(-4)}`;
}

export function getDynamicChannelsList() {
  const payload = getPublicChannelRegistryPayload({});
  return (payload.channels || []).map((d) => ({ id: d.id, name: d.name }));
}

export function newId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(4).toString('hex')}`;
}
