// gateway/src/modules/v2/auth-session.service.mjs
// OmniFlow Enterprise v2 — Phase 1A Persistent HttpOnly Session & Bootstrap Status Service

import crypto from 'node:crypto';
import { getV2Db, withV2Transaction } from './v2-db.mjs';
import { hmacLookupHash, makeHttpError, newId, verifyPassword } from './v2-http.mjs';
import { getCurrentWorkspace } from './saas.service.mjs';
import { writeAuditLog } from './erp/audit.service.mjs';

export const V2_SESSION_COOKIE_NAME = 'omniflow_v2_session';
export const SESSION_MAX_AGE_SEC = 31536000; // 365 days

export const PHASE1A_SCHEMA_DDL = `
CREATE TABLE IF NOT EXISTS v2_persistent_sessions (
  id TEXT PRIMARY KEY,
  account_id TEXT NOT NULL,
  workspace_id TEXT,
  token_hash TEXT UNIQUE NOT NULL,
  device_label TEXT,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_v2_sessions_account
  ON v2_persistent_sessions(account_id, revoked_at);

CREATE TABLE IF NOT EXISTS v2_workspace_settings (
  workspace_id TEXT PRIMARY KEY,
  auto_lock_minutes INTEGER NOT NULL DEFAULT 0,
  auto_start_enabled INTEGER NOT NULL DEFAULT 0,
  gateway_port INTEGER NOT NULL DEFAULT 4001,
  tunnel_mode TEXT NOT NULL DEFAULT 'off',
  sound_enabled INTEGER NOT NULL DEFAULT 1,
  quiet_hours_start TEXT NOT NULL DEFAULT '21:00',
  quiet_hours_end TEXT NOT NULL DEFAULT '08:30',
  tax_id TEXT NOT NULL DEFAULT '',
  store_address TEXT NOT NULL DEFAULT '',
  receipt_logo_url TEXT NOT NULL DEFAULT '',
  invoice_prefix TEXT NOT NULL DEFAULT 'INV-2026-',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`;

const initializedDbs = new WeakSet();

export function ensurePhase1ASchema(db = getV2Db()) {
  if (!db) throw new Error('ensurePhase1ASchema requires an active SQLite DatabaseSync instance');
  if (!initializedDbs.has(db)) {
    db.exec(PHASE1A_SCHEMA_DDL);
    initializedDbs.add(db);
  }
  return db;
}

function hashSessionToken(rawToken) {
  return crypto.createHash('sha256').update(String(rawToken)).digest('hex');
}

function isSecureRequest(req) {
  if (req?.socket?.encrypted) return true;
  const proto = String(req?.headers?.['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  return proto === 'https';
}

export function buildSessionSetCookie(rawToken, req = null) {
  const secureFlag = isSecureRequest(req) ? '; Secure' : '';
  return `${V2_SESSION_COOKIE_NAME}=${rawToken}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${SESSION_MAX_AGE_SEC}${secureFlag}`;
}

export function buildSessionClearCookie(req = null) {
  const secureFlag = isSecureRequest(req) ? '; Secure' : '';
  return `${V2_SESSION_COOKIE_NAME}=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0${secureFlag}`;
}

export function extractSessionToken(req) {
  if (!req || !req.headers) return '';
  const headerToken = String(req.headers['x-v2-session'] || '').trim();
  if (headerToken) return headerToken;

  const cookieHeader = String(req.headers.cookie || '');
  if (!cookieHeader) return '';
  for (const part of cookieHeader.split(';')) {
    const eqIdx = part.indexOf('=');
    if (eqIdx <= 0) continue;
    if (part.slice(0, eqIdx).trim() === V2_SESSION_COOKIE_NAME) {
      const val = part.slice(eqIdx + 1).trim();
      try {
        return decodeURIComponent(val);
      } catch {
        return val;
      }
    }
  }
  return '';
}

function getClientIp(req) {
  const rawFwd = String(req?.headers?.['x-forwarded-for'] || '').split(',')[0].trim();
  return rawFwd || String(req?.socket?.remoteAddress || '');
}

/**
 * Issue a long-lived HttpOnly persistent session. Stores ONLY SHA-256 token_hash in SQLite.
 */
export function issuePersistentSession({ accountId, workspaceId = null, deviceLabel = '', req = null } = {}, db = getV2Db()) {
  ensurePhase1ASchema(db);
  const accId = String(accountId || '').trim();
  if (!accId) throw makeHttpError(400, 'accountId is required to issue session');

  const rawToken = crypto.randomBytes(32).toString('hex');
  const tokenHash = hashSessionToken(rawToken);
  const sessionId = newId('SES');
  const expiresAt = new Date(Date.now() + SESSION_MAX_AGE_SEC * 1000).toISOString();
  const cleanLabel = String(deviceLabel || req?.headers?.['user-agent'] || 'desktop').trim().slice(0, 120);
  const wsId = workspaceId ? String(workspaceId).trim() : null;

  withV2Transaction((txDb) => {
    ensurePhase1ASchema(txDb);
    txDb
      .prepare(
        `INSERT INTO v2_persistent_sessions (id, account_id, workspace_id, token_hash, device_label, expires_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(sessionId, accId, wsId, tokenHash, cleanLabel, expiresAt);
  });

  return {
    rawToken,
    sessionId,
    accountId: accId,
    workspaceId: wsId,
    expiresAt,
    setCookieHeader: buildSessionSetCookie(rawToken, req),
  };
}

export function verifyPersistentSession(req, db = null) {
  const rawToken = extractSessionToken(req);
  if (!rawToken) return { ok: false, session: null };

  const activeDb = db || getV2Db();
  ensurePhase1ASchema(activeDb);

  const candidateHash = hashSessionToken(rawToken);
  const row = activeDb
    .prepare('SELECT * FROM v2_persistent_sessions WHERE token_hash = ?')
    .get(candidateHash);
  if (!row || !row.token_hash) return { ok: false, session: null };

  const expectedBuf = Buffer.from(String(row.token_hash), 'hex');
  const actualBuf = Buffer.from(candidateHash, 'hex');
  if (expectedBuf.length !== actualBuf.length || !crypto.timingSafeEqual(expectedBuf, actualBuf)) {
    return { ok: false, session: null };
  }
  if (row.revoked_at) return { ok: false, session: null };
  if (Date.parse(row.expires_at) <= Date.now()) return { ok: false, session: null };

  return {
    ok: true,
    session: {
      id: row.id,
      accountId: row.account_id,
      workspaceId: row.workspace_id,
      deviceLabel: row.device_label,
      expiresAt: row.expires_at,
      createdAt: row.created_at,
    },
  };
}

export function loginWithPassword({ email, password, deviceLabel = '', req = null } = {}, db = getV2Db()) {
  ensurePhase1ASchema(db);
  const cleanEmail = String(email || '').trim().toLowerCase();
  const rawPassword = String(password || '');
  if (!cleanEmail || !rawPassword) {
    throw makeHttpError(400, 'กรุณากรอกอีเมลและรหัสผ่านให้ครบถ้วน');
  }

  const emailHash = hmacLookupHash(cleanEmail);
  const acc = db.prepare('SELECT * FROM v2_saas_accounts WHERE email_hash = ?').get(emailHash);
  if (!acc || !verifyPassword(rawPassword, acc.password_hash)) {
    throw makeHttpError(401, 'อีเมลหรือรหัสผ่านไม่ถูกต้อง');
  }
  if (acc.status === 'suspended') {
    throw makeHttpError(403, 'บัญชีนี้ถูกระงับการใช้งานชั่วคราว');
  }
  if (acc.status === 'pending_otp') {
    const err = makeHttpError(409, 'บัญชีนี้ยังไม่ได้ยืนยัน OTP กรุณากรอกรหัส OTP เพื่อเปิดใช้งาน');
    err.code = 'OTP_REQUIRED';
    err.accountId = acc.id;
    throw err;
  }

  const ws = db
    .prepare('SELECT id FROM v2_workspaces WHERE owner_account_id = ? ORDER BY created_at DESC LIMIT 1')
    .get(acc.id);

  const issued = issuePersistentSession(
    { accountId: acc.id, workspaceId: ws?.id || null, deviceLabel, req },
    db
  );

  writeAuditLog(
    {
      actorId: acc.id,
      actorRole: acc.platform_role || 'owner',
      action: 'auth.login',
      targetType: 'session',
      targetId: issued.sessionId,
      after: { workspaceId: issued.workspaceId, expiresAt: issued.expiresAt },
      ip: getClientIp(req),
    },
    db
  );

  return {
    account: {
      id: acc.id,
      full_name: acc.full_name,
      company_name: acc.company_name,
      platform_role: acc.platform_role || 'owner',
      status: acc.status,
    },
    workspaceId: issued.workspaceId,
    session: { id: issued.sessionId, expiresAt: issued.expiresAt },
    setCookieHeader: issued.setCookieHeader,
  };
}

export function logoutPersistentSession(req, db = getV2Db()) {
  ensurePhase1ASchema(db);
  const rawToken = extractSessionToken(req);
  let revokedId = null;

  if (rawToken) {
    const tokenHash = hashSessionToken(rawToken);
    revokedId = withV2Transaction((txDb) => {
      ensurePhase1ASchema(txDb);
      const existing = txDb
        .prepare('SELECT id, account_id FROM v2_persistent_sessions WHERE token_hash = ? AND revoked_at IS NULL')
        .get(tokenHash);
      if (!existing) return null;
      txDb
        .prepare('UPDATE v2_persistent_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE id = ?')
        .run(existing.id);
      writeAuditLog(
        {
          actorId: existing.account_id,
          actorRole: 'owner',
          action: 'auth.logout',
          targetType: 'session',
          targetId: existing.id,
          after: { revoked: true },
          ip: getClientIp(req),
        },
        txDb
      );
      return existing.id;
    });
  }

  return {
    revoked: Boolean(revokedId),
    sessionId: revokedId,
    clearCookieHeader: buildSessionClearCookie(req),
  };
}

export function getBootstrapStatus(req = null, db = getV2Db(), opts = {}) {
  ensurePhase1ASchema(db);
  const accCount = Number(db.prepare('SELECT COUNT(*) AS cnt FROM v2_saas_accounts').get()?.cnt || 0);
  const wsCount = Number(db.prepare('SELECT COUNT(*) AS cnt FROM v2_workspaces').get()?.cnt || 0);
  const verified = verifyPersistentSession(req, db);
  const canSee = verified.ok || opts.trustedAdmin === true;
  const wsData = canSee
    ? getCurrentWorkspace(verified.session?.workspaceId || null)
    : { workspace: null, subscription: null, milestones: null, account: null, daysRemaining: null };

  return {
    hasAccount: accCount > 0,
    hasWorkspace: wsCount > 0,
    authenticated: verified.ok,
    session: verified.session,
    ...wsData,
  };
}
