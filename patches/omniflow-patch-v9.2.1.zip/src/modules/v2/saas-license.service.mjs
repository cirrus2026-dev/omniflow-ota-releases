// gateway/src/modules/v2/saas-license.service.mjs
// OmniFlow Enterprise v2 — 3-Tier License Key Activation (Windows Sandbox Demo Keys + HMAC Production Keys)

import crypto from 'node:crypto';
import { withV2Transaction } from './v2-db.mjs';
import { encryptPii, hashPassword, hmacLookupHash, makeHttpError, newId } from './v2-http.mjs';
import { getCurrentWorkspace, PLAN_MRR_SATANG, upgradeSubscription } from './saas.service.mjs';
import { writeAuditLog } from './erp/audit.service.mjs';

export const SANDBOX_DEMO_LICENSE_KEYS = Object.freeze({
  'OMNI-STARTER-2026-TRIAL': { planCode: 'starter', billingCycle: 'monthly', mode: 'sandbox_demo' },
  'OMNI-PRO-2026-TRIAL': { planCode: 'pro', billingCycle: 'monthly', mode: 'sandbox_demo' },
  'OMNI-ENTERPRISE-2026-VIP': { planCode: 'enterprise', billingCycle: 'monthly', mode: 'sandbox_demo' },
});

function getLicenseSigningSecret() {
  const raw = String(process.env.OMNIFLOW_V2_LICENSE_SECRET || process.env.OMNIFLOW_V2_HASH_PEPPER || '').trim();
  if (!raw && process.env.NODE_ENV === 'production') {
    throw new Error('Missing OMNIFLOW_V2_LICENSE_SECRET in production');
  }
  return raw || 'omniflow-v2-license-dev-secret';
}

function signLicensePayload(payloadPart) {
  return crypto
    .createHmac('sha256', getLicenseSigningSecret())
    .update(payloadPart)
    .digest('hex')
    .slice(0, 12)
    .toUpperCase();
}

/**
 * Generate a cryptographically signed production license key for real customer handover.
 * Format: OMNI-<PLAN>-<MONTHLY|YEARLY>-<CUSTOMER_REF>-<HMAC12>
 */
export function generateSignedLicenseKey({ planCode, billingCycle = 'monthly', customerRef = 'CUST' } = {}) {
  const plan = String(planCode || '').trim().toLowerCase();
  if (!Object.hasOwn(PLAN_MRR_SATANG, plan) || plan === 'free_trial') {
    throw makeHttpError(400, 'แพ็กเกจสำหรับสร้างคีย์ไม่ถูกต้อง');
  }
  const cycle = billingCycle === 'yearly' ? 'YEARLY' : 'MONTHLY';
  const cleanRef = String(customerRef || 'CUST').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10) || 'CUST';
  const payloadPart = `OMNI-${plan.toUpperCase()}-${cycle}-${cleanRef}`;
  return `${payloadPart}-${signLicensePayload(payloadPart)}`;
}

export function parseAndVerifyLicenseKey(rawKey) {
  const normalized = String(rawKey || '').trim().toUpperCase();
  if (!normalized) throw makeHttpError(400, 'กรุณากรอกรหัสคีย์แพ็กเกจ (License Key)');

  const allowDemoKeys = process.env.NODE_ENV !== 'production' || process.env.ALLOW_DEMO_LICENSE_KEYS === 'true';
  if (allowDemoKeys && Object.hasOwn(SANDBOX_DEMO_LICENSE_KEYS, normalized)) {
    return SANDBOX_DEMO_LICENSE_KEYS[normalized];
  }

  const m = /^OMNI-(STARTER|PRO|ENTERPRISE)-(MONTHLY|YEARLY)-([A-Z0-9]{1,10})-([A-F0-9]{12})$/.exec(normalized);
  if (!m) throw makeHttpError(400, 'รหัสคีย์แพ็กเกจไม่ถูกต้อง');

  const [, planUpper, cycleUpper, ref, sigHex] = m;
  const payloadPart = `OMNI-${planUpper}-${cycleUpper}-${ref}`;
  const expectedSig = signLicensePayload(payloadPart);
  const actualBuf = Buffer.from(sigHex, 'utf8');
  const expectedBuf = Buffer.from(expectedSig, 'utf8');
  if (actualBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(actualBuf, expectedBuf)) {
    throw makeHttpError(400, 'ลายเซ็นรหัสคีย์แพ็กเกจไม่ถูกต้อง');
  }

  return {
    planCode: planUpper.toLowerCase(),
    billingCycle: cycleUpper === 'YEARLY' ? 'yearly' : 'monthly',
    customerRef: ref,
    mode: 'signed_customer',
  };
}

export function activateLicenseKey({ licenseKey, workspaceId = null, companyName = '', fullName = '' } = {}) {
  const parsed = parseAndVerifyLicenseKey(licenseKey);

  return withV2Transaction((db) => {
    let ws = workspaceId
      ? db.prepare('SELECT * FROM v2_workspaces WHERE id = ?').get(workspaceId)
      : db.prepare('SELECT * FROM v2_workspaces ORDER BY created_at DESC LIMIT 1').get();

    if (!ws) {
      const nowIso = new Date().toISOString();
      const accountId = newId('ACC');
      const wsId = newId('WS');
      const resolvedCompany = String(companyName || '').trim() || 'OmniFlow Activated Store';
      const resolvedOwner = String(fullName || '').trim() || 'เจ้าของกิจการ (License Key)';
      const syntheticEmail = `license.${accountId.toLowerCase()}@omniflow.local`;
      const slug = `store-${wsId.slice(-6).toLowerCase()}`;

      db.prepare(
        `INSERT INTO v2_saas_accounts
         (id, email_hash, email_encrypted, password_hash, full_name, company_name, business_industry, team_size_bucket, email_verified_at, status)
         VALUES (?, ?, ?, ?, ?, ?, 'general', '3-10', ?, 'active')`
      ).run(
        accountId,
        hmacLookupHash(syntheticEmail),
        encryptPii(syntheticEmail),
        hashPassword(crypto.randomBytes(16).toString('hex')),
        resolvedOwner,
        resolvedCompany,
        nowIso
      );

      db.prepare('INSERT INTO v2_workspaces (id, slug, name, owner_account_id) VALUES (?, ?, ?, ?)').run(
        wsId, slug, resolvedCompany, accountId
      );
      db.prepare(
        `INSERT INTO v2_subscriptions (id, workspace_id, plan_code, billing_cycle, status, mrr_satang, trial_starts_at)
         VALUES (?, ?, 'free_trial', 'trial', 'trialing', 0, ?)`
      ).run(newId('SUB'), wsId, nowIso);
      db.prepare(
        `INSERT INTO v2_onboarding_milestones (workspace_id, step_account_verifiedAt, step_profile_completedAt, onboarding_score)
         VALUES (?, ?, ?, 50)`
      ).run(wsId, nowIso, nowIso);

      ws = db.prepare('SELECT * FROM v2_workspaces WHERE id = ?').get(wsId);
    }

    upgradeSubscription({
      workspaceId: ws.id,
      planCode: parsed.planCode,
      billingCycle: parsed.billingCycle,
    });

    writeAuditLog(
      {
        actorId: ws.owner_account_id || 'owner',
        actorRole: 'owner',
        action: 'license.activated',
        targetType: 'workspace',
        targetId: ws.id,
        after: { plan_code: parsed.planCode, billing_cycle: parsed.billingCycle, key_mode: parsed.mode },
      },
      db
    );

    return {
      ...getCurrentWorkspace(ws.id),
      activatedPlan: parsed.planCode,
      billingCycle: parsed.billingCycle,
      keyMode: parsed.mode,
    };
  });
}
