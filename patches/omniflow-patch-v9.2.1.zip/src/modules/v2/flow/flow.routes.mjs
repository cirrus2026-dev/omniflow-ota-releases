// gateway/src/modules/v2/flow/flow.routes.mjs
// OmniFlow Enterprise v2 — Phase 2 Visual AI Flow Builder & Telemetry HTTP Routes
// IMPORTANT: Must NOT import v2-router.mjs directly (registered via FEATURES array).

import { readJsonBody } from '../v2-http.mjs';
import { verifyPersistentSession } from '../auth-session.service.mjs';
import {
  createFlow,
  getFlowDetail,
  listFlows,
  publishFlowVersion,
  rollbackFlowVersion,
  saveFlowDraft,
} from './flow-repo.mjs';
import { simulateFlowTurn } from './flow-simulator.mjs';
import {
  getFlowTelemetryHeatmap,
  listFlowFeedbackItems,
  resolveFlowFeedbackItem,
} from './flow-telemetry.service.mjs';

function getUrl(req, ctx) {
  return ctx?.parsedUrl instanceof URL ? ctx.parsedUrl : new URL(req?.url || '/', 'http://127.0.0.1');
}

function resolveActorAndWorkspace(req, queryOrBody = {}) {
  const verified = verifyPersistentSession(req);
  const workspaceId =
    String(queryOrBody?.workspaceId || verified.session?.workspaceId || 'default').trim() || 'default';
  const actorId = String(
    verified.session?.accountId || req?.v2User?.id || req?.adminUser?.id || 'owner_pin'
  ).trim();
  return { workspaceId, actorId };
}

export function register(registerV2Route) {
  registerV2Route({
    method: 'GET',
    path: '/api/v2/flows',
    auth: 'admin',
    handler: (req, res, ctx) => {
      const q = getUrl(req, ctx).searchParams;
      const { workspaceId } = resolveActorAndWorkspace(req, { workspaceId: q.get('workspaceId') });
      const flows = listFlows(workspaceId);
      ctx.sendJson(res, 200, { ok: true, workspaceId, flows }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/flows',
    auth: 'strict',
    handler: async (req, res, ctx) => {
      const body = await readJsonBody(req);
      const { workspaceId, actorId } = resolveActorAndWorkspace(req, body);
      const created = createFlow({ ...body, workspaceId, actorId });
      ctx.sendJson(res, 201, { ok: true, ...created }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/flows/detail',
    auth: 'admin',
    handler: (req, res, ctx) => {
      const q = getUrl(req, ctx).searchParams;
      const { workspaceId } = resolveActorAndWorkspace(req, { workspaceId: q.get('workspaceId') });
      const flowId = q.get('id') || q.get('flowId') || null;
      const detail = getFlowDetail(flowId, workspaceId);
      ctx.sendJson(res, 200, { ok: true, ...detail }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'PUT',
    path: '/api/v2/flows/draft',
    auth: 'strict',
    handler: async (req, res, ctx) => {
      const body = await readJsonBody(req);
      const { workspaceId, actorId } = resolveActorAndWorkspace(req, body);
      const updated = saveFlowDraft({ ...body, workspaceId, actorId });
      ctx.sendJson(res, 200, { ok: true, ...updated }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/flows/publish',
    auth: 'strict',
    handler: async (req, res, ctx) => {
      const body = await readJsonBody(req);
      const { workspaceId, actorId } = resolveActorAndWorkspace(req, body);
      const published = publishFlowVersion({ ...body, workspaceId, actorId });
      ctx.sendJson(res, 200, { ok: true, ...published }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/flows/rollback',
    auth: 'strict',
    handler: async (req, res, ctx) => {
      const body = await readJsonBody(req);
      const { workspaceId, actorId } = resolveActorAndWorkspace(req, body);
      const rolled = rollbackFlowVersion({ ...body, workspaceId, actorId });
      ctx.sendJson(res, 200, { ok: true, ...rolled }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/flows/simulate',
    auth: 'admin',
    handler: async (req, res, ctx) => {
      const body = await readJsonBody(req);
      const { workspaceId } = resolveActorAndWorkspace(req, body);
      const result = await simulateFlowTurn({ ...body, workspaceId });
      ctx.sendJson(res, 200, { ok: true, ...result }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/flows/telemetry',
    auth: 'admin',
    handler: (req, res, ctx) => {
      const q = getUrl(req, ctx).searchParams;
      const { workspaceId } = resolveActorAndWorkspace(req, { workspaceId: q.get('workspaceId') });
      const flowId = q.get('flowId') || q.get('id');
      const heatmap = getFlowTelemetryHeatmap({
        workspaceId,
        flowId,
        versionId: q.get('versionId') || null,
        windowHours: q.get('windowHours') || 24,
      });
      ctx.sendJson(res, 200, { ok: true, ...heatmap }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/flows/feedback',
    auth: 'admin',
    handler: (req, res, ctx) => {
      const q = getUrl(req, ctx).searchParams;
      const { workspaceId } = resolveActorAndWorkspace(req, { workspaceId: q.get('workspaceId') });
      const items = listFlowFeedbackItems({
        workspaceId,
        flowId: q.get('flowId') || q.get('id') || null,
        status: q.get('status') || null,
      });
      ctx.sendJson(res, 200, { ok: true, items }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/flows/feedback/resolve',
    auth: 'strict',
    handler: async (req, res, ctx) => {
      const body = await readJsonBody(req);
      const item = resolveFlowFeedbackItem(body);
      ctx.sendJson(res, 200, { ok: true, item }, ctx.corsHeaders);
    },
  });
}
