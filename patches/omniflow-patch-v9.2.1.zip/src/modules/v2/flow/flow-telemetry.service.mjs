// gateway/src/modules/v2/flow/flow-telemetry.service.mjs
// OmniFlow Enterprise v2 — Phase 2 Telemetry Heatmap, PDPA-Masked Trace Capture & Feedback Loop Service

import { getV2Db, withV2Transaction } from '../v2-db.mjs';
import { makeHttpError, newId } from '../v2-http.mjs';
import { initFlowTables } from './flow-schema.mjs';
import { maskSensitivePreview } from './flow-node-executors.mjs';

const HYGIENE_INTERVAL_MS = 15 * 60 * 1000;
const VALID_RESOLUTION_STATUSES = new Set(['open', 'resolved_in_version', 'ignored']);
const VALID_TRIGGER_REASONS = new Set([
  'admin_takeover',
  'math_guard_reject',
  'vision_low_conf',
  'loop_ceiling',
  'manual_flag',
]);
let lastHygieneAtMs = 0;

export function runFlowRetentionHygiene({ force = false, nowMs = Date.now() } = {}, db = getV2Db()) {
  initFlowTables(db);
  if (!force && nowMs - lastHygieneAtMs < HYGIENE_INTERVAL_MS) {
    return { ran: false, expiredSessionsDeleted: 0, oldTelemetryDeleted: 0 };
  }
  lastHygieneAtMs = nowMs;
  const cutoffIso = new Date(nowMs - 30 * 86_400_000).toISOString();

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const sDel = txDb.prepare('DELETE FROM v2_flow_sessions WHERE expires_at < ?').run(nowMs);
    const tDel = txDb.prepare('DELETE FROM v2_flow_telemetry WHERE created_at < ?').run(cutoffIso);
    return {
      ran: true,
      expiredSessionsDeleted: Number(sDel?.changes || 0),
      oldTelemetryDeleted: Number(tDel?.changes || 0),
    };
  });
}

export function recordFlowTurnTelemetry(
  {
    traceId = newId('TRC'),
    workspaceId = 'default',
    flowId,
    versionId = 'draft',
    executionMode = 'hybrid_rules',
    traceSteps = [],
    feedbackEvents = [],
  } = {},
  db = getV2Db()
) {
  initFlowTables(db);
  const fId = String(flowId || '').trim();
  if (!fId) return { recordedSteps: 0, recordedFeedback: 0, traceId };
  const wsId = String(workspaceId || 'default').trim() || 'default';
  const vId = String(versionId || 'draft').trim() || 'draft';

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const insTel = txDb.prepare(
      `INSERT INTO v2_flow_telemetry
       (id, trace_id, workspace_id, flow_id, version_id, node_id, node_type, execution_mode, outcome, guard_code, latency_ms, masked_input_preview, metrics_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    let recordedSteps = 0;
    for (const s of traceSteps) {
      insTel.run(
        newId('TEL'),
        traceId,
        wsId,
        fId,
        vId,
        String(s.nodeId || 'unknown'),
        String(s.nodeType || 'unknown'),
        String(s.executionMode || executionMode),
        String(s.outcome || 'ok'),
        s.guardCode ? String(s.guardCode) : null,
        Math.max(0, Number(s.latencyMs || 0)),
        maskSensitivePreview(s.maskedInputPreview || ''),
        JSON.stringify(s.metrics || {})
      );
      recordedSteps += 1;
    }

    const insFb = txDb.prepare(
      `INSERT INTO v2_flow_feedback_loop
       (id, workspace_id, trace_id, flow_id, version_id, drop_node_id, trigger_reason, resolution_status, admin_note)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'open', ?)`
    );
    let recordedFeedback = 0;
    for (const fb of feedbackEvents) {
      const reason = VALID_TRIGGER_REASONS.has(fb.triggerReason) ? fb.triggerReason : 'manual_flag';
      insFb.run(
        newId('FBL'),
        wsId,
        traceId,
        fId,
        vId,
        String(fb.dropNodeId || 'unknown'),
        reason,
        String(fb.adminNote || fb.guardCode || '')
      );
      recordedFeedback += 1;
    }

    return { traceId, recordedSteps, recordedFeedback };
  });
}

export function getFlowTelemetryHeatmap(
  { workspaceId = 'default', flowId, versionId = null, windowHours = 24 } = {},
  db = getV2Db()
) {
  initFlowTables(db);
  runFlowRetentionHygiene({}, db);
  const wsId = String(workspaceId || 'default').trim() || 'default';
  const fId = String(flowId || '').trim();
  if (!fId) throw makeHttpError(400, 'ต้องระบุ flowId สำหรับดึง Telemetry');

  const hours = Math.max(1, Math.min(720, Number(windowHours || 24)));
  const sinceIso = new Date(Date.now() - hours * 3600_000).toISOString();
  const params = versionId ? [wsId, fId, String(versionId), sinceIso] : [wsId, fId, sinceIso];
  const verFilter = versionId ? 'AND version_id = ?' : '';

  const rows = db
    .prepare(
      `SELECT node_id, node_type,
              COUNT(*) AS total_hits,
              ROUND(AVG(latency_ms), 1) AS avg_latency_ms,
              SUM(CASE WHEN outcome = 'guard_blocked' THEN 1 ELSE 0 END) AS guard_blocked_count,
              SUM(CASE WHEN outcome = 'handoff' THEN 1 ELSE 0 END) AS handoff_count,
              SUM(CASE WHEN outcome = 'error' THEN 1 ELSE 0 END) AS error_count
       FROM v2_flow_telemetry
       WHERE workspace_id = ? AND flow_id = ? ${verFilter} AND created_at >= ?
       GROUP BY node_id, node_type`
    )
    .all(...params);

  let totalSteps = 0;
  let guardTrips = 0;
  let handoffCount = 0;
  let weightedLatency = 0;

  const nodeStats = rows.map((r) => {
    const hits = Number(r.total_hits || 0);
    const avgLat = Number(r.avg_latency_ms || 0);
    const guards = Number(r.guard_blocked_count || 0);
    const handoffs = Number(r.handoff_count || 0);
    totalSteps += hits;
    guardTrips += guards;
    handoffCount += handoffs;
    weightedLatency += hits * avgLat;
    return {
      nodeId: r.node_id,
      nodeType: r.node_type,
      totalHits: hits,
      avgLatencyMs: avgLat,
      guardBlockedCount: guards,
      handoffCount: handoffs,
      errorCount: Number(r.error_count || 0),
      guardRate: hits > 0 ? Number((guards / hits).toFixed(4)) : 0,
    };
  });

  return {
    flowId: fId,
    versionId: versionId || null,
    windowHours: hours,
    totalSteps,
    guardTrips,
    handoffCount,
    avgLatencyMs: totalSteps > 0 ? Number((weightedLatency / totalSteps).toFixed(1)) : 0,
    handoffRate: totalSteps > 0 ? Number((handoffCount / totalSteps).toFixed(4)) : 0,
    nodeStats,
  };
}

export function listFlowFeedbackItems({ workspaceId = 'default', flowId = null, status = null } = {}, db = getV2Db()) {
  initFlowTables(db);
  const wsId = String(workspaceId || 'default').trim() || 'default';
  const clauses = ['workspace_id = ?'];
  const params = [wsId];
  if (flowId) {
    clauses.push('flow_id = ?');
    params.push(String(flowId).trim());
  }
  if (status && VALID_RESOLUTION_STATUSES.has(String(status))) {
    clauses.push('resolution_status = ?');
    params.push(String(status));
  }
  return db
    .prepare(`SELECT * FROM v2_flow_feedback_loop WHERE ${clauses.join(' AND ')} ORDER BY created_at DESC LIMIT 100`)
    .all(...params);
}

export function resolveFlowFeedbackItem(
  { feedbackId, resolutionStatus = 'resolved_in_version', resolvedInVersionId = null, adminNote = '' } = {},
  db = getV2Db()
) {
  initFlowTables(db);
  const id = String(feedbackId || '').trim();
  if (!id) throw makeHttpError(400, 'ต้องระบุ feedbackId');
  if (!VALID_RESOLUTION_STATUSES.has(resolutionStatus)) {
    throw makeHttpError(400, 'resolutionStatus ไม่ถูกต้อง');
  }

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const existing = txDb.prepare('SELECT * FROM v2_flow_feedback_loop WHERE id = ?').get(id);
    if (!existing) throw makeHttpError(404, 'ไม่พบรายการ Feedback');
    const resolvedAt = resolutionStatus === 'open' ? null : new Date().toISOString();
    txDb
      .prepare(
        `UPDATE v2_flow_feedback_loop
         SET resolution_status = ?, resolved_in_version_id = ?, admin_note = ?, resolved_at = ?
         WHERE id = ?`
      )
      .run(resolutionStatus, resolvedInVersionId ? String(resolvedInVersionId) : null, String(adminNote || ''), resolvedAt, id);
    return txDb.prepare('SELECT * FROM v2_flow_feedback_loop WHERE id = ?').get(id);
  });
}
