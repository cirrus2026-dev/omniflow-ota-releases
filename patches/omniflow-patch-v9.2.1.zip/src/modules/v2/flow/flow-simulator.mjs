// gateway/src/modules/v2/flow/flow-simulator.mjs
// OmniFlow Enterprise v2 — Phase 2 Sandbox Dry-Run Simulator (Isolated from Production Customer Sessions)

import { getV2Db } from '../v2-db.mjs';
import { newId } from '../v2-http.mjs';
import { getFlowDetail } from './flow-repo.mjs';
import { runFlowTurn } from './flow-engine.mjs';
import { recordFlowTurnTelemetry } from './flow-telemetry.service.mjs';

export async function simulateFlowTurn(
  {
    workspaceId = 'default',
    flowId = null,
    useDraft = true,
    executionMode = null,
    mockMessage = {},
    mockImageCosine = null,
    sessionState = {},
    recordTelemetry = true,
    adapters = {},
  } = {},
  db = getV2Db()
) {
  const detail = getFlowDetail(flowId, workspaceId, db);
  const useDraftGraph = useDraft !== false || !detail.activeVersion;
  const graph = useDraftGraph ? detail.draftGraph : detail.activeVersion.graph;
  const effectiveMode = String(
    executionMode ||
      (useDraftGraph ? detail.flow.executionMode : detail.activeVersion?.executionMode || detail.flow.executionMode)
  ).trim();
  const versionId = useDraftGraph ? 'draft' : detail.activeVersion.id;

  const msgObj =
    typeof mockMessage === 'string'
      ? { text: mockMessage }
      : { ...(mockMessage || {}) };
  if (mockImageCosine !== null && mockImageCosine !== undefined && msgObj.mockImageCosine === undefined) {
    msgObj.mockImageCosine = Number(mockImageCosine);
    if (Number.isFinite(msgObj.mockImageCosine)) msgObj.hasImage = true;
  }

  const simulationSessionKey = `sim:${workspaceId}:${detail.flow.id}`;
  const turnResult = await runFlowTurn({
    graph,
    executionMode: effectiveMode,
    message: msgObj,
    sessionState,
    adapters,
    dryRun: true,
  });

  const traceId = newId('SIM');
  if (recordTelemetry !== false) {
    recordFlowTurnTelemetry(
      {
        traceId,
        workspaceId,
        flowId: detail.flow.id,
        versionId,
        executionMode: effectiveMode,
        traceSteps: turnResult.traceSteps,
        feedbackEvents: turnResult.feedbackEvents,
      },
      db
    );
  }

  return {
    traceId,
    simulationSessionKey,
    flowId: detail.flow.id,
    versionId,
    useDraft: useDraftGraph,
    ...turnResult,
  };
}
