// gateway/src/modules/v2/flow/flow-schema.mjs
// OmniFlow Enterprise v2 — Phase 2 Visual AI Flow Builder & Telemetry Loop SQLite DDL Schema

import { getV2Db } from '../v2-db.mjs';

export const FLOW_SCHEMA_DDL = `
CREATE TABLE IF NOT EXISTS v2_flows (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL DEFAULT 'default',
  slug TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  execution_mode TEXT NOT NULL DEFAULT 'hybrid_rules'
    CHECK (execution_mode IN ('smart_agent', 'hybrid_rules', 'strict_guard')),
  status TEXT NOT NULL DEFAULT 'draft'
    CHECK (status IN ('draft', 'published', 'archived')),
  active_version_id TEXT,
  draft_graph_json TEXT NOT NULL DEFAULT '{"nodes":[],"edges":[],"viewport":{"x":0,"y":0,"zoom":1}}',
  channel_bindings_json TEXT NOT NULL DEFAULT '["line","facebook"]',
  is_default INTEGER NOT NULL DEFAULT 0 CHECK (is_default IN (0, 1)),
  created_by TEXT NOT NULL DEFAULT 'system',
  updated_by TEXT NOT NULL DEFAULT 'system',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(workspace_id, slug)
);

CREATE INDEX IF NOT EXISTS idx_v2_flows_ws_status
  ON v2_flows(workspace_id, status, is_default);

CREATE TABLE IF NOT EXISTS v2_flow_versions (
  id TEXT PRIMARY KEY,
  flow_id TEXT NOT NULL REFERENCES v2_flows(id) ON DELETE CASCADE,
  version_num INTEGER NOT NULL,
  execution_mode TEXT NOT NULL
    CHECK (execution_mode IN ('smart_agent', 'hybrid_rules', 'strict_guard')),
  graph_json TEXT NOT NULL,
  checksum_sha256 TEXT NOT NULL,
  changelog TEXT NOT NULL DEFAULT '',
  published_by TEXT NOT NULL DEFAULT 'system',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE(flow_id, version_num)
);

CREATE INDEX IF NOT EXISTS idx_v2_flow_versions_lookup
  ON v2_flow_versions(flow_id, version_num DESC);

CREATE TABLE IF NOT EXISTS v2_flow_sessions (
  session_key TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL DEFAULT 'default',
  channel TEXT NOT NULL,
  external_user_id TEXT NOT NULL,
  flow_id TEXT NOT NULL REFERENCES v2_flows(id) ON DELETE CASCADE,
  version_id TEXT NOT NULL REFERENCES v2_flow_versions(id) ON DELETE CASCADE,
  current_node_id TEXT NOT NULL,
  effective_mode TEXT NOT NULL
    CHECK (effective_mode IN ('smart_agent', 'hybrid_rules', 'strict_guard')),
  lang_lock TEXT NOT NULL DEFAULT 'th' CHECK (lang_lock IN ('th', 'en')),
  lang_lock_until INTEGER NOT NULL DEFAULT 0,
  turn_count INTEGER NOT NULL DEFAULT 0 CHECK (turn_count >= 0 AND turn_count <= 100),
  state_json TEXT NOT NULL DEFAULT '{}',
  expires_at INTEGER NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_v2_flow_sessions_expiry
  ON v2_flow_sessions(expires_at);

CREATE TABLE IF NOT EXISTS v2_flow_telemetry (
  id TEXT PRIMARY KEY,
  trace_id TEXT NOT NULL,
  workspace_id TEXT NOT NULL DEFAULT 'default',
  flow_id TEXT NOT NULL,
  version_id TEXT NOT NULL,
  node_id TEXT NOT NULL,
  node_type TEXT NOT NULL,
  execution_mode TEXT NOT NULL,
  outcome TEXT NOT NULL
    CHECK (outcome IN ('ok', 'branch_miss', 'guard_blocked', 'fallback', 'handoff', 'error')),
  guard_code TEXT,
  latency_ms INTEGER NOT NULL DEFAULT 0,
  masked_input_preview TEXT NOT NULL DEFAULT '',
  metrics_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_v2_flow_telemetry_agg
  ON v2_flow_telemetry(flow_id, version_id, node_id, outcome, created_at);

CREATE INDEX IF NOT EXISTS idx_v2_flow_telemetry_trace
  ON v2_flow_telemetry(trace_id);

CREATE TABLE IF NOT EXISTS v2_flow_feedback_loop (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL DEFAULT 'default',
  trace_id TEXT NOT NULL,
  flow_id TEXT NOT NULL,
  version_id TEXT NOT NULL,
  drop_node_id TEXT NOT NULL,
  trigger_reason TEXT NOT NULL
    CHECK (trigger_reason IN ('admin_takeover', 'math_guard_reject', 'vision_low_conf', 'loop_ceiling', 'manual_flag')),
  resolution_status TEXT NOT NULL DEFAULT 'open'
    CHECK (resolution_status IN ('open', 'resolved_in_version', 'ignored')),
  resolved_in_version_id TEXT,
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  resolved_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_v2_flow_feedback_open
  ON v2_flow_feedback_loop(workspace_id, flow_id, resolution_status, created_at DESC);
`;

export const DEFAULT_STARTER_GRAPH = Object.freeze({
  schemaVersion: '2.0',
  entryNodeId: 'nd_trigger_1',
  viewport: { x: 40, y: 60, zoom: 1.0 },
  nodes: [
    {
      id: 'nd_trigger_1',
      type: 'trigger_inbound',
      label: 'รับข้อความเข้า (LINE / Facebook)',
      icon: 'message-square',
      position: { x: 60, y: 160 },
      config: { channels: ['line', 'facebook'], respectThaiLockMinutes: 60 },
    },
    {
      id: 'nd_router_intent',
      type: 'condition_router',
      label: 'แยกเจตนาลูกค้า',
      icon: 'git-branch',
      position: { x: 340, y: 160 },
      config: {
        rules: [
          { port: 'quote', matchType: 'regex_th', pattern: '(?:ราคา|ตารางเมตร|ตร\\.?ม|แผ่นละ)' },
          { port: 'image', matchType: 'has_attachment', mediaType: 'image' },
        ],
        fallbackPort: 'default',
      },
    },
    {
      id: 'nd_calc_quote',
      type: 'hardguard_math_quote',
      label: 'คำนวณใบเสนอราคา (HardGuard)',
      icon: 'calculator',
      position: { x: 640, y: 80 },
      config: { requireUnitCheck: true, wholesaleMinSqm: 50, enforceCutBelowSlab: true, slabPrice: 1200, cutPrice: 1350 },
    },
    {
      id: 'nd_reply_quote',
      type: 'template_reply',
      label: 'ส่งใบเสนอราคามาตรฐาน',
      icon: 'send',
      position: { x: 930, y: 80 },
      config: { template: 'พื้นที่สุทธิ {{net_area_sqm}} ตร.ม. รวมเป็นเงิน {{total_price_formatted}} บาทครับ' },
    },
    {
      id: 'nd_handoff_1',
      type: 'human_handoff',
      label: 'ส่งต่อแอดมินดูแล',
      icon: 'user-check',
      position: { x: 640, y: 260 },
      config: { reason: 'ลูกค้าต้องการเจ้าหน้าที่ดูแลเพิ่มเติม' },
    },
  ],
  edges: [
    { id: 'ed_1', source: 'nd_trigger_1', sourcePort: 'out', target: 'nd_router_intent' },
    { id: 'ed_2', source: 'nd_router_intent', sourcePort: 'quote', target: 'nd_calc_quote' },
    { id: 'ed_3', source: 'nd_calc_quote', sourcePort: 'out', target: 'nd_reply_quote' },
    { id: 'ed_4', source: 'nd_router_intent', sourcePort: 'default', target: 'nd_handoff_1' },
    { id: 'ed_5', source: 'nd_calc_quote', sourcePort: 'guard_blocked', target: 'nd_handoff_1' },
  ],
});

const initializedDbs = new WeakSet();

export function initFlowTables(db = getV2Db()) {
  if (!db) throw new Error('initFlowTables requires an active SQLite DatabaseSync instance');
  if (!initializedDbs.has(db)) {
    db.exec(FLOW_SCHEMA_DDL);
    initializedDbs.add(db);
  }
  return db;
}
