// gateway/src/modules/v2/flow/flow-engine.mjs
// OmniFlow Enterprise v2 — Phase 2 Directed Graph Execution Engine (3 Modes + Step Ceiling <= 25 + Thai Lock)

import { makeHttpError } from '../v2-http.mjs';
import {
  WAKE_BOT_RE,
  executeFlowNode,
  extractAndMaskPhones,
  maskSensitivePreview,
} from './flow-node-executors.mjs';
import { MAX_SESSION_STATE_BYTES, MAX_SESSION_TURNS, THAI_LOCK_MS } from './flow-repo.mjs';

export const MAX_STEPS_PER_TURN = 25;

function findNextEdge(edges, sourceId, port) {
  const outgoing = edges.filter((e) => e.source === sourceId);
  if (outgoing.length === 0) return null;
  const exact = outgoing.find((e) => (e.sourcePort || 'out') === port);
  if (exact) return exact;
  if (port === 'out') return outgoing[0];
  return outgoing.find((e) => e.sourcePort === 'default') || null;
}

export async function runFlowTurn({
  graph,
  executionMode = 'hybrid_rules',
  message = {},
  sessionState = {},
  adapters = {},
  dryRun = false,
} = {}) {
  if (!graph || !Array.isArray(graph.nodes) || !Array.isArray(graph.edges)) {
    throw makeHttpError(400, 'Invalid flow graph supplied to runFlowTurn');
  }

  const nowMs = Date.now();
  const rawText = String(message.text || '');
  const state = {
    slots: { ...(sessionState.slots || {}) },
    vars: { ...(sessionState.vars || {}) },
    crmPhones: [...(sessionState.crmPhones || [])],
    adminTakeover: Boolean(sessionState.adminTakeover),
    turnCount: Number(sessionState.turnCount || 0),
    langLock: 'th',
    langLockUntil: nowMs + THAI_LOCK_MS,
  };

  if (state.turnCount >= MAX_SESSION_TURNS) {
    throw makeHttpError(429, `Session turn count exceeded limit (${MAX_SESSION_TURNS})`);
  }

  if (state.adminTakeover) {
    if (!WAKE_BOT_RE.test(rawText)) {
      return {
        ok: true,
        haltedByTakeover: true,
        adminTakeover: true,
        executionMode,
        langLock: 'th',
        replies: [],
        traceSteps: [],
        feedbackEvents: [],
        state,
      };
    }
    state.adminTakeover = false;
  }

  const { maskedText, phones } = extractAndMaskPhones(rawText);
  if (phones.length > 0) {
    for (const p of phones) {
      if (!state.crmPhones.includes(p)) state.crmPhones.push(p);
    }
  }

  const nodeMap = new Map(graph.nodes.map((n) => [n.id, n]));
  const triggerNode =
    nodeMap.get(graph.entryNodeId) ||
    graph.nodes.find((n) => n.type === 'trigger_inbound') ||
    graph.nodes[0];

  if (!triggerNode) {
    throw makeHttpError(400, 'Flow graph has no entry node');
  }

  const ctx = {
    rawText,
    maskedText,
    message,
    state,
    replies: [],
    dryRun,
  };

  const traceSteps = [];
  const feedbackEvents = [];
  let currentNode = triggerNode;
  let stepCount = 0;
  let loopCut = false;

  while (currentNode && stepCount < MAX_STEPS_PER_TURN) {
    stepCount += 1;
    const t0 = performance.now();

    if (
      executionMode === 'strict_guard' &&
      (currentNode.type === 'agent_brain' || currentNode.type === 'slot_extractor_ai')
    ) {
      throw makeHttpError(400, `Forbidden LLM node "${currentNode.type}" in strict_guard runtime`);
    }
    if (executionMode === 'hybrid_rules' && currentNode.type === 'agent_brain') {
      throw makeHttpError(400, 'Forbidden agent_brain node in hybrid_rules runtime');
    }

    const res = await executeFlowNode(currentNode, ctx, adapters);
    const latencyMs = Math.max(0, Math.round(performance.now() - t0));
    const port = res?.port || 'out';
    const outcome = res?.outcome || 'ok';

    traceSteps.push({
      stepIndex: stepCount,
      nodeId: currentNode.id,
      nodeType: currentNode.type,
      label: currentNode.label || currentNode.id,
      executionMode,
      port,
      outcome,
      guardCode: res?.guardCode || null,
      latencyMs,
      maskedInputPreview: maskSensitivePreview(maskedText),
      metrics: res?.metrics || {},
    });

    if (res?.triggerReason) {
      feedbackEvents.push({
        dropNodeId: currentNode.id,
        triggerReason: res.triggerReason,
        guardCode: res.guardCode || null,
      });
    }

    if (currentNode.type === 'human_handoff') break;

    const nextEdge = findNextEdge(graph.edges, currentNode.id, port);
    if (!nextEdge) break;

    const nextNode = nodeMap.get(nextEdge.target);
    if (!nextNode) break;

    if (stepCount === MAX_STEPS_PER_TURN) {
      loopCut = true;
      traceSteps.push({
        stepIndex: stepCount + 1,
        nodeId: nextNode.id,
        nodeType: nextNode.type,
        label: nextNode.label || nextNode.id,
        executionMode,
        port: 'halt',
        outcome: 'guard_blocked',
        guardCode: 'LOOP_CEILING_25',
        latencyMs: 0,
        maskedInputPreview: maskSensitivePreview(maskedText),
        metrics: { maxStepsPerTurn: MAX_STEPS_PER_TURN },
      });
      feedbackEvents.push({
        dropNodeId: nextNode.id,
        triggerReason: 'loop_ceiling',
        guardCode: 'LOOP_CEILING_25',
      });
      break;
    }

    currentNode = nextNode;
  }

  state.turnCount += 1;
  const serializedState = JSON.stringify(state);
  if (Buffer.byteLength(serializedState, 'utf8') > MAX_SESSION_STATE_BYTES) {
    throw makeHttpError(413, 'Flow session state_json exceeded 64KB cap (AP-08)');
  }

  return {
    ok: true,
    haltedByTakeover: false,
    adminTakeover: Boolean(state.adminTakeover),
    loopCut,
    stepCount,
    executionMode,
    langLock: state.langLock,
    maskedInputPreview: maskSensitivePreview(maskedText),
    replies: ctx.replies,
    traceSteps,
    feedbackEvents,
    state,
  };
}
