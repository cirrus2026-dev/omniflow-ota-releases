// gateway/src/modules/v2/flow/flow-node-executors.mjs
// OmniFlow Enterprise v2 — Phase 2 Deterministic Node Executors (HardGuard Math, Vision >=0.82, Thai Regex, SSRF Guard)

import { isAreaUnitLabel, resolveQtyAreaSignal } from '../../qty-area-helper.mjs';
import { assertSafePublicUrl, fetchSafe, isPrivateOrReservedIp } from '../../fetch-safe.mjs';

export const WAKE_BOT_RE = /(?:^|\s)#บอท(?:\s|$)/;
const THAI_PHONE_RE = /(?:\+66|0)\d{1,2}[-\s]?\d{3}[-\s]?\d{3,4}/g;
const DISCRETE_BAG_RE = /(?:ปูนกาว|กาวยาแนว|ถุง|กระสอบ|bag)/i;
const DIMS_TEXT_RE = /(\d+(?:\.\d+)?)\s*[xX*×]\s*(\d+(?:\.\d+)?)\s*(ซม\.?|เซนติเมตร|cm|ม\.?|เมตร|m)?/i;
const AREA_TEXT_RE = /(\d+(?:\.\d+)?)\s*(ตร\.?\s*ม\.?|ตารางเมตร|sqm|sq\.?\s*m)/i;
const PIECE_TEXT_RE = /(\d+(?:\.\d+)?)\s*(แผ่น|ชิ้น|กล่อง|ห้อง)/i;

export function extractAndMaskPhones(rawText = '') {
  const text = String(rawText ?? '');
  const phones = [];
  const maskedText = text.replace(THAI_PHONE_RE, (m) => {
    phones.push(m.replace(/[-\s]/g, ''));
    return '[เบอร์ติดต่อของลูกค้า]';
  });
  return { maskedText, phones, hasPhone: phones.length > 0 };
}

export function maskSensitivePreview(rawText = '', maxLen = 120) {
  return extractAndMaskPhones(rawText).maskedText.trim().slice(0, maxLen);
}

export function interpolateSafeTemplate(template = '', vars = {}) {
  return String(template ?? '').replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_m, key) =>
    String(vars[key] ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
  );
}

function parseMathSlotsFromText(rawText = '', existingSlots = {}) {
  const text = String(rawText ?? '');
  const out = { ...existingSlots };
  if (out.widthM === undefined || out.lengthM === undefined) {
    const dm = text.match(DIMS_TEXT_RE);
    if (dm) {
      const scale = /^(?:ซม|เซน|cm)/i.test(String(dm[3] || '').trim()) ? 0.01 : 1;
      out.widthM = Number(dm[1]) * scale;
      out.lengthM = Number(dm[2]) * scale;
    }
  }
  const am = text.match(AREA_TEXT_RE);
  const pm = text.match(PIECE_TEXT_RE);
  if (am && out.qty === undefined) {
    out.qty = Number(am[1]);
    out.unitLabel = am[2];
  } else if (pm && out.qty === undefined) {
    out.qty = Number(pm[1]);
    out.unitLabel = pm[2];
  }
  if (DISCRETE_BAG_RE.test(text) && !out.productUnit) out.productUnit = 'ถุง';
  return out;
}

export function runHardGuardMathQuote(rawInput = {}, config = {}) {
  const slots = parseMathSlotsFromText(rawInput.text || '', rawInput.slots || rawInput);
  const rawText = String(rawInput.text || '');
  const isDiscreteBag = slots.productUnit === 'ถุง' || slots.productUnit === 'bag' || DISCRETE_BAG_RE.test(rawText);
  const mentionsArea = isAreaUnitLabel(slots.unitLabel) || AREA_TEXT_RE.test(rawText) || Number(slots.unitMismatchAreaSqm) > 0;

  if (config.requireUnitCheck !== false && isDiscreteBag && mentionsArea) {
    return {
      ok: false,
      port: 'guard_blocked',
      outcome: 'guard_blocked',
      guardCode: 'UNIT_MISMATCH_SQM',
      triggerReason: 'math_guard_reject',
      error: 'ห้ามคูณพื้นที่ (ตร.ม.) ข้ามหน่วยกับสินค้าที่ขายเป็นถุงโดยตรง (AP-20)',
    };
  }

  const resolved = resolveQtyAreaSignal({
    widthM: slots.widthM !== undefined ? Number(slots.widthM) : NaN,
    lengthM: slots.lengthM !== undefined ? Number(slots.lengthM) : NaN,
    qty: slots.qty !== undefined ? Number(slots.qty) : NaN,
    unitLabel: slots.unitLabel || '',
  });

  let netAreaSqm = 0;
  if (resolved.hasDims) {
    const baseArea = Number(resolved.sigObj.widthM) * Number(resolved.sigObj.lengthM);
    const mult = !Number.isNaN(Number(resolved.sigObj.qty)) && Number(resolved.sigObj.qty) > 0 ? Number(resolved.sigObj.qty) : 1;
    netAreaSqm = Number((baseArea * mult).toFixed(4));
  } else if (!Number.isNaN(Number(resolved.sigObj.qty)) && Number(resolved.sigObj.qty) > 0) {
    netAreaSqm = Number(Number(resolved.sigObj.qty).toFixed(4));
  }

  if (netAreaSqm <= 0) {
    return { ok: false, port: 'missing_slot_prompt', outcome: 'branch_miss', guardCode: 'MISSING_AREA_DIMENSIONS', netAreaSqm: 0 };
  }

  const wholesaleMinSqm = Number(config.wholesaleMinSqm ?? 50);
  const slabPrice = Number(slots.slabPrice ?? config.slabPrice ?? 1200);
  const cutPrice = Number(slots.cutPrice ?? config.cutPrice ?? 1350);
  let unitPrice = netAreaSqm >= wholesaleMinSqm ? slabPrice : cutPrice;
  let guardNotice = null;

  if (netAreaSqm >= wholesaleMinSqm && config.enforceCutBelowSlab !== false) {
    if (cutPrice < slabPrice) {
      unitPrice = cutPrice;
    } else {
      unitPrice = slabPrice;
      guardNotice = 'ENFORCED_SLAB_NOT_OVERRIDDEN_BY_HIGHER_CUT';
    }
  }

  const totalPrice = Math.round(netAreaSqm * unitPrice);
  return {
    ok: true,
    port: 'out',
    outcome: 'ok',
    netAreaSqm,
    unitPrice,
    totalPrice,
    totalPriceFormatted: totalPrice.toLocaleString('en-US'),
    guardNotice,
  };
}

function defaultLlmSlotAdapter({ maskedText, currentSlots = {} }) {
  const extracted = parseMathSlotsFromText(maskedText, currentSlots);
  const hasAny = Number.isFinite(Number(extracted.widthM)) || Number.isFinite(Number(extracted.qty));
  return { slots: extracted, confidence: hasAny ? 0.92 : 0.45, promptSeen: maskedText };
}

export async function executeFlowNode(node, ctx = {}, adapters = {}) {
  const type = node?.type;
  const cfg = node?.config || {};
  const maskedText = ctx.maskedText ?? extractAndMaskPhones(ctx.rawText || '').maskedText;

  if (type === 'trigger_inbound') return { port: 'out', outcome: 'ok', metrics: { langLock: 'th' } };

  if (type === 'condition_router') {
    for (const rule of Array.isArray(cfg.rules) ? cfg.rules : []) {
      if (rule.matchType === 'has_attachment' && ctx.message?.hasImage) return { port: rule.port || 'image', outcome: 'ok' };
      if ((rule.matchType === 'regex_th' || rule.matchType === 'regex') && rule.pattern && new RegExp(rule.pattern, 'iu').test(maskedText)) {
        return { port: rule.port || 'out', outcome: 'ok' };
      }
      if (rule.matchType === 'keyword' && rule.keyword && maskedText.includes(rule.keyword)) return { port: rule.port || 'out', outcome: 'ok' };
    }
    return { port: cfg.fallbackPort || 'default', outcome: 'fallback' };
  }

  if (type === 'slot_extractor_ai') {
    const llmFn = typeof adapters.llmAdapter === 'function' ? adapters.llmAdapter : defaultLlmSlotAdapter;
    const res = await llmFn({ maskedText, currentSlots: ctx.state?.slots || {}, langLock: 'th' });
    const confidence = Number(res?.confidence ?? 0);
    ctx.state.slots = { ...(ctx.state.slots || {}), ...(res?.slots || {}) };
    ctx.state.lastLlmPrompt = maskedText;
    if (confidence < Number(cfg.minConfidence ?? 0.75)) {
      return { port: 'missing_slot_prompt', outcome: 'branch_miss', guardCode: 'LOW_SLOT_CONFIDENCE', metrics: { confidence } };
    }
    return { port: 'out', outcome: 'ok', metrics: { confidence } };
  }

  if (type === 'vision_match') {
    const minCosine = Number(cfg.minCosine ?? 0.82);
    const sim = Number(ctx.message?.mockImageCosine ?? adapters.visionSimilarity ?? 0);
    const llmConfirmed = ctx.message?.mockVisionConfirmed !== false && adapters.visionConfirmed !== false;
    if (sim >= minCosine && llmConfirmed) return { port: 'matched', outcome: 'ok', metrics: { cosineSimilarity: sim } };
    return { port: 'uncertain', outcome: 'guard_blocked', guardCode: 'VISION_BELOW_THRESHOLD', triggerReason: 'vision_low_conf', metrics: { cosineSimilarity: sim, minCosine } };
  }

  if (type === 'hardguard_math_quote') {
    const q = runHardGuardMathQuote({ text: maskedText, slots: ctx.state?.slots || {} }, cfg);
    if (q.ok) ctx.state.vars = { ...(ctx.state.vars || {}), net_area_sqm: q.netAreaSqm, unit_price: q.unitPrice, total_price: q.totalPrice, total_price_formatted: q.totalPriceFormatted };
    return { port: q.port, outcome: q.outcome, guardCode: q.guardCode || null, triggerReason: q.triggerReason || null, metrics: q };
  }

  if (type === 'template_reply') {
    const text = interpolateSafeTemplate(cfg.template || '', { customer_name: ctx.message?.customerName || 'คุณลูกค้า', ...(ctx.state?.vars || {}) });
    const deliveryOk = ctx.message?.simulateDeliveryFail !== true;
    if (deliveryOk) ctx.replies.push(text);
    return { port: 'out', outcome: deliveryOk ? 'ok' : 'error', metrics: { replyText: text, committed: deliveryOk } };
  }

  if (type === 'agent_brain') {
    const maxHops = Math.min(4, Number(cfg.maxToolHops ?? 4));
    const q = runHardGuardMathQuote({ text: maskedText, slots: ctx.state?.slots || {} }, cfg);
    ctx.state.lastLlmPrompt = maskedText;
    if (q.ok) {
      ctx.state.vars = { ...(ctx.state.vars || {}), net_area_sqm: q.netAreaSqm, total_price_formatted: q.totalPriceFormatted };
      return { port: 'out', outcome: 'ok', metrics: { toolHops: 1, maxHops, quote: q } };
    }
    return { port: q.port, outcome: q.outcome, guardCode: q.guardCode || null, triggerReason: q.triggerReason || null };
  }

  if (type === 'http_webhook') {
    try {
      const checked = await assertSafePublicUrl(String(cfg.url || '').trim(), { allowHttp: true });
      if (checked.addresses.some((ip) => isPrivateOrReservedIp(ip))) throw Object.assign(new Error('Private IP blocked'), { code: 'ERR_SSRF_BLOCKED' });
      const timeoutMs = Math.min(4000, Number(cfg.timeoutMs || 4000));
      if (typeof adapters.fetchImpl === 'function') await adapters.fetchImpl(checked.href, { timeoutMs });
      else if (!ctx.dryRun) await fetchSafe(checked.href, { allowHttp: false, timeoutMs });
      return { port: 'out', outcome: 'ok' };
    } catch (err) {
      return { port: 'error', outcome: 'guard_blocked', guardCode: err?.code || 'ERR_SSRF_BLOCKED' };
    }
  }

  if (type === 'human_handoff') {
    const deliveryOk = ctx.message?.simulateDeliveryFail !== true;
    if (deliveryOk) ctx.state.adminTakeover = true;
    return { port: 'out', outcome: deliveryOk ? 'handoff' : 'error', triggerReason: deliveryOk ? 'admin_takeover' : null, metrics: { adminTakeover: Boolean(ctx.state.adminTakeover) } };
  }

  return { port: 'out', outcome: 'ok' };
}
