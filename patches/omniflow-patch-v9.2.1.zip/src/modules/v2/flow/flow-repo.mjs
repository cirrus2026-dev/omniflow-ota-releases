// gateway/src/modules/v2/flow/flow-repo.mjs
// OmniFlow Enterprise v2 — Phase 2 Synchronous SQLite Repository for Flows, Versions & Sessions

import { getV2Db, withV2Transaction } from '../v2-db.mjs';
import { makeHttpError, newId } from '../v2-http.mjs';
import { DEFAULT_STARTER_GRAPH, initFlowTables } from './flow-schema.mjs';
import {
  canonicalizeGraphJson,
  computeGraphSha256,
  validateFlowGraph,
  verifyGraphSha256,
} from './flow-validator.mjs';

export const SESSION_TTL_MS = 24 * 60 * 60 * 1000;
export const THAI_LOCK_MS = 60 * 60 * 1000;
export const MAX_SESSION_TURNS = 100;
export const MAX_SESSION_STATE_BYTES = 65536;

function safeParseJson(raw, fallback) {
  try {
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function normalizeSlug(raw, fallbackName = 'flow') {
  const base = String(raw || fallbackName)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48);
  return base || `flow-${Date.now().toString(36)}`;
}

function formatFlowRow(row, latestVersionNum = 0) {
  if (!row) return null;
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    slug: row.slug,
    name: row.name,
    description: row.description,
    executionMode: row.execution_mode,
    status: row.status,
    activeVersionId: row.active_version_id || null,
    latestVersionNum: Number(latestVersionNum || 0),
    channelBindings: safeParseJson(row.channel_bindings_json, ['line', 'facebook']),
    isDefault: Number(row.is_default) === 1,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function ensureDefaultWorkspaceFlow(workspaceId = 'default', db = getV2Db()) {
  initFlowTables(db);
  const wsId = String(workspaceId || 'default').trim() || 'default';
  const cnt = Number(db.prepare('SELECT COUNT(*) AS cnt FROM v2_flows WHERE workspace_id = ?').get(wsId)?.cnt || 0);
  if (cnt > 0) return;
  createFlow(
    {
      workspaceId: wsId,
      name: 'Stone & Construction Standard Flow',
      slug: 'default-stone-sales',
      description: 'กราฟมาตรฐานคัดกรองลูกค้า คำนวณราคาหิน HardGuard และส่งต่อแอดมิน',
      executionMode: 'hybrid_rules',
      channelBindings: ['line', 'facebook'],
      isDefault: true,
      draftGraph: DEFAULT_STARTER_GRAPH,
      actorId: 'system',
    },
    db
  );
}

export function listFlows(workspaceId = 'default', db = getV2Db()) {
  initFlowTables(db);
  const wsId = String(workspaceId || 'default').trim() || 'default';
  ensureDefaultWorkspaceFlow(wsId, db);
  return db
    .prepare(
      `SELECT f.*, COALESCE((SELECT MAX(v.version_num) FROM v2_flow_versions v WHERE v.flow_id = f.id), 0) AS latest_version_num
       FROM v2_flows f WHERE f.workspace_id = ? ORDER BY f.is_default DESC, f.updated_at DESC`
    )
    .all(wsId)
    .map((r) => formatFlowRow(r, r.latest_version_num));
}

export function getFlowDetail(flowId, workspaceId = 'default', db = getV2Db()) {
  initFlowTables(db);
  const wsId = String(workspaceId || 'default').trim() || 'default';
  ensureDefaultWorkspaceFlow(wsId, db);
  const row = flowId
    ? db.prepare('SELECT * FROM v2_flows WHERE id = ?').get(String(flowId).trim())
    : db.prepare('SELECT * FROM v2_flows WHERE workspace_id = ? ORDER BY is_default DESC, updated_at DESC LIMIT 1').get(wsId);
  if (!row) throw makeHttpError(404, 'ไม่พบข้อมูล Flow ที่ระบุ');

  const versions = db
    .prepare(
      `SELECT id, flow_id, version_num, execution_mode, checksum_sha256, changelog, published_by, created_at
       FROM v2_flow_versions WHERE flow_id = ? ORDER BY version_num DESC LIMIT 20`
    )
    .all(row.id);

  const activeVer = row.active_version_id
    ? db.prepare('SELECT * FROM v2_flow_versions WHERE id = ?').get(row.active_version_id)
    : null;

  return {
    flow: formatFlowRow(row, versions[0]?.version_num || 0),
    draftGraph: safeParseJson(row.draft_graph_json, DEFAULT_STARTER_GRAPH),
    activeVersion: activeVer
      ? {
          id: activeVer.id,
          versionNum: activeVer.version_num,
          executionMode: activeVer.execution_mode,
          checksumSha256: activeVer.checksum_sha256,
          graph: safeParseJson(activeVer.graph_json, DEFAULT_STARTER_GRAPH),
          createdAt: activeVer.created_at,
        }
      : null,
    versions,
  };
}

export function createFlow(payload = {}, db = getV2Db()) {
  initFlowTables(db);
  const wsId = String(payload.workspaceId || 'default').trim() || 'default';
  const name = String(payload.name || '').trim();
  if (!name) throw makeHttpError(400, 'กรุณาระบุชื่อ Flow');
  const executionMode = String(payload.executionMode || 'hybrid_rules').trim();
  const graph = payload.draftGraph || DEFAULT_STARTER_GRAPH;
  validateFlowGraph(graph, executionMode);

  const flowId = newId('FLW');
  const slug = normalizeSlug(payload.slug, name);
  const bindings = Array.isArray(payload.channelBindings) ? payload.channelBindings : ['line', 'facebook'];
  const actor = String(payload.actorId || 'system').trim() || 'system';

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const dup = txDb.prepare('SELECT id FROM v2_flows WHERE workspace_id = ? AND slug = ?').get(wsId, slug);
    const finalSlug = dup ? `${slug}-${flowId.slice(-4).toLowerCase()}` : slug;
    txDb
      .prepare(
        `INSERT INTO v2_flows (id, workspace_id, slug, name, description, execution_mode, status, draft_graph_json, channel_bindings_json, is_default, created_by, updated_by)
         VALUES (?, ?, ?, ?, ?, ?, 'draft', ?, ?, ?, ?, ?)`
      )
      .run(flowId, wsId, finalSlug, name, String(payload.description || ''), executionMode, canonicalizeGraphJson(graph), JSON.stringify(bindings), payload.isDefault ? 1 : 0, actor, actor);
    return getFlowDetail(flowId, wsId, txDb);
  });
}

export function saveFlowDraft({ flowId, workspaceId = 'default', draftGraph, executionMode, name, description, channelBindings, actorId = 'system' } = {}, db = getV2Db()) {
  initFlowTables(db);
  const id = String(flowId || '').trim();
  if (!id) throw makeHttpError(400, 'ต้องระบุ flowId');

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const existing = txDb.prepare('SELECT * FROM v2_flows WHERE id = ?').get(id);
    if (!existing) throw makeHttpError(404, 'ไม่พบ Flow ที่ต้องการบันทึก');

    const nextMode = String(executionMode || existing.execution_mode).trim();
    const nextGraph = draftGraph !== undefined ? draftGraph : safeParseJson(existing.draft_graph_json, DEFAULT_STARTER_GRAPH);
    validateFlowGraph(nextGraph, nextMode);

    const nextName = name !== undefined ? String(name).trim() || existing.name : existing.name;
    const nextDesc = description !== undefined ? String(description) : existing.description;
    const nextBindings = Array.isArray(channelBindings) ? JSON.stringify(channelBindings) : existing.channel_bindings_json;

    txDb
      .prepare(
        `UPDATE v2_flows SET name = ?, description = ?, execution_mode = ?, draft_graph_json = ?,
             channel_bindings_json = ?, updated_by = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
         WHERE id = ?`
      )
      .run(nextName, nextDesc, nextMode, canonicalizeGraphJson(nextGraph), nextBindings, String(actorId || 'system'), id);
    return getFlowDetail(id, workspaceId, txDb);
  });
}

export function publishFlowVersion({ flowId, workspaceId = 'default', changelog = '', actorId = 'system' } = {}, db = getV2Db()) {
  initFlowTables(db);
  const id = String(flowId || '').trim();
  if (!id) throw makeHttpError(400, 'ต้องระบุ flowId สำหรับ Publish');

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const flow = txDb.prepare('SELECT * FROM v2_flows WHERE id = ?').get(id);
    if (!flow) throw makeHttpError(404, 'ไม่พบ Flow ที่ต้องการ Publish');

    const graphObj = safeParseJson(flow.draft_graph_json, null);
    validateFlowGraph(graphObj, flow.execution_mode);
    const canonical = canonicalizeGraphJson(graphObj);
    const checksum = computeGraphSha256(canonical);
    const versionNum = Number(txDb.prepare('SELECT MAX(version_num) AS mv FROM v2_flow_versions WHERE flow_id = ?').get(id)?.mv || 0) + 1;
    const versionId = newId('FLV');
    const actor = String(actorId || 'system');

    txDb
      .prepare('INSERT INTO v2_flow_versions (id, flow_id, version_num, execution_mode, graph_json, checksum_sha256, changelog, published_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
      .run(versionId, id, versionNum, flow.execution_mode, canonical, checksum, String(changelog || ''), actor);
    txDb
      .prepare("UPDATE v2_flows SET status = 'published', active_version_id = ?, updated_by = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
      .run(versionId, actor, id);

    return { versionId, versionNum, checksumSha256: checksum, ...getFlowDetail(id, workspaceId, txDb) };
  });
}

export function rollbackFlowVersion({ flowId, versionId, workspaceId = 'default', actorId = 'system' } = {}, db = getV2Db()) {
  initFlowTables(db);
  const fId = String(flowId || '').trim();
  const vId = String(versionId || '').trim();
  if (!fId || !vId) throw makeHttpError(400, 'ต้องระบุ flowId และ versionId สำหรับ Rollback');

  return withV2Transaction((txDb) => {
    initFlowTables(txDb);
    const ver = txDb.prepare('SELECT * FROM v2_flow_versions WHERE id = ? AND flow_id = ?').get(vId, fId);
    if (!ver) throw makeHttpError(404, 'ไม่พบเวอร์ชันที่ต้องการ Rollback');
    if (!verifyGraphSha256(ver.graph_json, ver.checksum_sha256)) {
      throw makeHttpError(409, 'SHA-256 Checksum ของเวอร์ชันนี้ไม่ตรงกับข้อมูลในระบบ (AP-11 Integrity Block)');
    }
    validateFlowGraph(safeParseJson(ver.graph_json, null), ver.execution_mode);
    txDb
      .prepare("UPDATE v2_flows SET active_version_id = ?, execution_mode = ?, draft_graph_json = ?, status = 'published', updated_by = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
      .run(vId, ver.execution_mode, ver.graph_json, String(actorId || 'system'), fId);

    return { rolledBackToVersionId: vId, versionNum: ver.version_num, checksumSha256: ver.checksum_sha256, ...getFlowDetail(fId, workspaceId, txDb) };
  });
}
