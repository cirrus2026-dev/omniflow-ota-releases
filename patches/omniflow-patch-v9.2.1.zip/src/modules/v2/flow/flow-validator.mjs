// gateway/src/modules/v2/flow/flow-validator.mjs
// OmniFlow Enterprise v2 — Phase 2 Flow Graph Validator, Thai Regex Guard, Mode Isolation & SHA-256 Verifier

import crypto from 'node:crypto';
import { makeHttpError } from '../v2-http.mjs';

export const VALID_EXECUTION_MODES = Object.freeze(['smart_agent', 'hybrid_rules', 'strict_guard']);
export const ALLOWED_NODE_TYPES = Object.freeze([
  'trigger_inbound',
  'condition_router',
  'slot_extractor_ai',
  'vision_match',
  'hardguard_math_quote',
  'template_reply',
  'agent_brain',
  'http_webhook',
  'human_handoff',
]);

const VALID_MODES_SET = new Set(VALID_EXECUTION_MODES);
const ALLOWED_NODES_SET = new Set(ALLOWED_NODE_TYPES);
export const THAI_WORD_BOUNDARY_HAZARD_RE = /\\b[^\n]*[\u0E00-\u0E7F]|[\u0E00-\u0E7F][^\n]*\\b/;
export const SAFE_DATA_IMG_RE = /^data:image\/(?:png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=]+$/i;
export const MAX_NODES_PER_FLOW = 80;
export const MAX_GRAPH_BYTES = 65536;

export function isSafePreviewImageUrl(rawUrl) {
  const val = String(rawUrl ?? '').trim();
  if (!val) return true;
  if (val.length > 2_000_000) return false;
  if (SAFE_DATA_IMG_RE.test(val)) return true;
  if (val.startsWith('/') && !val.startsWith('//')) return true;
  try {
    const parsed = new URL(val);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

export function canonicalizeGraphJson(graph) {
  if (typeof graph === 'string') {
    const trimmed = graph.trim();
    if (!trimmed) throw makeHttpError(400, 'Graph JSON string cannot be empty');
    return JSON.stringify(JSON.parse(trimmed));
  }
  if (!graph || typeof graph !== 'object') {
    throw makeHttpError(400, 'Graph must be a non-null object');
  }
  return JSON.stringify(graph);
}

export function computeGraphSha256(canonicalJsonString) {
  const buf = Buffer.from(String(canonicalJsonString ?? ''), 'utf8');
  if (buf.byteLength === 0) {
    throw makeHttpError(400, 'Cannot compute SHA-256 on empty graph buffer');
  }
  return crypto.createHash('sha256').update(buf).digest('hex');
}

export function verifyGraphSha256(canonicalJsonString, expectedHex) {
  if (typeof expectedHex !== 'string' || !/^[0-9a-f]{64}$/i.test(expectedHex)) return false;
  const actualHex = computeGraphSha256(canonicalJsonString);
  return crypto.timingSafeEqual(
    Buffer.from(actualHex, 'utf8'),
    Buffer.from(expectedHex.toLowerCase(), 'utf8')
  );
}

export function validateFlowGraph(graph, executionMode = 'hybrid_rules') {
  if (!VALID_MODES_SET.has(executionMode)) {
    throw makeHttpError(400, `Invalid execution_mode: ${executionMode}`);
  }
  if (!graph || typeof graph !== 'object' || !Array.isArray(graph.nodes) || !Array.isArray(graph.edges)) {
    throw makeHttpError(400, 'Flow graph requires nodes[] and edges[] arrays');
  }
  if (graph.nodes.length === 0 || graph.nodes.length > MAX_NODES_PER_FLOW) {
    throw makeHttpError(400, `Flow must contain 1..${MAX_NODES_PER_FLOW} nodes`);
  }

  const serialized = JSON.stringify(graph);
  if (Buffer.byteLength(serialized, 'utf8') > MAX_GRAPH_BYTES) {
    throw makeHttpError(400, `Flow graph exceeds maximum size (${MAX_GRAPH_BYTES} bytes)`);
  }

  const nodeIds = new Set();
  let triggerCount = 0;

  for (const node of graph.nodes) {
    const id = String(node?.id || '').trim();
    if (!id || nodeIds.has(id)) {
      throw makeHttpError(400, `Invalid or duplicate node id: "${id}"`);
    }
    if (!ALLOWED_NODES_SET.has(node.type)) {
      throw makeHttpError(400, `Unsupported node type: "${node.type}"`);
    }
    if (executionMode === 'strict_guard' && (node.type === 'agent_brain' || node.type === 'slot_extractor_ai')) {
      throw makeHttpError(400, `Node type "${node.type}" is forbidden in strict_guard mode`);
    }
    if (executionMode === 'hybrid_rules' && node.type === 'agent_brain') {
      throw makeHttpError(400, 'Node type "agent_brain" is only permitted in smart_agent mode');
    }
    if (node.type === 'trigger_inbound') triggerCount += 1;

    if (node.type === 'condition_router' && Array.isArray(node.config?.rules)) {
      for (const rule of node.config.rules) {
        if (typeof rule?.pattern === 'string') {
          if (THAI_WORD_BOUNDARY_HAZARD_RE.test(rule.pattern)) {
            throw makeHttpError(
              400,
              `Anti-Pattern AP-16 violation: "\\b" cannot be used with Thai characters in node "${id}"`
            );
          }
          try {
            new RegExp(rule.pattern, 'u');
          } catch (err) {
            throw makeHttpError(400, `Invalid regex pattern in node "${id}": ${err.message}`);
          }
        }
      }
    }

    const previewImg = node.config?.previewImageUrl ?? node.config?.imageUrl ?? '';
    if (previewImg && !isSafePreviewImageUrl(previewImg)) {
      throw makeHttpError(400, `Unsafe previewImageUrl in node "${id}" (AP-23 guard)`);
    }

    nodeIds.add(id);
  }

  if (triggerCount !== 1) {
    throw makeHttpError(400, 'Flow graph must have exactly 1 trigger_inbound node');
  }

  for (const edge of graph.edges) {
    if (!nodeIds.has(edge?.source) || !nodeIds.has(edge?.target)) {
      throw makeHttpError(400, `Edge "${edge?.id || ''}" references non-existent node`);
    }
  }

  return { ok: true, nodeCount: graph.nodes.length, edgeCount: graph.edges.length };
}
