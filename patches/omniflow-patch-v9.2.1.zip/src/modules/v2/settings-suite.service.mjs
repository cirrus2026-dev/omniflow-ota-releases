// gateway/src/modules/v2/settings-suite.service.mjs
// OmniFlow Enterprise v2 — Phase 1A Missing Settings Suite (5 Categories), Password Change, Startup Script & Diagnostics

import { getV2Db, getV2DbHealth, withV2Transaction } from './v2-db.mjs';
import { hashPassword, makeHttpError, verifyPassword } from './v2-http.mjs';
import { ensurePhase1ASchema } from './auth-session.service.mjs';
import { ensureErpSchema } from './erp/erp.schema.mjs';
import { writeAuditLog } from './erp/audit.service.mjs';

const APP_VERSION = '2.2.1-v2';
const TIME_HHMM_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const SAFE_DATA_IMG_RE = /^data:image\/(?:png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/i;
const INVOICE_PREFIX_RE = /^[A-Za-z0-9_-]{1,32}$/;
const VALID_TUNNEL_MODES = new Set(['off', 'quick', 'named']);

function resolveWorkspaceId(workspaceId, db) {
  const explicit = String(workspaceId || '').trim();
  if (explicit) return explicit;
  const row = db.prepare('SELECT id FROM v2_workspaces ORDER BY created_at DESC LIMIT 1').get();
  return row?.id || 'default';
}

function ensureSettingsRow(wsId, db) {
  db.prepare('INSERT OR IGNORE INTO v2_workspace_settings (workspace_id) VALUES (?)').run(wsId);
  return db.prepare('SELECT * FROM v2_workspace_settings WHERE workspace_id = ?').get(wsId);
}

function formatSettingsRow(row) {
  return {
    workspaceId: row.workspace_id,
    autoLockMinutes: Number(row.auto_lock_minutes || 0),
    autoStartEnabled: Number(row.auto_start_enabled || 0) === 1,
    gatewayPort: Number(row.gateway_port || 4001),
    tunnelMode: String(row.tunnel_mode || 'off'),
    soundEnabled: Number(row.sound_enabled ?? 1) === 1,
    quietHoursStart: String(row.quiet_hours_start || '21:00'),
    quietHoursEnd: String(row.quiet_hours_end || '08:30'),
    taxId: String(row.tax_id || ''),
    storeAddress: String(row.store_address || ''),
    receiptLogoUrl: String(row.receipt_logo_url || ''),
    invoicePrefix: String(row.invoice_prefix || 'INV-2026-'),
    updatedAt: row.updated_at || null,
  };
}

function validateLogoUrl(raw) {
  const val = String(raw ?? '').trim();
  if (!val) return '';
  if (val.length > 2_000_000) throw makeHttpError(400, 'receiptLogoUrl exceeds maximum allowed size');
  if (SAFE_DATA_IMG_RE.test(val)) return val;
  if (val.startsWith('/') && !val.startsWith('//')) return val;
  try {
    const parsed = new URL(val);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') return parsed.toString();
  } catch { /* fall through */ }
  throw makeHttpError(400, 'receiptLogoUrl must be https://, http://, relative /path, or safe PNG/JPG/WebP data URL');
}

function validatePatch(patch, prev) {
  const pick = (camel, snake) => (patch[camel] !== undefined ? patch[camel] : patch[snake]);

  const rawLock = pick('autoLockMinutes', 'auto_lock_minutes');
  const autoLockMinutes = rawLock === undefined ? Number(prev.auto_lock_minutes) : Number.parseInt(rawLock, 10);
  if (!Number.isInteger(autoLockMinutes) || autoLockMinutes < 0 || autoLockMinutes > 1440) {
    throw makeHttpError(400, 'autoLockMinutes must be an integer between 0 and 1440');
  }

  const rawAutoStart = pick('autoStartEnabled', 'auto_start_enabled');
  const autoStartEnabled = rawAutoStart === undefined ? Number(prev.auto_start_enabled) : rawAutoStart === true || Number(rawAutoStart) === 1 ? 1 : 0;

  const rawPort = pick('gatewayPort', 'gateway_port');
  const gatewayPort = rawPort === undefined ? Number(prev.gateway_port) : Number.parseInt(rawPort, 10);
  if (!Number.isInteger(gatewayPort) || gatewayPort < 1024 || gatewayPort > 65535) {
    throw makeHttpError(400, 'gatewayPort must be between 1024 and 65535');
  }

  const rawTunnel = pick('tunnelMode', 'tunnel_mode');
  const tunnelMode = rawTunnel === undefined ? String(prev.tunnel_mode) : String(rawTunnel).trim().toLowerCase();
  if (!VALID_TUNNEL_MODES.has(tunnelMode)) {
    throw makeHttpError(400, 'tunnelMode must be off, quick, or named');
  }

  const rawSound = pick('soundEnabled', 'sound_enabled');
  const soundEnabled = rawSound === undefined ? Number(prev.sound_enabled) : rawSound === true || Number(rawSound) === 1 ? 1 : 0;

  const rawQuietStart = pick('quietHoursStart', 'quiet_hours_start');
  const quietHoursStart = rawQuietStart === undefined ? String(prev.quiet_hours_start) : String(rawQuietStart).trim();
  if (!TIME_HHMM_RE.test(quietHoursStart)) {
    throw makeHttpError(400, 'quietHoursStart must follow HH:MM format (00:00-23:59)');
  }

  const rawQuietEnd = pick('quietHoursEnd', 'quiet_hours_end');
  const quietHoursEnd = rawQuietEnd === undefined ? String(prev.quiet_hours_end) : String(rawQuietEnd).trim();
  if (!TIME_HHMM_RE.test(quietHoursEnd)) {
    throw makeHttpError(400, 'quietHoursEnd must follow HH:MM format (00:00-23:59)');
  }

  const rawTaxId = pick('taxId', 'tax_id');
  const taxId = rawTaxId === undefined ? String(prev.tax_id) : String(rawTaxId).trim().slice(0, 32);

  const rawAddress = pick('storeAddress', 'store_address');
  const storeAddress = rawAddress === undefined ? String(prev.store_address) : String(rawAddress).trim().slice(0, 500);

  const rawLogo = pick('receiptLogoUrl', 'receipt_logo_url');
  const receiptLogoUrl = rawLogo === undefined ? String(prev.receipt_logo_url) : validateLogoUrl(rawLogo);

  const rawPrefix = pick('invoicePrefix', 'invoice_prefix');
  const invoicePrefix = rawPrefix === undefined ? String(prev.invoice_prefix) : String(rawPrefix).trim();
  if (!INVOICE_PREFIX_RE.test(invoicePrefix)) {
    throw makeHttpError(400, 'invoicePrefix must be 1-32 ASCII characters (A-Z, 0-9, -, _)');
  }

  return {
    autoLockMinutes,
    autoStartEnabled,
    gatewayPort,
    tunnelMode,
    soundEnabled,
    quietHoursStart,
    quietHoursEnd,
    taxId,
    storeAddress,
    receiptLogoUrl,
    invoicePrefix,
  };
}

export function getWorkspaceSettingsSuite(workspaceId = null, db = getV2Db()) {
  ensurePhase1ASchema(db);
  const wsId = resolveWorkspaceId(workspaceId, db);
  const row = ensureSettingsRow(wsId, db);
  return formatSettingsRow(row);
}

function redactLogoForAudit(obj) {
  if (!obj || typeof obj.receiptLogoUrl !== 'string' || !obj.receiptLogoUrl.startsWith('data:')) return obj;
  return { ...obj, receiptLogoUrl: `[data-url ${obj.receiptLogoUrl.length} chars]` };
}

export function updateWorkspaceSettingsSuite(workspaceId = null, patch = {}, actor = {}, db = getV2Db()) {
  ensurePhase1ASchema(db);
  const wsId = resolveWorkspaceId(workspaceId, db);
  const actorId = String(actor.actorId || 'owner_pin').trim() || 'owner_pin';
  const actorRole = String(actor.actorRole || 'owner').trim() || 'owner';

  const updated = withV2Transaction((txDb) => {
    ensurePhase1ASchema(txDb);
    const prev = ensureSettingsRow(wsId, txDb);
    const next = validatePatch(patch || {}, prev);

    txDb
      .prepare(
        `UPDATE v2_workspace_settings
         SET auto_lock_minutes = ?, auto_start_enabled = ?, gateway_port = ?, tunnel_mode = ?,
             sound_enabled = ?, quiet_hours_start = ?, quiet_hours_end = ?, tax_id = ?,
             store_address = ?, receipt_logo_url = ?, invoice_prefix = ?, updated_at = CURRENT_TIMESTAMP
         WHERE workspace_id = ?`
      )
      .run(
        next.autoLockMinutes,
        next.autoStartEnabled,
        next.gatewayPort,
        next.tunnelMode,
        next.soundEnabled,
        next.quietHoursStart,
        next.quietHoursEnd,
        next.taxId,
        next.storeAddress,
        next.receiptLogoUrl,
        next.invoicePrefix,
        wsId
      );

    const nextRow = txDb.prepare('SELECT * FROM v2_workspace_settings WHERE workspace_id = ?').get(wsId);
    writeAuditLog(
      {
        actorId,
        actorRole,
        action: 'settings_suite.updated',
        targetType: 'settings',
        targetId: wsId,
        before: redactLogoForAudit(formatSettingsRow(prev)),
        after: redactLogoForAudit(formatSettingsRow(nextRow)),
        ip: actor.ip || '',
      },
      txDb
    );
    return nextRow;
  });

  return formatSettingsRow(updated);
}

export function changeAccountPassword({ accountId, currentPassword, newPassword, actor = {} } = {}, db = getV2Db()) {
  ensurePhase1ASchema(db);
  const accId = String(accountId || '').trim();
  const curr = String(currentPassword || '');
  const nextPw = String(newPassword || '');
  if (!accId) throw makeHttpError(400, 'accountId is required');
  if (!curr) throw makeHttpError(400, 'กรุณากรอกรหัสผ่านปัจจุบัน');
  if (nextPw.length < 6) throw makeHttpError(400, 'รหัสผ่านใหม่ต้องมีอย่างน้อย 6 ตัวอักษร');

  const changedAt = new Date().toISOString();
  const sessionsRevoked = withV2Transaction((txDb) => {
    ensurePhase1ASchema(txDb);
    const acc = txDb.prepare('SELECT id, password_hash, platform_role FROM v2_saas_accounts WHERE id = ?').get(accId);
    if (!acc) throw makeHttpError(404, 'ไม่พบบัญชีผู้ใช้');
    if (!verifyPassword(curr, acc.password_hash)) {
      throw makeHttpError(403, 'รหัสผ่านปัจจุบันไม่ถูกต้อง');
    }
    txDb.prepare('UPDATE v2_saas_accounts SET password_hash = ? WHERE id = ?').run(hashPassword(nextPw), accId);
    const revoked = txDb.prepare('UPDATE v2_persistent_sessions SET revoked_at = CURRENT_TIMESTAMP WHERE account_id = ? AND revoked_at IS NULL').run(accId);
    const revokedCount = Number(revoked?.changes || 0);
    writeAuditLog(
      {
        actorId: String(actor.actorId || accId),
        actorRole: String(actor.actorRole || acc.platform_role || 'owner'),
        action: 'account.password_changed',
        targetType: 'account',
        targetId: accId,
        before: { password: '[REDACTED]' },
        after: { password: '[REDACTED]', changedAt, sessionsRevoked: revokedCount },
        ip: actor.ip || '',
      },
      txDb
    );
    return revokedCount;
  });

  return { accountId: accId, changedAt, sessionsRevoked };
}

/**
 * Generate a safe downloadable Windows Startup helper script (.bat) without touching host C:\Windows.
 */
export function generateWindowsStartupScript({ port = 4001, appUrl = '' } = {}) {
  const parsedPort = Number.parseInt(port, 10);
  const safePort = Number.isInteger(parsedPort) && parsedPort >= 1024 && parsedPort <= 65535 ? parsedPort : 4001;
  let safeUrl = `http://127.0.0.1:${safePort}/`;
  const rawUrl = String(appUrl || '').trim();
  if (rawUrl && !/[&|<>^%"'\r\n]/.test(rawUrl)) {
    try {
      const u = new URL(rawUrl);
      if (u.protocol === 'https:' || (u.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(u.hostname))) {
        safeUrl = u.toString();
      }
    } catch { /* fallback to safe localhost url */ }
  }

  const lines = [
    '@echo off',
    'REM OmniFlow Enterprise v2 - Windows Auto-Start Helper',
    'REM Place this file in Windows Startup folder (Win+R -> shell:startup)',
    'title OmniFlow Enterprise v2 Launcher',
    `echo Starting OmniFlow Enterprise v2 on port ${safePort}...`,
    'timeout /t 3 /nobreak >nul',
    `start "" "${safeUrl}"`,
    'exit /b 0',
  ];

  return {
    filename: 'omniflow-autostart.bat',
    contentType: 'application/octet-stream; charset=utf-8',
    content: `${lines.join('\r\n')}\r\n`,
  };
}

/**
 * Return redacted system health & table count diagnostics (ZERO secrets/env vars/PII).
 */
export function getDiagnosticsReport(db = getV2Db()) {
  ensurePhase1ASchema(db);
  ensureErpSchema(db);
  const health = getV2DbHealth();
  const countOf = (table) => Number(db.prepare(`SELECT COUNT(*) AS cnt FROM ${table}`).get()?.cnt || 0);

  return {
    appVersion: APP_VERSION,
    nodeVersion: process.version,
    platform: process.platform,
    uptimeSec: Math.floor(process.uptime()),
    dbOk: Boolean(health.ok),
    journalMode: health.journalMode,
    tableCount: health.tableCount,
    counts: {
      accounts: countOf('v2_saas_accounts'),
      workspaces: countOf('v2_workspaces'),
      activeSessions: Number(
        db.prepare('SELECT COUNT(*) AS cnt FROM v2_persistent_sessions WHERE revoked_at IS NULL').get()?.cnt || 0
      ),
      auditLogs: countOf('v2_audit_logs'),
      erpApiKeys: countOf('v2_erp_api_keys'),
    },
    generatedAt: new Date().toISOString(),
  };
}
