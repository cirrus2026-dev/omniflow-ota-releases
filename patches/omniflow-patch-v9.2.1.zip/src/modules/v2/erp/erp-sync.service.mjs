// gateway/src/modules/v2/erp/erp-sync.service.mjs
// OmniFlow Enterprise v2 — Human-Gated Outbound ERP Sync (Atomic Lock, Idempotency, HMAC + fetchSafe)

import crypto from 'node:crypto';
import { getV2Db, withV2Transaction } from '../v2-db.mjs';
import { decryptPii, encryptPii, makeHttpError, newId } from '../v2-http.mjs';
import { fetchSafe } from '../../fetch-safe.mjs';
import { ensureErpSchema } from './erp.schema.mjs';
import { writeAuditLog } from './audit.service.mjs';

const VALID_SYNC_MODES = new Set(['manual_approval', 'auto_verified']);
const MASKED_SECRET_PLACEHOLDER = '••••••••';

function buildSignedHeaders(rawBody, secret, idempotencyKey) {
  const ts = String(Math.floor(Date.now() / 1000));
  const headers = {
    'Content-Type': 'application/json; charset=utf-8',
    'X-OmniFlow-Timestamp': ts,
    'X-OmniFlow-Idempotency-Key': String(idempotencyKey || ''),
  };
  if (secret) {
    const sig = crypto.createHmac('sha256', secret).update(`${ts}.${rawBody}`).digest('hex');
    headers['X-OmniFlow-Signature'] = `sha256=${sig}`;
  }
  return headers;
}

function toPublicSettings(row) {
  const hasSecret = Boolean(String(row?.webhook_secret_encrypted || '').trim());
  return {
    id: row?.id || 'default',
    outbound_enabled: Number(row?.outbound_enabled || 0),
    sync_mode: row?.sync_mode || 'manual_approval',
    webhook_url: row?.webhook_url || '',
    has_webhook_secret: hasSecret,
    webhook_secret_masked: hasSecret ? MASKED_SECRET_PLACEHOLDER : '',
    updated_by: row?.updated_by || null,
    updated_at: row?.updated_at || null,
  };
}

function formatQueueRow(row) {
  if (!row) return null;
  const satang = Number(row.amount_satang || 0);
  return { ...row, amount_satang: satang, amount_thb: Number((satang / 100).toFixed(2)) };
}

export function getSyncSettings(db = getV2Db()) {
  ensureErpSchema(db);
  return toPublicSettings(db.prepare("SELECT * FROM v2_erp_sync_settings WHERE id = 'default'").get());
}

export function updateSyncSettings(input = {}, actor = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const rawEnabled = input.outbound_enabled ?? input.outboundEnabled;
  const rawMode = input.sync_mode ?? input.syncMode;
  const rawUrl = input.webhook_url ?? input.webhookUrl;
  const rawSecret = input.webhook_secret ?? input.webhookSecret;

  if (rawMode !== undefined && !VALID_SYNC_MODES.has(String(rawMode))) {
    throw makeHttpError(400, 'sync_mode must be manual_approval or auto_verified');
  }
  if (rawUrl !== undefined && String(rawUrl).trim() !== '') {
    try {
      const parsed = new URL(String(rawUrl).trim());
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') throw new Error('bad protocol');
    } catch {
      throw makeHttpError(400, 'webhook_url must be a valid HTTP(S) URL');
    }
  }

  const actorId = String(actor.actorId || 'owner').trim() || 'owner';
  const actorRole = String(actor.actorRole || 'owner').trim() || 'owner';

  const updated = withV2Transaction((txDb) => {
    ensureErpSchema(txDb);
    const prev = txDb.prepare("SELECT * FROM v2_erp_sync_settings WHERE id = 'default'").get();
    const nextEnabled =
      rawEnabled === undefined ? Number(prev.outbound_enabled) : rawEnabled === true || Number(rawEnabled) === 1 ? 1 : 0;
    const nextMode = rawMode === undefined ? prev.sync_mode : String(rawMode);
    const nextUrl = rawUrl === undefined ? prev.webhook_url : String(rawUrl).trim();
    let nextSecretEnc = prev.webhook_secret_encrypted || '';
    if (rawSecret !== undefined && rawSecret !== MASKED_SECRET_PLACEHOLDER) {
      const trimmed = String(rawSecret ?? '').trim();
      nextSecretEnc = trimmed ? encryptPii(trimmed) : '';
    }

    txDb
      .prepare(
        `UPDATE v2_erp_sync_settings SET outbound_enabled = ?, sync_mode = ?, webhook_url = ?,
         webhook_secret_encrypted = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 'default'`
      )
      .run(nextEnabled, nextMode, nextUrl, nextSecretEnc, actorId);

    const nextRow = txDb.prepare("SELECT * FROM v2_erp_sync_settings WHERE id = 'default'").get();
    writeAuditLog(
      { actorId, actorRole, action: 'erp_sync.settings_updated', targetType: 'settings', targetId: 'erp_sync_default', before: toPublicSettings(prev), after: toPublicSettings(nextRow), ip: actor.ip || '' },
      txDb
    );
    return nextRow;
  });
  return toPublicSettings(updated);
}

export function enqueueOrderForApproval(input = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const orderId = String(input.orderId || input.order_id || '').trim();
  const amountSatang = input.amountSatang ?? input.amount_satang;
  if (!orderId) throw makeHttpError(400, 'order_id is required');
  if (!Number.isSafeInteger(amountSatang) || amountSatang < 0) {
    throw makeHttpError(400, 'amount_satang must be a non-negative integer');
  }
  const payloadJson = JSON.stringify(input.payload && typeof input.payload === 'object' ? input.payload : {});
  const aiNote = String(input.aiConfidenceNote || input.ai_confidence_note || '').trim().slice(0, 500) || null;
  const fallbackHash = crypto.createHash('sha256').update(payloadJson).digest('hex').slice(0, 16);
  const idemKey = String(input.idempotencyKey || input.idempotency_key || `${orderId}:${fallbackHash}`).trim();

  return withV2Transaction((txDb) => {
    ensureErpSchema(txDb);
    const existing = txDb.prepare('SELECT * FROM v2_erp_outbound_queue WHERE idempotency_key = ?').get(idemKey);
    if (existing) return { duplicated: true, item: formatQueueRow(existing) };
    const id = newId('erpq');
    txDb
      .prepare("INSERT INTO v2_erp_outbound_queue (id, order_id, idempotency_key, amount_satang, payload_json, ai_confidence_note, status) VALUES (?, ?, ?, ?, ?, ?, 'pending_approval')")
      .run(id, orderId, idemKey, amountSatang, payloadJson, aiNote);
    return { duplicated: false, item: formatQueueRow(txDb.prepare('SELECT * FROM v2_erp_outbound_queue WHERE id = ?').get(id)) };
  });
}

export function listOutboundQueue(filters = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const limit = Math.min(100, Math.max(1, Number.parseInt(filters.limit, 10) || 50));
  const offset = Math.max(0, Number.parseInt(filters.offset, 10) || 0);
  const status = String(filters.status || '').trim();
  const whereSql = status ? 'WHERE status = ?' : '';
  const params = status ? [status] : [];
  const totalRow = db.prepare(`SELECT COUNT(*) AS total FROM v2_erp_outbound_queue ${whereSql}`).get(...params);
  const rows = db
    .prepare(`SELECT * FROM v2_erp_outbound_queue ${whereSql} ORDER BY created_at DESC, rowid DESC LIMIT ? OFFSET ?`)
    .all(...params, limit, offset);
  return { items: rows.map(formatQueueRow), total: Number(totalRow?.total || 0), limit, offset };
}

export async function approveAndDispatchViaFetchSafe(input = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const id = String(input.id || '').trim();
  if (!id) throw makeHttpError(400, 'Queue item id is required');
  const approvedBy = String(input.approvedBy || 'owner').trim() || 'owner';
  const actorRole = String(input.actorRole || 'owner').trim() || 'owner';
  const fetchImpl = typeof input.fetchImpl === 'function' ? input.fetchImpl : fetchSafe;

  const locked = withV2Transaction((txDb) => {
    ensureErpSchema(txDb);
    const settings = txDb.prepare("SELECT * FROM v2_erp_sync_settings WHERE id = 'default'").get();
    if (!settings || Number(settings.outbound_enabled) !== 1) {
      throw makeHttpError(409, 'Outbound ERP Sync is OFF. Enable Master Switch before dispatching.');
    }
    if (!String(settings.webhook_url || '').trim()) throw makeHttpError(400, 'Outbound ERP webhook_url is not configured');
    const res = txDb
      .prepare("UPDATE v2_erp_outbound_queue SET status = 'sending', approved_by = ?, approved_at = CURRENT_TIMESTAMP, last_error = NULL WHERE id = ? AND status IN ('pending_approval', 'send_failed')")
      .run(approvedBy, id);
    if (res.changes !== 1) {
      const exists = txDb.prepare('SELECT status FROM v2_erp_outbound_queue WHERE id = ?').get(id);
      if (!exists) throw makeHttpError(404, 'Outbound queue item not found');
      throw makeHttpError(409, `Queue item cannot be dispatched in status: ${exists.status}`);
    }
    return { row: txDb.prepare('SELECT * FROM v2_erp_outbound_queue WHERE id = ?').get(id), settings };
  });

  const secret = decryptPii(locked.settings.webhook_secret_encrypted);
  const satang = Number(locked.row.amount_satang);
  const rawBody = JSON.stringify({
    event: 'erp.order.approved',
    queue_id: locked.row.id,
    order_id: locked.row.order_id,
    idempotency_key: locked.row.idempotency_key,
    amount_satang: satang,
    amount_thb: Number((satang / 100).toFixed(2)),
    approved_by: approvedBy,
    payload: JSON.parse(locked.row.payload_json || '{}'),
  });
  const headers = buildSignedHeaders(rawBody, secret, locked.row.idempotency_key);

  let dispatchOk = false;
  let httpStatus = 0;
  let lastError = null;
  try {
    const resp = await fetchImpl(locked.settings.webhook_url, {
      method: 'POST', allowHttp: Boolean(input.allowHttp), headers, body: rawBody, timeoutMs: 12_000,
    });
    httpStatus = Number(resp?.status || 0);
    dispatchOk = Boolean(resp?.ok);
    if (!dispatchOk) lastError = `Remote ERP returned HTTP ${httpStatus}`;
  } catch (err) {
    lastError = String(err?.message || 'Outbound ERP dispatch failed').slice(0, 500);
  }

  const finalRow = withV2Transaction((txDb) => {
    const finalStatus = dispatchOk ? 'approved_sent' : 'send_failed';
    txDb.prepare('UPDATE v2_erp_outbound_queue SET status = ?, http_status = ?, last_error = ? WHERE id = ?').run(finalStatus, httpStatus, lastError, id);
    writeAuditLog(
      { actorId: approvedBy, actorRole, action: dispatchOk ? 'erp_sync.approved' : 'erp_sync.send_failed', targetType: 'order', targetId: locked.row.order_id, before: { queue_id: id, status: 'pending_approval' }, after: { queue_id: id, status: finalStatus, http_status: httpStatus, last_error: lastError }, ip: input.ip || '' },
      txDb
    );
    return txDb.prepare('SELECT * FROM v2_erp_outbound_queue WHERE id = ?').get(id);
  });
  return { ok: dispatchOk, httpStatus, error: lastError, item: formatQueueRow(finalRow) };
}

export function rejectOutboundQueue(input = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const id = String(input.id || '').trim();
  if (!id) throw makeHttpError(400, 'Queue item id is required');
  const reason = String(input.reason || 'Rejected by human reviewer').trim().slice(0, 500);
  const rejectedBy = String(input.rejectedBy || 'owner').trim() || 'owner';
  const actorRole = String(input.actorRole || 'owner').trim() || 'owner';

  const row = withV2Transaction((txDb) => {
    ensureErpSchema(txDb);
    const res = txDb
      .prepare("UPDATE v2_erp_outbound_queue SET status = 'rejected', approved_by = ?, approved_at = CURRENT_TIMESTAMP, last_error = ? WHERE id = ? AND status IN ('pending_approval', 'send_failed')")
      .run(rejectedBy, reason, id);
    if (res.changes !== 1) {
      const exists = txDb.prepare('SELECT status FROM v2_erp_outbound_queue WHERE id = ?').get(id);
      if (!exists) throw makeHttpError(404, 'Outbound queue item not found');
      throw makeHttpError(409, `Queue item cannot be rejected in status: ${exists.status}`);
    }
    const updated = txDb.prepare('SELECT * FROM v2_erp_outbound_queue WHERE id = ?').get(id);
    writeAuditLog({ actorId: rejectedBy, actorRole, action: 'erp_sync.rejected', targetType: 'order', targetId: updated.order_id, after: { queue_id: id, status: 'rejected', reason }, ip: input.ip || '' }, txDb);
    return updated;
  });
  return formatQueueRow(row);
}

export async function dryRunPingWebhook(input = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const saved = db.prepare("SELECT * FROM v2_erp_sync_settings WHERE id = 'default'").get();
  const targetUrl = String(input.webhookUrl || input.webhook_url || saved?.webhook_url || '').trim();
  if (!targetUrl) throw makeHttpError(400, 'webhook_url is required for ping');
  const secret = input.webhookSecret && input.webhookSecret !== MASKED_SECRET_PLACEHOLDER ? String(input.webhookSecret).trim() : decryptPii(saved?.webhook_secret_encrypted);
  const fetchImpl = typeof input.fetchImpl === 'function' ? input.fetchImpl : fetchSafe;
  const rawBody = JSON.stringify({ event: 'erp.webhook.ping', dry_run: true, ts: new Date().toISOString() });
  const headers = buildSignedHeaders(rawBody, secret, newId('ping'));
  const started = Date.now();
  try {
    const resp = await fetchImpl(targetUrl, { method: 'POST', allowHttp: Boolean(input.allowHttp), headers, body: rawBody, timeoutMs: 8_000 });
    return { ok: Boolean(resp?.ok), status: Number(resp?.status || 0), latencyMs: Date.now() - started };
  } catch (err) {
    return { ok: false, status: 0, latencyMs: Date.now() - started, error: String(err?.message || 'Ping failed').slice(0, 300) };
  }
}
