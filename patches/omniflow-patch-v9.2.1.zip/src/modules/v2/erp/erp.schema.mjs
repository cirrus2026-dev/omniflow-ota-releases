// gateway/src/modules/v2/erp/erp.schema.mjs
// OmniFlow Enterprise v2 — SQLite Schema for Immutable Audit Log, External ERP API Keys & Outbound Sync

import { getV2Db } from '../v2-db.mjs';

export const ERP_TABLES = Object.freeze([
  'v2_audit_logs',
  'v2_erp_api_keys',
  'v2_erp_sync_settings',
  'v2_erp_outbound_queue',
]);

export const ERP_SCHEMA_DDL = `
CREATE TABLE IF NOT EXISTS v2_audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  target_type TEXT NOT NULL,
  target_id TEXT NOT NULL,
  before_json TEXT,
  after_json TEXT,
  ip_hash TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_v2_audit_time ON v2_audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_v2_audit_actor_action ON v2_audit_logs(actor_id, action, created_at DESC);

CREATE TABLE IF NOT EXISTS v2_erp_api_keys (
  id TEXT PRIMARY KEY,
  key_name TEXT NOT NULL,
  key_prefix TEXT NOT NULL,
  key_last4 TEXT NOT NULL,
  key_hash TEXT UNIQUE NOT NULL,
  scopes_json TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active', 'revoked')),
  created_by TEXT NOT NULL,
  expires_at TEXT,
  last_used_at TEXT,
  revoked_at TEXT,
  revoked_by TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_v2_erp_keys_status ON v2_erp_api_keys(status, created_at DESC);

CREATE TABLE IF NOT EXISTS v2_erp_sync_settings (
  id TEXT PRIMARY KEY DEFAULT 'default',
  outbound_enabled INTEGER NOT NULL DEFAULT 0,
  sync_mode TEXT NOT NULL DEFAULT 'manual_approval' CHECK(sync_mode IN ('manual_approval', 'auto_verified')),
  webhook_url TEXT NOT NULL DEFAULT '',
  webhook_secret_encrypted TEXT NOT NULL DEFAULT '',
  updated_by TEXT,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS v2_erp_outbound_queue (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL,
  idempotency_key TEXT UNIQUE NOT NULL,
  amount_satang INTEGER NOT NULL,
  payload_json TEXT NOT NULL,
  ai_confidence_note TEXT,
  status TEXT NOT NULL DEFAULT 'pending_approval'
    CHECK(status IN ('pending_approval', 'sending', 'approved_sent', 'rejected', 'send_failed')),
  approved_by TEXT,
  approved_at TEXT,
  http_status INTEGER,
  last_error TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_v2_erp_queue_status ON v2_erp_outbound_queue(status, created_at DESC);

INSERT OR IGNORE INTO v2_erp_sync_settings (
  id, outbound_enabled, sync_mode, webhook_url, webhook_secret_encrypted
) VALUES ('default', 0, 'manual_approval', '', '');
`;

const initializedDbs = new WeakSet();

export function ensureErpSchema(db = getV2Db()) {
  if (!db) {
    throw new Error('ensureErpSchema requires an active SQLite DatabaseSync instance');
  }
  if (!initializedDbs.has(db)) {
    db.exec(ERP_SCHEMA_DDL);
    initializedDbs.add(db);
  }
  return db;
}
