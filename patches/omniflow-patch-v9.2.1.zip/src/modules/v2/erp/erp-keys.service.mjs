// gateway/src/modules/v2/erp/erp-keys.service.mjs
// OmniFlow Enterprise v2 — External ERP Bearer API Keys (SHA-256 Hash Only, Scopes, Per-Key Rate Limit)

import crypto from 'node:crypto';
import { getV2Db, withV2Transaction } from '../v2-db.mjs';
import { makeHttpError, newId } from '../v2-http.mjs';
import { ensureErpSchema } from './erp.schema.mjs';
import { writeAuditLog } from './audit.service.mjs';

export const ALLOWED_ERP_SCOPES = Object.freeze(['orders:read', 'quotes:read', 'catalog:read']);

const ALLOWED_SCOPE_SET = new Set(ALLOWED_ERP_SCOPES);
const KEY_TAG = 'of_live_';
const MAX_RATE_BUCKETS = 1000;
const DEFAULT_RATE_WINDOW_MS = 60_000;
const DEFAULT_MAX_REQ_PER_WINDOW = 120;
const keyRateBuckets = new Map();

function hashRawKey(rawKey) {
  return crypto.createHash('sha256').update(String(rawKey)).digest('hex');
}

function parseScopesJson(raw) {
  try {
    const parsed = JSON.parse(String(raw || '[]'));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function normalizeScopes(scopesInput) {
  if (!Array.isArray(scopesInput) || scopesInput.length === 0) {
    throw makeHttpError(400, 'At least one valid scope is required');
  }
  const unique = [];
  for (const item of scopesInput) {
    const scope = String(item || '').trim();
    if (!ALLOWED_SCOPE_SET.has(scope)) throw makeHttpError(400, `Unsupported ERP scope: ${scope}`);
    if (!unique.includes(scope)) unique.push(scope);
  }
  return unique;
}

function checkKeyRateLimit(keyId, { windowMs = DEFAULT_RATE_WINDOW_MS, maxReq = DEFAULT_MAX_REQ_PER_WINDOW } = {}) {
  const now = Date.now();
  if (keyRateBuckets.size >= MAX_RATE_BUCKETS) {
    for (const [id, b] of keyRateBuckets) {
      if (b.resetAt <= now) keyRateBuckets.delete(id);
      if (keyRateBuckets.size < MAX_RATE_BUCKETS) break;
    }
    if (keyRateBuckets.size >= MAX_RATE_BUCKETS) {
      const oldestKey = keyRateBuckets.keys().next().value;
      if (oldestKey) keyRateBuckets.delete(oldestKey);
    }
  }
  let bucket = keyRateBuckets.get(keyId);
  if (!bucket || bucket.resetAt <= now) {
    bucket = { count: 0, resetAt: now + windowMs };
    keyRateBuckets.set(keyId, bucket);
  }
  bucket.count += 1;
  if (bucket.count > maxReq) {
    return { allowed: false, retryAfterSec: Math.max(1, Math.ceil((bucket.resetAt - now) / 1000)) };
  }
  return { allowed: true, retryAfterSec: 0 };
}

export function resetErpKeyRateLimiter() {
  keyRateBuckets.clear();
}

function toPublicKeyView(row) {
  return {
    id: row.id,
    key_name: row.key_name,
    key_prefix: row.key_prefix,
    key_last4: row.key_last4,
    masked_key: `${row.key_prefix}••••••••${row.key_last4}`,
    scopes: parseScopesJson(row.scopes_json),
    status: row.status,
    created_by: row.created_by,
    expires_at: row.expires_at,
    last_used_at: row.last_used_at,
    revoked_at: row.revoked_at,
    revoked_by: row.revoked_by,
    created_at: row.created_at,
  };
}

export function generateErpKey(input = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const keyName = String(input.keyName || input.key_name || '').trim();
  if (!keyName || keyName.length > 100) throw makeHttpError(400, 'key_name is required (1-100 characters)');
  const scopes = normalizeScopes(input.scopes);

  let expiresAt = null;
  const rawExpires = input.expiresAt ?? input.expires_at;
  if (rawExpires !== undefined && rawExpires !== null && String(rawExpires).trim() !== '') {
    const parsedMs = Date.parse(String(rawExpires));
    if (!Number.isFinite(parsedMs) || parsedMs <= Date.now()) {
      throw makeHttpError(400, 'expires_at must be a valid future ISO timestamp');
    }
    expiresAt = new Date(parsedMs).toISOString();
  }

  const createdBy = String(input.createdBy || 'owner').trim() || 'owner';
  const actorRole = String(input.actorRole || 'owner').trim() || 'owner';
  const id = newId('erpk');
  const rawKey = `${KEY_TAG}${crypto.randomBytes(24).toString('hex')}`;
  const keyPrefix = rawKey.slice(0, 12);
  const keyLast4 = rawKey.slice(-4);
  const keyHash = hashRawKey(rawKey);
  const scopesJson = JSON.stringify(scopes);

  const createdRow = withV2Transaction((txDb) => {
    ensureErpSchema(txDb);
    txDb
      .prepare(
        `INSERT INTO v2_erp_api_keys (
          id, key_name, key_prefix, key_last4, key_hash, scopes_json, status, created_by, expires_at
        ) VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)`
      )
      .run(id, keyName, keyPrefix, keyLast4, keyHash, scopesJson, createdBy, expiresAt);

    writeAuditLog(
      {
        actorId: createdBy,
        actorRole,
        action: 'erp_key.created',
        targetType: 'erp_key',
        targetId: id,
        after: { id, key_name: keyName, key_prefix: keyPrefix, key_last4: keyLast4, scopes, expires_at: expiresAt },
        ip: input.ip || '',
      },
      txDb
    );
    return txDb.prepare('SELECT * FROM v2_erp_api_keys WHERE id = ?').get(id);
  });

  return { ...toPublicKeyView(createdRow), rawKey };
}

export function listMaskedKeys(db = getV2Db()) {
  ensureErpSchema(db);
  const rows = db
    .prepare(
      `SELECT id, key_name, key_prefix, key_last4, scopes_json, status,
              created_by, expires_at, last_used_at, revoked_at, revoked_by, created_at
       FROM v2_erp_api_keys ORDER BY created_at DESC, rowid DESC`
    )
    .all();
  return rows.map(toPublicKeyView);
}

export function revokeErpKey(input = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const id = String(input.id || '').trim();
  if (!id) throw makeHttpError(400, 'API key id is required');
  const revokedBy = String(input.revokedBy || 'owner').trim() || 'owner';
  const actorRole = String(input.actorRole || 'owner').trim() || 'owner';

  const updated = withV2Transaction((txDb) => {
    ensureErpSchema(txDb);
    const existing = txDb.prepare('SELECT * FROM v2_erp_api_keys WHERE id = ?').get(id);
    if (!existing) throw makeHttpError(404, 'ERP API key not found');
    txDb
      .prepare("UPDATE v2_erp_api_keys SET status = 'revoked', revoked_at = CURRENT_TIMESTAMP, revoked_by = ? WHERE id = ?")
      .run(revokedBy, id);
    writeAuditLog(
      {
        actorId: revokedBy,
        actorRole,
        action: 'erp_key.revoked',
        targetType: 'erp_key',
        targetId: id,
        before: { status: existing.status, key_name: existing.key_name },
        after: { status: 'revoked', revoked_by: revokedBy },
        ip: input.ip || '',
      },
      txDb
    );
    return txDb.prepare('SELECT * FROM v2_erp_api_keys WHERE id = ?').get(id);
  });

  keyRateBuckets.delete(id);
  return toPublicKeyView(updated);
}

export function verifyBearerKey(req, requiredScope, options = {}) {
  const db = options.db || getV2Db();
  ensureErpSchema(db);
  const authHeader = String(req?.headers?.authorization || req?.headers?.Authorization || '').trim();
  const match = /^Bearer\s+(\S+)$/i.exec(authHeader);
  if (!match) return { ok: false, statusCode: 401, error: 'Missing or invalid Authorization Bearer token' };

  const candidateHash = hashRawKey(match[1]);
  const row = db.prepare('SELECT * FROM v2_erp_api_keys WHERE key_hash = ?').get(candidateHash);
  if (!row || !row.key_hash) return { ok: false, statusCode: 401, error: 'Invalid ERP API key' };

  const expectedBuf = Buffer.from(String(row.key_hash), 'hex');
  const actualBuf = Buffer.from(candidateHash, 'hex');
  if (expectedBuf.length !== actualBuf.length || !crypto.timingSafeEqual(expectedBuf, actualBuf)) {
    return { ok: false, statusCode: 401, error: 'Invalid ERP API key' };
  }
  if (row.status !== 'active') return { ok: false, statusCode: 401, error: 'ERP API key has been revoked' };
  if (row.expires_at) {
    const expMs = Date.parse(row.expires_at);
    if (!Number.isFinite(expMs) || expMs <= Date.now()) return { ok: false, statusCode: 401, error: 'ERP API key has expired' };
  }

  const rl = checkKeyRateLimit(row.id, options.rateLimit);
  if (!rl.allowed) {
    return { ok: false, statusCode: 429, retryAfterSec: rl.retryAfterSec, error: `Rate limit exceeded. Retry after ${rl.retryAfterSec}s` };
  }

  const scopes = parseScopesJson(row.scopes_json);
  if (requiredScope && !scopes.includes(requiredScope)) {
    return { ok: false, statusCode: 403, error: `Missing required scope: ${requiredScope}` };
  }

  db.prepare('UPDATE v2_erp_api_keys SET last_used_at = CURRENT_TIMESTAMP WHERE id = ?').run(row.id);
  return { ok: true, statusCode: 200, key: { id: row.id, keyName: row.key_name, scopes } };
}
