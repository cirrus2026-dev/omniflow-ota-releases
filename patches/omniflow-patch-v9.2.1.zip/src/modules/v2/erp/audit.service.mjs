// gateway/src/modules/v2/erp/audit.service.mjs
// OmniFlow Enterprise v2 — Append-Only Immutable Audit Log Service (Redaction + Safe CSV Export)

import { getV2Db } from '../v2-db.mjs';
import { hmacLookupHash, newId } from '../v2-http.mjs';
import { ensureErpSchema } from './erp.schema.mjs';

const SENSITIVE_KEY_RE =
  /(?:secret|token|password|passwd|pin|api[_-]?key|raw[_-]?key|authorization|cookie|private[_-]?key|webhook[_-]?secret|key[_-]?hash)/i;
const INLINE_SECRET_RE = /(?:of_live_[a-f0-9]{8,}|bearer\s+[A-Za-z0-9._~+/=-]{8,})/gi;
const FORMULA_PREFIX_RE = /^[=+\-@\t\r]/;
const MAX_REDACT_DEPTH = 8;
const MAX_CSV_ROWS = 5000;

export function redactSecrets(value, depth = 0) {
  if (value === null || value === undefined) return value;
  if (depth > MAX_REDACT_DEPTH) return '[TRUNCATED]';
  if (typeof value === 'string') return value.replace(INLINE_SECRET_RE, '[REDACTED]');
  if (typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map((item) => redactSecrets(item, depth + 1));
  const out = {};
  for (const [key, val] of Object.entries(value)) {
    out[key] = SENSITIVE_KEY_RE.test(key) ? '[REDACTED]' : redactSecrets(val, depth + 1);
  }
  return out;
}

function serializeSnapshot(raw) {
  if (raw === undefined || raw === null) return null;
  if (typeof raw === 'string') {
    try {
      return JSON.stringify(redactSecrets(JSON.parse(raw)));
    } catch {
      return JSON.stringify(redactSecrets(raw));
    }
  }
  return JSON.stringify(redactSecrets(raw));
}

export function writeAuditLog(entry = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const id = newId('aud');
  const actorId = String(entry.actorId || 'system').trim().slice(0, 128) || 'system';
  const actorRole = String(entry.actorRole || 'owner').trim().slice(0, 64) || 'owner';
  const action = String(entry.action || 'unknown').trim().slice(0, 128) || 'unknown';
  const targetType = String(entry.targetType || 'system').trim().slice(0, 64) || 'system';
  const targetId = String(entry.targetId || '-').trim().slice(0, 128) || '-';
  const beforeJson = serializeSnapshot(entry.before);
  const afterJson = serializeSnapshot(entry.after);
  const ipHash = entry.ipHash
    ? String(entry.ipHash).slice(0, 128)
    : entry.ip
      ? hmacLookupHash(String(entry.ip))
      : null;

  db.prepare(
    `INSERT INTO v2_audit_logs (
      id, actor_id, actor_role, action, target_type, target_id, before_json, after_json, ip_hash
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, actorId, actorRole, action, targetType, targetId, beforeJson, afterJson, ipHash);

  return db.prepare('SELECT * FROM v2_audit_logs WHERE id = ?').get(id);
}

function normalizeToBound(rawTo) {
  const s = String(rawTo || '').trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? `${s}T23:59:59.999Z` : s;
}

function buildFilterWhere(filters = {}) {
  const clauses = [];
  const params = [];
  if (filters.from) { clauses.push('created_at >= ?'); params.push(String(filters.from).trim()); }
  if (filters.to) { clauses.push('created_at <= ?'); params.push(normalizeToBound(filters.to)); }
  if (filters.action) { clauses.push('action = ?'); params.push(String(filters.action).trim()); }
  if (filters.actor) { clauses.push('actor_id = ?'); params.push(String(filters.actor).trim()); }
  if (filters.targetType) { clauses.push('target_type = ?'); params.push(String(filters.targetType).trim()); }
  if (filters.targetId) { clauses.push('target_id = ?'); params.push(String(filters.targetId).trim()); }
  return { whereSql: clauses.length > 0 ? `WHERE ${clauses.join(' AND ')}` : '', params };
}

export function queryAuditLogs(filters = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const limit = Math.min(200, Math.max(1, Number.parseInt(filters.limit, 10) || 50));
  const offset = Math.max(0, Number.parseInt(filters.offset, 10) || 0);
  const { whereSql, params } = buildFilterWhere(filters);
  const countRow = db.prepare(`SELECT COUNT(*) AS total FROM v2_audit_logs ${whereSql}`).get(...params);
  const items = db
    .prepare(
      `SELECT id, actor_id, actor_role, action, target_type, target_id,
              before_json, after_json, ip_hash, created_at
       FROM v2_audit_logs ${whereSql}
       ORDER BY created_at DESC, rowid DESC LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset);
  return { items, total: Number(countRow?.total || 0), limit, offset };
}

export function sanitizeCsvCell(value) {
  if (value === null || value === undefined) return '';
  let str = typeof value === 'object' ? JSON.stringify(value) : String(value);
  let escapedFormula = false;
  if (FORMULA_PREFIX_RE.test(str)) {
    str = `'${str}`;
    escapedFormula = true;
  }
  if (escapedFormula || /[",\r\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export function exportAuditCsv(filters = {}, db = getV2Db()) {
  ensureErpSchema(db);
  const { whereSql, params } = buildFilterWhere(filters);
  const rows = db
    .prepare(
      `SELECT id, created_at, actor_id, actor_role, action, target_type, target_id,
              before_json, after_json, ip_hash
       FROM v2_audit_logs ${whereSql}
       ORDER BY created_at DESC, rowid DESC LIMIT ?`
    )
    .all(...params, MAX_CSV_ROWS);

  const headers = [
    'id', 'created_at', 'actor_id', 'actor_role', 'action',
    'target_type', 'target_id', 'before_json', 'after_json', 'ip_hash',
  ];
  const lines = [headers.join(',')];
  for (const row of rows) {
    lines.push(headers.map((col) => sanitizeCsvCell(row[col])).join(','));
  }
  return {
    filename: `omniflow-audit-logs-${new Date().toISOString().slice(0, 10)}.csv`,
    contentType: 'text/csv; charset=utf-8',
    csv: `\uFEFF${lines.join('\r\n')}\r\n`,
    rowCount: rows.length,
  };
}
