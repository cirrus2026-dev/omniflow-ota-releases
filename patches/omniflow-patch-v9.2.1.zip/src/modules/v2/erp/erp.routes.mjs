// gateway/src/modules/v2/erp/erp.routes.mjs
// OmniFlow Enterprise v2 — ERP Audit Log, API Keys & Human-Gated Sync Routes

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { makeHttpError, maskPhone, readJsonBody } from '../v2-http.mjs';
import { exportAuditCsv, queryAuditLogs } from './audit.service.mjs';
import { generateErpKey, listMaskedKeys, revokeErpKey, verifyBearerKey } from './erp-keys.service.mjs';
import {
  approveAndDispatchViaFetchSafe, dryRunPingWebhook, getSyncSettings,
  listOutboundQueue, rejectOutboundQueue, updateSyncSettings,
} from './erp-sync.service.mjs';

const DEFAULT_DATA_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../../data');

function getUrl(req, ctx) {
  return ctx?.parsedUrl instanceof URL ? ctx.parsedUrl : new URL(req?.url || '/', 'http://127.0.0.1');
}

function assertOwnerRole(req) {
  const actorId = String(req?.v2User?.id || req?.adminUser?.id || 'owner_pin').trim();
  const actorRole = String(req?.v2User?.role || req?.adminUser?.role || 'owner').trim().toLowerCase();
  const ip = String(req?.headers?.['x-forwarded-for'] || '').split(',')[0].trim() || String(req?.socket?.remoteAddress || '');
  if (actorRole !== 'owner') throw makeHttpError(403, 'Owner role is required for ERP & Audit management');
  return { actorId, actorRole, ip };
}

function parseExternalPagination(url) {
  return {
    limit: Math.min(100, Math.max(1, Number.parseInt(url.searchParams.get('limit'), 10) || 50)),
    offset: Math.max(0, Number.parseInt(url.searchParams.get('offset'), 10) || 0),
  };
}

function toSatang(amountThb) {
  const cleaned = typeof amountThb === 'string' ? amountThb.replace(/[^0-9.-]/g, '') : amountThb;
  const num = Number(cleaned);
  return Number.isFinite(num) && num >= 0 ? Math.round(num * 100) : 0;
}

function readLocalDataList(filename) {
  const targetPath = path.resolve(process.env.GATEWAY_DATA_DIR || DEFAULT_DATA_DIR, filename);
  try {
    if (!fs.existsSync(targetPath)) return [];
    const parsed = JSON.parse(fs.readFileSync(targetPath, 'utf8'));
    return Array.isArray(parsed) ? parsed : Array.isArray(parsed?.items) ? parsed.items : [];
  } catch {
    return [];
  }
}

function normalizeExternalOrder(item) {
  const amountSatang = Number.isSafeInteger(item?.amount_satang)
    ? item.amount_satang
    : toSatang(item?.estimatedTotal ?? item?.total ?? item?.amount ?? 0);
  return {
    id: String(item?.id || item?.orderId || ''),
    customer_name: String(item?.customerName || item?.customer || ''),
    customer_phone_masked: item?.phone ? maskPhone(item.phone) : '',
    status: String(item?.status || 'pending'),
    items: Array.isArray(item?.items) ? item.items : [],
    amount_satang: amountSatang,
    amount_thb: Number((amountSatang / 100).toFixed(2)),
    created_at: item?.createdAt || item?.timestamp || null,
  };
}

function normalizeExternalCatalog(item) {
  const slabSatang = Number.isSafeInteger(item?.slab_price_satang) ? item.slab_price_satang : toSatang(item?.slabPrice ?? item?.price ?? 0);
  const cutSatang = Number.isSafeInteger(item?.cut_price_satang) ? item.cut_price_satang : toSatang(item?.cutPrice ?? 0);
  return {
    id: String(item?.id || item?.sku || ''),
    name: String(item?.name || item?.stoneName || ''),
    category: String(item?.category || ''),
    unit: String(item?.unit || 'sqm'),
    slab_price_satang: slabSatang,
    slab_price_thb: Number((slabSatang / 100).toFixed(2)),
    cut_price_satang: cutSatang,
    cut_price_thb: Number((cutSatang / 100).toFixed(2)),
  };
}

function sendBearerAuthError(res, authRes, corsHeaders, sendJson) {
  const extraHeaders = authRes.retryAfterSec ? { 'Retry-After': String(authRes.retryAfterSec) } : {};
  sendJson(res, authRes.statusCode, { ok: false, error: authRes.error }, { ...extraHeaders, ...corsHeaders });
}

export function register(registerV2Route) {
  registerV2Route({
    method: 'GET', path: '/api/v2/audit-logs', auth: 'strict',
    handler: (req, res, ctx) => {
      assertOwnerRole(req);
      const q = getUrl(req, ctx).searchParams;
      const data = queryAuditLogs({
        from: q.get('from') || '', to: q.get('to') || '', action: q.get('action') || '',
        actor: q.get('actor') || '', targetType: q.get('targetType') || '', limit: q.get('limit'), offset: q.get('offset'),
      });
      ctx.sendJson(res, 200, { ok: true, ...data }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/audit-logs/export-csv', auth: 'strict',
    handler: (req, res, ctx) => {
      assertOwnerRole(req);
      const q = getUrl(req, ctx).searchParams;
      const exported = exportAuditCsv({ from: q.get('from') || '', to: q.get('to') || '', action: q.get('action') || '', actor: q.get('actor') || '' });
      res.writeHead(200, {
        'Content-Type': exported.contentType,
        'Content-Disposition': `attachment; filename="${exported.filename}"`,
        'Cache-Control': 'no-store',
        ...(ctx.corsHeaders || {}),
      });
      res.end(exported.csv);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/erp/keys', auth: 'strict',
    handler: (req, res, ctx) => {
      assertOwnerRole(req);
      ctx.sendJson(res, 200, { ok: true, items: listMaskedKeys() }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST', path: '/api/v2/erp/keys', auth: 'strict',
    handler: async (req, res, ctx) => {
      const actor = assertOwnerRole(req);
      const body = await readJsonBody(req);
      const created = generateErpKey({ ...body, createdBy: actor.actorId, actorRole: actor.actorRole, ip: actor.ip });
      ctx.sendJson(res, 201, { ok: true, key: created }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST', path: '/api/v2/erp/keys/revoke', auth: 'strict',
    handler: async (req, res, ctx) => {
      const actor = assertOwnerRole(req);
      const body = await readJsonBody(req);
      const revoked = revokeErpKey({ id: body.id, revokedBy: actor.actorId, actorRole: actor.actorRole, ip: actor.ip });
      ctx.sendJson(res, 200, { ok: true, key: revoked }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/erp/sync-settings', auth: 'strict',
    handler: (req, res, ctx) => {
      assertOwnerRole(req);
      ctx.sendJson(res, 200, { ok: true, settings: getSyncSettings() }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'PUT', path: '/api/v2/erp/sync-settings', auth: 'strict',
    handler: async (req, res, ctx) => {
      const actor = assertOwnerRole(req);
      const body = await readJsonBody(req);
      ctx.sendJson(res, 200, { ok: true, settings: updateSyncSettings(body, actor) }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST', path: '/api/v2/erp/sync-settings/ping', auth: 'strict',
    handler: async (req, res, ctx) => {
      assertOwnerRole(req);
      const body = await readJsonBody(req);
      const result = await dryRunPingWebhook({ webhookUrl: body.webhookUrl ?? body.webhook_url, webhookSecret: body.webhookSecret ?? body.webhook_secret });
      ctx.sendJson(res, result.ok ? 200 : 502, result, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/erp/outbound-queue', auth: 'strict',
    handler: (req, res, ctx) => {
      assertOwnerRole(req);
      const q = getUrl(req, ctx).searchParams;
      ctx.sendJson(res, 200, { ok: true, ...listOutboundQueue({ status: q.get('status') || '', limit: q.get('limit'), offset: q.get('offset') }) }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST', path: '/api/v2/erp/outbound-queue/approve', auth: 'strict',
    handler: async (req, res, ctx) => {
      const actor = assertOwnerRole(req);
      const body = await readJsonBody(req);
      const result = await approveAndDispatchViaFetchSafe({ id: body.id, approvedBy: actor.actorId, actorRole: actor.actorRole, ip: actor.ip });
      ctx.sendJson(res, result.ok ? 200 : 502, result, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST', path: '/api/v2/erp/outbound-queue/reject', auth: 'strict',
    handler: async (req, res, ctx) => {
      const actor = assertOwnerRole(req);
      const body = await readJsonBody(req);
      const item = rejectOutboundQueue({ id: body.id, reason: body.reason, rejectedBy: actor.actorId, actorRole: actor.actorRole, ip: actor.ip });
      ctx.sendJson(res, 200, { ok: true, item }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/erp/external/orders', auth: 'public',
    handler: (req, res, ctx) => {
      const authRes = verifyBearerKey(req, 'orders:read');
      if (!authRes.ok) return sendBearerAuthError(res, authRes, ctx.corsHeaders, ctx.sendJson);
      const { limit, offset } = parseExternalPagination(getUrl(req, ctx));
      const all = readLocalDataList('orders-db.json').map(normalizeExternalOrder);
      ctx.sendJson(res, 200, { ok: true, items: all.slice(offset, offset + limit), total: all.length, limit, offset }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/erp/external/quotes', auth: 'public',
    handler: (req, res, ctx) => {
      const authRes = verifyBearerKey(req, 'quotes:read');
      if (!authRes.ok) return sendBearerAuthError(res, authRes, ctx.corsHeaders, ctx.sendJson);
      const { limit, offset } = parseExternalPagination(getUrl(req, ctx));
      const rawQuotes = readLocalDataList('quotes-db.json');
      const source = rawQuotes.length > 0 ? rawQuotes : readLocalDataList('orders-db.json').filter((o) => ['quote', 'quoted', 'pending'].includes(String(o?.status || '')));
      const all = source.map(normalizeExternalOrder);
      ctx.sendJson(res, 200, { ok: true, items: all.slice(offset, offset + limit), total: all.length, limit, offset }, ctx.corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET', path: '/api/v2/erp/external/catalog', auth: 'public',
    handler: (req, res, ctx) => {
      const authRes = verifyBearerKey(req, 'catalog:read');
      if (!authRes.ok) return sendBearerAuthError(res, authRes, ctx.corsHeaders, ctx.sendJson);
      const { limit, offset } = parseExternalPagination(getUrl(req, ctx));
      const all = readLocalDataList('catalog-db.json').map(normalizeExternalCatalog);
      ctx.sendJson(res, 200, { ok: true, items: all.slice(offset, offset + limit), total: all.length, limit, offset }, ctx.corsHeaders);
    },
  });
}
