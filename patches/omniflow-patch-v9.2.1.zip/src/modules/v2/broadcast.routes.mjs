// gateway/src/modules/v2/broadcast.routes.mjs
// Category 3: Campaigns, Policy Audience Preview, Smart Drip Steps & Queue Routes

import { readJsonBody } from './v2-http.mjs';
import {
  listCampaigns,
  createCampaign,
  previewPolicyAudience,
  enqueueCampaignBroadcast,
  listDripSteps,
  upsertDripStep,
  getQueueStats,
} from './broadcast.service.mjs';

export function register(registerV2Route) {
  registerV2Route({
    method: 'GET',
    path: '/api/v2/campaigns',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, campaigns: listCampaigns() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/campaigns',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      const campaign = createCampaign(body);
      sendJson(res, 201, { ok: true, campaign }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/campaigns/preview',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson, stateStore }) => {
      const body = await readJsonBody(req);
      const preview = previewPolicyAudience({ ...body, stateStore });
      sendJson(res, 200, { ok: true, ...preview, eligible: undefined }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/campaigns/send',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson, stateStore }) => {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, ...enqueueCampaignBroadcast({ ...body, stateStore }) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/drip-steps',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, steps: listDripSteps() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/drip-steps',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, step: upsertDripStep(body) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/queue/status',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, ...getQueueStats() }, corsHeaders);
    },
  });
}
