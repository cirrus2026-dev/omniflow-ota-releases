// gateway/src/modules/v2/rbac.routes.mjs
// Category 2: RBAC, Chat Assignment & Shift Handover HTTP Routes

import { readJsonBody } from './v2-http.mjs';
import {
  listUsers,
  createUser,
  updateUser,
  listAssignments,
  assignChat,
  getAgentKpis,
  listShiftHandovers,
  createShiftHandover,
} from './rbac.service.mjs';

export function register(registerV2Route) {
  registerV2Route({
    method: 'GET',
    path: '/api/v2/rbac/users',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, users: listUsers() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/rbac/users',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      const user = createUser(body);
      sendJson(res, 201, { ok: true, user }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/rbac/users/update',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      const user = updateUser(body);
      sendJson(res, 200, { ok: true, user }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/rbac/assignments',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, assignments: listAssignments() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/rbac/assignments',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      const assignment = assignChat(body);
      sendJson(res, 200, { ok: true, assignment }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/rbac/kpis',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, kpis: getAgentKpis() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/shifts/handovers',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, handovers: listShiftHandovers() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/shifts/handover',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson, stateStore }) => {
      const body = await readJsonBody(req);
      const handover = createShiftHandover({ ...body, stateStore });
      sendJson(res, 201, { ok: true, handover }, corsHeaders);
    },
  });
}
