// gateway/src/modules/v2/marketing.routes.mjs
// Category 5: SaaS Growth Marketing, Attribution, ROAS, PQL & PDPA Routes

import { readJsonBody } from './v2-http.mjs';
import {
  recordTouchpoint,
  recordAdSpend,
  getSaasMetrics,
  getFunnelRoas,
  getHotPqlAccounts,
  recordConsent,
  anonymizeSaasAccount,
} from './marketing.service.mjs';

export function register(registerV2Route) {
  registerV2Route({
    method: 'POST',
    path: '/api/v2/marketing/touchpoint',
    auth: 'public',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 201, { ok: true, ...recordTouchpoint(body) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/marketing/ad-spend',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, spend: recordAdSpend(body) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/marketing/saas-metrics',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, metrics: getSaasMetrics() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/marketing/funnel-roas',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, campaigns: getFunnelRoas() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/marketing/pql-hot',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      sendJson(res, 200, { ok: true, leads: getHotPqlAccounts() }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/pdpa/consents',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 201, { ok: true, consent: recordConsent(body) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/pdpa/dsar/anonymize-account',
    auth: 'strict',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, ...anonymizeSaasAccount(body) }, corsHeaders);
    },
  });
}
