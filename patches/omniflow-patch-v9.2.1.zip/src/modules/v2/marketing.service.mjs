// gateway/src/modules/v2/marketing.service.mjs
// Category 5: SaaS Growth Marketing, UTM Attribution, ROAS, Hot PQL & PDPA DSAR

import { getV2Db, withV2Transaction } from './v2-db.mjs';
import { makeHttpError, newId } from './v2-http.mjs';

const VALID_STAGE_EVENTS = new Set([
  'landing_view',
  'signup_started',
  'trial_created',
  'channel_linked',
  'aha_moment',
  'subscription_paid',
  'plan_upgraded',
]);

const VALID_PURPOSE_CODES = new Set([
  'saas_tos_dpa',
  'product_onboarding_comms',
  'saas_marketing_promo',
  'ad_conversion_capi',
]);

export function recordTouchpoint(payload = {}) {
  const visitorAnonId = String(payload.visitorAnonId || newId('VIS')).trim();
  const stageEvent = String(payload.stageEvent || 'landing_view').trim();
  if (!VALID_STAGE_EVENTS.has(stageEvent)) {
    throw makeHttpError(400, `stageEvent ไม่ถูกต้อง (${stageEvent})`);
  }
  const id = newId('EVT');
  getV2Db()
    .prepare(
      `INSERT INTO v2_saas_attribution_events
       (id, visitor_anon_id, account_id, workspace_id, stage_event, utm_source, utm_medium, utm_campaign, fbclid, gclid, ttclid, referrer_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      id,
      visitorAnonId,
      payload.accountId || null,
      payload.workspaceId || null,
      stageEvent,
      payload.utmSource || null,
      payload.utmMedium || null,
      payload.utmCampaign || null,
      payload.fbclid || null,
      payload.gclid || null,
      payload.ttclid || null,
      payload.referrerUrl || null
    );
  return { id, visitorAnonId, stageEvent };
}

export function recordAdSpend({ spendDate, adPlatform, utmCampaign, spendSatang, impressions = 0, clicks = 0 }) {
  if (!spendDate || !adPlatform || !utmCampaign) {
    throw makeHttpError(400, 'กรุณาระบุ spendDate, adPlatform และ utmCampaign');
  }
  const satang = Math.max(0, Math.round(Number(spendSatang) || 0));
  getV2Db()
    .prepare(
      `INSERT INTO v2_saas_ad_spend (spend_date, ad_platform, utm_campaign, spend_satang, impressions, clicks)
       VALUES (?, ?, ?, ?, ?, ?)
       ON CONFLICT(spend_date, ad_platform, utm_campaign) DO UPDATE SET
         spend_satang = excluded.spend_satang,
         impressions = excluded.impressions,
         clicks = excluded.clicks`
    )
    .run(String(spendDate), String(adPlatform), String(utmCampaign), satang, Number(impressions) || 0, Number(clicks) || 0);
  return { spendDate, adPlatform, utmCampaign, spendSatang: satang };
}

export function getSaasMetrics() {
  const db = getV2Db();
  const subRow = db
    .prepare(
      `SELECT
         SUM(CASE WHEN status = 'active' THEN mrr_satang ELSE 0 END) AS mrr_satang,
         SUM(CASE WHEN status = 'trialing' THEN 1 ELSE 0 END) AS trialing_count,
         SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_paid_count,
         SUM(CASE WHEN status IN ('churned', 'cancelled') THEN 1 ELSE 0 END) AS churned_count
       FROM v2_subscriptions`
    )
    .get();

  const spendRow = db.prepare('SELECT COALESCE(SUM(spend_satang), 0) AS total_spend_satang FROM v2_saas_ad_spend').get();

  const mrrSatang = Number(subRow?.mrr_satang || 0);
  const activePaid = Number(subRow?.active_paid_count || 0);
  const trialing = Number(subRow?.trialing_count || 0);
  const churned = Number(subRow?.churned_count || 0);
  const totalSpendSatang = Number(spendRow?.total_spend_satang || 0);

  const totalTrials = activePaid + trialing + churned;
  const trialToPaidPct = totalTrials > 0 ? Math.round((activePaid / totalTrials) * 1000) / 10 : 0;
  const churnPct = activePaid + churned > 0 ? Math.round((churned / (activePaid + churned)) * 1000) / 10 : 0;
  const cacBaht = activePaid > 0 ? Math.round(totalSpendSatang / activePaid / 100) : 0;

  return {
    mrrBaht: Math.round(mrrSatang / 100),
    arrBaht: Math.round((mrrSatang * 12) / 100),
    activePaidCount: activePaid,
    trialingCount: trialing,
    trialToPaidPct,
    churnPct,
    cacBaht,
    totalAdSpendBaht: Math.round(totalSpendSatang / 100),
  };
}

export function getFunnelRoas() {
  const db = getV2Db();
  const spends = db
    .prepare('SELECT utm_campaign, ad_platform, SUM(spend_satang) AS spend_satang FROM v2_saas_ad_spend GROUP BY utm_campaign, ad_platform')
    .all();
  const signups = db
    .prepare(
      `SELECT utm_campaign,
              COUNT(DISTINCT account_id) AS signups,
              SUM(revenue_satang) AS revenue_satang
       FROM v2_saas_attribution_events
       WHERE utm_campaign IS NOT NULL
       GROUP BY utm_campaign`
    )
    .all();

  const sigMap = new Map(signups.map((s) => [s.utm_campaign, s]));
  const campaignSpendTotals = new Map();
  for (const sp of spends) {
    campaignSpendTotals.set(
      sp.utm_campaign,
      (campaignSpendTotals.get(sp.utm_campaign) || 0) + Number(sp.spend_satang || 0)
    );
  }

  return spends.map((sp) => {
    const s = sigMap.get(sp.utm_campaign);
    const rowSpendSatang = Number(sp.spend_satang || 0);
    const totalCampSpendSatang = campaignSpendTotals.get(sp.utm_campaign) || rowSpendSatang;
    const share = totalCampSpendSatang > 0 ? rowSpendSatang / totalCampSpendSatang : 1;
    const spendBaht = Math.round(rowSpendSatang / 100);
    const revBaht = Math.round((Number(s?.revenue_satang || 0) * share) / 100);
    const roas = spendBaht > 0 ? Math.round((revBaht / spendBaht) * 100) / 100 : 0;
    return {
      utmCampaign: sp.utm_campaign,
      adPlatform: sp.ad_platform,
      spendBaht,
      signups: Math.round(Number(s?.signups || 0) * share),
      revenueBaht: revBaht,
      roas,
    };
  });
}

export function getHotPqlAccounts() {
  return getV2Db()
    .prepare(
      `SELECT w.id AS workspace_id, a.company_name, a.team_size_bucket, s.plan_code, s.status,
              w.connected_channels_count, w.ai_quota_used,
              (CASE WHEN a.team_size_bucket IN ('11-50','50+') THEN 30 ELSE 10 END
               + CASE WHEN w.connected_channels_count > 0 THEN 30 ELSE 0 END
               + CASE WHEN w.ai_quota_used >= 20 THEN 40 ELSE w.ai_quota_used * 2 END) AS pql_score
       FROM v2_workspaces w
       JOIN v2_saas_accounts a ON w.owner_account_id = a.id
       JOIN v2_subscriptions s ON s.workspace_id = w.id
       WHERE s.status = 'trialing'
       ORDER BY pql_score DESC LIMIT 20`
    )
    .all();
}

export function recordConsent({ accountId, purposeCode, action, policyVersion = 'v2026.1', proofSource = 'account_settings' }) {
  if (!accountId || !purposeCode || !['opt_in', 'opt_out'].includes(action)) {
    throw makeHttpError(400, 'ข้อมูล Consent ไม่ครบถ้วน');
  }
  if (!VALID_PURPOSE_CODES.has(purposeCode)) {
    throw makeHttpError(400, `purposeCode ไม่ถูกต้อง (${purposeCode})`);
  }
  const id = newId('CNS');
  getV2Db()
    .prepare(
      `INSERT INTO v2_consent_logs (id, account_id, purpose_code, action, policy_version, proof_source)
       VALUES (?, ?, ?, ?, ?, ?)`
    )
    .run(id, accountId, purposeCode, action, policyVersion, proofSource);
  return { id, accountId, purposeCode, action };
}

export function anonymizeSaasAccount({ accountId }) {
  if (!accountId) throw makeHttpError(400, 'ต้องระบุ accountId');
  return withV2Transaction((db) => {
    const acc = db.prepare('SELECT id FROM v2_saas_accounts WHERE id = ?').get(accountId);
    if (!acc) throw makeHttpError(404, 'ไม่พบบัญชีผู้ใช้');
    const redactedToken = `REDACTED_${accountId}`;
    db.prepare(
      `UPDATE v2_saas_accounts
       SET email_hash = ?, email_encrypted = 'REDACTED', phone_hash = NULL, phone_encrypted = NULL,
           password_hash = 'REDACTED', full_name = 'REDACTED', status = 'anonymized'
       WHERE id = ?`
    ).run(redactedToken, accountId);
    db.prepare(
      `UPDATE v2_saas_attribution_events
       SET visitor_anon_id = ?, fbclid = NULL, gclid = NULL, ttclid = NULL, referrer_url = NULL
       WHERE account_id = ?`
    ).run(redactedToken, accountId);
    db.prepare(
      `INSERT INTO v2_consent_logs (id, account_id, purpose_code, action, policy_version, proof_source)
       VALUES (?, ?, 'saas_tos_dpa', 'opt_out', 'v2026.1', 'dsar_anonymize')`
    ).run(newId('CNS'), accountId);
    return { accountId, status: 'anonymized', revenuePreserved: true };
  });
}
