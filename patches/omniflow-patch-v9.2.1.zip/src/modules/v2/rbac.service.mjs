// gateway/src/modules/v2/rbac.service.mjs
// Category 2: Multi-User RBAC, Chat Assignments & Shift Handover Service

import { getV2Db, withV2Transaction } from './v2-db.mjs';
import { hashPassword, makeHttpError, newId } from './v2-http.mjs';

const VALID_ROLES = new Set(['owner', 'sales_morning', 'sales_night', 'accounting']);
const VALID_SHIFTS = new Set(['morning', 'night']);
const VALID_ASSIGN_STATUS = new Set(['open', 'pending_deposit', 'resolved_ai', 'resolved_human']);

export function listUsers() {
  const db = getV2Db();
  return db
    .prepare('SELECT id, username, display_name, role, is_active, created_at FROM v2_users ORDER BY created_at DESC')
    .all()
    .map((u) => ({ ...u, canViewApiKeys: u.role === 'owner' }));
}

export function createUser({ username, password, displayName, role }) {
  const uname = String(username || '').trim().toLowerCase();
  const dname = String(displayName || '').trim();
  if (!uname || !password || !dname) {
    throw makeHttpError(400, 'กรุณากรอก username, password และ displayName ให้ครบ');
  }
  if (String(password).length < 6) {
    throw makeHttpError(400, 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร');
  }
  if (!VALID_ROLES.has(role)) {
    throw makeHttpError(400, 'สิทธิ์ Role ไม่ถูกต้อง');
  }
  const db = getV2Db();
  const exists = db.prepare('SELECT id FROM v2_users WHERE username = ?').get(uname);
  if (exists) throw makeHttpError(409, 'Username นี้มีผู้ใช้งานแล้ว');

  const id = newId('USR');
  const passwordHash = hashPassword(password);
  db.prepare(
    'INSERT INTO v2_users (id, username, password_hash, display_name, role, is_active) VALUES (?, ?, ?, ?, ?, 1)'
  ).run(id, uname, passwordHash, dname, role);
  return { id, username: uname, display_name: dname, role, is_active: 1, canViewApiKeys: role === 'owner' };
}

export function updateUser({ id, role, isActive, displayName }) {
  if (!id) throw makeHttpError(400, 'ต้องระบุ id ผู้ใช้');
  const db = getV2Db();
  const existing = db.prepare('SELECT id, role, is_active, display_name FROM v2_users WHERE id = ?').get(id);
  if (!existing) throw makeHttpError(404, 'ไม่พบผู้ใช้งาน');

  const nextRole = role && VALID_ROLES.has(role) ? role : existing.role;
  const nextActive = typeof isActive === 'boolean' ? (isActive ? 1 : 0) : existing.is_active;
  const nextName = displayName ? String(displayName).trim() : existing.display_name;

  db.prepare('UPDATE v2_users SET role = ?, is_active = ?, display_name = ? WHERE id = ?').run(
    nextRole,
    nextActive,
    nextName,
    id
  );
  return { id, role: nextRole, is_active: nextActive, display_name: nextName, canViewApiKeys: nextRole === 'owner' };
}

export function listAssignments() {
  return getV2Db()
    .prepare(
      `SELECT a.*, u.display_name AS agent_name, u.role AS agent_role
       FROM v2_chat_assignments a
       LEFT JOIN v2_users u ON a.assigned_to = u.id
       ORDER BY a.assigned_at DESC LIMIT 100`
    )
    .all();
}

export function assignChat({ chatId, channel, assignedTo, assignedBy, status = 'open', firstResponseMs = null }) {
  if (!chatId || !channel) throw makeHttpError(400, 'ต้องระบุ chatId และ channel');
  if (!VALID_ASSIGN_STATUS.has(status)) throw makeHttpError(400, 'สถานะแชทไม่ถูกต้อง');
  const db = getV2Db();
  const resolvedAt = status.startsWith('resolved_') ? new Date().toISOString() : null;
  db.prepare(
    `INSERT INTO v2_chat_assignments (chat_id, channel, assigned_to, assigned_by, status, first_response_ms, resolved_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)
     ON CONFLICT(chat_id) DO UPDATE SET
       assigned_to = excluded.assigned_to,
       assigned_by = excluded.assigned_by,
       status = excluded.status,
       first_response_ms = COALESCE(excluded.first_response_ms, v2_chat_assignments.first_response_ms),
       resolved_at = excluded.resolved_at`
  ).run(chatId, String(channel), assignedTo || null, assignedBy || null, status, firstResponseMs, resolvedAt);
  return db.prepare('SELECT * FROM v2_chat_assignments WHERE chat_id = ?').get(chatId);
}

export function getAgentKpis() {
  return getV2Db()
    .prepare(
      `SELECT u.id, u.display_name, u.role,
              COUNT(a.chat_id) AS total_chats,
              SUM(CASE WHEN a.status = 'resolved_human' THEN 1 ELSE 0 END) AS resolved_chats,
              ROUND(AVG(a.first_response_ms)) AS avg_frt_ms
       FROM v2_users u
       LEFT JOIN v2_chat_assignments a ON u.id = a.assigned_to
       WHERE u.is_active = 1
       GROUP BY u.id
       ORDER BY total_chats DESC`
    )
    .all();
}

export function listShiftHandovers() {
  return getV2Db()
    .prepare(
      `SELECT h.*, u.display_name AS handover_by_name
       FROM v2_shift_handovers h
       LEFT JOIN v2_users u ON h.handover_by = u.id
       ORDER BY h.created_at DESC LIMIT 30`
    )
    .all();
}

export function createShiftHandover({ fromShift, toShift, handoverBy, pinnedNotes = '', stateStore = null }) {
  if (!VALID_SHIFTS.has(fromShift) || !VALID_SHIFTS.has(toShift) || fromShift === toShift) {
    throw makeHttpError(400, 'กะส่งมอบ (morning <-> night) ไม่ถูกต้อง');
  }
  return withV2Transaction((db) => {
    const openRows = db
      .prepare("SELECT chat_id, channel, status FROM v2_chat_assignments WHERE status IN ('open', 'pending_deposit')")
      .all();
    const getList = stateStore?.getConversationsList || stateStore?.listConversations;
    const liveConvCount = typeof getList === 'function' ? (getList.call(stateStore) || []).length : 0;
    const openChatsCount = openRows.filter((r) => r.status === 'open').length || liveConvCount;
    const pendingQuotesCount = openRows.filter((r) => r.status === 'pending_deposit').length;

    const id = newId('SHF');
    const snapshotJson = JSON.stringify({ openRows: openRows.slice(0, 50), liveConvCount });
    db.prepare(
      `INSERT INTO v2_shift_handovers
       (id, from_shift, to_shift, handover_by, open_chats_count, pending_quotes_count, pinned_notes, snapshot_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, fromShift, toShift, handoverBy || null, openChatsCount, pendingQuotesCount, String(pinnedNotes), snapshotJson);

    return db.prepare('SELECT * FROM v2_shift_handovers WHERE id = ?').get(id);
  });
}
