// gateway/src/modules/v2/auth-rate-limit.mjs
// OmniFlow Enterprise v2 — Shared Rate Limiter for Login & OTP Verification

import { createPinRateLimiter, getRateLimitClientKey } from '../admin-auth-guard.mjs';
import { makeHttpError } from './v2-http.mjs';

const limiter = createPinRateLimiter({
  maxAttempts: 5,
  windowMs: 15 * 60 * 1000,
  lockoutMs: 15 * 60 * 1000,
});

export function assertAuthAttemptAllowed(req) {
  const key = getRateLimitClientKey(req);
  const rl = limiter.checkPinRateLimit(key);
  if (!rl.allowed) {
    throw makeHttpError(429, `ลองผิดเกินกำหนด กรุณารอ ${rl.retryAfterSec} วินาที`);
  }
}

export function recordAuthFailure(req) {
  return limiter.recordPinFailure(getRateLimitClientKey(req));
}

export function clearAuthFailures(req) {
  return limiter.clearPinFailures(getRateLimitClientKey(req));
}

export function resetAuthRateLimit() {
  limiter.resetAll();
}
