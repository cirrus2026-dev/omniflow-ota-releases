// gateway/src/modules/v2/v2-db.mjs
// OmniFlow Enterprise v2 — SQLite Foundation Core (Built-in node:sqlite, WAL Mode, 16 Tables)
// IMPORTANT: Must NOT import v2-router.mjs directly to prevent circular TDZ initialization.

import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { V2_EXPECTED_TABLES, V2_SCHEMA_DDL } from './v2-schema.mjs';

export { V2_EXPECTED_TABLES, V2_SCHEMA_DDL };

let dbInstance = null;
let activeDbPath = null;
let txDepth = 0;

function isMemoryTarget(targetPath) {
  return targetPath === ':memory:' || targetPath.startsWith('file::memory:') || targetPath.includes('mode=memory');
}

function resolveV2DbPath(customPath) {
  const raw = String(customPath || process.env.OMNIFLOW_V2_DB_PATH || '').trim();
  if (!raw) {
    return path.resolve(process.cwd(), 'data', 'omniflow-v2.db');
  }
  return isMemoryTarget(raw) ? raw : path.resolve(raw);
}

/**
 * Initialize SQLite database in WAL mode and create all 16 schema tables & indexes idempotently.
 */
export function initV2Db(options = {}) {
  const requestedPath = resolveV2DbPath(options?.dbPath);
  if (dbInstance && activeDbPath === requestedPath) {
    return dbInstance;
  }
  if (dbInstance && activeDbPath !== requestedPath) {
    closeV2Db();
  }

  const inMemory = isMemoryTarget(requestedPath);
  if (!inMemory) {
    fs.mkdirSync(path.dirname(requestedPath), { recursive: true });
  }

  const db = new DatabaseSync(requestedPath);
  try {
    db.exec('PRAGMA foreign_keys = ON;');
    db.exec('PRAGMA busy_timeout = 5000;');
    if (!inMemory) {
      db.exec('PRAGMA journal_mode = WAL;');
      db.exec('PRAGMA synchronous = NORMAL;');
    }
    db.exec(V2_SCHEMA_DDL);
  const subSql = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='v2_subscriptions'").get()?.sql || '';
  if (subSql && !subSql.includes("'free_6m'")) {
    const cols = 'id, workspace_id, plan_code, billing_cycle, status, mrr_satang, trial_starts_at, trial_ends_at, current_period_start, current_period_end, converted_from_trial_at, canceled_at, created_at, updated_at';
    db.exec('PRAGMA foreign_keys = OFF;');
    try {
      db.exec('BEGIN IMMEDIATE;');
      db.exec(`
        CREATE TABLE v2_subscriptions_new (
          id TEXT PRIMARY KEY,
          workspace_id TEXT NOT NULL UNIQUE REFERENCES v2_workspaces(id) ON DELETE CASCADE,
          plan_code TEXT NOT NULL DEFAULT 'free_trial' CHECK (plan_code IN ('free_trial', 'free_6m', 'starter', 'pro', 'enterprise')),
          billing_cycle TEXT NOT NULL DEFAULT 'trial' CHECK (billing_cycle IN ('trial', 'monthly', 'yearly')),
          status TEXT NOT NULL DEFAULT 'trialing' CHECK (status IN ('trialing', 'active', 'past_due', 'canceled', 'expired')),
          mrr_satang INTEGER NOT NULL DEFAULT 0,
          trial_starts_at TEXT, trial_ends_at TEXT, current_period_start TEXT, current_period_end TEXT,
          converted_from_trial_at TEXT, canceled_at TEXT,
          created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        INSERT INTO v2_subscriptions_new (${cols}) SELECT ${cols} FROM v2_subscriptions;
        DROP TABLE v2_subscriptions;
        ALTER TABLE v2_subscriptions_new RENAME TO v2_subscriptions;
      `);
      db.exec('COMMIT;');
    } catch (err) {
      try { db.exec('ROLLBACK;'); } catch { /* ignore */ }
      throw err;
    } finally {
      db.exec('PRAGMA foreign_keys = ON;');
    }
  }
  } catch (err) {
    try { db.close(); } catch { /* ignore close error on failed init */ }
    throw err;
  }

  dbInstance = db;
  activeDbPath = requestedPath;
  txDepth = 0;
  return dbInstance;
}

/**
 * Return the active DatabaseSync instance, initializing lazily if needed.
 */
export function getV2Db() {
  return dbInstance || initV2Db();
}

/**
 * Execute synchronous callback inside an immediate SQLite transaction (with savepoints for nested calls).
 * Rejects async callbacks because node:sqlite DatabaseSync transactions cannot safely interleave across await.
 */
export function withV2Transaction(fn) {
  if (typeof fn !== 'function') {
    throw new TypeError('withV2Transaction requires a callback function');
  }
  const db = getV2Db();
  const depth = txDepth;
  const spName = `v2_sp_${depth}`;

  db.exec(depth === 0 ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${spName}`);
  txDepth += 1;

  let committed = false;
  try {
    const result = fn(db);
    if (result && typeof result.then === 'function') {
      throw new TypeError('withV2Transaction does not support async callbacks with synchronous node:sqlite');
    }
    db.exec(depth === 0 ? 'COMMIT' : `RELEASE SAVEPOINT ${spName}`);
    txDepth -= 1;
    committed = true;
    return result;
  } catch (err) {
    if (!committed) {
      txDepth = depth;
      try {
        db.exec(depth === 0 ? 'ROLLBACK' : `ROLLBACK TO SAVEPOINT ${spName}`);
        if (depth > 0) db.exec(`RELEASE SAVEPOINT ${spName}`);
      } catch { /* ignore secondary rollback error */ }
    }
    throw err;
  }
}

/**
 * Return database readiness metrics, journal mode, and created table count.
 */
export function getV2DbHealth() {
  try {
    const db = getV2Db();
    const jmRow = db.prepare('PRAGMA journal_mode').get();
    const cntRow = db.prepare("SELECT COUNT(*) AS cnt FROM sqlite_master WHERE type = 'table' AND name LIKE 'v2_%'").get();
    const journalMode = String(jmRow?.journal_mode || '').toLowerCase();
    const tableCount = Number(cntRow?.cnt ?? 0);
    return {
      ok: Boolean(journalMode) && tableCount >= V2_EXPECTED_TABLES.length,
      journalMode,
      tableCount,
      dbName: activeDbPath ? path.basename(activeDbPath) : null,
    };
  } catch (err) {
    return { ok: false, journalMode: 'error', tableCount: 0, dbName: null, error: err.message };
  }
}

/**
 * Safely close the active SQLite connection and reset internal handle state.
 */
export function closeV2Db() {
  if (!dbInstance) return;
  const db = dbInstance;
  dbInstance = null;
  activeDbPath = null;
  txDepth = 0;
  try {
    db.close();
  } catch { /* ignore already-closed handle */ }
}

/**
 * Register database health endpoint with v2-router (initializes DB lazily on first use).
 */
export function register(registerV2Route) {
  registerV2Route({
    method: 'GET',
    path: '/api/v2/db/health',
    auth: 'admin',
    handler: (_req, res, { corsHeaders, sendJson }) => {
      const health = getV2DbHealth();
      sendJson(res, health.ok ? 200 : 503, health, corsHeaders);
    },
  });
}
