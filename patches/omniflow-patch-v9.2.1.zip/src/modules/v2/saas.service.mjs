// gateway/src/modules/v2/saas.service.mjs
// Category 4: B2B SaaS Signup, Workspaces, Free 6M (180 Days), Trial-to-Paid & Onboarding Milestones

import { getV2Db, withV2Transaction } from './v2-db.mjs';
import { encryptPii, hashPassword, hmacLookupHash, makeHttpError, newId } from './v2-http.mjs';

export const PLAN_MRR_SATANG = Object.freeze({
  free_trial: 0,
  free_6m: 0,        // Free 6-Month Launch Plan (180 days)
  starter: 149000,   // 1,490 THB/mo
  pro: 299000,       // 2,990 THB/mo
  enterprise: 799000 // 7,990 THB/mo
});

export const TRIAL_DAYS = 14;
export const FREE_6M_DAYS = 180;
const DAY_MS = 86_400_000;
const MAX_PENDING_PLANS = 500;
const pendingTrialPlanByAccount = new Map();

function normalizeInitialPlan(rawPlan) {
  return String(rawPlan || '').trim().toLowerCase() === 'free_6m' ? 'free_6m' : 'free_trial';
}

function rememberPendingPlan(accountId, planCode) {
  if (pendingTrialPlanByAccount.size >= MAX_PENDING_PLANS) {
    const oldestKey = pendingTrialPlanByAccount.keys().next().value;
    if (oldestKey) pendingTrialPlanByAccount.delete(oldestKey);
  }
  pendingTrialPlanByAccount.set(accountId, planCode);
}

export function computeDaysRemaining(trialEndsAt, nowMs = Date.now()) {
  if (!trialEndsAt) return null;
  const endMs = Date.parse(String(trialEndsAt));
  if (!Number.isFinite(endMs)) return null;
  return Math.max(0, Math.ceil((endMs - nowMs) / DAY_MS));
}

export function signupSaasAccount(payload = {}) {
  const email = String(payload.email || '').trim().toLowerCase();
  const phone = String(payload.phone || '').trim();
  const fullName = String(payload.fullName || '').trim();
  const companyName = String(payload.companyName || '').trim();
  const industry = String(payload.businessIndustry || 'general').trim();
  const teamSize = String(payload.teamSizeBucket || '1-2').trim();
  const primaryGoal = String(payload.primaryGoal || 'unify_channels').trim();
  const password = String(payload.password || '');
  const selectedPlan = normalizeInitialPlan(payload.planCode);

  if (!email || !fullName || !companyName || password.length < 6) {
    throw makeHttpError(400, 'กรุณากรอกอีเมล, ชื่อ, ชื่อบริษัท และรหัสผ่าน (>= 6 ตัวอักษร)');
  }
  if (!payload.acceptTosDpa) {
    throw makeHttpError(400, 'กรุณายอมรับเงื่อนไขการใช้บริการและ B2B DPA ก่อนสมัคร');
  }

  return withV2Transaction((db) => {
    const emailHash = hmacLookupHash(email);
    const exists = db.prepare('SELECT id FROM v2_saas_accounts WHERE email_hash = ?').get(emailHash);
    if (exists) throw makeHttpError(409, 'อีเมลนี้ลงทะเบียนใช้งานแล้ว');

    const accountId = newId('ACC');
    const phoneHash = phone ? hmacLookupHash(phone) : null;
    if (phoneHash) {
      const phoneExists = db.prepare('SELECT id FROM v2_saas_accounts WHERE phone_hash = ?').get(phoneHash);
      if (phoneExists) throw makeHttpError(409, 'เบอร์โทรศัพท์นี้ลงทะเบียนใช้งานแล้ว');
    }
    db.prepare(
      `INSERT INTO v2_saas_accounts
       (id, email_hash, email_encrypted, phone_hash, phone_encrypted, password_hash, full_name,
        company_name, business_industry, team_size_bucket, primary_goal, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_otp')`
    ).run(
      accountId,
      emailHash,
      encryptPii(email),
      phoneHash,
      phone ? encryptPii(phone) : null,
      hashPassword(password),
      fullName,
      companyName,
      industry,
      teamSize,
      primaryGoal
    );

    const consents = [
      ['saas_tos_dpa', 'opt_in'],
      ['product_onboarding_comms', payload.acceptOnboardingComms ? 'opt_in' : 'opt_out'],
      ['saas_marketing_promo', payload.acceptMarketingPromo ? 'opt_in' : 'opt_out'],
      ['ad_conversion_capi', payload.acceptCapi ? 'opt_in' : 'opt_out'],
    ];
    const insertConsent = db.prepare(
      `INSERT INTO v2_consent_logs (id, account_id, purpose_code, action, policy_version, proof_source)
       VALUES (?, ?, ?, ?, 'v2026.1', 'signup_form')`
    );
    for (const [purpose, action] of consents) {
      insertConsent.run(newId('CNS'), accountId, purpose, action);
    }

    const visitorAnonId = String(payload.visitorAnonId || newId('VIS'));
    db.prepare(
      `INSERT INTO v2_saas_attribution_events
       (id, visitor_anon_id, account_id, stage_event, utm_source, utm_medium, utm_campaign, fbclid, gclid, ttclid)
       VALUES (?, ?, ?, 'signup_started', ?, ?, ?, ?, ?, ?)`
    ).run(
      newId('EVT'),
      visitorAnonId,
      accountId,
      payload.utmSource || null,
      payload.utmMedium || null,
      payload.utmCampaign || null,
      payload.fbclid || null,
      payload.gclid || null,
      payload.ttclid || null
    );

    rememberPendingPlan(accountId, selectedPlan);
    const isSandboxOtp = process.env.NODE_ENV !== 'production' && (process.env.ENABLE_SANDBOX_SIMULATOR === 'true' || process.env.OMNIFLOW_SANDBOX_OTP !== '0');
    return { accountId, planCode: selectedPlan, status: 'pending_otp', ...(isSandboxOtp ? { devOtpHint: '123456' } : {}) };
  });
}

export function verifySaasOtp({ accountId, otp, planCode } = {}) {
  if (!accountId || !otp) throw makeHttpError(400, 'ต้องระบุ accountId และรหัส OTP');
  const allowSandboxOtp = process.env.NODE_ENV !== 'production' && (process.env.ENABLE_SANDBOX_SIMULATOR === 'true' || process.env.OMNIFLOW_SANDBOX_OTP !== '0');
  if (!allowSandboxOtp) {
    throw makeHttpError(501, 'Production OTP verification requires configured SMS/Email provider');
  }
  if (String(otp).trim() !== '123456') throw makeHttpError(400, 'รหัส OTP ไม่ถูกต้อง (Sandbox ใช้ 123456)');

  const resolvedPlan = normalizeInitialPlan(planCode ?? pendingTrialPlanByAccount.get(accountId));
  const durationDays = resolvedPlan === 'free_6m' ? FREE_6M_DAYS : TRIAL_DAYS;

  const out = withV2Transaction((db) => {
    const acc = db.prepare('SELECT * FROM v2_saas_accounts WHERE id = ?').get(accountId);
    if (!acc) throw makeHttpError(404, 'ไม่พบบัญชีผู้ใช้');
    if (acc.status !== 'pending_otp') {
      throw makeHttpError(409, 'บัญชีนี้ยืนยันแล้ว กรุณาเข้าสู่ระบบด้วยอีเมลและรหัสผ่าน');
    }

    const now = new Date();
    const trialEnds = new Date(now.getTime() + durationDays * DAY_MS).toISOString();
    const nowIso = now.toISOString();

    db.prepare("UPDATE v2_saas_accounts SET status = 'active', email_verified_at = ? WHERE id = ?").run(nowIso, accountId);

    let ws = db.prepare('SELECT * FROM v2_workspaces WHERE owner_account_id = ?').get(accountId);
    if (!ws) {
      const wsId = newId('WS');
      const slug = `${acc.company_name.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 20) || 'shop'}-${wsId.slice(-4)}`;
      db.prepare('INSERT INTO v2_workspaces (id, slug, name, owner_account_id) VALUES (?, ?, ?, ?)').run(
        wsId,
        slug,
        acc.company_name,
        accountId
      );
      db.prepare(
        `INSERT INTO v2_subscriptions (id, workspace_id, plan_code, billing_cycle, status, mrr_satang, trial_starts_at, trial_ends_at)
         VALUES (?, ?, ?, 'trial', 'trialing', 0, ?, ?)`
      ).run(newId('SUB'), wsId, resolvedPlan, nowIso, trialEnds);
      db.prepare(
        `INSERT INTO v2_onboarding_milestones (workspace_id, step_account_verifiedAt, step_profile_completedAt, onboarding_score)
         VALUES (?, ?, ?, 40)`
      ).run(wsId, nowIso, nowIso);
      const dripAt = new Date(now.getTime() + DAY_MS).toISOString();
      db.prepare(
        `INSERT INTO v2_saas_onboarding_drips (id, account_id, workspace_id, trigger_rule, delivery_channel, status, scheduled_for)
         VALUES (?, ?, ?, 'no_channel_24h', 'email', 'scheduled', ?)`
      ).run(newId('DRP'), accountId, wsId, dripAt);
      db.prepare(
        `INSERT INTO v2_saas_attribution_events (id, visitor_anon_id, account_id, workspace_id, stage_event)
         VALUES (?, ?, ?, ?, 'trial_created')`
      ).run(newId('EVT'), accountId, accountId, wsId);
      ws = db.prepare('SELECT * FROM v2_workspaces WHERE id = ?').get(wsId);
    }

    const sub = db.prepare('SELECT * FROM v2_subscriptions WHERE workspace_id = ?').get(ws.id);
    const activeTrialEnds = sub?.trial_ends_at || trialEnds;
    return {
      accountId,
      workspace: ws,
      planCode: sub?.plan_code || resolvedPlan,
      trialEndsAt: activeTrialEnds,
      daysRemaining: computeDaysRemaining(activeTrialEnds, now.getTime()),
    };
  });

  pendingTrialPlanByAccount.delete(accountId);
  return out;
}

export function getCurrentWorkspace(workspaceId = null) {
  const db = getV2Db();
  const ws = workspaceId
    ? db.prepare('SELECT * FROM v2_workspaces WHERE id = ?').get(workspaceId)
    : db.prepare('SELECT * FROM v2_workspaces ORDER BY created_at DESC LIMIT 1').get();
  if (!ws) return { workspace: null, subscription: null, milestones: null, daysRemaining: null };
  const rawSub = db.prepare('SELECT * FROM v2_subscriptions WHERE workspace_id = ?').get(ws.id);
  const daysRemaining = computeDaysRemaining(rawSub?.trial_ends_at);
  const subscription = rawSub ? { ...rawSub, daysRemaining } : null;
  const milestones = db.prepare('SELECT * FROM v2_onboarding_milestones WHERE workspace_id = ?').get(ws.id);
  const account = db
    .prepare('SELECT id, full_name, company_name, business_industry, team_size_bucket, platform_role, status FROM v2_saas_accounts WHERE id = ?')
    .get(ws.owner_account_id);
  return { workspace: ws, subscription, milestones, account, daysRemaining };
}

export function syncOnboardingMilestones({ workspaceId, connectedChannelsCount = 1, firstChannel = 'line' }) {
  if (!workspaceId) throw makeHttpError(400, 'ต้องระบุ workspaceId');
  return withV2Transaction((db) => {
    const ws = db.prepare('SELECT id FROM v2_workspaces WHERE id = ?').get(workspaceId);
    if (!ws) throw makeHttpError(404, 'ไม่พบ Workspace');
    const nowIso = new Date().toISOString();
    db.prepare('UPDATE v2_workspaces SET connected_channels_count = ? WHERE id = ?').run(
      Number(connectedChannelsCount) || 1,
      workspaceId
    );
    db.prepare(
      `UPDATE v2_onboarding_milestones
       SET step_first_channel_connectedAt = COALESCE(step_first_channel_connectedAt, ?),
           first_connected_channel = COALESCE(first_connected_channel, ?),
           onboarding_score = MAX(onboarding_score, 75),
           updated_at = ?
       WHERE workspace_id = ?`
    ).run(nowIso, String(firstChannel), nowIso, workspaceId);
    db.prepare(
      `UPDATE v2_saas_onboarding_drips SET status = 'cancelled_completed'
       WHERE workspace_id = ? AND trigger_rule = 'no_channel_24h' AND status = 'scheduled'`
    ).run(workspaceId);
    return getCurrentWorkspace(workspaceId);
  });
}

export function upgradeSubscription({ workspaceId, planCode, billingCycle = 'monthly' }) {
  if (!workspaceId || !Object.hasOwn(PLAN_MRR_SATANG, planCode) || planCode === 'free_trial' || planCode === 'free_6m') {
    throw makeHttpError(400, 'แพ็กเกจอัปเกรดไม่ถูกต้อง');
  }
  if (!['monthly', 'yearly'].includes(billingCycle)) {
    throw makeHttpError(400, 'รอบบิลต้องเป็น monthly หรือ yearly เท่านั้น');
  }
  return withV2Transaction((db) => {
    const ws = db.prepare('SELECT * FROM v2_workspaces WHERE id = ?').get(workspaceId);
    if (!ws) throw makeHttpError(404, 'ไม่พบ Workspace');
    const monthlySatang = PLAN_MRR_SATANG[planCode];
    const chargedSatang = billingCycle === 'yearly' ? monthlySatang * 10 : monthlySatang;
    const now = new Date();
    const nowIso = now.toISOString();
    const periodDays = billingCycle === 'yearly' ? 365 : 30;
    const periodEndIso = new Date(now.getTime() + periodDays * DAY_MS).toISOString();
    const seatLimit = planCode === 'enterprise' ? 25 : planCode === 'pro' ? 10 : 3;
    const aiQuota = planCode === 'enterprise' ? 50000 : planCode === 'pro' ? 15000 : 5000;

    db.prepare('UPDATE v2_workspaces SET seat_limit = ?, ai_quota_monthly = ? WHERE id = ?').run(seatLimit, aiQuota, workspaceId);
    db.prepare(
      `UPDATE v2_subscriptions
       SET plan_code = ?, billing_cycle = ?, status = 'active', mrr_satang = ?,
           converted_from_trial_at = COALESCE(converted_from_trial_at, ?),
           current_period_start = ?, current_period_end = ?, updated_at = ?
       WHERE workspace_id = ?`
    ).run(planCode, billingCycle, monthlySatang, nowIso, nowIso, periodEndIso, nowIso, workspaceId);

    const origAttr = db
      .prepare(
        `SELECT visitor_anon_id, utm_source, utm_medium, utm_campaign
         FROM v2_saas_attribution_events
         WHERE account_id = ? AND (utm_campaign IS NOT NULL OR utm_source IS NOT NULL)
         ORDER BY created_at ASC LIMIT 1`
      )
      .get(ws.owner_account_id);

    db.prepare(
      `INSERT INTO v2_saas_attribution_events
       (id, visitor_anon_id, account_id, workspace_id, stage_event, utm_source, utm_medium, utm_campaign, revenue_satang)
       VALUES (?, ?, ?, ?, 'subscription_paid', ?, ?, ?, ?)`
    ).run(
      newId('EVT'),
      origAttr?.visitor_anon_id || ws.owner_account_id,
      ws.owner_account_id,
      workspaceId,
      origAttr?.utm_source || null,
      origAttr?.utm_medium || null,
      origAttr?.utm_campaign || null,
      chargedSatang
    );

    return getCurrentWorkspace(workspaceId);
  });
}
