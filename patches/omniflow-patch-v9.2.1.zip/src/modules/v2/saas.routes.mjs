// gateway/src/modules/v2/saas.routes.mjs
// Category 4: B2B SaaS Signup, OTP Verification (HttpOnly Persistent Session), Workspace & Subscription Routes

import { readJsonBody } from './v2-http.mjs';
import {
  signupSaasAccount,
  verifySaasOtp,
  getCurrentWorkspace,
  syncOnboardingMilestones,
  upgradeSubscription,
} from './saas.service.mjs';
import { activateLicenseKey } from './saas-license.service.mjs';
import { issuePersistentSession, verifyPersistentSession } from './auth-session.service.mjs';
import { assertAuthAttemptAllowed, clearAuthFailures, recordAuthFailure } from './auth-rate-limit.mjs';

export function register(registerV2Route) {
  registerV2Route({
    method: 'POST',
    path: '/api/v2/saas/signup',
    auth: 'public',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      const result = signupSaasAccount(body);
      sendJson(res, 201, { ok: true, ...result }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/saas/verify-otp',
    auth: 'public',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      assertAuthAttemptAllowed(req);
      const body = await readJsonBody(req);
      let result;
      try {
        result = verifySaasOtp(body);
      } catch (err) {
        if (err?.statusCode === 400 || err?.statusCode === 409) recordAuthFailure(req);
        throw err;
      }
      clearAuthFailures(req);
      const issued = issuePersistentSession({
        accountId: result.accountId,
        workspaceId: result.workspace?.id || null,
        deviceLabel: body.deviceLabel || 'first-run-otp',
        req,
      });
      sendJson(
        res,
        200,
        { ok: true, ...result, session: { id: issued.sessionId, expiresAt: issued.expiresAt } },
        { 'Set-Cookie': issued.setCookieHeader, ...(corsHeaders || {}) }
      );
    },
  });

  registerV2Route({
    method: 'GET',
    path: '/api/v2/saas/workspace/current',
    auth: 'admin',
    handler: (req, res, { parsedUrl, corsHeaders, sendJson }) => {
      const wsId = parsedUrl.searchParams.get('workspaceId') || verifyPersistentSession(req).session?.workspaceId || null;
      sendJson(res, 200, { ok: true, ...getCurrentWorkspace(wsId) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/saas/milestones/sync',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, ...syncOnboardingMilestones(body) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/saas/subscriptions/upgrade',
    auth: 'admin',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      const body = await readJsonBody(req);
      sendJson(res, 200, { ok: true, ...upgradeSubscription(body) }, corsHeaders);
    },
  });

  registerV2Route({
    method: 'POST',
    path: '/api/v2/saas/license/activate',
    auth: 'public',
    handler: async (req, res, { corsHeaders, sendJson }) => {
      assertAuthAttemptAllowed(req);
      const body = await readJsonBody(req);
      let result;
      try {
        result = activateLicenseKey(body);
      } catch (err) {
        if (err?.statusCode === 400 || err?.statusCode === 403) recordAuthFailure(req);
        throw err;
      }
      clearAuthFailures(req);
      const ownerId = result.workspace?.owner_account_id;
      if (ownerId) {
        const issued = issuePersistentSession({
          accountId: ownerId,
          workspaceId: result.workspace?.id || null,
          deviceLabel: body.deviceLabel || 'license-key',
          req,
        });
        sendJson(
          res,
          200,
          { ok: true, ...result, session: { id: issued.sessionId, expiresAt: issued.expiresAt } },
          { 'Set-Cookie': issued.setCookieHeader, ...(corsHeaders || {}) }
        );
        return;
      }
      sendJson(res, 200, { ok: true, ...result }, corsHeaders);
    },
  });
}
