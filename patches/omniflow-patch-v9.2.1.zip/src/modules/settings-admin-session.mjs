// gateway/src/modules/settings-admin-session.mjs
// Admin PIN Session Guard & Protected Settings HTTP Routes (Extracted from settings-vault.mjs)

import crypto from 'node:crypto';
import {
  isDirectLocalHostRequest,
  getRateLimitClientKey,
  checkPinRateLimit,
  recordPinFailure,
  clearPinFailures,
  createAdminSessionStore
} from './admin-auth-guard.mjs';
import {
  getRuntimeConfig,
  getMaskedChannelsView,
  updateChannelsSettings,
  getBrainProvidersMasked,
  updateBrainProvidersSettings
} from './settings-vault.mjs';
import { sendAdminLeadNotification } from './settings-lead-notifier.mjs';

const ADMIN_SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const ADMIN_MAX_SESSIONS = 100;

const activeAdminSessions = createAdminSessionStore({
  maxSessions: ADMIN_MAX_SESSIONS,
  ttlMs: ADMIN_SESSION_TTL_MS
});

export function timingSafePinEquals(candidate, expected) {
  if (!candidate || !expected) return false;
  const candidateDigest = crypto.createHash('sha256').update(candidate).digest();
  const expectedDigest = crypto.createHash('sha256').update(expected).digest();
  return crypto.timingSafeEqual(candidateDigest, expectedDigest);
}

export function clearAllAdminSessions() {
  activeAdminSessions.clear?.();
  activeAdminSessions.revokeAll?.();
}

export function getConfiguredAdminPin() {
  const configured = getRuntimeConfig()?.security?.adminPin;
  if (configured !== undefined && configured !== null) {
    return String(configured).trim();
  }
  return String(process.env.ADMIN_PIN || '123456').trim();
}

export function verifyAdminPinAndIssueSession(pinInput, reqOrClientKey = null) {
  const clientKey =
    typeof reqOrClientKey === 'string' && reqOrClientKey.trim()
      ? reqOrClientKey.trim()
      : reqOrClientKey && typeof reqOrClientKey === 'object'
      ? getRateLimitClientKey(reqOrClientKey)
      : 'global';

  const rl = checkPinRateLimit(clientKey);
  if (!rl.allowed) {
    return {
      ok: false,
      statusCode: 429,
      locked: true,
      retryAfterSec: rl.retryAfterSec,
      error: `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${rl.retryAfterSec} วินาที`
    };
  }

  const expected = getConfiguredAdminPin();
  if (!expected) {
    return { ok: false, statusCode: 401, error: 'ยังไม่ได้ตั้งค่ารหัส PIN แอดมินในระบบ' };
  }

  const candidate = String(pinInput ?? '').trim();
  if (!candidate) {
    return { ok: false, statusCode: 400, error: 'กรุณากรอกรหัส PIN แอดมิน' };
  }

  if (!timingSafePinEquals(candidate, expected)) {
    const fail = recordPinFailure(clientKey);
    return {
      ok: false,
      statusCode: fail.locked ? 429 : 401,
      locked: fail.locked,
      remainingAttempts: fail.remainingAttempts,
      retryAfterSec: fail.retryAfterSec,
      error: fail.locked
        ? `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${fail.retryAfterSec} วินาที`
        : 'รหัส PIN แอดมินไม่ถูกต้อง'
    };
  }

  clearPinFailures(clientKey);
  const sess = activeAdminSessions.create({ clientKey });
  return { ok: true, token: sess.token, expiresAt: sess.expiresAt };
}

export function parseAdminSessionToken(req) {
  if (!req || !req.headers) return '';
  const headerToken = String(req.headers['x-admin-token'] || '').trim();
  if (headerToken) return headerToken;

  const authHeader = String(req.headers.authorization || '').trim();
  if (/^Bearer\s+/i.test(authHeader)) {
    return authHeader.replace(/^Bearer\s+/i, '').trim();
  }

  const cookieHeader = String(req.headers.cookie || '');
  if (cookieHeader) {
    for (const part of cookieHeader.split(';')) {
      const eqIdx = part.indexOf('=');
      if (eqIdx <= 0) continue;
      if (part.slice(0, eqIdx).trim() === 'omniflow_admin_session') {
        const val = part.slice(eqIdx + 1).trim();
        try {
          return decodeURIComponent(val);
        } catch {
          return val;
        }
      }
    }
  }
  return '';
}

export function hasValidAdminSession(req) {
  const token = parseAdminSessionToken(req);
  return Boolean(token && activeAdminSessions.isValid(token));
}

export function revokeAdminSession(req) {
  const token = parseAdminSessionToken(req);
  return Boolean(token && activeAdminSessions.revoke(token));
}

export function hasValidAdminPinHeader() {
  return false;
}

export function isLocalAdminRequest(req) {
  return isDirectLocalHostRequest(req) || hasValidAdminSession(req);
}

export function registerSettingsRoutes(app) {
  const guard = (req, res, next) => {
    if (hasValidAdminSession(req)) return next();
    const rl = checkPinRateLimit(getRateLimitClientKey(req));
    if (!rl.allowed) {
      return res.status(429).json({
        ok: false,
        code: 'ADMIN_SESSION_REQUIRED',
        error: `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${rl.retryAfterSec} วินาที`,
        retryAfterSec: rl.retryAfterSec,
        requirePin: true
      });
    }
    return res.status(401).json({
      ok: false,
      code: 'ADMIN_SESSION_REQUIRED',
      error: 'Unauthorized: Admin Access Required',
      requirePin: true
    });
  };

  app.get('/api/settings/channels', guard, (_req, res) => {
    res.json({ ok: true, ...getMaskedChannelsView() });
  });

  app.post('/api/settings/channels', guard, async (req, res) => {
    try {
      res.json({ ok: true, ...(await updateChannelsSettings(req.body || {})) });
    } catch (err) {
      res.status(err.statusCode || 500).json({ ok: false, error: err.message });
    }
  });

  app.get('/api/settings/brain', guard, (_req, res) => {
    res.json({ ok: true, ...getBrainProvidersMasked() });
  });

  app.post('/api/settings/brain', guard, async (req, res) => {
    try {
      res.json({ ok: true, ...(await updateBrainProvidersSettings(req.body || {})) });
    } catch (err) {
      res.status(err.statusCode || 500).json({ ok: false, error: err.message });
    }
  });

  app.get('/api/settings/flowise', guard, (_req, res) => {
    res.json({ ok: true, ...getBrainProvidersMasked() });
  });

  app.post('/api/settings/flowise', guard, async (req, res) => {
    try {
      res.json({ ok: true, ...(await updateBrainProvidersSettings(req.body || {})) });
    } catch (err) {
      res.status(err.statusCode || 500).json({ ok: false, error: err.message });
    }
  });

  app.post('/api/settings/test-webhook', guard, async (req, res) => {
    try {
      const customUrl = String(req.body?.webhookUrl || req.body?.adminNotifyWebhookUrl || '').trim();
      const sampleOrder = {
        id: `ord_test_${Date.now().toString(36)}`,
        timestamp: new Date().toLocaleString('sv-SE', { timeZone: 'Asia/Bangkok' }),
        channel: 'line',
        customerName: 'คุณลูกค้า (ทดสอบระบบแจ้งเตือน)',
        productName: 'หินแกรนิตดำเกล็ดทอง (Black Galaxy)',
        dimensions: '60x60 ซม.',
        quantity: '15 ตร.ม.',
        estimatedTotal: '37,350 บาท',
        phone: '081-234-5678',
        address: 'กรุงเทพมหานคร (ข้อความทดสอบจากหน้าตั้งค่าแอดมิน)',
        note: 'ทดสอบการยิงแจ้งเตือนออเดอร์ใหม่เข้าแชตแอดมิน (Notify on Lead)'
      };
      const result = await sendAdminLeadNotification(sampleOrder, {
        isTest: true,
        webhookUrlOverride: customUrl
      });
      res.json({ ok: true, ...result });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message || 'ไม่สามารถส่งการแจ้งเตือนได้' });
    }
  });
}
