// modules/atomic-write.mjs
// เขียนไฟล์แบบ atomic: เขียนลง .tmp → fsync → rename ทับไฟล์จริง (รองรับทั้ง Sync และ Async)
// ถ้าไฟดับหรือโปรเซสตายกลางทาง ไฟล์จริงจะยังเป็น "เวอร์ชันเก่าที่สมบูรณ์" เสมอ ไม่ใช่ JSON ที่เขียนได้ครึ่งเดียว
import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';

const RENAME_RETRY_CODES = new Set(['EPERM', 'EACCES', 'EBUSY']);
const MAX_RENAME_ATTEMPTS = 5;

function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function sleepAsync(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function buildTempPath(filePath) {
  const dir = path.dirname(filePath);
  return path.join(
    dir,
    `.${path.basename(filePath)}.${process.pid}.${crypto.randomBytes(4).toString('hex')}.tmp`
  );
}

export function writeFileAtomic(filePath, content, encoding = 'utf8') {
  const dir = path.dirname(filePath);
  fs.mkdirSync(dir, { recursive: true });
  const tmpPath = buildTempPath(filePath);

  const fd = fs.openSync(tmpPath, 'w');
  try {
    fs.writeFileSync(fd, content, encoding);
    fs.fsyncSync(fd); // บังคับ flush ลงดิสก์ก่อน rename
  } catch (err) {
    try { fs.closeSync(fd); } catch { /* ignore */ }
    try { fs.unlinkSync(tmpPath); } catch { /* ignore */ }
    throw err;
  }
  fs.closeSync(fd);

  // บน Windows ถ้า antivirus หรือ indexer เปิดไฟล์ค้างไว้ rename อาจได้ EPERM/EBUSY ชั่วคราว จึง retry สั้น ๆ
  for (let attempt = 1; ; attempt += 1) {
    try {
      fs.renameSync(tmpPath, filePath);
      return;
    } catch (err) {
      if (RENAME_RETRY_CODES.has(err?.code) && attempt < MAX_RENAME_ATTEMPTS) {
        sleepSync(20 * attempt);
        continue;
      }
      try { fs.unlinkSync(tmpPath); } catch { /* ignore */ }
      throw err;
    }
  }
}

export function writeJsonAtomic(filePath, data) {
  writeFileAtomic(filePath, JSON.stringify(data, null, 2), 'utf8');
}

export async function writeFileAtomicAsync(filePath, content, encoding = 'utf8') {
  const dir = path.dirname(filePath);
  await fsp.mkdir(dir, { recursive: true });
  const tmpPath = buildTempPath(filePath);

  let handle;
  try {
    handle = await fsp.open(tmpPath, 'w');
    await handle.writeFile(content, encoding);
    await handle.sync(); // บังคับ flush ลงดิสก์ก่อน rename
  } catch (err) {
    if (handle) {
      await handle.close().catch(() => {});
    }
    await fsp.unlink(tmpPath).catch(() => {});
    throw err;
  }
  await handle.close();

  for (let attempt = 1; ; attempt += 1) {
    try {
      await fsp.rename(tmpPath, filePath);
      return;
    } catch (err) {
      if (RENAME_RETRY_CODES.has(err?.code) && attempt < MAX_RENAME_ATTEMPTS) {
        await sleepAsync(20 * attempt);
        continue;
      }
      await fsp.unlink(tmpPath).catch(() => {});
      throw err;
    }
  }
}

export async function writeJsonAtomicAsync(filePath, data) {
  await writeFileAtomicAsync(filePath, JSON.stringify(data, null, 2), 'utf8');
}
