// gateway/src/modules/fetch-safe.mjs
// Zero-Dependency SSRF Guard, DNS Rebinding IP Pinning, Redirect Blocker, Secret Redactor & Stream Byte Cap

import net from 'node:net';
import dns from 'node:dns/promises';
import { URL } from 'node:url';

const DEFAULT_TIMEOUT_MS = 12_000;
const DEFAULT_MAX_BYTES = 8 * 1024 * 1024; // 8 MB
const SENSITIVE_PARAM_RE = /(?:^|_|-)(?:token|access_token|key|api_key|apikey|secret|sig|signature|pass|password|auth|client_secret|webhook_secret)$/i;
const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data',
  'host.docker.internal'
]);

let cachedUndiciAgentCtor;

async function getUndiciAgentCtor() {
  if (cachedUndiciAgentCtor !== undefined) return cachedUndiciAgentCtor;
  try {
    const mod = await import('undici');
    cachedUndiciAgentCtor = typeof mod?.Agent === 'function' ? mod.Agent : null;
  } catch {
    cachedUndiciAgentCtor = null;
  }
  return cachedUndiciAgentCtor;
}

function parseIpv4Octets(ip) {
  const parts = String(ip || '').split('.');
  if (parts.length !== 4) return null;
  const nums = [];
  for (const part of parts) {
    if (!/^\d{1,3}$/.test(part)) return null;
    const n = Number(part);
    if (!Number.isInteger(n) || n < 0 || n > 255) return null;
    nums.push(n);
  }
  return nums;
}

function isPrivateIpv4(ip) {
  const octets = parseIpv4Octets(ip);
  if (!octets) return true;
  const [a, b, c] = octets;
  if (a === 0) return true; // 0.0.0.0/8
  if (a === 10) return true; // 10.0.0.0/8
  if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 (CGNAT)
  if (a === 127) return true; // 127.0.0.0/8 (Loopback)
  if (a === 169 && b === 254) return true; // 169.254.0.0/16 (Link-local / Cloud Metadata)
  if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12 (Private RFC1918)
  if (a === 192 && b === 0 && (c === 0 || c === 2)) return true; // 192.0.0.0/24, 192.0.2.0/24
  if (a === 192 && b === 168) return true; // 192.168.0.0/16
  if (a === 198 && (b === 18 || b === 19)) return true; // 198.18.0.0/15
  if (a === 198 && b === 51 && c === 100) return true; // 198.51.100.0/24
  if (a === 203 && b === 0 && c === 113) return true; // 203.0.113.0/24
  if (a >= 224) return true; // 224.0.0.0/4 Multicast & 240.0.0.0/4 Reserved/Broadcast
  return false;
}

function expandIpv6Hextets(rawIp) {
  let ip = String(rawIp || '').toLowerCase();
  const lastColon = ip.lastIndexOf(':');
  if (ip.includes('.') && lastColon !== -1) {
    const v4 = parseIpv4Octets(ip.slice(lastColon + 1));
    if (!v4) return null;
    const hi = ((v4[0] << 8) | v4[1]).toString(16);
    const lo = ((v4[2] << 8) | v4[3]).toString(16);
    ip = `${ip.slice(0, lastColon)}:${hi}:${lo}`;
  }
  const halves = ip.split('::');
  if (halves.length > 2) return null;
  const left = halves[0] ? halves[0].split(':') : [];
  const right = halves.length === 2 && halves[1] ? halves[1].split(':') : [];
  const missing = 8 - (left.length + right.length);
  if ((halves.length === 1 && missing !== 0) || (halves.length === 2 && missing < 0)) return null;
  const full = halves.length === 2 ? [...left, ...Array(missing).fill('0'), ...right] : left;
  if (full.length !== 8) return null;
  const out = [];
  for (const seg of full) {
    if (!/^[0-9a-f]{1,4}$/.test(seg)) return null;
    out.push(parseInt(seg, 16));
  }
  return out;
}

function isPrivateIpv6(ip) {
  const h = expandIpv6Hextets(ip);
  if (!h) return true;
  const isAllZeroPrefix = h[0] === 0 && h[1] === 0 && h[2] === 0 && h[3] === 0 && h[4] === 0;
  if (isAllZeroPrefix && h[5] === 0 && h[6] === 0 && (h[7] === 0 || h[7] === 1)) return true; // :: & ::1
  if (isAllZeroPrefix && (h[5] === 0xffff || h[5] === 0)) return true; // ::ffff:* & deprecated ::/96
  if ((h[0] & 0xfe00) === 0xfc00) return true; // fc00::/7 (Unique Local)
  if ((h[0] & 0xffc0) === 0xfe80) return true; // fe80::/10 (Link-local)
  if ((h[0] & 0xffc0) === 0xfec0) return true; // fec0::/10 (Site-local)
  if ((h[0] & 0xff00) === 0xff00) return true; // ff00::/8 (Multicast)
  if (h[0] === 0x0064 && h[1] === 0xff9b) return true; // 64:ff9b::/96 (NAT64)
  if (h[0] === 0x2001 && h[1] === 0x0000) return true; // 2001:0000::/32 (Teredo)
  if (h[0] === 0x2001 && h[1] === 0x0db8) return true; // 2001:db8::/32 (Documentation)
  if (h[0] === 0x2002) return true; // 2002::/16 (6to4)
  if (h[0] === 0x0100 && h[1] === 0 && h[2] === 0 && h[3] === 0) return true; // 100::/64 (Discard)
  return false;
}

export function isPrivateOrReservedIp(rawIp) {
  const cleaned = String(rawIp || '').trim().replace(/^\[|\]$/g, '').split('%')[0].toLowerCase();
  if (!cleaned) return true;
  const kind = net.isIP(cleaned);
  if (kind === 4) return isPrivateIpv4(cleaned);
  if (kind === 6) return isPrivateIpv6(cleaned);
  return true; // Fail-closed on invalid IP string
}

function scrubPathTokens(pathname) {
  return String(pathname || '')
    .replace(/(\/bot)\d+:[A-Za-z0-9_-]{8,}(?=\/|$)/gi, '$1REDACTED')
    .replace(/(\/(?:token|access_token|secret|api_key|apikey|key|webhook|hooks?|services)\/)([^/?#\s]+)/gi, '$1REDACTED');
}

export function redactUrlSecrets(rawUrl) {
  const input = String(rawUrl || '').trim();
  if (!input) return '';
  try {
    const parsed = new URL(input);
    if (parsed.username) parsed.username = 'REDACTED';
    if (parsed.password) parsed.password = 'REDACTED';
    parsed.pathname = scrubPathTokens(parsed.pathname);
    for (const key of [...parsed.searchParams.keys()]) {
      if (SENSITIVE_PARAM_RE.test(key)) parsed.searchParams.set(key, 'REDACTED');
    }
    return parsed.toString();
  } catch {
    return scrubPathTokens(input)
      .replace(/(\/\/)([^/@\s]+)@/g, '$1REDACTED@')
      .replace(/([?&][^=&#\s]*(?:token|key|secret|sig|pass|auth)[^=&#\s]*=)([^&#\s]*)/gi, '$1REDACTED');
  }
}

function isDomainAllowed(hostname, allowedDomains = []) {
  const host = String(hostname || '').toLowerCase().replace(/\.$/, '');
  for (const rawRule of allowedDomains) {
    const rule = String(rawRule || '').trim().toLowerCase().replace(/\.$/, '');
    if (!rule) continue;
    if (rule.startsWith('*.')) {
      const suffix = rule.slice(1); // '.kakao.com'
      if (host.endsWith(suffix) && host.length > suffix.length) return true;
    } else if (rule.startsWith('.')) {
      const bare = rule.slice(1);
      if (host === bare || host.endsWith(rule)) return true;
    } else if (host === rule) {
      return true;
    }
  }
  return false;
}

export async function assertSafePublicUrl(rawUrl, { allowHttp = false, allowedDomains = [] } = {}) {
  const safeDisplay = redactUrlSecrets(rawUrl);
  let parsed;
  try {
    parsed = new URL(String(rawUrl || '').trim());
  } catch {
    throw Object.assign(new Error(`Invalid URL: ${safeDisplay}`), { code: 'ERR_INVALID_URL' });
  }

  const allowedProtocols = allowHttp ? ['https:', 'http:'] : ['https:'];
  if (!allowedProtocols.includes(parsed.protocol)) {
    throw Object.assign(new Error(`Disallowed protocol (${parsed.protocol}) for ${safeDisplay}`), {
      code: 'ERR_DISALLOWED_PROTOCOL'
    });
  }

  const hostname = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!hostname || BLOCKED_HOSTNAMES.has(hostname) || /\.(?:localhost|local|internal)$/i.test(hostname)) {
    throw Object.assign(new Error(`Blocked internal hostname: ${hostname}`), { code: 'ERR_SSRF_BLOCKED' });
  }

  if (Array.isArray(allowedDomains) && allowedDomains.length > 0 && !isDomainAllowed(hostname, allowedDomains)) {
    throw Object.assign(new Error(`Domain not in allowlist: ${hostname}`), { code: 'ERR_DOMAIN_NOT_ALLOWED' });
  }

  if (net.isIP(hostname) !== 0) {
    if (isPrivateOrReservedIp(hostname)) {
      throw Object.assign(new Error(`Blocked private/reserved IP: ${hostname}`), { code: 'ERR_SSRF_BLOCKED' });
    }
    return { url: parsed, href: parsed.href, hostname, addresses: [hostname] };
  }

  let records;
  try {
    records = await dns.lookup(hostname, { all: true, verbatim: true });
  } catch (err) {
    throw Object.assign(new Error(`DNS lookup failed for ${hostname}: ${err.code || err.message}`), {
      code: 'ERR_DNS_LOOKUP'
    });
  }

  if (!Array.isArray(records) || records.length === 0) {
    throw Object.assign(new Error(`DNS returned no addresses for ${hostname}`), { code: 'ERR_DNS_EMPTY' });
  }

  const addresses = [];
  for (const rec of records) {
    const addr = String(rec?.address || '').trim();
    if (!addr || isPrivateOrReservedIp(addr)) {
      throw Object.assign(new Error(`DNS resolved to private/reserved IP for ${hostname}`), {
        code: 'ERR_SSRF_BLOCKED'
      });
    }
    addresses.push(addr);
  }

  return { url: parsed, href: parsed.href, hostname, addresses };
}

async function readStreamWithByteCap(res, maxBytes) {
  const cap = Number.isFinite(Number(maxBytes)) && Number(maxBytes) > 0 ? Number(maxBytes) : DEFAULT_MAX_BYTES;
  const contentLength = Number(res.headers?.get('content-length') || 0);
  if (Number.isFinite(contentLength) && contentLength > cap) {
    await res.body?.cancel?.().catch(() => {});
    throw Object.assign(new Error(`Response Content-Length (${contentLength}) exceeds maxBytes (${cap})`), {
      code: 'ERR_MAX_BYTES_EXCEEDED',
      statusCode: 413
    });
  }

  if (!res.body || typeof res.body.getReader !== 'function') {
    const ab = await res.arrayBuffer();
    if (ab.byteLength > cap) {
      throw Object.assign(new Error(`Response body exceeds maxBytes (${cap})`), {
        code: 'ERR_MAX_BYTES_EXCEEDED',
        statusCode: 413
      });
    }
    return Buffer.from(ab);
  }

  const reader = res.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > cap) {
        await reader.cancel().catch(() => {});
        throw Object.assign(new Error(`Response stream exceeded maxBytes (${cap})`), {
          code: 'ERR_MAX_BYTES_EXCEEDED',
          statusCode: 413
        });
      }
      chunks.push(Buffer.from(value.buffer, value.byteOffset, value.byteLength));
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks, total);
}

async function createPinnedDispatcher(verified) {
  const UndiciAgent = await getUndiciAgentCtor();
  const pinnedIp = String(verified?.addresses?.[0] || '').trim();
  const pinnedFamily = net.isIP(pinnedIp);
  if (!UndiciAgent || !pinnedIp || !pinnedFamily) return null;

  return new UndiciAgent({
    connect: {
      lookup: (_hostname, options, cb) => {
        const callback = typeof options === 'function' ? options : cb;
        if (options && typeof options === 'object' && options.all) {
          callback(null, [{ address: pinnedIp, family: pinnedFamily }]);
        } else {
          callback(null, pinnedIp, pinnedFamily);
        }
      }
    }
  });
}

export async function fetchSafe(rawUrl, options = {}) {
  const {
    allowHttp = false,
    allowedDomains = [],
    timeoutMs = DEFAULT_TIMEOUT_MS,
    maxBytes = DEFAULT_MAX_BYTES,
    signal: externalSignal,
    ...fetchInit
  } = options;

  const safeUrlDisplay = redactUrlSecrets(rawUrl);
  const verified = await assertSafePublicUrl(rawUrl, { allowHttp, allowedDomains });
  const timeoutSignal = AbortSignal.timeout(Math.max(500, Number(timeoutMs) || DEFAULT_TIMEOUT_MS));
  const combinedSignal =
    externalSignal && typeof AbortSignal.any === 'function'
      ? AbortSignal.any([externalSignal, timeoutSignal])
      : externalSignal || timeoutSignal;

  const dispatcher = await createPinnedDispatcher(verified);
  let res;
  try {
    try {
      res = await fetch(verified.href, {
        ...fetchInit,
        redirect: 'error',
        signal: combinedSignal,
        ...(dispatcher ? { dispatcher } : {})
      });
    } catch (err) {
      const cleanMsg = redactUrlSecrets(err?.message || 'Request failed').replaceAll(
        String(rawUrl || ''),
        safeUrlDisplay
      );
      throw Object.assign(new Error(`fetchSafe failed for ${safeUrlDisplay}: ${cleanMsg}`), {
        code: err?.code || (err?.name === 'TimeoutError' ? 'ERR_TIMEOUT' : 'ERR_FETCH_FAILED')
      });
    }

    const buf = await readStreamWithByteCap(res, maxBytes);
    return {
      ok: res.ok,
      status: res.status,
      statusText: res.statusText,
      headers: res.headers,
      url: redactUrlSecrets(res.url || verified.href),
      bytesRead: buf.length,
      buffer: async () => buf,
      arrayBuffer: async () => buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength),
      text: async () => buf.toString('utf8'),
      json: async () => JSON.parse(buf.toString('utf8'))
    };
  } finally {
    if (dispatcher && typeof dispatcher.close === 'function') {
      await dispatcher.close().catch(() => {});
    }
  }
}
