// Phase 8.4 Modular Plugin: Stone Name -> Preview Image resolver (for dashboard hover popover)
// Priority: 1) matching row in Catalog/Price_List (shop's own photo)  2) Wikipedia page thumbnail (free, no key)
const previewCache = new Map(); // normalizedKey -> { expiresAt, result }
const POSITIVE_CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours for found previews
const NEGATIVE_CACHE_TTL_MS = 5 * 60 * 1000;      // 5 minutes for misses
const MAX_PREVIEW_CACHE_ENTRIES = 500;

function normalize(str) {
  return String(str || '')
    .toLowerCase()
    .replace(/หินแกรนิต|หินอ่อน|หินเทียม|หินควอตซ์|หิน|granite|marble|stone/g, '')
    .replace(/[^a-z0-9ก-๙]+/g, '');
}

function englishPart(name) {
  const paren = String(name || '').match(/\(([^)]+)\)/);
  const raw = paren ? paren[1] : String(name || '');
  return raw.replace(/[^A-Za-z0-9 \-]/g, ' ').replace(/\s+/g, ' ').trim();
}

function isSafeImageUrl(rawUrl) {
  const s = String(rawUrl || '').trim();
  if (!s || /^(?:javascript|vbscript|data):/i.test(s)) return false;
  if (/^\/(?!\/)/.test(s)) return true;
  try {
    const parsed = new URL(s);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

function getPreviewCache(cacheKey, now = Date.now()) {
  const cached = previewCache.get(cacheKey);
  if (!cached) return null;
  if (cached.expiresAt <= now) {
    previewCache.delete(cacheKey);
    return null;
  }
  // Refresh LRU order on cache hit
  previewCache.delete(cacheKey);
  previewCache.set(cacheKey, cached);
  return cached.result;
}

function setPreviewCache(cacheKey, result, ttlMs, now = Date.now()) {
  if (previewCache.has(cacheKey)) {
    previewCache.delete(cacheKey);
  }
  if (previewCache.size >= MAX_PREVIEW_CACHE_ENTRIES) {
    for (const [k, entry] of previewCache) {
      if (!entry || entry.expiresAt <= now) previewCache.delete(k);
    }
    while (previewCache.size >= MAX_PREVIEW_CACHE_ENTRIES) {
      const oldestKey = previewCache.keys().next().value;
      if (oldestKey === undefined) break;
      previewCache.delete(oldestKey);
    }
  }
  previewCache.set(cacheKey, { expiresAt: now + ttlMs, result });
}

export function clearStonePreviewCache() {
  previewCache.clear();
}

function findCatalogImage(name, rows) {
  const target = normalize(englishPart(name) || name);
  const targetThai = normalize(name);
  if (!target && !targetThai) return null;

  const hit = (rows || []).find((r) => {
    const imgUrl = String(r?.imgRaw || r?.imageUrl || '').trim();
    if (!imgUrl || !isSafeImageUrl(imgUrl)) return false;
    const n = normalize(r?.name);
    if (!n) return false;
    return (target && (n.includes(target) || target.includes(n))) || (targetThai && n.includes(targetThai));
  });

  if (!hit) return null;
  return {
    imageUrl: String(hit.imgRaw || hit.imageUrl).trim(),
    source: 'catalog',
    label: hit.name,
  };
}

async function findWikipediaImage(name) {
  const eng = englishPart(name);
  if (!eng || eng.length < 3) return null;
  const titles = [eng, eng.replace(/o$/i, 'e'), `${eng} (rock)`, `${eng} granite`];
  for (const title of [...new Set(titles)]) {
    try {
      const res = await fetch(
        `https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title.replace(/ /g, '_'))}`,
        { headers: { 'User-Agent': 'OmniFlow-Gateway/1.0' }, signal: AbortSignal.timeout(6000) }
      );
      if (!res.ok) continue;
      const data = await res.json();
      const img = data?.thumbnail?.source || data?.originalimage?.source;
      if (img && isSafeImageUrl(img)) {
        return { imageUrl: img, source: 'wikipedia', label: data.title || title };
      }
    } catch {
      // Try next title variant
    }
  }
  return null;
}

/**
 * @param {string} name stone name, e.g. "หินทราเวอร์ทีน (Travertino)"
 * @param {object} deps { getCatalogRows }
 */
export async function resolveStonePreview(name, deps = {}) {
  const key = String(name || '').trim().slice(0, 200);
  if (!key) return { ok: false, reason: 'missing name' };

  const cacheKey = key.toLowerCase();
  const cachedResult = getPreviewCache(cacheKey);
  if (cachedResult) return cachedResult;

  const rows = typeof deps.getCatalogRows === 'function' ? await deps.getCatalogRows(false) : [];
  const found = findCatalogImage(key, rows) || (await findWikipediaImage(key));
  const result = found ? { ok: true, ...found } : { ok: false, reason: 'no preview image found' };
  const ttlMs = found ? POSITIVE_CACHE_TTL_MS : NEGATIVE_CACHE_TTL_MS;
  setPreviewCache(cacheKey, result, ttlMs);
  return result;
}
