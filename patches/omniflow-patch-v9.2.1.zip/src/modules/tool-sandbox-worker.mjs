// gateway/src/modules/tool-sandbox-worker.mjs
// Isolated Child Process Worker for Custom Tools Studio (Hardened VM Boundary + SSRF Guard)

import vm from 'node:vm';
import { URL as NodeURL } from 'node:url';
import { fetchSafe } from './fetch-safe.mjs';

const MAX_LOG_LEN = 2000;
const MAX_LOGS = 100;
const MAX_RESULT_BYTES = 2 * 1024 * 1024;
const MAX_FETCH_BYTES = 2 * 1024 * 1024;
const MAX_RPC_CALLS = 25;
const MAX_FETCH_CALLS = 10;

let rpcSeq = 0;
let rpcCount = 0;
let fetchCount = 0;
let logCount = 0;
const pendingRpc = new Map();

function safeSend(payload) {
  if (typeof process.send === 'function' && process.connected) {
    try {
      process.send(payload);
    } catch {
      // Ignore closed IPC channel
    }
  }
}

function callParentRpc(method, params, timeoutMs) {
  rpcCount += 1;
  if (rpcCount > MAX_RPC_CALLS) {
    return Promise.resolve(JSON.stringify({ ok: false, error: 'RPC call limit exceeded in sandbox' }));
  }
  const id = `rpc_${++rpcSeq}`;
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      pendingRpc.delete(id);
      resolve(JSON.stringify({ ok: false, error: `RPC "${method}" timed out` }));
    }, Math.max(500, timeoutMs));
    pendingRpc.set(id, (res) => {
      clearTimeout(timer);
      resolve(JSON.stringify(res));
    });
    safeSend({ type: 'rpc', id, method, params });
  });
}

async function hostFetchBridge(reqJson, deadlineAt) {
  fetchCount += 1;
  if (fetchCount > MAX_FETCH_CALLS) {
    return JSON.stringify({ ok: false, error: 'External fetch call limit exceeded in sandbox' });
  }
  try {
    const req = JSON.parse(String(reqJson || '{}'));
    const rawUrl = String(req.url || '').trim();
    const init = req.init && typeof req.init === 'object' ? req.init : {};
    const method = typeof init.method === 'string' ? init.method.toUpperCase().slice(0, 12) : 'GET';
    const headers = {};
    if (init.headers && typeof init.headers === 'object') {
      for (const [k, v] of Object.entries(init.headers)) {
        if (typeof k === 'string' && v !== undefined && v !== null) headers[k.slice(0, 128)] = String(v).slice(0, 2048);
      }
    }
    const body = typeof init.body === 'string' && !['GET', 'HEAD'].includes(method) ? init.body : undefined;
    const remainingMs = Math.max(500, deadlineAt - Date.now());
    const res = await fetchSafe(rawUrl, {
      method,
      headers,
      body,
      allowHttp: false,
      timeoutMs: remainingMs,
      maxBytes: MAX_FETCH_BYTES
    });
    const text = await res.text();
    const resHeaders = {};
    if (res.headers && typeof res.headers.entries === 'function') {
      for (const [k, v] of res.headers.entries()) resHeaders[k.toLowerCase()] = v;
    }
    return JSON.stringify({
      ok: true,
      response: { ok: res.ok, status: res.status, statusText: res.statusText, url: res.url, headers: resHeaders, text }
    });
  } catch (err) {
    return JSON.stringify({ ok: false, error: String(err?.message || 'Sandbox fetch blocked') });
  }
}

function hostUrlBridge(rawUrl, baseUrl) {
  try {
    const u = baseUrl ? new NodeURL(String(rawUrl), String(baseUrl)) : new NodeURL(String(rawUrl));
    return JSON.stringify({
      ok: true,
      href: u.href,
      origin: u.origin,
      protocol: u.protocol,
      host: u.host,
      hostname: u.hostname,
      port: u.port,
      pathname: u.pathname,
      search: u.search,
      hash: u.hash
    });
  } catch (err) {
    return JSON.stringify({ ok: false, error: String(err?.message || 'Invalid URL') });
  }
}

// Pure In-Realm Bootstrapper:
// - Never exposes Host functions, Host Promises, or Host Errors to user code
// - Wraps every Host bridge call in an in-realm try/catch converting exceptions to in-realm Error
// - Serializes final output to a primitive string inside the VM realm (Host never awaits a VM Promise)
const BOOTSTRAP_SOURCE = `(function bootstrap(hostLog, hostRpcCb, hostFetchCb, hostUrl, initJson) {
  'use strict';
  const RealmError = Error;
  const RealmTypeError = TypeError;
  const init = JSON.parse(String(initJson || '{}'));

  function callHostSync(fn, ...args) {
    try {
      return fn(...args);
    } catch (err) {
      throw new RealmError(String(err && err.message ? err.message : 'Host bridge error'));
    }
  }

  function callHostAsync(fn, ...args) {
    return new Promise((resolve, reject) => {
      try {
        fn(...args, (rawStr) => resolve(String(rawStr ?? '')));
      } catch (err) {
        reject(new RealmError(String(err && err.message ? err.message : 'Host async bridge error')));
      }
    });
  }

  const fmt = (v) => {
    if (typeof v === 'string') return v;
    if (v instanceof RealmError) return v.name + ': ' + v.message;
    try { return JSON.stringify(v); } catch { return String(v); }
  };
  const emitLog = (level, items) => {
    try { callHostSync(hostLog, String(level), items.map(fmt).join(' ')); } catch {}
  };
  globalThis.console = Object.freeze({
    log: (...a) => emitLog('info', a),
    info: (...a) => emitLog('info', a),
    warn: (...a) => emitLog('warn', a),
    error: (...a) => emitLog('error', a)
  });

  class URLSearchParams {
    constructor(input = '', onChange = null) {
      this._pairs = [];
      this._onChange = typeof onChange === 'function' ? onChange : null;
      if (typeof input === 'string') {
        const clean = input.startsWith('?') ? input.slice(1) : input;
        for (const seg of clean.split('&')) {
          if (!seg) continue;
          const idx = seg.indexOf('=');
          const k = decodeURIComponent((idx >= 0 ? seg.slice(0, idx) : seg).replace(/\\+/g, ' '));
          const v = decodeURIComponent((idx >= 0 ? seg.slice(idx + 1) : '').replace(/\\+/g, ' '));
          this._pairs.push([k, v]);
        }
      } else if (input && typeof input === 'object') {
        for (const [k, v] of Object.entries(input)) this._pairs.push([String(k), String(v)]);
      }
    }
    _notify() { if (this._onChange) this._onChange(); }
    get(k) { const f = this._pairs.find(([key]) => key === String(k)); return f ? f[1] : null; }
    has(k) { return this._pairs.some(([key]) => key === String(k)); }
    append(k, v) { this._pairs.push([String(k), String(v)]); this._notify(); }
    set(k, v) {
      const key = String(k);
      let replaced = false;
      const next = [];
      for (const pair of this._pairs) {
        if (pair[0] === key) {
          if (!replaced) { next.push([key, String(v)]); replaced = true; }
        } else {
          next.push(pair);
        }
      }
      if (!replaced) next.push([key, String(v)]);
      this._pairs = next;
      this._notify();
    }
    delete(k) { this._pairs = this._pairs.filter(([key]) => key !== String(k)); this._notify(); }
    entries() { return this._pairs.map(([k, v]) => [k, v]); }
    toString() { return this._pairs.map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v)).join('&'); }
  }

  class URL {
    constructor(raw, base) {
      const parsed = JSON.parse(String(callHostSync(hostUrl, String(raw ?? ''), base !== undefined ? String(base) : '')));
      if (!parsed.ok) throw new RealmTypeError(parsed.error || 'Invalid URL');
      Object.assign(this, parsed);
      delete this.ok;
      this.searchParams = new URLSearchParams(this.search, () => {
        const qs = this.searchParams.toString();
        this.search = qs ? '?' + qs : '';
        this.href = this.origin + this.pathname + this.search + this.hash;
      });
    }
    toString() { return this.href; }
  }
  globalThis.URLSearchParams = URLSearchParams;
  globalThis.URL = URL;

  globalThis.fetch = async function fetch(url, opts = {}) {
    const raw = await callHostAsync(
      hostFetchCb,
      JSON.stringify({ url: String(url ?? ''), init: opts && typeof opts === 'object' ? opts : {} })
    );
    const parsed = JSON.parse(raw);
    if (!parsed.ok) throw new RealmError(parsed.error || 'Sandbox fetch failed');
    const r = parsed.response;
    const hdrs = r.headers || {};
    return Object.freeze({
      ok: Boolean(r.ok),
      status: Number(r.status),
      statusText: String(r.statusText || ''),
      url: String(r.url || ''),
      headers: Object.freeze({
        get: (name) => hdrs[String(name || '').toLowerCase()] ?? null,
        has: (name) => Object.prototype.hasOwnProperty.call(hdrs, String(name || '').toLowerCase()),
        entries: () => Object.entries(hdrs)
      }),
      text: async () => String(r.text ?? ''),
      json: async () => JSON.parse(String(r.text ?? ''))
    });
  };

  async function callTool(method, params) {
    const raw = await callHostAsync(hostRpcCb, String(method), JSON.stringify(params));
    const parsed = JSON.parse(raw);
    if (!parsed.ok) throw new RealmError(parsed.error || 'Tool bridge error');
    return parsed.data;
  }
  globalThis.OmniFlowTools = Object.freeze({
    lookupPrice: async (kw) => callTool('lookupPrice', [kw]),
    calculateQuotation: async (kw, qty, w, l, mode) => callTool('calculateQuotation', [kw, qty, w, l, mode]),
    recordOrderLead: async (orderData) => callTool('recordOrderLead', [orderData]),
    getAllCatalogItems: async () => callTool('getAllCatalogItems', [])
  });

  const safeArgs = init.args && typeof init.args === 'object' ? init.args : {};
  globalThis.$input = Object.freeze({ ...safeArgs });
  globalThis.args = Object.freeze({ ...safeArgs });
  globalThis.$vars = Object.freeze({ gatewayPort: init.gatewayPort, sandboxEnv: 'OmniFlow-Studio-Isolated-Worker' });
  for (const key of init.dollarKeys || []) {
    if (key === 'input' || key === 'vars') continue;
    globalThis['$' + key] = safeArgs[key];
  }

  function serializeOutput(val) {
    if (val === undefined) return JSON.stringify({ isString: false, valueJson: 'null' });
    if (typeof val === 'string') return JSON.stringify({ isString: true, valueJson: JSON.stringify(val) });
    return JSON.stringify({ isString: false, valueJson: JSON.stringify(val) ?? 'null' });
  }

  return function runUserEntry(userFn, hostDone) {
    Promise.resolve()
      .then(() => userFn())
      .then(
        (val) => {
          try {
            callHostSync(hostDone, true, serializeOutput(val));
          } catch (serErr) {
            callHostSync(hostDone, false, String(serErr && serErr.message ? serErr.message : 'Output serialization failed'));
          }
        },
        (err) => {
          const msg = err && typeof err === 'object' && 'message' in err ? String(err.message) : String(err ?? 'Unknown Sandbox Error');
          callHostSync(hostDone, false, msg);
        }
      );
  };
})`;

async function runPayload(msg) {
  const safeTimeout = Math.min(15000, Math.max(300, Number(msg.timeoutMs) || 5000));
  const deadlineAt = Date.now() + safeTimeout;
  const ctx = vm.createContext(Object.create(null), { codeGeneration: { strings: false, wasm: false } });
  const bootstrapFn = vm.runInContext(BOOTSTRAP_SOURCE, ctx, { filename: 'sandbox-bootstrap.vm.js' });

  const hostLog = (level, text) => {
    if (logCount >= MAX_LOGS) return;
    logCount += 1;
    safeSend({
      type: 'log',
      entry: { level: String(level || 'info'), time: new Date().toISOString(), message: String(text || '').slice(0, MAX_LOG_LEN) }
    });
  };
  const hostRpcCb = (method, paramsJson, cb) => {
    let params = [];
    try { params = JSON.parse(String(paramsJson || '[]')); } catch { params = []; }
    callParentRpc(String(method || ''), Array.isArray(params) ? params : [], Math.max(500, deadlineAt - Date.now()))
      .then((resStr) => { try { cb(String(resStr)); } catch {} })
      .catch((err) => { try { cb(JSON.stringify({ ok: false, error: String(err?.message || 'RPC error') })); } catch {} });
  };
  const hostFetchCb = (reqJson, cb) => {
    hostFetchBridge(reqJson, deadlineAt)
      .then((resStr) => { try { cb(String(resStr)); } catch {} })
      .catch((err) => { try { cb(JSON.stringify({ ok: false, error: String(err?.message || 'Fetch error') })); } catch {} });
  };

  const initJson = JSON.stringify({ args: msg.args || {}, dollarKeys: msg.dollarKeys || [], gatewayPort: Number(msg.gatewayPort || 4001) });
  const runUserEntry = bootstrapFn(hostLog, hostRpcCb, hostFetchCb, hostUrlBridge, initJson);
  const filename = `custom-tool:${String(msg.toolName || 'inline')}.vm.js`;
  const userCode = String(msg.code || '');

  try {
    // Compile via vm.compileFunction inside parsingContext (omits importModuleDynamically so Node default rejects in-realm)
    const userFn = vm.compileFunction(
      `'use strict';\nreturn (async function __sandbox_tool__() {\n${userCode}\n})();`,
      [],
      { parsingContext: ctx, filename }
    );

    const outcome = await new Promise((resolve) => {
      let settled = false;
      const finish = (res) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        resolve(res);
      };
      const timer = setTimeout(() => {
        finish({ ok: false, timedOut: true, error: `Timeout Guard: Script execution timed out (${safeTimeout}ms)` });
      }, safeTimeout);

      const hostDone = (ok, payloadStr) => {
        finish(ok ? { ok: true, serializedJson: String(payloadStr ?? '') } : { ok: false, timedOut: false, error: String(payloadStr || 'Unknown Sandbox Error') });
      };

      try {
        runUserEntry(userFn, hostDone);
      } catch (err) {
        finish({ ok: false, timedOut: false, error: String(err?.message || err || 'Unknown Sandbox Error') });
      }
    });

    if (!outcome.ok) {
      safeSend({ type: 'done', ok: false, timedOut: Boolean(outcome.timedOut), error: outcome.error });
    } else if (Buffer.byteLength(outcome.serializedJson, 'utf8') > MAX_RESULT_BYTES) {
      safeSend({ type: 'done', ok: false, timedOut: false, error: 'Sandbox output exceeds maximum allowed size (2MB)' });
    } else {
      safeSend({ type: 'done', ok: true, serializedJson: outcome.serializedJson });
    }
  } catch (err) {
    const rawMsg = String(err?.message || err || 'Unknown Sandbox Error');
    const isTimeout = rawMsg.includes('Script execution timed out') || rawMsg.includes('Timeout Guard:');
    safeSend({ type: 'done', ok: false, timedOut: isTimeout, error: rawMsg });
  } finally {
    setTimeout(() => process.exit(0), 20).unref();
  }
}

process.on('message', (msg) => {
  if (!msg || typeof msg !== 'object') return;
  if (msg.type === 'rpc_res' && msg.id && pendingRpc.has(msg.id)) {
    const cb = pendingRpc.get(msg.id);
    pendingRpc.delete(msg.id);
    cb({ ok: Boolean(msg.ok), data: msg.data, error: msg.error });
    return;
  }
  if (msg.type === 'run') runPayload(msg);
});
