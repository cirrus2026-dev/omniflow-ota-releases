// gateway/src/modules/settings-lead-notifier.mjs
// Admin Lead & Order Amendment Webhook Notifier (Extracted from settings-vault.mjs)

import { fetchSafe, redactUrlSecrets } from './fetch-safe.mjs';
import { getRuntimeConfig, isMaskedPlaceholder } from './settings-vault.mjs';

function scrubBotTokens(text) {
  return redactUrlSecrets(String(text || ''))
    .replace(/bot\d+:[A-Za-z0-9_-]+/g, 'botREDACTED')
    .replace(/(\/api\/webhooks\/\d+\/)([^/?#\s]+)/gi, '$1REDACTED')
    .replace(/(\/services\/[A-Za-z0-9]+\/[A-Za-z0-9]+\/)([^/?#\s]+)/gi, '$1REDACTED');
}

export async function sendAdminLeadNotification(order = {}, options = {}) {
  const runtimeConfig = getRuntimeConfig();
  const isTest = Boolean(options.isTest);
  const override = String(options.webhookUrlOverride || '').trim();
  const rawUrl =
    !override || isMaskedPlaceholder(override)
      ? String(runtimeConfig?.business?.adminNotifyWebhookUrl || process.env.ADMIN_NOTIFY_WEBHOOK_URL || '').trim()
      : override;

  if (!rawUrl) {
    if (isTest) throw new Error('กรุณากรอก Webhook URL สำหรับแจ้งเตือนแอดมินก่อนกดทดสอบ');
    return { sent: false, skipped: true, reason: 'no_webhook_url' };
  }

  let parsedRawUrl;
  try {
    parsedRawUrl = new URL(rawUrl);
  } catch {
    throw new Error(`รูปแบบ Webhook URL ไม่ถูกต้อง: ${scrubBotTokens(rawUrl)}`);
  }

  const isAmendment = Boolean(options.isAmendment);
  const businessName = runtimeConfig?.business?.businessName || process.env.BUSINESS_NAME || 'Aether AI Commerce';
  const headerTitle = isTest
    ? `🔔 [ทดสอบระบบแจ้งเตือน] ${businessName}`
    : isAmendment
    ? `🔄 [อัปเดตออเดอร์เพิ่มเติม #${order.id || '-'}] ${businessName}`
    : `🚨 [ลูกค้าสนใจสั่งซื้อใหม่!] ${businessName}`;

  const dimAndQty = [order.dimensions, order.quantity ? `(${order.quantity})` : ''].filter(Boolean).join(' ').trim();
  const summaryText = [
    headerTitle,
    '━━━━━━━━━━━━━━━',
    `🆔 รหัส: ${order.id || '-'}`,
    `🕒 เวลา: ${order.timestamp || new Date().toISOString()}`,
    `📱 ช่องทาง: ${String(order.channel || 'direct').toUpperCase()}`,
    `👤 ลูกค้า: ${order.customerName || 'ลูกค้าหน้าร้าน'}`,
    `📞 เบอร์โทร: ${order.phone || '-'}`,
    `🪨 สินค้า: ${order.productName || '-'}`,
    dimAndQty ? `📐 ขนาด/จำนวน: ${dimAndQty}` : '',
    order.estimatedTotal ? `💰 ยอดประเมิน: ${order.estimatedTotal}` : '',
    `📍 ที่อยู่: ${order.address || '-'}`,
    order.note ? `📝 หมายเหตุ: ${order.note}` : ''
  ]
    .filter(Boolean)
    .join('\n');

  let targetUrl = rawUrl;
  const headers = { 'Content-Type': 'application/json' };
  let bodyStr = '';
  let provider = 'generic';

  if (/notify-api\.line\.me\/api\/notify/i.test(rawUrl)) {
    provider = 'line_notify';
    const u = new URL(parsedRawUrl.toString());
    const token = u.searchParams.get('token') || u.hash.replace(/^#/, '').trim();
    u.searchParams.delete('token');
    u.hash = '';
    targetUrl = u.toString();
    if (token) headers.Authorization = `Bearer ${token}`;
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
    bodyStr = new URLSearchParams({ message: `\n${summaryText}` }).toString();
  } else if (/discord(?:app)?\.com\/api\/webhooks\//i.test(rawUrl)) {
    provider = 'discord';
    bodyStr = JSON.stringify({
      username: businessName,
      content: summaryText,
      embeds: [
        {
          title: isTest
            ? '🔔 ทดสอบแจ้งเตือนออเดอร์ (Test Lead)'
            : isAmendment
            ? `🔄 อัปเดตออเดอร์เพิ่มเติม #${order.id || '-'}`
            : `🛒 ออเดอร์ใหม่ #${order.id || '-'}`,
          color: isTest || isAmendment ? 0x06b6d4 : 0x10b981,
          fields: [
            { name: 'ลูกค้า', value: String(order.customerName || '-'), inline: true },
            { name: 'เบอร์โทร', value: String(order.phone || '-'), inline: true },
            { name: 'ช่องทาง', value: String(order.channel || 'direct').toUpperCase(), inline: true },
            { name: 'สินค้า', value: String(order.productName || '-'), inline: false },
            { name: 'ขนาด / จำนวน', value: dimAndQty || '-', inline: true },
            { name: 'ยอดประเมิน', value: String(order.estimatedTotal || '-'), inline: true },
            { name: 'ที่อยู่จัดส่ง', value: String(order.address || '-'), inline: false }
          ],
          timestamp: new Date().toISOString()
        }
      ]
    });
  } else if (/api\.telegram\.org\/bot/i.test(rawUrl)) {
    provider = 'telegram';
    const chatId = parsedRawUrl.searchParams.get('chat_id') || parsedRawUrl.searchParams.get('chatId') || '';
    bodyStr = JSON.stringify({ ...(chatId ? { chat_id: chatId } : {}), text: summaryText });
  } else {
    const inquiryDetail = [
      order.productName || 'สอบถามสินค้า',
      dimAndQty ? `ขนาด/จำนวน ${dimAndQty}` : '',
      order.estimatedTotal ? `ยอดประเมิน ${order.estimatedTotal}` : ''
    ]
      .filter(Boolean)
      .join(' | ');
    bodyStr = JSON.stringify({
      event: isTest ? 'lead.test' : 'lead.created',
      businessName,
      timestamp: order.timestamp || new Date().toISOString(),
      customerName: order.customerName || 'ลูกค้าไม่ระบุชื่อ',
      inquiryDetail,
      contactNumber: order.phone || 'ไม่ได้ระบุเบอร์โทร',
      address: order.address || 'ไม่ได้ระบุที่อยู่',
      imageUrl: order.imageUrl || '',
      text: summaryText,
      message: summaryText,
      content: summaryText,
      order,
      sentAt: new Date().toISOString()
    });
  }

  let res;
  try {
    res = await fetchSafe(targetUrl, {
      method: 'POST',
      headers,
      body: bodyStr,
      allowHttp: false,
      timeoutMs: 8000,
      maxBytes: 1024 * 1024
    });
  } catch (err) {
    throw new Error(scrubBotTokens(err?.message || 'ไม่สามารถเชื่อมต่อ Webhook URL ได้'));
  }

  if (!res.ok) {
    const errText = scrubBotTokens(await res.text().catch(() => '')).slice(0, 180);
    throw new Error(`${provider === 'line_notify' ? 'LINE Notify' : 'Webhook'} HTTP ${res.status}: ${errText}`);
  }

  return provider === 'line_notify' ? { sent: true, provider, status: res.status } : { sent: true, status: res.status };
}
