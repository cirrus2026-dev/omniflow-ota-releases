// gateway/src/modules/line-handoff-media.mjs
// Modular LINE Image Ingestion for Human Handoff & Payment Slip Dashboard Display

import fs from 'node:fs/promises';
import path from 'node:path';

const LINE_CONTENT_URL_RE = /api-data\.line\.me\/v2\/bot\/message\/([^/?#]+)\/content/i;
const LINE_PROXY_URL_RE = /\/api\/chat\/line-image\/([^/?#]+)/i;
const SAFE_MSG_ID_RE = /^[A-Za-z0-9_-]+$/;
const MAX_LINE_IMAGE_BYTES = 10 * 1024 * 1024;

function extractLineMessageId(imgObj) {
  if (!imgObj) return '';
  if (imgObj.messageId) return String(imgObj.messageId).trim();
  const url = String(imgObj.url || '').trim();
  if (!url) return '';
  const contentMatch = url.match(LINE_CONTENT_URL_RE);
  if (contentMatch) return decodeURIComponent(contentMatch[1]).trim();
  const proxyMatch = url.match(LINE_PROXY_URL_RE);
  if (proxyMatch) return decodeURIComponent(proxyMatch[1]).trim();
  return '';
}

function getExtFromContentType(contentType = '') {
  const ct = String(contentType).toLowerCase();
  if (ct.includes('png')) return '.png';
  if (ct.includes('webp')) return '.webp';
  if (ct.includes('gif')) return '.gif';
  return '.jpg';
}

/**
 * Download LINE message image content into images_web/line-uploads so the Dashboard
 * and Order Leads can display it reliably even after LINE ephemeral tokens rotate.
 */
export async function ingestLineImage(imgObj, config = {}) {
  if (!imgObj) return '';
  const rawUrl = String(imgObj.url || '').trim();
  if (rawUrl && !LINE_CONTENT_URL_RE.test(rawUrl) && !LINE_PROXY_URL_RE.test(rawUrl)) {
    return rawUrl;
  }

  const messageId = extractLineMessageId(imgObj);
  if (!messageId || !SAFE_MSG_ID_RE.test(messageId)) {
    return '';
  }

  const proxyUrl = `/api/chat/line-image/${encodeURIComponent(messageId)}`;
  const token = String(
    process.env.LINE_CHANNEL_ACCESS_TOKEN || config?.lineChannelAccessToken || ''
  ).trim();
  if (!token) {
    return proxyUrl;
  }

  try {
    const res = await fetch(
      `https://api-data.line.me/v2/bot/message/${encodeURIComponent(messageId)}/content`,
      {
        headers: { Authorization: `Bearer ${token}` },
        signal: AbortSignal.timeout(8000),
      }
    );
    if (!res.ok) {
      return proxyUrl;
    }
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > MAX_LINE_IMAGE_BYTES) {
      return proxyUrl;
    }

    const ext = getExtFromContentType(res.headers.get('content-type') || '');
    const fileName = `line_${messageId}${ext}`;
    const uploadsDir = path.resolve(process.cwd(), 'images_web', 'line-uploads');
    await fs.mkdir(uploadsDir, { recursive: true });
    await fs.writeFile(path.join(uploadsDir, fileName), buf);
    return `/images_web/line-uploads/${fileName}`;
  } catch (err) {
    console.warn(`[LineHandoffMedia] Ingest failed for ${messageId}:`, err?.message || err);
    return proxyUrl;
  }
}

/**
 * Resolve a customer's attached image URL during Step 2.5 Human Handoff escalation.
 */
export async function resolveHandoffImageUrl(turn, config = {}) {
  const firstImg = turn?.images?.[0] || null;
  if (!firstImg) return '';
  const url = String(firstImg.url || '').trim();
  const isLineMedia =
    firstImg.platform === 'line' ||
    Boolean(firstImg.messageId) ||
    LINE_CONTENT_URL_RE.test(url) ||
    LINE_PROXY_URL_RE.test(url);

  if (isLineMedia) {
    return ingestLineImage(firstImg, config);
  }
  return url;
}
