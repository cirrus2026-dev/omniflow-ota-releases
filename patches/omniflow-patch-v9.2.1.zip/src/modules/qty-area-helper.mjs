// gateway/src/modules/qty-area-helper.mjs
// Pure helper for resolving dimension + area-unit signals (qtyIsArea guard)

const AREA_UNIT_LABEL_REGEX = /^(?:ตร|ตารางเมตร|sqm|sq\.?\s*m)/i;

/**
 * Check whether a parsed unitLabel represents an area unit (ตร.ม. / ตารางเมตร / sqm / sq.m.).
 */
export function isAreaUnitLabel(unitLabel = '') {
  return AREA_UNIT_LABEL_REGEX.test(String(unitLabel || '').trim());
}

/**
 * Normalize raw turn signals when both dimensions (widthM x lengthM) and an area quantity
 * (e.g. "ตร.ม.") are present:
 * - "60x60 ซม. ใช้ 10 ตร.ม." (tile size <= 1.2m & qty > tileArea * 1.5) -> keep total area qty, clear widthM/lengthM
 * - "2.5x4 = 10 ตร.ม." -> clear qty so dimensions are not multiplied twice (preventing 100 ตร.ม.)
 */
export function resolveQtyAreaSignal(rawSigObj = {}) {
  const src = rawSigObj && typeof rawSigObj === 'object' ? rawSigObj : {};
  const widthM = Number(src.widthM);
  const lengthM = Number(src.lengthM);
  const qty = Number(src.qty);
  const rawHasDims = !Number.isNaN(widthM) && !Number.isNaN(lengthM);
  const qtyIsArea = isAreaUnitLabel(src.unitLabel);

  let sigObj = src;
  let isTileSizePlusTotalArea = false;

  if (rawHasDims && qtyIsArea && !Number.isNaN(qty) && qty > 0) {
    const tileArea = widthM * lengthM;
    isTileSizePlusTotalArea =
      widthM <= 1.2 && lengthM <= 1.2 && qty > tileArea * 1.5;

    sigObj = isTileSizePlusTotalArea
      ? { ...src, widthM: NaN, lengthM: NaN }
      : { ...src, qty: NaN };
  }

  const hasDims = !Number.isNaN(sigObj.widthM) && !Number.isNaN(sigObj.lengthM);
  const hasDimsOrQty = hasDims || !Number.isNaN(sigObj.qty);

  return {
    sigObj,
    hasDims,
    qtyIsArea,
    isTileSizePlusTotalArea,
    hasDimsOrQty,
  };
}
