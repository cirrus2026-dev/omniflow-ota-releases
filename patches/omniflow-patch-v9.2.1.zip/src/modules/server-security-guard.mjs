// gateway/src/modules/server-security-guard.mjs
// Centralized Auth Gate, Strict Port-Scoped CORS, Rate-Limited Admin Session Guard, Health Redaction & Direct Image Helper

import {
  isLocalAdminRequest,
  isDirectLocalHostRequest,
  verifyAdminPinAndIssueSession,
  hasValidAdminSession,
  revokeAdminSession
} from './settings-vault.mjs';
import {
  checkPinRateLimit,
  getRateLimitClientKey
} from './admin-auth-guard.mjs';

export const STRICT_ADMIN_PATHS = new Set([
  '/api/tools/test-run',
  '/api/custom-tools',
  '/api/system/ota/apply',
  '/api/system/rollback',
  '/api/ota/rollback',
  '/api/presets/install',
  '/api/presets/reset-core',
  '/api/system/reset-core',
  '/api/settings/channels',
  '/api/settings/brain',
  '/api/settings/flowise',
  '/api/settings/test-webhook',
  '/api/settings/brain/discover-models',
  '/api/local-ai/models',
  '/canary'
]);

export function isStrictAdminPath(pathname = '') {
  const clean = String(pathname || '').trim().replace(/\/+$/, '') || '/';
  return STRICT_ADMIN_PATHS.has(clean) || clean.startsWith('/api/custom-tools/');
}

export function getLocalCorsHeaders(req, port = 4003) {
  const expectedPort = String(port || 4003).trim();
  const origin = String(req?.headers?.origin || '').trim();
  const allowedOrigins = new Set([
    `http://127.0.0.1:${expectedPort}`,
    `http://localhost:${expectedPort}`
  ]);
  const allowOrigin = allowedOrigins.has(origin.toLowerCase()) ? origin : `http://127.0.0.1:${expectedPort}`;
  return {
    'Access-Control-Allow-Origin': allowOrigin,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token, Authorization',
    'Access-Control-Allow-Credentials': 'true',
    Vary: 'Origin'
  };
}

function isHttpsRequest(req) {
  if (req?.socket?.encrypted) return true;
  const forwardedProto = String(req?.headers?.['x-forwarded-proto'] || '').split(',')[0].trim().toLowerCase();
  return forwardedProto === 'https';
}

export function requireAdminJson(req, res, corsHeaders = {}) {
  if (isLocalAdminRequest(req)) return true;
  const rl = checkPinRateLimit(getRateLimitClientKey(req));
  if (!rl.allowed) {
    res.writeHead(429, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Retry-After': String(rl.retryAfterSec),
      ...corsHeaders
    });
    res.end(JSON.stringify({
      ok: false,
      locked: true,
      retryAfterSec: rl.retryAfterSec,
      requirePin: true,
      error: `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${rl.retryAfterSec} วินาที`
    }));
    return false;
  }
  res.writeHead(401, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...corsHeaders
  });
  res.end(JSON.stringify({ ok: false, error: 'Unauthorized', requirePin: true }));
  return false;
}

export function requireStrictAdminSession(req, res, pathname, corsHeaders = {}) {
  if (!isStrictAdminPath(pathname)) return true;
  if (hasValidAdminSession(req)) return true;
  const rl = checkPinRateLimit(getRateLimitClientKey(req));
  if (!rl.allowed) {
    res.writeHead(429, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Retry-After': String(rl.retryAfterSec),
      ...corsHeaders
    });
    res.end(JSON.stringify({
      ok: false,
      locked: true,
      retryAfterSec: rl.retryAfterSec,
      code: 'ADMIN_SESSION_REQUIRED',
      requirePin: true,
      error: `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${rl.retryAfterSec} วินาที`
    }));
    return false;
  }
  res.writeHead(401, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...corsHeaders
  });
  res.end(JSON.stringify({
    ok: false,
    code: 'ADMIN_SESSION_REQUIRED',
    requirePin: true,
    error: 'ต้องยืนยัน Admin PIN ก่อนใช้งานฟังก์ชันนี้'
  }));
  return false;
}

export function isChannelEnabled(runtimeConfig, channelId) {
  const ch = runtimeConfig?.channels?.[channelId];
  return Boolean(ch && typeof ch === 'object' && ch.enabled === true);
}

export function canRunCanaryChatCommand(userId, adminUserIds) {
  const cleanId = String(userId || '').trim();
  if (!cleanId || !(adminUserIds instanceof Set) || adminUserIds.size === 0) return false;
  return adminUserIds.has(cleanId);
}

export function buildHealthPayload({ isLocal, config, botSwitch, stateStore, sandboxSimulatorEnabled }) {
  const base = {
    status: 'ok',
    service: 'aether-business-command-center',
    port: config.port,
    botStatus: botSwitch
  };
  if (!isLocal) return base;
  return {
    ...base,
    version: '8.5',
    activeSessionLocks: stateStore.sessionLocks.size,
    activeTakeoverCount: stateStore.getActiveTakeovers().length,
    conversationCount: stateStore.conversations.size,
    flowisePrimaryId: config.flowisePrimaryId,
    flowiseFallbackId: config.flowiseFallbackId,
    lineChannelId: config.lineChannelId,
    lineDeliveryMode: config.lineDeliveryMode,
    hasFbToken: Boolean(config.fbPageAccessToken),
    hasGroqKey: Boolean(config.groqApiKey),
    hasFbSecret: Boolean(config.fbAppSecret),
    sandboxSimulatorEnabled
  };
}

export async function sendDirectImageViaDispatcher({
  platform,
  userId,
  imageUrl,
  caption = '',
  config,
  stateStore,
  dispatchDualMessage
}) {
  const cleanUrl = String(imageUrl || '').trim();
  if (!cleanUrl) throw new Error('Missing imageUrl');
  const userKey = `${platform}:${userId}`;
  const channelMeta = stateStore.conversations?.get(userKey)?.channelMeta || {};
  const dispatchRes = await dispatchDualMessage(
    { platform, userId, channelMeta },
    { text: caption || '', images: [{ url: cleanUrl }] },
    config
  );
  return {
    ...(dispatchRes && typeof dispatchRes === 'object' ? dispatchRes : {}),
    platform,
    ok: Boolean(dispatchRes?.ok)
  };
}

export function renderAdminPinGateHtml() {
  return `<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>OmniFlow Admin Security Gate</title>
  <style>
    * { box-sizing: border-box; font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; }
    body { margin: 0; min-height: 100vh; display: flex; align-items: center; justify-content: center; background: radial-gradient(circle at top right, #0e2a47, #050914 70%); color: #e2e8f0; padding: 16px; }
    .card { width: 100%; max-width: 400px; padding: 32px 28px; border-radius: 20px; background: rgba(10, 18, 38, 0.85); backdrop-filter: blur(18px); border: 1px solid rgba(34, 211, 238, 0.28); box-shadow: 0 20px 60px rgba(0, 0, 0, 0.55); }
    .badge { display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 999px; font-size: 11px; font-weight: 700; background: rgba(6, 182, 212, 0.15); color: #67e8f9; border: 1px solid rgba(34, 211, 238, 0.35); margin-bottom: 14px; }
    h1 { margin: 0 0 6px; font-size: 20px; color: #f8fafc; }
    p { margin: 0 0 20px; font-size: 13px; color: #94a3b8; line-height: 1.5; }
    label { display: block; font-size: 12px; font-weight: 600; color: #cbd5e1; margin-bottom: 8px; }
    input[type="password"] { width: 100%; padding: 12px 14px; border-radius: 12px; background: rgba(2, 6, 23, 0.85); border: 1px solid rgba(100, 116, 139, 0.5); color: #f8fafc; font-size: 16px; letter-spacing: 4px; outline: none; }
    input[type="password"]:focus { border-color: #22d3ee; }
    button { margin-top: 16px; width: 100%; padding: 12px 16px; border: 0; border-radius: 12px; background: linear-gradient(135deg, #06b6d4, #2563eb); color: #020617; font-weight: 800; font-size: 14px; cursor: pointer; }
    button:disabled { opacity: 0.55; cursor: not-allowed; }
    .err { margin-top: 12px; padding: 10px 12px; border-radius: 10px; font-size: 12px; background: rgba(225, 29, 72, 0.18); border: 1px solid rgba(244, 63, 94, 0.45); color: #fda4af; display: none; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">🔐 Remote Access Protection</div>
    <h1>OmniFlow Remote Admin PIN Guard</h1>
    <p>กรุณากรอกรหัส Admin PIN เพื่อยืนยันสิทธิ์เข้าใช้งาน Dashboard</p>
    <form id="pinForm">
      <label for="pinInput">รหัสผ่าน Admin PIN</label>
      <input id="pinInput" type="password" inputmode="numeric" autocomplete="current-password" placeholder="••••••" autofocus required />
      <button id="submitBtn" type="submit">🔓 ปลดล็อกเข้าใช้งานระบบ</button>
      <div id="errBox" class="err"></div>
    </form>
  </div>
  <script>
    const form = document.getElementById('pinForm');
    const pinInput = document.getElementById('pinInput');
    const submitBtn = document.getElementById('submitBtn');
    const errBox = document.getElementById('errBox');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      errBox.style.display = 'none';
      submitBtn.disabled = true;
      submitBtn.textContent = '⏳ กำลังตรวจสอบ PIN...';
      try {
        const res = await fetch('/api/admin/auth/pin', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({ pin: pinInput.value.trim() })
        });
        const data = await res.json();
        if (!res.ok || !data.ok) throw new Error(data.error || 'รหัส PIN ไม่ถูกต้อง');
        window.location.reload();
      } catch (err) {
        errBox.textContent = err.message;
        errBox.style.display = 'block';
        submitBtn.disabled = false;
        submitBtn.textContent = '🔓 ปลดล็อกเข้าใช้งานระบบ';
        pinInput.focus();
      }
    });
  </script>
</body>
</html>`;
}

export async function handleAdminAuthRoutes(req, res, parsedUrl, corsHeaders, readJsonBody) {
  const { pathname } = parsedUrl;
  const secureAttr = isHttpsRequest(req) ? '; Secure' : '';

  if (req.method === 'GET' && pathname === '/enterprise-preview.html') {
    if (!isLocalAdminRequest(req)) {
      res.writeHead(401, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(renderAdminPinGateHtml());
      return true;
    }
    res.writeHead(302, { Location: '/', 'Cache-Control': 'no-store', ...corsHeaders });
    res.end();
    return true;
  }

  if (req.method === 'GET' && pathname === '/api/auth/session') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...corsHeaders });
    res.end(JSON.stringify({
      ok: true,
      authorized: isLocalAdminRequest(req),
      isDirectLocal: isDirectLocalHostRequest(req),
      hasSession: hasValidAdminSession(req)
    }));
    return true;
  }

  if (req.method === 'POST' && (pathname === '/api/admin/auth/pin' || pathname === '/api/auth/login' || pathname === '/api/auth/admin-pin')) {
    try {
      const body = await readJsonBody(req);
      const result = verifyAdminPinAndIssueSession(body?.pin, req);
      if (!result.ok) {
        res.writeHead(result.statusCode || 401, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
          ...(result.retryAfterSec ? { 'Retry-After': String(result.retryAfterSec) } : {}),
          ...corsHeaders
        });
        res.end(JSON.stringify({
          ok: false,
          error: result.error,
          requirePin: true,
          ...(result.locked ? { locked: true, retryAfterSec: result.retryAfterSec } : {})
        }));
        return true;
      }
      res.writeHead(200, {
        'Content-Type': 'application/json; charset=utf-8',
        'Cache-Control': 'no-store',
        'Set-Cookie': `omniflow_admin_session=${result.token}; HttpOnly; Path=/; Max-Age=43200; SameSite=Lax${secureAttr}`,
        ...corsHeaders
      });
      res.end(JSON.stringify({ ok: true, token: result.token, expiresAt: result.expiresAt }));
    } catch (err) {
      res.writeHead(err.statusCode || 400, { 'Content-Type': 'application/json; charset=utf-8', ...corsHeaders });
      res.end(JSON.stringify({ ok: false, error: err.message }));
    }
    return true;
  }

  if (req.method === 'POST' && pathname === '/api/auth/logout') {
    revokeAdminSession(req);
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store',
      'Set-Cookie': `omniflow_admin_session=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax${secureAttr}`,
      ...corsHeaders
    });
    res.end(JSON.stringify({ ok: true }));
    return true;
  }

  return false;
}
