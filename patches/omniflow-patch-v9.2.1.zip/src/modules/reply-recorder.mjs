// gateway/src/modules/reply-recorder.mjs
// Outbound Reply Dispatch Verification & Chat History Recording Module (Task D-8)

function normalizeImageUrls(images = []) {
  if (!Array.isArray(images)) return [];
  return images
    .map((img) => {
      if (typeof img === 'string') return img.trim();
      if (img && typeof img === 'object') return String(img.url || img.mirrorUrl || '').trim();
      return '';
    })
    .filter(Boolean);
}

/**
 * Dispatch a bot reply via dispatchDualMessage and record only verified delivery
 * results (messageId, delivered text & confirmed sent images) into stateStore.
 */
export async function handleBotReplyRecording({
  userKey,
  ctx,
  parsedReply = {},
  config,
  stateStore,
  dispatchDualMessage,
}) {
  const reply = parsedReply || {};
  let dispatchRes;

  try {
    dispatchRes = await dispatchDualMessage(ctx, reply, config);
  } catch (err) {
    const errorMsg = err?.message || 'Bot outbound dispatch failed';
    console.error(`[ReplyRecorder:Bot] Dispatch exception for ${userKey}:`, errorMsg);
    dispatchRes = {
      ok: false,
      platform: ctx?.platform || 'unknown',
      messageId: '',
      textSent: false,
      imagesSent: [],
      error: errorMsg,
    };
  }

  const isOk = dispatchRes?.ok !== false;
  const messageId = isOk && dispatchRes?.messageId ? String(dispatchRes.messageId) : '';

  let finalImages = [];
  if (Array.isArray(dispatchRes?.imagesSent)) {
    finalImages = normalizeImageUrls(dispatchRes.imagesSent);
  } else if (isOk) {
    finalImages = normalizeImageUrls(reply.images);
  }

  const recordedText = isOk || dispatchRes?.textSent === true ? String(reply.text || '') : '';
  if (recordedText.trim() || finalImages.length > 0) {
    stateStore.appendChatMessage(
      userKey,
      {
        sender: 'bot',
        messageId,
        text: recordedText,
        images: finalImages,
        timestamp: Date.now(),
      },
      {
        platform: ctx?.platform,
        userId: ctx?.userId,
      }
    );
  }

  return {
    ok: isOk,
    dispatchRes,
  };
}

/**
 * Send an admin reply to the customer platform (unless sandbox) and record
 * Human Takeover + chat message only when outbound delivery succeeds.
 */
export async function handleAdminReplyAndTakeover({
  userKey,
  text,
  replyToText,
  platform,
  userId,
  config,
  stateStore,
  sendAdminReply,
  convMeta,
}) {
  const cleanPlatform = String(platform || '').trim().toLowerCase();
  const cleanText = String(text || '');
  const cleanReplyTo = String(replyToText || '').trim();

  if (cleanPlatform !== 'sandbox') {
    const outboundText = cleanReplyTo
      ? `↩️ ตอบกลับ: "${cleanReplyTo.replace(/\s+/g, ' ').slice(0, 120)}"\n\n${cleanText}`
      : cleanText;

    try {
      const meta =
        convMeta !== undefined
          ? convMeta
          : stateStore?.conversations?.get(userKey)?.channelMeta || {};
      const res = await sendAdminReply(platform, userId, outboundText, config, {
        channelMeta: meta,
      });

      if (!res || res.ok === false) {
        return {
          ok: false,
          error: res?.error || `Failed to send admin reply via ${platform}`,
          dispatchRes: res,
        };
      }
    } catch (err) {
      return {
        ok: false,
        error: err?.message || `Failed to send admin reply via ${platform}`,
      };
    }
  }

  const now = Date.now();
  const takeoverTtlMs = Number(config?.takeoverTtlMs) > 0 ? Number(config.takeoverTtlMs) : 1800000;
  stateStore.setTakeover(userKey, takeoverTtlMs, now);

  stateStore.appendChatMessage(
    userKey,
    {
      sender: 'admin',
      text: cleanText,
      ...(cleanReplyTo ? { replyToText: cleanReplyTo } : {}),
      timestamp: now,
    },
    {
      platform,
      userId,
    }
  );

  return {
    ok: true,
    now,
    userKey,
  };
}
