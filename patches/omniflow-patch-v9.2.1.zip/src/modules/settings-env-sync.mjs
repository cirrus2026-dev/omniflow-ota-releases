// gateway/src/modules/settings-env-sync.mjs
// Runtime Env Hot-Reload & Token Cache Invalidation (Extracted from settings-vault.mjs + D-3 Fix)

import * as channelRegistry from './channels/channel-registry.mjs';

const TOKEN_CACHE_MODULES = [
  './channels/lark-adapter.mjs',
  './channels/dingtalk-adapter.mjs',
  './channels/wechat-adapter.mjs',
  './channels/teams-adapter.mjs',
  './channels/zalo-adapter.mjs',
  './channels/google-chat-adapter.mjs',
  './channels/whatsapp-adapter.mjs',
  './channels/line-adapter.mjs'
];

export const CORE_ENV_BINDINGS = [
  ['line', 'channelId', 'LINE_CHANNEL_ID'],
  ['line', 'channelSecret', 'LINE_CHANNEL_SECRET'],
  ['line', 'channelAccessToken', 'LINE_CHANNEL_ACCESS_TOKEN'],
  ['facebook', 'pageAccessToken', 'FB_PAGE_ACCESS_TOKEN'],
  ['facebook', 'appSecret', 'FB_APP_SECRET'],
  ['facebook', 'verifyToken', 'FB_VERIFY_TOKEN'],
  ['whatsapp', 'phoneNumberId', 'WHATSAPP_PHONE_NUMBER_ID'],
  ['whatsapp', 'accessToken', 'WHATSAPP_ACCESS_TOKEN'],
  ['whatsapp', 'appSecret', 'WHATSAPP_APP_SECRET'],
  ['whatsapp', 'verifyToken', 'WHATSAPP_VERIFY_TOKEN'],
  ['tiktok', 'appKey', 'TIKTOK_APP_KEY'],
  ['tiktok', 'appSecret', 'TIKTOK_APP_SECRET'],
  ['tiktok', 'shopId', 'TIKTOK_SHOP_ID'],
  ['shopee', 'partnerId', 'SHOPEE_PARTNER_ID'],
  ['shopee', 'partnerKey', 'SHOPEE_PARTNER_KEY'],
  ['shopee', 'shopId', 'SHOPEE_SHOP_ID'],
  ['lazada', 'appKey', 'LAZADA_APP_KEY'],
  ['lazada', 'appSecret', 'LAZADA_APP_SECRET'],
  ['lazada', 'accessToken', 'LAZADA_ACCESS_TOKEN'],
  ['email', 'fromEmail', 'EMAIL_FROM'],
  ['email', 'fromName', 'EMAIL_FROM_NAME'],
  ['email', 'webhookSecret', 'EMAIL_WEBHOOK_SECRET'],
  ['email', 'smtpHost', 'EMAIL_SMTP_HOST'],
  ['email', 'smtpPort', 'EMAIL_SMTP_PORT'],
  ['email', 'smtpUser', 'EMAIL_SMTP_USER'],
  ['email', 'smtpPass', 'EMAIL_SMTP_PASS'],
  ['email', 'outboundWebhookUrl', 'EMAIL_OUTBOUND_WEBHOOK_URL']
];

const tokenCacheClearers = new Set();

export function registerTokenCacheClearer(fn) {
  if (typeof fn === 'function') tokenCacheClearers.add(fn);
}

export async function clearCachedToken() {
  try { channelRegistry.clearCachedToken?.(); } catch { /* ignore */ }
  try { channelRegistry.clearAllCachedTokens?.(); } catch { /* ignore */ }
  for (const fn of tokenCacheClearers) {
    try { await fn(); } catch { /* ignore */ }
  }
  await Promise.all(
    TOKEN_CACHE_MODULES.map(async (modPath) => {
      try {
        const mod = await import(modPath);
        mod?.clearCachedToken?.();
      } catch {
        // Skip adapters that are absent or do not cache OAuth tokens
      }
    })
  );
}

/**
 * D-3 Fix: Explicitly delete process.env[envKey] when cleared to empty/whitespace string
 * so cleared secrets/vars behave identically to unset env variables.
 */
function setOrDeleteEnv(envKey, rawVal) {
  if (!envKey) return;
  const trimmed = String(rawVal ?? '').trim();
  if (trimmed === '') {
    delete process.env[envKey];
  } else {
    process.env[envKey] = trimmed;
  }
}

function syncRegistryEnvKeys(ch) {
  const skip = new Set([
    'getRegistryDefaultChannelsConfig',
    'getRegistrySecretFieldsMap',
    'clearCachedToken',
    'clearAllCachedTokens'
  ]);
  const descriptors = [];
  for (const [name, exp] of Object.entries(channelRegistry)) {
    if (skip.has(name)) continue;
    if (Array.isArray(exp)) {
      descriptors.push(...exp);
    } else if (
      typeof exp === 'function' &&
      exp.length === 0 &&
      /(?:schema|list|all|registry|def|meta)/i.test(name)
    ) {
      try {
        const res = exp();
        if (Array.isArray(res)) descriptors.push(...res);
        else if (res && typeof res === 'object') descriptors.push(...Object.values(res));
      } catch {
        // Ignore non-zero-arg or unavailable registry helpers
      }
    } else if (exp && typeof exp === 'object' && /registry|channels|defs|schemas/i.test(name)) {
      descriptors.push(...Object.values(exp));
    }
  }

  for (const item of descriptors) {
    const meta = item?.meta && typeof item.meta === 'object' ? item.meta : item;
    const chId = meta?.id || meta?.channelId;
    if (!chId || !ch[chId] || !Array.isArray(meta?.fields)) continue;
    for (const field of meta.fields) {
      if (field?.envKey && field?.key && ch[chId][field.key] !== undefined) {
        setOrDeleteEnv(field.envKey, ch[chId][field.key]);
      }
    }
  }
}

export function applyRuntimeEnvHotReload(cfg = {}) {
  if (cfg.business?.businessName !== undefined) {
    setOrDeleteEnv('BUSINESS_NAME', cfg.business.businessName);
  }
  if (cfg.business?.businessTagline !== undefined) {
    setOrDeleteEnv('BUSINESS_TAGLINE', cfg.business.businessTagline);
  }
  if (cfg.business?.adminNotifyWebhookUrl !== undefined) {
    setOrDeleteEnv('ADMIN_NOTIFY_WEBHOOK_URL', cfg.business.adminNotifyWebhookUrl);
  }
  if (cfg.publicBaseUrl !== undefined) {
    const cleanBase = String(cfg.publicBaseUrl ?? '').trim().replace(/\/+$/, '');
    setOrDeleteEnv('PUBLIC_BASE_URL', cleanBase);
  }

  const ch = cfg.channels || {};
  for (const [chId, fieldKey, envKey] of CORE_ENV_BINDINGS) {
    if (ch[chId] && ch[chId][fieldKey] !== undefined) {
      setOrDeleteEnv(envKey, ch[chId][fieldKey]);
    }
  }
  syncRegistryEnvKeys(ch);

  if (cfg.security?.adminPin !== undefined) {
    setOrDeleteEnv('ADMIN_PIN', cfg.security.adminPin);
  }
}
