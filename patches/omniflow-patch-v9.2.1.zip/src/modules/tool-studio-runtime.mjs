// gateway/src/modules/tool-studio-runtime.mjs
// Isolated Worker-Process Sandbox Runtime with Node 22 --permission Guard, Hard-Kill Timeout, RPC Bridge & Atomic Write Queue

import { fork } from 'node:child_process';
import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { lookupPrice, calculateQuotation, recordOrderLead } from './ai-brain-engine.mjs';
import { getAllCatalogItems } from './local-db-manager.mjs';

const DEFAULT_TIMEOUT_MS = 5000;
const MIN_TIMEOUT_MS = 300;
const MAX_TIMEOUT_MS = 15000;
const MAX_LOGS = 100;
const WORKER_PATH = fileURLToPath(new URL('./tool-sandbox-worker.mjs', import.meta.url));
const FETCH_SAFE_PATH = fileURLToPath(new URL('./fetch-safe.mjs', import.meta.url));
const LEGACY_STONE_TERMS_REGEX = /(ร้านหิน|รหัสบล็อก|ยกสแลป|หินแกรนิต)/i;
const IDENTIFIER_RE = /^[a-zA-Z_][a-zA-Z0-9_]*$/;
const SAFE_ENV_KEYS = ['TZ', 'LANG', 'LC_ALL'];

function buildSandboxEnv() {
  const env = { NODE_ENV: 'sandbox' };
  for (const key of SAFE_ENV_KEYS) {
    if (typeof process.env[key] === 'string' && process.env[key].length > 0) {
      env[key] = process.env[key];
    }
  }
  return env;
}

export const WHITE_LABEL_STANDARD_TOOLS = [
  {
    id: 'preset_standard_lookup_price_memory',
    name: 'lookup_price_memory',
    description:
      'ค้นหาข้อมูลสินค้า วัสดุ ขนาดมาตรฐาน รหัสสินค้า/ล็อต ราคาปกติ ราคาพิเศษ/สั่งตัดตามขนาด และลิงก์รูปภาพจากฐานข้อมูลคลังสินค้าของร้าน รองรับคำพ้องความหมายและคำค้นภาษาธรรมชาติสำหรับทุกหมวดธุรกิจ',
    color: 'linear-gradient(135deg, #06b6d4, #2563eb)',
    schema: JSON.stringify([
      { id: 1, property: 'keyword', description: 'คำค้นหาชื่อสินค้า รุ่น สี ประเภทวัสดุ หรือรหัสสินค้า (เว้นว่างเพื่อดูรายการสินค้าแนะนำ)', type: 'string', required: false }
    ]),
    func: `const kw = typeof $keyword !== 'undefined' ? String($keyword || '') : String($input?.keyword || '');
const results = await OmniFlowTools.lookupPrice(kw);
console.log(\`[lookup_price_memory] query="\${kw}" -> matched \${results.length} item(s)\`);
return JSON.stringify({
  ok: true, query: kw, count: results.length,
  items: results.map((item) => ({
    id: item.id, category: item.category, name: item.name, skuOrLot: item.blockCode || item.sku || '',
    size: item.size || '', unit: item.unit || 'หน่วย', primaryPrice: item.slabPrice ?? null,
    secondaryPrice: item.cutPrice ?? null, note: item.note || '', imageUrl: item.imageUrl || ''
  }))
}, null, 2);`
  },
  {
    id: 'preset_standard_calc_quote',
    name: 'calc_quote',
    description:
      'คำนวณใบเสนอราคาเบื้องต้นและปริมาณพื้นที่ใช้งาน (กว้าง x ยาว เป็นตารางเมตร หรือคำนวณตามจำนวนหน่วย) พร้อมระบบ Hard Guard ตรวจสอบขนาดผิดปกติ และเปรียบเทียบราคาปกติกับราคาพิเศษ/สั่งตัดตามขนาดหรือเรทราคาส่งอัตโนมัติ',
    color: 'linear-gradient(135deg, #10b981, #059669)',
    schema: JSON.stringify([
      { id: 1, property: 'productKeyword', description: 'ชื่อสินค้า รุ่น หรือวัสดุที่ต้องการคำนวณราคา', type: 'string', required: true },
      { id: 2, property: 'width', description: 'ความกว้าง (หน่วยเป็นเมตร เช่น 1.2) หากคำนวณตามพื้นที่', type: 'number', required: false },
      { id: 3, property: 'length', description: 'ความยาว/ความสูง (หน่วยเป็นเมตร เช่น 2.4) หากคำนวณตามพื้นที่', type: 'number', required: false },
      { id: 4, property: 'quantity', description: 'จำนวนชิ้น หรือปริมาณพื้นที่รวม (กรณีไม่ระบุ กว้าง x ยาว)', type: 'number', required: false },
      { id: 5, property: 'purchaseMode', description: 'รูปแบบราคาที่ต้องการเปรียบเทียบ: both | primary | secondary', type: 'string', required: false }
    ]),
    func: `const kw = typeof $productKeyword !== 'undefined' ? $productKeyword : ($input?.productKeyword || $input?.keyword || '');
const w = typeof $width !== 'undefined' ? $width : $input?.width;
const l = typeof $length !== 'undefined' ? $length : $input?.length;
const qty = typeof $quantity !== 'undefined' ? $quantity : $input?.quantity;
const mode = typeof $purchaseMode !== 'undefined' ? $purchaseMode : ($input?.purchaseMode || 'both');
const quote = await OmniFlowTools.calculateQuotation(kw, qty, w, l, mode);
console.log(\`[calc_quote] product="\${kw}" ok=\${quote.ok}\`);
return JSON.stringify(quote, null, 2);`
  },
  {
    id: 'preset_standard_send_to_activepieces',
    name: 'send_to_activepieces',
    description:
      'บันทึกข้อมูลออเดอร์ รายการสินค้า ขนาดพื้นที่/จำนวน ยอดประเมินเบื้องต้น และเบอร์โทรศัพท์ติดต่อของลูกค้าเข้าสู่ระบบจัดการออเดอร์ของร้าน พร้อมส่งแจ้งเตือนให้ทีมฝ่ายขายดูแลต่อทันที',
    color: 'linear-gradient(135deg, #8b5cf6, #6d28d9)',
    schema: JSON.stringify([
      { id: 1, property: 'customerName', description: 'ชื่อลูกค้า (ถ้าทราบ)', type: 'string', required: false },
      { id: 2, property: 'phone', description: 'เบอร์โทรศัพท์ติดต่อกลับของลูกค้า', type: 'string', required: true },
      { id: 3, property: 'productName', description: 'ชื่อสินค้าหรือบริการที่ลูกค้าสนใจสั่งซื้อ', type: 'string', required: true },
      { id: 4, property: 'dimensions', description: 'ขนาดที่สั่งตัด หรือรายละเอียดสเปกหน้างาน (เช่น 1.2x2.4 ม.)', type: 'string', required: false },
      { id: 5, property: 'quantity', description: 'จำนวนหรือปริมาณรวม', type: 'number', required: false },
      { id: 6, property: 'estimatedTotal', description: 'ยอดประเมินเบื้องต้น (เช่น 4,500 บาท)', type: 'string', required: false },
      { id: 7, property: 'address', description: 'สถานที่จัดส่งหรือข้อความรายละเอียดเพิ่มเติมจากลูกค้า', type: 'string', required: false }
    ]),
    func: `const payload = {
  channel: $input?.channel || 'studio-test',
  customerName: (typeof $customerName !== 'undefined' ? $customerName : $input?.customerName) || 'ลูกค้าติดต่อสั่งซื้อ',
  phone: String((typeof $phone !== 'undefined' ? $phone : $input?.phone) || '').trim(),
  productName: String((typeof $productName !== 'undefined' ? $productName : $input?.productName) || 'สอบถามสั่งซื้อสินค้า').trim(),
  dimensions: String((typeof $dimensions !== 'undefined' ? $dimensions : $input?.dimensions) || '').trim(),
  quantity: typeof $quantity !== 'undefined' ? $quantity : ($input?.quantity ?? ''),
  estimatedTotal: String((typeof $estimatedTotal !== 'undefined' ? $estimatedTotal : $input?.estimatedTotal) || '').trim(),
  address: String((typeof $address !== 'undefined' ? $address : $input?.address) || '').trim(),
  status: 'pending'
};
if (!payload.phone) return JSON.stringify({ ok: false, error: 'กรุณาระบุเบอร์โทรศัพท์ติดต่อของลูกค้า (phone)' });
if ($input?.dryRun === true) {
  console.log('[send_to_activepieces] Dry-run mode enabled (order not persisted to DB)');
  return JSON.stringify({ ok: true, dryRun: true, previewOrder: payload }, null, 2);
}
const saved = await OmniFlowTools.recordOrderLead(payload);
console.log(\`[send_to_activepieces] Order saved id=\${saved.id}\`);
return JSON.stringify({ ok: true, order: saved }, null, 2);`
  }
];

export class ToolStudioRuntime {
  constructor(options = {}) {
    this.appRoot = options.appRoot || path.resolve(process.cwd());
    this.dataDir = options.dataDir || path.join(this.appRoot, 'data');
    this.customToolsFile = path.join(this.dataDir, 'custom-tools-db.json');
    this._writeQueue = Promise.resolve();
  }

  async _readToolsDb() {
    try {
      if (!existsSync(this.customToolsFile)) return [];
      const parsed = JSON.parse(await fs.readFile(this.customToolsFile, 'utf-8'));
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  async _writeToolsDbAtomic(tools) {
    const task = async () => {
      await fs.mkdir(path.dirname(this.customToolsFile), { recursive: true });
      const tmp = `${this.customToolsFile}.studio.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2, 6)}.tmp`;
      try {
        await fs.writeFile(tmp, JSON.stringify(tools, null, 2), 'utf-8');
        await fs.rename(tmp, this.customToolsFile);
      } catch (err) {
        await fs.unlink(tmp).catch(() => {});
        throw err;
      }
    };
    const next = this._writeQueue.then(task, task);
    this._writeQueue = next.catch(() => {});
    return next;
  }

  async ensureWhiteLabelStandardTools() {
    const existing = await this._readToolsDb();
    const nowIso = new Date().toISOString();
    let mutated = false;
    if (existing.length === 0) {
      const seeded = WHITE_LABEL_STANDARD_TOOLS.map((t) => ({
        ...t, iconSrc: '', source: 'preset-pack', packId: 'white-label-core', createdDate: nowIso, updatedDate: nowIso
      }));
      await this._writeToolsDbAtomic(seeded);
      return { updated: true, count: seeded.length };
    }
    const standardMap = new Map(WHITE_LABEL_STANDARD_TOOLS.map((t) => [t.name, t]));
    const nextList = existing.map((tool) => {
      if (!tool || !standardMap.has(tool.name)) return tool;
      const wl = standardMap.get(tool.name);
      const needsDescClean = !tool.description || LEGACY_STONE_TERMS_REGEX.test(tool.description);
      const needsSchemaClean = !tool.schema || LEGACY_STONE_TERMS_REGEX.test(String(tool.schema));
      const needsFuncSeed = !String(tool.func || '').trim() || /(?:\/root\/\.flowise|CORE v3\.7|activepieces:8080|node_modules\/flowise)/i.test(String(tool.func || ''));
      if (!needsDescClean && !needsSchemaClean && !needsFuncSeed) return tool;
      mutated = true;
      return {
        ...tool,
        description: needsDescClean ? wl.description : tool.description,
        schema: needsSchemaClean ? wl.schema : tool.schema,
        func: needsFuncSeed ? wl.func : tool.func,
        updatedDate: nowIso
      };
    });
    if (mutated) await this._writeToolsDbAtomic(nextList);
    return { updated: mutated, count: nextList.length };
  }

  parseToolSchema(rawSchema) {
    if (Array.isArray(rawSchema)) return rawSchema;
    if (typeof rawSchema === 'string' && rawSchema.trim()) {
      try {
        const parsed = JSON.parse(rawSchema);
        return Array.isArray(parsed) ? parsed : [];
      } catch {
        return [];
      }
    }
    return [];
  }

  async _dispatchRpc(method, params = []) {
    if (method === 'lookupPrice') return lookupPrice(params[0]);
    if (method === 'calculateQuotation') return calculateQuotation(params[0], params[1], params[2], params[3], params[4]);
    if (method === 'recordOrderLead') return recordOrderLead(params[0]);
    if (method === 'getAllCatalogItems') return getAllCatalogItems();
    throw new Error(`Disallowed RPC method: ${method}`);
  }

  _runInIsolatedWorker({ code, toolName, args, dollarKeys, timeoutMs }) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      const logs = [];
      let stderrText = '';
      let settled = false;
      const child = fork(WORKER_PATH, [], {
        env: buildSandboxEnv(),
        execArgv: [
          '--max-old-space-size=128',
          '--permission',
          `--allow-fs-read=${WORKER_PATH}`,
          `--allow-fs-read=${FETCH_SAFE_PATH}`
        ],
        stdio: ['ignore', 'ignore', 'pipe', 'ipc'],
        serialization: 'json'
      });

      const finish = (payload) => {
        if (settled) return;
        settled = true;
        clearTimeout(killTimer);
        if (!child.killed) {
          try { child.kill('SIGKILL'); } catch { /* ignore */ }
        }
        resolve(payload);
      };

      const killTimer = setTimeout(() => {
        finish({
          ok: false, timedOut: true, toolName, durationMs: Date.now() - startedAt, timeoutMs,
          error: `Timeout Guard ทำงาน: หยุดการทำงานอัตโนมัติเนื่องจากใช้เวลาเกิน ${timeoutMs} ms`, logs
        });
      }, timeoutMs);

      child.stderr?.on('data', (chunk) => {
        if (stderrText.length < 1024) stderrText += chunk.toString('utf8');
      });

      child.on('message', async (msg) => {
        try {
          if (!msg || typeof msg !== 'object') return;
          if (msg.type === 'log' && msg.entry && logs.length < MAX_LOGS) {
            logs.push(msg.entry);
            return;
          }
          if (msg.type === 'rpc' && msg.id) {
            try {
              const data = await this._dispatchRpc(msg.method, Array.isArray(msg.params) ? msg.params : []);
              if (child.connected) child.send({ type: 'rpc_res', id: msg.id, ok: true, data });
            } catch (err) {
              if (child.connected) child.send({ type: 'rpc_res', id: msg.id, ok: false, error: err?.message || 'RPC failed' });
            }
            return;
          }
          if (msg.type === 'done') {
            const durationMs = Date.now() - startedAt;
            if (!msg.ok) {
              const isTimeout = Boolean(msg.timedOut);
              return finish({
                ok: false, timedOut: isTimeout, toolName, durationMs, timeoutMs,
                error: isTimeout ? `Timeout Guard ทำงาน: หยุดการทำงานอัตโนมัติเนื่องจากใช้เวลาเกิน ${timeoutMs} ms` : String(msg.error || 'Unknown Sandbox Error'),
                logs
              });
            }
            const envelope = JSON.parse(msg.serializedJson || '{"isString":false,"valueJson":"null"}');
            const rawResult = JSON.parse(envelope?.valueJson ?? 'null');
            let normalizedOutput = rawResult;
            if (envelope?.isString && typeof rawResult === 'string') {
              try { normalizedOutput = JSON.parse(rawResult); } catch { normalizedOutput = rawResult; }
            }
            finish({
              ok: true, toolName, durationMs, timeoutMs, result: normalizedOutput ?? null,
              rawText: typeof rawResult === 'string' ? rawResult : JSON.stringify(rawResult ?? null, null, 2), logs
            });
          }
        } catch (err) {
          finish({
            ok: false, timedOut: false, toolName, durationMs: Date.now() - startedAt, timeoutMs,
            error: `Invalid sandbox IPC payload: ${err?.message || 'JSON parse error'}`, logs
          });
        }
      });

      child.on('error', (err) => finish({
        ok: false, timedOut: false, toolName, durationMs: Date.now() - startedAt, timeoutMs,
        error: err?.message || 'Sandbox worker spawn error', logs
      }));

      child.on('exit', (code, signal) => finish({
        ok: false, timedOut: false, toolName, durationMs: Date.now() - startedAt, timeoutMs,
        error: stderrText.trim() || `Sandbox worker exited unexpectedly (code=${code}, signal=${signal})`, logs
      }));

      child.send({ type: 'run', code, toolName, args, dollarKeys, timeoutMs, gatewayPort: Number(process.env.PORT || 4001) });
    });
  }

  async executeToolSandbox({ toolId = '', toolName = '', code = '', schema = [], args = {}, timeoutMs = DEFAULT_TIMEOUT_MS } = {}) {
    const safeTimeout = Math.min(MAX_TIMEOUT_MS, Math.max(MIN_TIMEOUT_MS, Number(timeoutMs) || DEFAULT_TIMEOUT_MS));
    let effectiveCode = typeof code === 'string' ? code : '';
    let effectiveSchema = schema;
    let resolvedName = String(toolName || '').trim();

    if (!effectiveCode.trim() && (toolId || resolvedName)) {
      const dbTools = await this._readToolsDb();
      let targetTool = dbTools.find((t) => t && ((toolId && t.id === toolId) || (resolvedName && t.name === resolvedName)));
      if (!targetTool) targetTool = WHITE_LABEL_STANDARD_TOOLS.find((t) => t.name === resolvedName || t.id === toolId) || null;
      if (!targetTool) {
        return { ok: false, error: `ไม่พบ Custom Tool "${resolvedName || toolId}" ในระบบ`, logs: [], durationMs: 0 };
      }
      effectiveCode = String(targetTool.func || '');
      effectiveSchema = targetTool.schema || [];
      resolvedName = targetTool.name || resolvedName;
    }

    if (!effectiveCode.trim()) {
      return { ok: false, error: 'โค้ด JavaScript ของ Tool ว่างเปล่า กรุณาเขียนโค้ดก่อนกด Test Run', logs: [], durationMs: 0 };
    }

    const parsedSchema = this.parseToolSchema(effectiveSchema);
    let safeArgs = {};
    if (args && typeof args === 'object' && !Array.isArray(args)) {
      try { safeArgs = JSON.parse(JSON.stringify(args)); } catch { safeArgs = {}; }
    }

    for (const prop of parsedSchema) {
      const key = String(prop?.property || prop?.name || '').trim();
      if (key && prop.required && (safeArgs[key] === undefined || safeArgs[key] === '')) {
        return { ok: false, error: `พารามิเตอร์บังคับ "${key}" ยังไม่ได้ระบุค่า`, logs: [], durationMs: 0 };
      }
    }

    const dollarKeySet = new Set();
    for (const prop of parsedSchema) {
      const key = String(prop?.property || prop?.name || '').trim();
      if (IDENTIFIER_RE.test(key)) dollarKeySet.add(key);
    }
    for (const k of Object.keys(safeArgs)) {
      if (IDENTIFIER_RE.test(k)) dollarKeySet.add(k);
    }

    return this._runInIsolatedWorker({
      code: effectiveCode,
      toolName: resolvedName || 'inline_tool',
      args: safeArgs,
      dollarKeys: [...dollarKeySet],
      timeoutMs: safeTimeout
    });
  }
}

const toolStudioRuntime = new ToolStudioRuntime();
export default toolStudioRuntime;
