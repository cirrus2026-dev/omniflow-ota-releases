// gateway/src/modules/ota-backup-manager.mjs
// Hardened Full-System OTA Update, Backup & Migration Manager (Path Traversal, Zip-Bomb, SSRF, Checksum, Mutex & Vault Sync Guard)

import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { fetchSafe } from './fetch-safe.mjs';
import { loadVaultConfig } from './settings-vault.mjs';
import {
  extractZipEntries,
  assertNoSymlinkPath,
  normalizeJsonPatch,
  parsePatchPackage,
  MAX_ZIP_ENTRIES,
  MAX_ZIP_OUTPUT_BYTES
} from './zip-reader.mjs';

const execFileAsync = promisify(execFile);
const BACKUP_NAME_RE = /^backup-[A-Za-z0-9_-]+$/;
const SHA256_HEX_RE = /^[a-f0-9]{64}$/i;
const FORBIDDEN_MERGE_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
const MAX_BASE64_INPUT_LEN = Math.ceil((MAX_ZIP_OUTPUT_BYTES * 4) / 3) + 64;
const DEFAULT_TARGET_FILES = [
  'gateway-config.json',
  'catalog-db.json',
  'orders-db.json',
  'custom-tools-db.json',
  'active-business-preset.json'
];

const DEFAULT_OTA_MANIFEST_URL = 'https://raw.githubusercontent.com/cirrus2026-dev/omniflow-ota-releases/main/manifest.json';

export class OTABackupManager {
  constructor(options = {}) {
    this.appRoot = options.appRoot || path.resolve(process.cwd());
    this.dataDir = options.dataDir || path.resolve(this.appRoot, 'data');
    this.backupDir = options.backupDir || path.join(this.dataDir, 'backups');
    this.releaseManifestUrl = options.releaseManifestUrl || process.env.OTA_MANIFEST_URL || DEFAULT_OTA_MANIFEST_URL;
    this.allowedCodePrefixes = ['src/', 'public/'];
    this.targetFiles = options.targetFiles || [...DEFAULT_TARGET_FILES];
    this.maxBackups = options.maxBackups || 5;
    this._activeOp = Promise.resolve();
  }

  _runSerialized(taskFn) {
    const next = this._activeOp.then(taskFn, taskFn);
    this._activeOp = next.catch(() => {});
    return next;
  }

  async _syncVaultConfig() {
    const cfgPath = path.join(this.dataDir, 'gateway-config.json');
    if (existsSync(cfgPath)) {
      await loadVaultConfig(cfgPath).catch(() => {});
    }
  }

  async _ensureDirectories() {
    await fs.mkdir(this.dataDir, { recursive: true });
    await fs.mkdir(this.backupDir, { recursive: true });
  }

  async _readJsonSafe(filePath, fallback = null) {
    try {
      if (!existsSync(filePath)) return fallback;
      return JSON.parse(await fs.readFile(filePath, 'utf-8'));
    } catch {
      return fallback;
    }
  }

  async _writeFileAtomic(baseDir, absDest, data, encoding) {
    await assertNoSymlinkPath(baseDir, absDest);
    await fs.mkdir(path.dirname(absDest), { recursive: true });
    const tmpDest = `${absDest}.ota.${process.pid}.${Date.now()}.${crypto.randomBytes(3).toString('hex')}.tmp`;
    try {
      await fs.writeFile(tmpDest, data, encoding);
      await fs.rename(tmpDest, absDest);
    } catch (err) {
      await fs.unlink(tmpDest).catch(() => {});
      throw err;
    }
  }

  async _copyFileAtomic(srcBase, srcAbs, destBase, destAbs) {
    await assertNoSymlinkPath(srcBase, srcAbs);
    const stat = await fs.lstat(srcAbs);
    if (!stat.isFile()) throw new Error(`แหล่งไฟล์ไม่ปลอดภัยหรือไม่ใช่ไฟล์ปกติ: ${path.basename(srcAbs)}`);
    const content = await fs.readFile(srcAbs);
    await this._writeFileAtomic(destBase, destAbs, content);
  }

  async _resolveSafeBackupDir(rawName) {
    const clean = String(rawName || '').trim();
    if (!BACKUP_NAME_RE.test(clean)) {
      throw new Error(`ชื่อ Backup ไม่ถูกต้องหรือเสี่ยง Path Traversal: ${rawName}`);
    }
    const resolvedRoot = path.resolve(this.backupDir);
    const absPath = path.resolve(resolvedRoot, clean);
    if (!absPath.startsWith(resolvedRoot + path.sep)) {
      throw new Error(`ตรวจพบการออกนอกโฟลเดอร์ Backup: ${rawName}`);
    }
    await assertNoSymlinkPath(resolvedRoot, absPath);
    return { name: clean, absPath };
  }

  _verifySha256(buffer, expectedHex, mandatory = true) {
    const expected = String(expectedHex || '').trim().toLowerCase();
    if (!expected) {
      if (mandatory) throw new Error('ต้องระบุ SHA-256 Checksum สำหรับการอัปเดต Patch เพื่อความปลอดภัย');
      return;
    }
    if (!SHA256_HEX_RE.test(expected)) {
      throw new Error('รูปแบบ SHA-256 Checksum ไม่ถูกต้อง (ต้องเป็น Hex 64 ตัวอักษร)');
    }
    const actual = crypto.createHash('sha256').update(buffer).digest('hex');
    if (!crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'))) {
      throw new Error('ตรวจสอบ SHA-256 Checksum ไม่ตรงกัน ยกเลิกการติดตั้งเพื่อความปลอดภัย');
    }
  }

  async createBackup(targetCodeRelPaths = []) {
    await this._ensureDirectories();
    const backupFolderName = `backup-${new Date().toISOString().replace(/[:.]/g, '-')}`;
    const { absPath: currentBackupPath } = await this._resolveSafeBackupDir(backupFolderName);
    await fs.mkdir(currentBackupPath, { recursive: true });

    let copiedCount = 0;
    for (const file of this.targetFiles) {
      const srcPath = path.join(this.dataDir, file);
      if (existsSync(srcPath)) {
        await this._copyFileAtomic(this.dataDir, srcPath, currentBackupPath, path.join(currentBackupPath, file));
        await this._copyFileAtomic(this.dataDir, srcPath, currentBackupPath, path.join(currentBackupPath, `${file}.bak`));
        copiedCount++;
      } else {
        console.warn(`[OTA-Backup] Warning: ${file} not found, skipping backup for this file.`);
      }
    }

    const backedUpCodeFiles = [];
    const createdFiles = [];
    if (Array.isArray(targetCodeRelPaths) && targetCodeRelPaths.length > 0) {
      const snapshotRoot = path.join(currentBackupPath, 'code_snapshot');
      for (const relPath of targetCodeRelPaths) {
        const safeRel = this._normalizePatchTargetPath(relPath);
        const absSrc = path.resolve(this.appRoot, safeRel);
        if (existsSync(absSrc)) {
          await this._copyFileAtomic(this.appRoot, absSrc, currentBackupPath, path.join(snapshotRoot, safeRel));
          backedUpCodeFiles.push(safeRel);
        } else {
          createdFiles.push(safeRel);
        }
      }
    }

    const meta = {
      backupName: backupFolderName,
      createdAt: new Date().toISOString(),
      version: await this.getCurrentVersion(),
      dataFiles: this.targetFiles,
      backedUpCodeFiles,
      createdFiles
    };
    await this._writeFileAtomic(currentBackupPath, path.join(currentBackupPath, 'backup-meta.json'), JSON.stringify(meta, null, 2), 'utf-8');
    console.log(`[OTA-Backup] Created backup '${backupFolderName}' (${copiedCount} data files, ${backedUpCodeFiles.length} code files).`);
    await this._enforceRetention();
    return backupFolderName;
  }

  async _enforceRetention() {
    const backupFolders = await this.listBackups();
    if (backupFolders.length <= this.maxBackups) return;
    for (const folder of backupFolders.slice(this.maxBackups)) {
      const { absPath } = await this._resolveSafeBackupDir(folder);
      await fs.rm(absPath, { recursive: true, force: true });
      console.log(`[OTA-Retention] Deleted old backup: ${folder}`);
    }
  }

  async migrateSchema(fileName, newDefaultSchema) {
    if (typeof fileName !== 'string' || path.basename(fileName) !== fileName || !this.targetFiles.includes(fileName)) {
      throw new Error(`ไม่อนุญาตให้ทำ Schema Migration กับไฟล์: ${fileName}`);
    }
    const filePath = path.join(this.dataDir, fileName);
    if (!existsSync(filePath)) {
      await this._writeFileAtomic(this.dataDir, filePath, JSON.stringify(newDefaultSchema, null, 2), 'utf-8');
      if (fileName === 'gateway-config.json') await this._syncVaultConfig();
      return;
    }
    try {
      await assertNoSymlinkPath(this.dataDir, filePath);
      const currentData = JSON.parse(await fs.readFile(filePath, 'utf-8'));
      const migratedData = this._deepMerge(newDefaultSchema, currentData);
      await this._writeFileAtomic(this.dataDir, filePath, JSON.stringify(migratedData, null, 2), 'utf-8');
      if (fileName === 'gateway-config.json') await this._syncVaultConfig();
    } catch (error) {
      throw new Error(`Schema migration failed for ${fileName}: ${error.message}`);
    }
  }

  _deepMerge(defaultSchema, userData) {
    if (Array.isArray(defaultSchema) || Array.isArray(userData) || typeof defaultSchema !== 'object' || typeof userData !== 'object' || !defaultSchema || !userData) {
      return userData !== undefined ? userData : defaultSchema;
    }
    const result = { ...defaultSchema };
    for (const key of Object.keys(userData)) {
      if (FORBIDDEN_MERGE_KEYS.has(key)) continue;
      result[key] = Object.prototype.hasOwnProperty.call(defaultSchema, key)
        ? this._deepMerge(defaultSchema[key], userData[key])
        : userData[key];
    }
    return result;
  }

  async _rollbackUnlocked(targetBackupName = null) {
    await this._ensureDirectories();
    let backupToRestore = targetBackupName;
    if (backupToRestore === null || backupToRestore === undefined || backupToRestore === '') {
      const backups = await this.listBackups();
      if (backups.length === 0) throw new Error('No backups available to rollback.');
      backupToRestore = backups[0];
    }
    const { name: safeName, absPath: backupSourcePath } = await this._resolveSafeBackupDir(backupToRestore);
    if (!existsSync(backupSourcePath) || !(await fs.lstat(backupSourcePath)).isDirectory()) {
      throw new Error(`Backup version '${safeName}' not found.`);
    }

    for (const file of this.targetFiles) {
      const primary = path.join(backupSourcePath, file);
      const fallback = path.join(backupSourcePath, `${file}.bak`);
      const sourceFile = existsSync(primary) ? primary : fallback;
      if (existsSync(sourceFile)) {
        await this._copyFileAtomic(backupSourcePath, sourceFile, this.dataDir, path.join(this.dataDir, file));
      }
    }

    const meta = await this._readJsonSafe(path.join(backupSourcePath, 'backup-meta.json'));
    if (meta && typeof meta === 'object') {
      const snapshotRoot = path.join(backupSourcePath, 'code_snapshot');
      for (const relPath of meta.backedUpCodeFiles || []) {
        const safeRel = this._normalizePatchTargetPath(relPath);
        const snapFile = path.join(snapshotRoot, safeRel);
        if (existsSync(snapFile)) {
          await this._copyFileAtomic(snapshotRoot, snapFile, this.appRoot, path.resolve(this.appRoot, safeRel));
        }
      }
      for (const relPath of meta.createdFiles || []) {
        const safeRel = this._normalizePatchTargetPath(relPath);
        const targetCodePath = path.resolve(this.appRoot, safeRel);
        await assertNoSymlinkPath(this.appRoot, targetCodePath);
        if (existsSync(targetCodePath)) await fs.unlink(targetCodePath).catch(() => {});
      }
    }
    await this._syncVaultConfig();
    console.log(`[OTA-Rollback] Rollback completed successfully (${safeName}).`);
    return safeName;
  }

  async rollback(targetBackupName = null) {
    return this._runSerialized(() => this._rollbackUnlocked(targetBackupName));
  }

  async listBackups() {
    if (!existsSync(this.backupDir)) return [];
    const entries = await fs.readdir(this.backupDir, { withFileTypes: true });
    return entries
      .filter((d) => d.isDirectory() && !d.isSymbolicLink() && BACKUP_NAME_RE.test(d.name))
      .map((d) => d.name)
      .sort((a, b) => b.localeCompare(a));
  }

  async getCurrentVersion() {
    const cfg = await this._readJsonSafe(path.join(this.dataDir, 'gateway-config.json'));
    return cfg?.version ? String(cfg.version).trim() : '1.0.0';
  }

  async getConfiguredManifestUrl() {
    const cfg = await this._readJsonSafe(path.join(this.dataDir, 'gateway-config.json'));
    return cfg?.ota?.manifestUrl ? String(cfg.ota.manifestUrl).trim() : this.releaseManifestUrl;
  }

  _compareSemver(vA = '0.0.0', vB = '0.0.0') {
    const a = String(vA).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
    const b = String(vB).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(a.length, b.length, 3); i++) {
      const diff = (a[i] || 0) - (b[i] || 0);
      if (diff !== 0) return diff > 0 ? 1 : -1;
    }
    return 0;
  }

  async checkForUpdates(manifestUrlOverride = '') {
    const currentVersion = await this.getCurrentVersion();
    const manifestUrl = String(manifestUrlOverride || (await this.getConfiguredManifestUrl()) || '').trim();
    if (!manifestUrl) {
      return {
        ok: true, currentVersion, latestVersion: currentVersion, updateAvailable: false,
        channel: 'stable', source: 'local', manifestUrl: '', changelog: [],
        note: 'ยังไม่ได้กำหนด Remote Manifest URL (สามารถกรอก URL หรือใช้โหมดอัปโหลดแพตช์ออฟไลน์ได้ทันที)'
      };
    }
    const res = await fetchSafe(manifestUrl, {
      headers: { Accept: 'application/json' },
      timeoutMs: 8000,
      maxBytes: 5 * 1024 * 1024
    });
    if (!res.ok) throw new Error(`ไม่สามารถเชื่อมต่อ Remote Release Manifest ได้ (HTTP ${res.status})`);
    const rawBuf = await res.buffer();
    const manifest = JSON.parse(rawBuf.toString('utf-8'));
    const latestVersion = String(manifest.version || currentVersion).trim();
    const result = {
      ok: true, currentVersion, latestVersion,
      updateAvailable: this._compareSemver(latestVersion, currentVersion) > 0,
      channel: manifest.channel || 'stable', releaseDate: manifest.releaseDate || '',
      changelog: Array.isArray(manifest.changelog) ? manifest.changelog : [],
      patchUrl: manifest.patchUrl || '', sha256: manifest.sha256 || '',
      manifestUrl, source: 'remote', hasInlineFiles: Boolean(manifest.files)
    };
    Object.defineProperties(result, {
      _manifest: { value: manifest, enumerable: false },
      _rawManifestBuffer: { value: rawBuf, enumerable: false }
    });
    return result;
  }

  _normalizePatchTargetPath(rawRelPath) {
    let clean = String(rawRelPath || '').replace(/\\/g, '/').replace(/^\.\/+/, '').replace(/^\/+/, '').trim();
    if (clean.startsWith('gateway/')) clean = clean.slice('gateway/'.length);
    if (!clean || clean.includes('\0') || clean.split('/').includes('..') || /^[a-zA-Z]:/.test(clean)) {
      throw new Error(`ไม่อนุญาตให้เขียนไฟล์พาธไม่ปลอดภัย: ${rawRelPath}`);
    }
    if (!this.allowedCodePrefixes.some((prefix) => clean.startsWith(prefix))) {
      throw new Error(`ไฟล์ "${rawRelPath}" อยู่นอกขอบเขตที่อนุญาต (อนุญาตเฉพาะ src/ และ public/)`);
    }
    const resolved = path.resolve(this.appRoot, clean);
    if (!resolved.startsWith(path.resolve(this.appRoot) + path.sep)) {
      throw new Error(`ตรวจพบการออกนอกโฟลเดอร์ระบบ: ${rawRelPath}`);
    }
    return clean;
  }

  _extractZipEntries(zipBuffer) {
    return extractZipEntries(zipBuffer, { maxEntries: MAX_ZIP_ENTRIES, maxOutputLength: MAX_ZIP_OUTPUT_BYTES });
  }

  _normalizeJsonPatch(obj) {
    return normalizeJsonPatch(obj, (p) => this._normalizePatchTargetPath(p));
  }

  _parsePatchPackage(input = {}) {
    return parsePatchPackage(input, (p) => this._normalizePatchTargetPath(p));
  }

  async verifySystemHealth(updatedCodeAbsPaths = []) {
    const errors = [];
    const checks = [];
    for (const file of this.targetFiles) {
      const fp = path.join(this.dataDir, file);
      if (!existsSync(fp)) continue;
      try {
        JSON.parse(await fs.readFile(fp, 'utf-8'));
        checks.push({ target: `data/${file}`, ok: true });
      } catch (err) {
        errors.push(`JSON เสียหายใน data/${file}: ${err.message}`);
        checks.push({ target: `data/${file}`, ok: false, error: err.message });
      }
    }
    const jsTargets = [...updatedCodeAbsPaths.filter((p) => /\.(?:mjs|js|cjs)$/i.test(p))];
    const coreServerPath = path.resolve(this.appRoot, 'src', 'server.mjs');
    if (existsSync(coreServerPath) && !jsTargets.includes(coreServerPath)) jsTargets.push(coreServerPath);
    for (const absPath of jsTargets) {
      try {
        await execFileAsync(process.execPath, ['--check', absPath], { timeout: 5000 });
        checks.push({ target: path.relative(this.appRoot, absPath), ok: true });
      } catch (err) {
        const msg = (err.stderr || err.message || 'Syntax error').trim().slice(0, 240);
        errors.push(`Syntax check ไม่ผ่าน (${path.basename(absPath)}): ${msg}`);
        checks.push({ target: path.relative(this.appRoot, absPath), ok: false, error: msg });
      }
    }
    return { ok: errors.length === 0, checks, errors };
  }

  async _applyOtaUpdateUnlocked(options = {}) {
    const mode = options.mode === 'remote' ? 'remote' : 'offline';
    const previousVersion = await this.getCurrentVersion();
    let patchPackage;

    if (mode === 'remote') {
      const checkInfo = await this.checkForUpdates(options.manifestUrl || '');
      const targetPatchUrl = String(options.patchUrl || checkInfo.patchUrl || '').trim();
      if (!targetPatchUrl && checkInfo.manifestUrl) {
        const rawBuf = Buffer.isBuffer(checkInfo._rawManifestBuffer) ? checkInfo._rawManifestBuffer : null;
        const manifestObj = checkInfo._manifest;
        if (!rawBuf || !manifestObj || typeof manifestObj !== 'object') {
          throw new Error('ไม่พบข้อมูล Remote Manifest ที่โหลดไว้ล่วงหน้า');
        }
        const expectedSha = String(options.sha256 || checkInfo.sha256 || '').trim();
        this._verifySha256(rawBuf, expectedSha, true);
        patchPackage = this._normalizeJsonPatch(manifestObj);
      } else if (targetPatchUrl) {
        const expectedSha = String(options.sha256 || checkInfo.sha256 || '').trim();
        if (!SHA256_HEX_RE.test(expectedSha)) {
          throw new Error('ต้องระบุ SHA-256 Checksum ที่ถูกต้อง (64 Hex) สำหรับ Remote Patch เพื่อความปลอดภัย');
        }
        const pRes = await fetchSafe(targetPatchUrl, { timeoutMs: 20000, maxBytes: MAX_ZIP_OUTPUT_BYTES });
        if (!pRes.ok) throw new Error(`ดาวน์โหลดไฟล์อัปเดตไม่สำเร็จ (HTTP ${pRes.status})`);
        const buf = await pRes.buffer();
        this._verifySha256(buf, expectedSha, true);
        patchPackage = this._parsePatchPackage({ filename: path.basename(new URL(targetPatchUrl).pathname), buffer: buf });
      } else {
        throw new Error('ไม่พบลิงก์ Patch URL จาก Remote Release');
      }
    } else {
      if (options.patchJson && typeof options.patchJson === 'object') {
        const patchBuf = Buffer.from(JSON.stringify(options.patchJson), 'utf-8');
        this._verifySha256(patchBuf, options.sha256 || '', true);
      } else if (options.sha256 && options.contentBase64) {
        const rawB64 = String(options.contentBase64).includes(',') ? String(options.contentBase64).split(',')[1] : String(options.contentBase64);
        if (rawB64.length > MAX_BASE64_INPUT_LEN) {
          throw new Error(`ขนาดไฟล์แพตช์เกินเพดานสูงสุด (${MAX_ZIP_OUTPUT_BYTES} bytes)`);
        }
        this._verifySha256(Buffer.from(rawB64, 'base64'), options.sha256, true);
      }
      patchPackage = this._parsePatchPackage({
        filename: options.filename || '',
        contentBase64: options.contentBase64 || '',
        patchJson: options.patchJson || null
      });
    }

    if (patchPackage.files.length === 0 && Object.keys(patchPackage.schemaMigrations || {}).length === 0) {
      throw new Error('ไฟล์แพตช์ไม่มีรายการไฟล์โค้ด (src/, public/) หรือ Schema Migration ให้ติดตั้ง');
    }

    const targetRelPaths = patchPackage.files.map((f) => f.relPath);
    const backupName = await this.createBackup(targetRelPaths);
    const writtenAbsPaths = [];
    const migratedSchemas = [];

    try {
      for (const fileItem of patchPackage.files) {
        const absDest = path.resolve(this.appRoot, fileItem.relPath);
        await this._writeFileAtomic(this.appRoot, absDest, fileItem.buffer);
        writtenAbsPaths.push(absDest);
      }
      for (const [targetJsonName, defaultSchema] of Object.entries(patchPackage.schemaMigrations || {})) {
        if (!this.targetFiles.includes(targetJsonName)) continue;
        await this.migrateSchema(targetJsonName, defaultSchema);
        migratedSchemas.push(targetJsonName);
      }
      const newVersion = patchPackage.version || previousVersion;
      const cfgPath = path.join(this.dataDir, 'gateway-config.json');
      const existingCfg = (await this._readJsonSafe(cfgPath, {})) || {};
      const nextCfg = {
        ...existingCfg,
        version: newVersion,
        ota: {
          ...(existingCfg.ota || {}),
          manifestUrl: options.manifestUrl || existingCfg.ota?.manifestUrl || this.releaseManifestUrl,
          lastUpdatedAt: new Date().toISOString(),
          lastBackupName: backupName,
          previousVersion
        }
      };
      await this._writeFileAtomic(this.dataDir, cfgPath, JSON.stringify(nextCfg, null, 2), 'utf-8');
      await this._syncVaultConfig();

      const healthcheck = await this.verifySystemHealth(writtenAbsPaths);
      if (!healthcheck.ok) throw new Error(`Safety Healthcheck ไม่ผ่าน: ${healthcheck.errors.join(' | ')}`);

      const requiresRestart = targetRelPaths.some((p) => p.startsWith('src/'));
      return {
        ok: true, mode, backupName, previousVersion, newVersion, updatedFiles: targetRelPaths,
        migratedSchemas, healthcheck, requiresRestart,
        message: requiresRestart
          ? `อัปเดตระบบเป็น v${newVersion} สำเร็จ (ผ่าน Safety Healthcheck 100%) — มีการอัปเดตฝั่ง Backend แนะนำให้รีสตาร์ทเซอร์วิสเพื่อให้โค้ดใหม่ทำงานสมบูรณ์`
          : `อัปเดตหน้าแดชบอร์ดเป็น v${newVersion} สำเร็จ (ผ่าน Safety Healthcheck 100%) — รีเฟรชหน้าเว็บเพื่อใช้งานได้ทันที`
      };
    } catch (err) {
      console.error(`[OTA-Update] Failure detected, triggering Auto-Rollback (${backupName}):`, err.message);
      let rollbackOk = false;
      try { await this._rollbackUnlocked(backupName); rollbackOk = true; } catch (rbErr) { console.error('[OTA-Update] Critical Auto-Rollback error:', rbErr.message); }
      const wrapped = new Error(`${err.message} — ${rollbackOk ? `ระบบทำ Auto-Rollback กลับไปจุดสำรอง "${backupName}" อัตโนมัติแล้ว` : 'Auto-Rollback ล้มเหลว กรุณากู้คืนด้วยตนเอง'}`);
      wrapped.rolledBack = rollbackOk;
      wrapped.backupName = backupName;
      throw wrapped;
    }
  }

  async applyOtaUpdate(options = {}) {
    return this._runSerialized(() => this._applyOtaUpdateUnlocked(options));
  }
}

export default new OTABackupManager();
