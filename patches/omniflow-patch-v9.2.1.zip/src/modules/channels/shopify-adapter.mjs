// gateway/src/modules/channels/shopify-adapter.mjs
// Wave 1 Adapter: Shopify Storefront / Customer Inquiry Webhook (Strict HMAC-SHA256 + SSRF-Guarded Reply)

import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

const MYSHOPIFY_DOMAIN_RE = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.myshopify\.com$/;

function validateSafeHttpsUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return '';
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

function normalizeValidShopDomain(rawDomain = '') {
  const cleaned = String(rawDomain || '')
    .trim()
    .replace(/^https?:\/\//i, '')
    .replace(/\/.*$/, '')
    .toLowerCase();
  if (!cleaned || !MYSHOPIFY_DOMAIN_RE.test(cleaned)) return '';
  return cleaned;
}

const shopifyAdapter = {
  meta: {
    id: 'shopify',
    wave: 'wave1',
    category: 'ecommerce',
    label: 'Shopify Storefront & Inbox',
    shortLabel: 'SHOPIFY',
    badgeColor: '#95BF47',
    badgeBg: 'rgba(149, 191, 71, 0.14)',
    webhookPath: '/webhook/shopify',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'shopDomain', label: 'Shop Domain', type: 'text', secret: false, required: true, placeholder: 'your-store.myshopify.com', envKey: 'SHOPIFY_SHOP_DOMAIN' },
      { key: 'apiVersion', label: 'Admin API Version', type: 'text', secret: false, placeholder: '2024-10', envKey: 'SHOPIFY_API_VERSION' },
      { key: 'webhookSecret', label: 'Webhook Signing Secret', type: 'password', secret: true, required: true, placeholder: 'Shopify Webhook Secret', envKey: 'SHOPIFY_WEBHOOK_SECRET' },
      { key: 'adminAccessToken', label: 'Admin Access Token (shpat_...)', type: 'password', secret: true, placeholder: 'shpat_...', envKey: 'SHOPIFY_ADMIN_ACCESS_TOKEN' },
      { key: 'outboundWebhookUrl', label: 'Outbound Reply Bridge URL (ทางเลือก)', type: 'url', secret: false, placeholder: 'https://... (Shopify Inbox / Flow Bridge)', envKey: 'SHOPIFY_OUTBOUND_WEBHOOK_URL' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const secret = String(channelCfg.webhookSecret || process.env.SHOPIFY_WEBHOOK_SECRET || '').trim();
    return verifyHmacTimingSafe({
      rawBody: rawBuf || rawBody,
      secret,
      signature: h['x-shopify-hmac-sha256'] || '',
      encoding: 'base64',
      allowMockBypass: false
    });
  },

  normalizeInbound(payload = {}, { headers = {} } = {}) {
    if (!payload || typeof payload !== 'object') return [];
    if (payload.author_type === 'staff' || payload.sender_type === 'bot' || payload.is_echo) return [];

    const h = normalizeHeaders(headers);
    const customer = payload.customer || {};
    const extId = String(
      payload.conversation_id || customer.id || payload.customer_id || payload.email || payload.contact_email || ''
    ).trim();
    if (!extId) return [];

    const fullName = [customer.first_name, customer.last_name].filter(Boolean).join(' ').trim();
    const senderName = String(payload.sender_name || fullName || payload.email || `Shopify (${extId.slice(-6)})`).trim();

    const noteAttrs = Array.isArray(payload.note_attributes)
      ? payload.note_attributes.map((a) => `${a.name}: ${a.value}`).join(', ')
      : '';
    const lineSummary = Array.isArray(payload.line_items)
      ? payload.line_items.map((li) => `${li.title || li.name} x${li.quantity || 1}`).join(', ')
      : '';

    const rawText = String(payload.text || payload.message || payload.body || payload.note || '').trim();
    const textParts = [rawText, noteAttrs ? `[รายละเอียด] ${noteAttrs}` : '', lineSummary ? `[สินค้า] ${lineSummary}` : ''].filter(Boolean);
    const text = textParts.join('\n').trim();

    const attachments = [];
    const seenImg = new Set();
    const pushImg = (u) => {
      const s = String(u || '').trim();
      if (s && /^https?:\/\//i.test(s) && !seenImg.has(s)) {
        seenImg.add(s);
        attachments.push({ type: 'image', url: s });
      }
    };
    pushImg(payload.image?.src);
    for (const att of Array.isArray(payload.attachments) ? payload.attachments : []) pushImg(att?.url || att?.src);
    for (const li of Array.isArray(payload.line_items) ? payload.line_items : []) pushImg(li?.image?.src);

    if (!text && attachments.length === 0) return [];

    const messageId = String(h['x-shopify-webhook-id'] || payload.message_id || payload.id || `shopify_${Date.now()}`);
    return [
      buildNormalizedInbound({
        channel: 'shopify',
        externalUserId: extId,
        senderName,
        text,
        messageId,
        attachments,
        timestamp: Date.parse(payload.updated_at || payload.created_at || '') || Date.now(),
        meta: {
          shopDomain: normalizeValidShopDomain(h['x-shopify-shop-domain'] || ''),
          topic: h['x-shopify-topic'] || '',
          orderId: payload.order_id || (payload.order_number ? payload.id : ''),
          customerId: customer.id || payload.customer_id || '',
          customerEmail: customer.email || payload.email || ''
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const mediaUrls = resolvePublicMediaUrls(images);
    const fullText = mediaUrls.length > 0 ? `${String(text || '').trim()}\n\n${mediaUrls.join('\n')}` : String(text || '').trim();
    if (!fullText) throw new Error('Shopify reply text cannot be empty');

    const rawBridgeUrl = String(channelCfg.outboundWebhookUrl || process.env.SHOPIFY_OUTBOUND_WEBHOOK_URL || '').trim();
    if (rawBridgeUrl) {
      const safeBridgeUrl = validateSafeHttpsUrl(rawBridgeUrl);
      if (!safeBridgeUrl) {
        throw new Error('Blocked unsafe Shopify Outbound Bridge URL (must be public HTTPS)');
      }
      const headers = { 'Content-Type': 'application/json' };
      if (channelCfg.webhookSecret) headers['X-Webhook-Secret'] = String(channelCfg.webhookSecret);
      const res = await fetchWithTimeout(safeBridgeUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({ to, text: fullText, images: mediaUrls, meta, sentAt: new Date().toISOString() })
      });
      if (!res.ok) throw new Error(`Shopify Bridge HTTP ${res.status}`);
      return { ok: true, platform: 'shopify', messageId: `shp_bridge_${Date.now()}`, mode: 'outbound_bridge' };
    }

    const configuredDomain = normalizeValidShopDomain(channelCfg.shopDomain || process.env.SHOPIFY_SHOP_DOMAIN || '');
    const shopDomain = configuredDomain || normalizeValidShopDomain(meta.shopDomain || '');
    const token = String(channelCfg.adminAccessToken || process.env.SHOPIFY_ADMIN_ACCESS_TOKEN || '').trim();
    const apiVersion = String(channelCfg.apiVersion || process.env.SHOPIFY_API_VERSION || '2024-10').trim();
    if (!shopDomain || !token) {
      throw new Error('Missing valid Shopify Shop Domain (*.myshopify.com) / Admin Access Token or Outbound Bridge URL');
    }

    if (meta.orderId) {
      const targetUrl = validateSafeHttpsUrl(
        `https://${shopDomain}/admin/api/${encodeURIComponent(apiVersion)}/orders/${encodeURIComponent(meta.orderId)}.json`
      );
      if (!targetUrl) throw new Error('Blocked invalid Shopify Admin API URL');
      const res = await fetchWithTimeout(targetUrl, {
        method: 'PUT',
        headers: { 'X-Shopify-Access-Token': token, 'Content-Type': 'application/json' },
        body: JSON.stringify({ order: { id: Number(meta.orderId) || meta.orderId, note: fullText.slice(0, 4000) } })
      });
      if (!res.ok) throw new Error(`Shopify Admin API HTTP ${res.status}`);
      return { ok: true, platform: 'shopify', messageId: `shp_order_${meta.orderId}_${Date.now()}`, mode: 'admin_order_note' };
    }

    throw new Error('Configure Outbound Reply Bridge URL for live Shopify Inbox messaging');
  }
};

export default shopifyAdapter;
