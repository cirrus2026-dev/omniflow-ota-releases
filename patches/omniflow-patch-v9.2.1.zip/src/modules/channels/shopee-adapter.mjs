// gateway/src/modules/channels/shopee-adapter.mjs
// Phase 9.3: Shopee Open Platform Webhook Verification (Strict Fail-Closed) & Inbound Message Normalizer

import crypto from 'node:crypto';

export function verifyShopeeSignature({ signature, webhookUrl, rawBody, partnerKey }) {
  const key = String(partnerKey || '').trim();
  if (!key) {
    return { valid: false, reason: 'Missing Shopee partnerKey configuration' };
  }
  if (!signature || !rawBody) {
    return { valid: false, reason: 'Missing Shopee Authorization header or raw body' };
  }

  const baseString = `${webhookUrl}|${rawBody}`;
  const expected = crypto
    .createHmac('sha256', key)
    .update(baseString, 'utf8')
    .digest('hex');

  const sigBuf = Buffer.from(String(signature).trim(), 'utf8');
  const expBuf = Buffer.from(expected, 'utf8');
  if (sigBuf.length !== expBuf.length) {
    return { valid: false, reason: 'Shopee signature length mismatch' };
  }

  const match = crypto.timingSafeEqual(sigBuf, expBuf);
  return { valid: match, reason: match ? null : 'Invalid Shopee HMAC-SHA256 signature' };
}

export function handleShopeeChallenge(req) {
  const challenge =
    req.query?.challenge ||
    req.body?.challenge ||
    req.query?.['hub.challenge'] ||
    null;
  if (challenge) {
    return { isChallenge: true, response: String(challenge) };
  }
  return { isChallenge: false };
}

export function normalizeShopeeInbound(payload = {}) {
  const data = payload.data || payload.message || payload;
  const shopId = String(payload.shop_id || data.shop_id || '');

  const rawSenderId =
    data.from_id ||
    data.sender_id ||
    data.buyer_id ||
    data.user_id ||
    payload.senderId ||
    'shopee_guest';

  const senderId = String(rawSenderId).startsWith('shopee:')
    ? String(rawSenderId)
    : `shopee:${rawSenderId}`;

  const senderName =
    data.from_user_name ||
    data.sender_name ||
    data.buyer_username ||
    payload.senderName ||
    `Shopee Buyer (${String(rawSenderId).slice(-6)})`;

  const content = data.content || {};
  let text = '';
  const attachments = [];

  if (typeof data.text === 'string') {
    text = data.text.trim();
  } else if (typeof content.text === 'string') {
    text = content.text.trim();
  } else if (typeof payload.text === 'string') {
    text = payload.text.trim();
  }

  const imageUrl =
    content.url ||
    content.image_url ||
    data.image_url ||
    (Array.isArray(data.attachments) ? data.attachments[0]?.url : null);

  if (imageUrl) {
    attachments.push({
      type: 'image',
      url: String(imageUrl)
    });
  }

  if (Array.isArray(payload.attachments)) {
    for (const att of payload.attachments) {
      if (att?.url && !attachments.some((a) => a.url === att.url)) {
        attachments.push({
          type: att.type || 'image',
          url: String(att.url)
        });
      }
    }
  }

  if (!text && !attachments.length && (data.ordersn || payload.ordersn)) {
    const orderSn = data.ordersn || payload.ordersn;
    const status = data.status || payload.status || 'UPDATED';
    text = `[Shopee Order #${orderSn}] สถานะคำสั่งซื้อ: ${status}`;
  }

  const conversationId = data.conversation_id || payload.conversation_id || '';
  const timestamp = Number(payload.timestamp || data.created_timestamp || Date.now());

  if (!text && attachments.length === 0) {
    return null;
  }

  return {
    channel: 'shopee',
    senderId,
    senderName,
    text,
    attachments,
    replyToken: conversationId || `shopee_conv_${rawSenderId}`,
    timestamp: timestamp < 1e12 ? timestamp * 1000 : timestamp,
    meta: {
      shopId,
      conversationId,
      messageId: data.message_id || payload.msg_id || `shp_${Date.now()}`
    }
  };
}
