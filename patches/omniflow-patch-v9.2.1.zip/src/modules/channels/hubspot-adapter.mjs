// gateway/src/modules/channels/hubspot-adapter.mjs
// Wave 1 Adapter: HubSpot Conversations Inbox (Strict Signature v3/v1 + OAuth Refresh Cache + Thread Reply)

import crypto from 'node:crypto';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  verifyHmacTimingSafe,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const HS_API_BASE = 'https://api.hubapi.com';

async function resolveHubSpotToken(channelCfg = {}) {
  const staticTok = String(channelCfg.accessToken || process.env.HUBSPOT_ACCESS_TOKEN || '').trim();
  const refreshTok = String(channelCfg.refreshToken || process.env.HUBSPOT_REFRESH_TOKEN || '').trim();
  const clientId = String(channelCfg.clientId || process.env.HUBSPOT_CLIENT_ID || '').trim();
  const clientSecret = String(channelCfg.clientSecret || process.env.HUBSPOT_CLIENT_SECRET || '').trim();

  if (staticTok && !refreshTok) return staticTok;
  if (refreshTok && clientId && clientSecret) {
    const portalKey = String(channelCfg.portalId || clientId);
    return getCachedToken(`hubspot:${portalKey}`, async () => {
      const res = await fetchWithTimeout(`${HS_API_BASE}/oauth/v1/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          client_id: clientId,
          client_secret: clientSecret,
          refresh_token: refreshTok
        })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.access_token) throw new Error(`HubSpot OAuth HTTP ${res.status}`);
      return { token: json.access_token, expiresInSec: Number(json.expires_in || 1800) };
    });
  }
  return staticTok;
}

const hubspotAdapter = {
  meta: {
    id: 'hubspot',
    wave: 'wave1',
    category: 'crm',
    label: 'HubSpot Conversations',
    shortLabel: 'HUBSPOT',
    badgeColor: '#FF7A59',
    badgeBg: 'rgba(255, 122, 89, 0.14)',
    webhookPath: '/webhook/hubspot',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'portalId', label: 'Portal ID', type: 'text', secret: false, placeholder: 'เช่น 12345678', envKey: 'HUBSPOT_PORTAL_ID' },
      { key: 'inboxId', label: 'Conversations Inbox ID', type: 'text', secret: false, placeholder: 'Inbox ID', envKey: 'HUBSPOT_INBOX_ID' },
      { key: 'clientId', label: 'OAuth Client ID (ถ้าใช้ OAuth)', type: 'text', secret: false, placeholder: 'Optional สำหรับ OAuth', envKey: 'HUBSPOT_CLIENT_ID' },
      { key: 'clientSecret', label: 'App Client Secret', type: 'password', secret: true, required: true, placeholder: 'สำหรับตรวจ X-HubSpot-Signature-v3', envKey: 'HUBSPOT_CLIENT_SECRET' },
      { key: 'accessToken', label: 'Private App Token (pat-...)', type: 'password', secret: true, placeholder: 'pat-na1-...', envKey: 'HUBSPOT_ACCESS_TOKEN' },
      { key: 'refreshToken', label: 'OAuth Refresh Token (ทางเลือก)', type: 'password', secret: true, placeholder: 'Optional สำหรับ Refresh OAuth', envKey: 'HUBSPOT_REFRESH_TOKEN' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBody = '', channelCfg = {}, reqUrl = '/webhook/hubspot' }) {
    const h = normalizeHeaders(headers);
    const secret = String(channelCfg.clientSecret || process.env.HUBSPOT_CLIENT_SECRET || '').trim();
    if (!secret) return { valid: false, reason: 'Missing HubSpot clientSecret configuration' };

    const sigV3 = h['x-hubspot-signature-v3'] || '';
    const tsRaw = h['x-hubspot-request-timestamp'] || '';
    if (sigV3 && tsRaw) {
      const tsNum = Number(tsRaw);
      if (!Number.isFinite(tsNum) || Math.abs(Date.now() - tsNum) > 300000) {
        return { valid: false, reason: 'HubSpot signature timestamp expired (>300s)' };
      }
      const host = h['x-forwarded-host'] || h.host || 'localhost';
      const proto = h['x-forwarded-proto'] || 'https';
      const uriCandidates = [`${proto}://${host}${reqUrl}`, `https://${host}${reqUrl}`, `http://${host}${reqUrl}`];
      for (const uri of [...new Set(uriCandidates)]) {
        const res = verifyHmacTimingSafe({
          secret,
          signature: sigV3,
          encoding: 'base64',
          baseString: `POST${uri}${rawBody}${tsRaw}`,
          allowMockBypass: false
        });
        if (res.valid) return { valid: true, mode: 'hubspot_v3' };
      }
      return { valid: false, reason: 'Invalid HubSpot v3 signature' };
    }

    const sigV1 = h['x-hubspot-signature'] || '';
    if (sigV1) {
      const expected = crypto.createHash('sha256').update(`${secret}${rawBody}`, 'utf8').digest('hex');
      const ok = timingSafeEqualStr(sigV1, expected);
      return { valid: ok, mode: ok ? 'hubspot_v1' : undefined, reason: ok ? undefined : 'Invalid HubSpot v1 signature' };
    }
    return { valid: false, reason: 'Missing HubSpot signature header' };
  },

  async normalizeInbound(payload = {}, { channelCfg = {} } = {}) {
    const events = Array.isArray(payload) ? payload : [payload];
    const token = await resolveHubSpotToken(channelCfg).catch(() => '');
    const out = [];

    for (const evt of events) {
      if (!evt || typeof evt !== 'object') continue;
      const threadId = String(evt.threadId || evt.objectId || evt.conversationId || '').trim();
      const msgId = String(evt.messageId || evt.eventId || '').trim();
      if (!threadId) continue;

      let msgData = evt;
      if (!evt.text && msgId && token) {
        try {
          const url = `${HS_API_BASE}/conversations/v3/conversations/threads/${encodeURIComponent(threadId)}/messages/${encodeURIComponent(msgId)}`;
          const res = await fetchWithTimeout(url, { headers: { Authorization: `Bearer ${token}` } }, 8000);
          if (res.ok) msgData = await res.json();
        } catch (err) {
          console.warn('[hubspot-adapter] message fetch warning:', err?.message || err);
        }
      }

      const direction = String(msgData.direction || evt.direction || '').toUpperCase();
      const actorId = String(msgData.senders?.[0]?.actorId || '').trim();
      if (direction === 'OUTGOING' || actorId.startsWith('A-') || actorId.startsWith('B-')) continue;

      const text = String(msgData.text || evt.text || evt.message || '').trim();
      const attachments = [];
      for (const att of Array.isArray(msgData.attachments) ? msgData.attachments : []) {
        if (att?.url && (att.type === 'FILE' || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(att.url))) {
          attachments.push({ type: 'image', url: String(att.url) });
        }
      }
      if (!text && attachments.length === 0) continue;

      const senderName = String(msgData.senders?.[0]?.name || evt.senderName || `HubSpot #${threadId.slice(-6)}`).trim();
      out.push(
        buildNormalizedInbound({
          channel: 'hubspot',
          externalUserId: threadId,
          senderName,
          text,
          messageId: msgId || `hs_${threadId}_${Date.now()}`,
          attachments,
          timestamp: Number(evt.occurredAt || Date.parse(msgData.createdAt || '') || Date.now()),
          meta: {
            threadId,
            channelId: msgData.channelId || '',
            channelAccountId: msgData.channelAccountId || ''
          }
        })
      );
    }
    return out;
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const token = await resolveHubSpotToken(channelCfg);
    if (!token) throw new Error('Missing HubSpot Access Token or OAuth credentials');
    const threadId = String(meta.threadId || to || '').trim();
    if (!threadId) throw new Error('Missing HubSpot threadId');

    const mediaUrls = resolvePublicMediaUrls(images);
    const cleanText = String(text || '').trim();
    const fullText = mediaUrls.length > 0 ? `${cleanText}\n${mediaUrls.join('\n')}`.trim() : cleanText;
    const richImg = mediaUrls.map((u) => `<p><img src="${u}" alt="image" /></p>`).join('');
    const richText = `<p>${cleanText.replace(/\n/g, '<br/>')}</p>${richImg}`;

    const url = `${HS_API_BASE}/conversations/v3/conversations/threads/${encodeURIComponent(threadId)}/messages`;
    const body = {
      type: 'MESSAGE',
      text: fullText,
      richText,
      ...(meta.channelId ? { channelId: meta.channelId } : {}),
      ...(meta.channelAccountId ? { channelAccountId: meta.channelAccountId } : {})
    };
    const res = await fetchWithTimeout(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`HubSpot Send HTTP ${res.status}: ${json?.message || ''}`);
    return { ok: true, platform: 'hubspot', messageId: json?.id || `hs_${Date.now()}`, mode: 'conversations_v3' };
  }
};

export default hubspotAdapter;
