// gateway/src/modules/channels/signal-adapter.mjs
// Wave 2 Adapter: Signal Messenger via Self-Hosted signal-cli-rest-api (Strict Auth + SSRF-Guarded Image Fetch)

import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024;
const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

function normalizePhoneDigits(raw = '') {
  return String(raw || '').replace(/[^\d+]/g, '').trim();
}

function validateSafeHttpsUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return '';
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

async function fetchImageAsBase64DataUri(url) {
  const safeUrl = validateSafeHttpsUrl(url);
  if (!safeUrl) throw new Error('Blocked unsafe Signal image URL (must be public HTTPS)');
  const res = await fetchWithTimeout(safeUrl, { method: 'GET' }, 12000);
  if (!res.ok) throw new Error(`Image fetch HTTP ${res.status}`);
  const len = Number(res.headers.get('content-length') || 0);
  if (len > MAX_ATTACHMENT_BYTES) throw new Error('Image exceeds 5MB limit');
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length === 0 || buf.length > MAX_ATTACHMENT_BYTES) {
    throw new Error('Invalid or oversized image buffer (>5MB)');
  }
  const mime = String(res.headers.get('content-type') || 'image/jpeg').split(';')[0].trim();
  return `data:${mime};base64,${buf.toString('base64')}`;
}

const signalAdapter = {
  meta: {
    id: 'signal',
    wave: 'wave2',
    category: 'messaging',
    label: 'Signal (signal-cli-rest-api)',
    shortLabel: 'SIGNAL',
    badgeColor: '#3A76F0',
    badgeBg: 'rgba(58, 118, 240, 0.14)',
    webhookPath: '/webhook/signal',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'bridgeBaseUrl', label: 'Signal CLI REST Base URL', type: 'url', secret: false, required: true, placeholder: 'http://127.0.0.1:8080', envKey: 'SIGNAL_BRIDGE_BASE_URL' },
      { key: 'botNumber', label: 'Signal Bot Number (E.164)', type: 'text', secret: false, required: true, placeholder: '+66812345678', envKey: 'SIGNAL_BOT_NUMBER' },
      { key: 'webhookSecret', label: 'Webhook Secret Header', type: 'password', secret: true, placeholder: 'ตรวจ X-Signal-Webhook-Secret / Bearer', envKey: 'SIGNAL_WEBHOOK_SECRET' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, channelCfg = {} }) {
    const expected = String(channelCfg.webhookSecret || process.env.SIGNAL_WEBHOOK_SECRET || '').trim();
    if (!expected) return { valid: false, reason: 'Missing Signal webhook secret configuration' };

    const h = normalizeHeaders(headers);
    const candidate =
      h['x-signal-webhook-secret'] ||
      (h.authorization || '').replace(/^Bearer\s+/i, '').trim();
    if (!candidate) return { valid: false, reason: 'Missing Signal webhook secret header' };

    const valid = timingSafeEqualStr(candidate, expected);
    return { valid, mode: valid ? 'shared_secret' : undefined, reason: valid ? undefined : 'Invalid Signal webhook secret' };
  },

  normalizeInbound(payload = {}, { channelCfg = {} } = {}) {
    const items = Array.isArray(payload) ? payload : [payload];
    const botNum = normalizePhoneDigits(channelCfg.botNumber || process.env.SIGNAL_BOT_NUMBER || '');
    const bridgeBase = String(channelCfg.bridgeBaseUrl || process.env.SIGNAL_BRIDGE_BASE_URL || '').trim().replace(/\/+$/, '');
    const out = [];

    for (const raw of items) {
      const env = raw?.envelope && typeof raw.envelope === 'object' ? raw.envelope : raw;
      const dm = env?.dataMessage;
      if (!dm || typeof dm !== 'object') continue;

      const source = normalizePhoneDigits(env.sourceNumber || env.source || env.sourceUuid || '');
      if (!source || (botNum && source === botNum)) continue;

      const text = String(dm.message || dm.text || '').trim();
      const attachments = [];
      let unsupportedMediaType = '';
      let mediaFileName = '';

      for (const att of Array.isArray(dm.attachments) ? dm.attachments : []) {
        const mime = String(att?.contentType || '').toLowerCase();
        const attId = String(att?.id || '').trim();
        const url = att?.url || (bridgeBase && attId ? `${bridgeBase}/v1/attachments/${encodeURIComponent(attId)}` : '');
        if (mime.startsWith('image/') && (url || attId)) {
          attachments.push({ type: 'image', url, mediaId: attId, mimeType: mime });
        } else if (attId || url) {
          unsupportedMediaType = mime.startsWith('audio/') ? 'audio' : mime.startsWith('video/') ? 'video' : 'file';
          mediaFileName = mediaFileName || String(att?.filename || attId || 'attachment');
        }
      }

      if (!text && attachments.length === 0 && !unsupportedMediaType) continue;

      const ts = Number(dm.timestamp || env.timestamp || Date.now());
      const senderName = String(env.sourceName || `Signal (${source.slice(-6)})`).trim();
      out.push(
        buildNormalizedInbound({
          channel: 'signal',
          externalUserId: source,
          senderName,
          text: text || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Signal: ${mediaFileName || unsupportedMediaType}]` : ''),
          messageId: `signal_${source}_${ts}`,
          attachments,
          timestamp: ts,
          unsupportedMediaType,
          mediaFileName,
          meta: { sourceNumber: source, groupId: dm.groupInfo?.groupId || '' }
        })
      );
    }
    return out;
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const bridgeBase = String(channelCfg.bridgeBaseUrl || process.env.SIGNAL_BRIDGE_BASE_URL || '').trim().replace(/\/+$/, '');
    const botNumber = normalizePhoneDigits(channelCfg.botNumber || process.env.SIGNAL_BOT_NUMBER || '');
    if (!bridgeBase || !botNumber) throw new Error('Missing Signal bridgeBaseUrl or botNumber');

    const recipient = String(meta.groupId || to || '').replace(/^signal:/i, '').trim();
    if (!recipient) throw new Error('Missing Signal recipient number');

    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const base64Attachments = [];
    for (const url of mediaUrls) {
      try {
        base64Attachments.push(await fetchImageAsBase64DataUri(url));
      } catch (err) {
        console.warn(`[SignalAdapter] Skipping image (${url}):`, err.message);
      }
    }

    const cleanText = String(text || '').trim();
    if (!cleanText && base64Attachments.length === 0) throw new Error('Signal reply message cannot be empty');

    const res = await fetchWithTimeout(`${bridgeBase}/v2/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: cleanText,
        number: botNumber,
        recipients: [recipient],
        ...(base64Attachments.length > 0 ? { base64_attachments: base64Attachments } : {})
      })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Signal Bridge HTTP ${res.status}: ${json?.error || ''}`);
    return { ok: true, platform: 'signal', messageId: String(json?.timestamp || `sig_out_${Date.now()}`), mode: 'signal_cli_v2' };
  }
};

export default signalAdapter;
