// gateway/src/modules/channels/slack-adapter.mjs
// Wave 3 Adapter: Slack Events & Chat API (Strict v0 HMAC + Replay + Anti-Echo + Safe Attachment Flag)

import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const SLACK_POST_URL = 'https://slack.com/api/chat.postMessage';
const IGNORED_SUBTYPES = new Set(['bot_message', 'message_changed', 'message_deleted']);

function isDevWebhookBypassEnabled() {
  return String(process.env.ALLOW_UNVERIFIED_WEBHOOK_DEV || '').trim().toLowerCase() === 'true';
}

const slackAdapter = {
  meta: {
    id: 'slack',
    wave: 'wave3',
    category: 'workplace',
    label: 'Slack Workspace',
    shortLabel: 'SLACK',
    badgeColor: '#E01E5A',
    badgeBg: 'rgba(224, 30, 90, 0.14)',
    webhookPath: '/webhook/slack',
    supportsImages: true,
    supportsChallenge: true,
    fields: [
      { key: 'appId', label: 'Slack App ID', type: 'text', secret: false, placeholder: 'A0123456789', envKey: 'SLACK_APP_ID' },
      { key: 'defaultChannelId', label: 'Default Channel ID', type: 'text', secret: false, placeholder: 'C0123456789', envKey: 'SLACK_DEFAULT_CHANNEL_ID' },
      { key: 'botToken', label: 'Bot User OAuth Token (xoxb-...)', type: 'password', secret: true, required: true, placeholder: 'xoxb-...', envKey: 'SLACK_BOT_TOKEN' },
      { key: 'signingSecret', label: 'Signing Secret', type: 'password', secret: true, required: true, placeholder: 'Slack Signing Secret', envKey: 'SLACK_SIGNING_SECRET' }
    ]
  },

  handleChallenge(req, _channelCfg = {}, _parsedUrl, payload = {}) {
    if (req.method === 'POST' && payload?.type === 'url_verification' && payload?.challenge) {
      return {
        isChallenge: true,
        status: 200,
        contentType: 'application/json; charset=utf-8',
        response: { challenge: String(payload.challenge) }
      };
    }
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const secret = String(channelCfg.signingSecret || process.env.SLACK_SIGNING_SECRET || '').trim();
    if (!secret) {
      if (isDevWebhookBypassEnabled()) return { valid: true, mode: 'mock_bypass' };
      return { valid: false, reason: 'Missing Slack signing secret' };
    }

    const tsRaw = String(h['x-slack-request-timestamp'] || '').trim();
    const sig = String(h['x-slack-signature'] || '').trim();
    if (!tsRaw || !sig) {
      return { valid: false, reason: 'Missing Slack signature or timestamp headers' };
    }

    const tsSec = Number(tsRaw);
    if (!Number.isFinite(tsSec) || Math.abs(Math.floor(Date.now() / 1000) - tsSec) > 300) {
      return { valid: false, reason: 'Slack request timestamp outside 300s window' };
    }

    const bodyText = Buffer.isBuffer(rawBuf) ? rawBuf.toString('utf8') : String(rawBody || '');
    return verifyHmacTimingSafe({
      secret,
      signature: sig,
      encoding: 'hex',
      prefix: 'v0=',
      baseString: `v0:${tsRaw}:${bodyText}`,
      allowMockBypass: false
    });
  },

  normalizeInbound(payload = {}, { headers = {}, channelCfg = {} } = {}) {
    const h = normalizeHeaders(headers);
    if (h['x-slack-retry-num'] || payload?.type === 'url_verification') return [];

    const evt = payload?.event || payload;
    if (!evt || typeof evt !== 'object') return [];

    const configuredAppId = String(channelCfg.appId || process.env.SLACK_APP_ID || '').trim();
    const subtype = String(evt.subtype || '').trim().toLowerCase();
    if (evt.bot_id || evt.bot_profile || evt.app_id || IGNORED_SUBTYPES.has(subtype)) {
      return [];
    }

    const userId = String(evt.user || evt.senderId || '').trim();
    if (configuredAppId && userId === configuredAppId) return [];

    const authedUsers = Array.isArray(payload?.authed_users)
      ? payload.authed_users.map((u) => String(u || '').trim()).filter(Boolean)
      : [];
    const authedBotIds = Array.isArray(payload?.authorizations)
      ? payload.authorizations
          .filter((a) => a && a.is_bot)
          .map((a) => String(a.user_id || '').trim())
          .filter(Boolean)
      : [];
    if (userId && (authedUsers.includes(userId) || authedBotIds.includes(userId))) {
      return [];
    }

    const channelId = String(evt.channel || channelCfg.defaultChannelId || userId).trim();
    if (!userId && !channelId) return [];

    const rawText = String(evt.text || '').replace(/<@[A-Z0-9]+>/g, '').trim();
    const attachments = [];
    let unsupportedMediaType = '';
    let mediaFileName = '';
    for (const f of Array.isArray(evt.files) ? evt.files : []) {
      const mime = String(f?.mimetype || '').toLowerCase();
      const url = String(f?.url_private || f?.permalink || f?.url_private_download || '').trim();
      if (mime.startsWith('image/') && url) {
        attachments.push({ type: 'image', url, mimeType: mime, requiresChannelAuth: 'slack' });
      } else if (url || f?.name) {
        unsupportedMediaType = mime.startsWith('audio/') ? 'audio' : mime.startsWith('video/') ? 'video' : 'file';
        mediaFileName = mediaFileName || String(f?.name || 'file');
      }
    }

    if (!rawText && attachments.length === 0 && !unsupportedMediaType) return [];
    const extId = channelId || userId;
    const tsMs = Math.round((Number(evt.ts || evt.event_ts) || Date.now() / 1000) * 1000);

    return [
      buildNormalizedInbound({
        channel: 'slack',
        externalUserId: extId,
        senderName: `Slack (${(userId || extId).slice(-6)})`,
        text: rawText || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Slack: ${mediaFileName || unsupportedMediaType}]` : ''),
        messageId: String(evt.client_msg_id || evt.ts || `slack_${Date.now()}`),
        attachments,
        replyToken: String(evt.thread_ts || ''),
        timestamp: tsMs,
        unsupportedMediaType,
        mediaFileName,
        meta: { channelId: channelId || extId, userId, threadTs: String(evt.thread_ts || '') }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], replyToken = '', channelCfg = {}, meta = {} }) {
    const botToken = String(channelCfg.botToken || process.env.SLACK_BOT_TOKEN || '').trim();
    if (!botToken) throw new Error('Missing Slack Bot Token');
    const channel = String(meta.channelId || channelCfg.defaultChannelId || to || '').replace(/^slack:/i, '').trim();
    if (!channel) throw new Error('Missing Slack channel ID');

    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const cleanText = String(text || '').trim().slice(0, 3000);
    if (!cleanText && mediaUrls.length === 0) throw new Error('Slack reply message cannot be empty');

    const blocks = [];
    if (cleanText) blocks.push({ type: 'section', text: { type: 'mrkdwn', text: cleanText } });
    for (const url of mediaUrls) {
      blocks.push({ type: 'image', image_url: url, alt_text: 'Product preview' });
    }

    const threadTs = String(replyToken || meta.threadTs || '').trim();
    const res = await fetchWithTimeout(SLACK_POST_URL, {
      method: 'POST',
      headers: { Authorization: `Bearer ${botToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        channel,
        text: cleanText || mediaUrls[0] || '',
        blocks,
        ...(threadTs ? { thread_ts: threadTs } : {})
      })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || json.ok === false) throw new Error(`Slack Send Error: ${json.error || `HTTP ${res.status}`}`);
    return { ok: true, platform: 'slack', messageId: String(json.ts || `slack_out_${Date.now()}`), mode: 'chat_postMessage' };
  }
};

export default slackAdapter;
