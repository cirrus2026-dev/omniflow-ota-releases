// gateway/src/modules/channels/channel-registry.mjs
// Registry-Driven Omnichannel Router, Dynamic UI Metadata & Vault Schema Provider

import { readRawBody, validateAdapterContract, buildNormalizedInbound } from './channel-contract.mjs';
import { verifyEmailWebhookSecret, normalizeEmailInbound, sendEmailReply } from './email-adapter.mjs';
import instagramAdapter from './instagram-adapter.mjs';
import shopifyAdapter from './shopify-adapter.mjs';
import hubspotAdapter from './hubspot-adapter.mjs';
import wechatAdapter from './wechat-adapter.mjs';
import discordAdapter from './discord-adapter.mjs';
import signalAdapter from './signal-adapter.mjs';
import viberAdapter from './viber-adapter.mjs';
import kakaotalkAdapter from './kakaotalk-adapter.mjs';
import slackAdapter from './slack-adapter.mjs';
import teamsAdapter from './teams-adapter.mjs';
import googleChatAdapter from './google-chat-adapter.mjs';
import larkAdapter from './lark-adapter.mjs';
import dingtalkAdapter from './dingtalk-adapter.mjs';
import zohoSalesiqAdapter from './zoho-salesiq-adapter.mjs';
import crispAdapter from './crisp-adapter.mjs';
import tidioAdapter from './tidio-adapter.mjs';

export const CHANNEL_GROUPS = [
  { id: 'core', label: 'ช่องทางหลักยอดนิยม (Core Social & Email)' },
  { id: 'wave1', label: 'Social Commerce & CRM (Wave 1)' },
  { id: 'wave2', label: 'Global & Regional Messengers (Wave 2)' },
  { id: 'wave3', label: 'Enterprise Workspace (Wave 3)' },
  { id: 'wave4', label: 'Website Live Chat Widgets (Wave 4)' }
];

const CORE_CHANNEL_DESCRIPTORS = [
  { id: 'line', wave: 'core', category: 'messaging', label: 'LINE Official Account', shortLabel: 'LINE', badgeColor: '#10b981', badgeBg: 'rgba(16, 185, 129, 0.14)', webhookPath: '/webhook', supportsImages: true, fields: [
    { key: 'channelId', label: 'Channel ID', type: 'text', secret: false, placeholder: 'LINE Channel ID', envKey: 'LINE_CHANNEL_ID' },
    { key: 'channelSecret', label: 'Channel Secret', type: 'password', secret: true, required: true, envKey: 'LINE_CHANNEL_SECRET' },
    { key: 'channelAccessToken', label: 'Channel Access Token', type: 'password', secret: true, required: true, envKey: 'LINE_CHANNEL_ACCESS_TOKEN' }
  ] },
  { id: 'facebook', wave: 'core', category: 'social', label: 'Facebook Messenger', shortLabel: 'FB', badgeColor: '#3b82f6', badgeBg: 'rgba(59, 130, 246, 0.14)', webhookPath: '/webhook', supportsImages: true, fields: [
    { key: 'pageAccessToken', label: 'Page Access Token', type: 'password', secret: true, required: true, envKey: 'FB_PAGE_ACCESS_TOKEN' },
    { key: 'appSecret', label: 'App Secret', type: 'password', secret: true, required: true, envKey: 'FB_APP_SECRET' },
    { key: 'verifyToken', label: 'Verify Token', type: 'text', secret: false, envKey: 'FB_VERIFY_TOKEN' }
  ] },
  { id: 'whatsapp', wave: 'core', category: 'messaging', label: 'WhatsApp Business Cloud', shortLabel: 'WA', badgeColor: '#22c55e', badgeBg: 'rgba(34, 197, 94, 0.14)', webhookPath: '/api/webhook/whatsapp', supportsImages: true, fields: [
    { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', secret: false, required: true, envKey: 'WHATSAPP_PHONE_NUMBER_ID' },
    { key: 'accessToken', label: 'Access Token', type: 'password', secret: true, required: true, envKey: 'WHATSAPP_ACCESS_TOKEN' },
    { key: 'appSecret', label: 'Meta App Secret', type: 'password', secret: true, envKey: 'WHATSAPP_APP_SECRET' },
    { key: 'verifyToken', label: 'Verify Token', type: 'text', secret: false, envKey: 'WHATSAPP_VERIFY_TOKEN' }
  ] },
  { id: 'shopee', wave: 'core', category: 'ecommerce', label: 'Shopee Chat', shortLabel: 'SHOPEE', badgeColor: '#f97316', badgeBg: 'rgba(249, 115, 22, 0.14)', webhookPath: '/webhook/shopee', supportsImages: true, fields: [
    { key: 'partnerId', label: 'Partner ID', type: 'text', secret: false, envKey: 'SHOPEE_PARTNER_ID' },
    { key: 'partnerKey', label: 'Partner Key', type: 'password', secret: true, required: true, envKey: 'SHOPEE_PARTNER_KEY' },
    { key: 'shopId', label: 'Shop ID', type: 'text', secret: false, envKey: 'SHOPEE_SHOP_ID' }
  ] },
  { id: 'tiktok', wave: 'core', category: 'ecommerce', label: 'TikTok Shop', shortLabel: 'TIKTOK', badgeColor: '#f43f5e', badgeBg: 'rgba(244, 63, 94, 0.14)', webhookPath: '/webhook/tiktok', supportsImages: true, fields: [
    { key: 'appKey', label: 'App Key', type: 'text', secret: false, envKey: 'TIKTOK_APP_KEY' },
    { key: 'appSecret', label: 'App Secret', type: 'password', secret: true, required: true, envKey: 'TIKTOK_APP_SECRET' },
    { key: 'shopId', label: 'Shop ID', type: 'text', secret: false, envKey: 'TIKTOK_SHOP_ID' }
  ] },
  { id: 'lazada', wave: 'core', category: 'ecommerce', label: 'Lazada Chat', shortLabel: 'LAZADA', badgeColor: '#6366f1', badgeBg: 'rgba(99, 102, 241, 0.14)', webhookPath: '/webhook/lazada', supportsImages: true, fields: [
    { key: 'appKey', label: 'App Key', type: 'text', secret: false, envKey: 'LAZADA_APP_KEY' },
    { key: 'appSecret', label: 'App Secret', type: 'password', secret: true, required: true, envKey: 'LAZADA_APP_SECRET' },
    { key: 'accessToken', label: 'Access Token', type: 'password', secret: true, envKey: 'LAZADA_ACCESS_TOKEN' }
  ] }
];

const emailAdapter = {
  meta: {
    id: 'email', wave: 'core', category: 'email', label: 'Email Chat (SMTP / Webhook)', shortLabel: 'EMAIL',
    badgeColor: '#38bdf8', badgeBg: 'rgba(56, 189, 248, 0.14)', webhookPath: '/webhook/email', supportsImages: true, supportsChallenge: false,
    fields: [
      { key: 'fromEmail', label: 'อีเมลผู้ส่งของร้าน (From Email)', type: 'text', secret: false, required: true, placeholder: 'sales@yourdomain.com', envKey: 'EMAIL_FROM' },
      { key: 'fromName', label: 'ชื่อผู้ส่ง (From Name)', type: 'text', secret: false, placeholder: 'ฝ่ายขาย OmniFlow', envKey: 'EMAIL_FROM_NAME' },
      { key: 'webhookSecret', label: 'Inbound Webhook Secret', type: 'password', secret: true, placeholder: 'ตั้งรหัสลับตรวจ Header X-Email-Webhook-Secret', envKey: 'EMAIL_WEBHOOK_SECRET' },
      { key: 'smtpHost', label: 'SMTP Host', type: 'text', secret: false, placeholder: 'smtp.gmail.com', envKey: 'EMAIL_SMTP_HOST' },
      { key: 'smtpPort', label: 'SMTP Port', type: 'text', secret: false, placeholder: '587 หรือ 465', envKey: 'EMAIL_SMTP_PORT' },
      { key: 'smtpUser', label: 'SMTP Username', type: 'text', secret: false, placeholder: 'sales@yourdomain.com', envKey: 'EMAIL_SMTP_USER' },
      { key: 'smtpPass', label: 'SMTP Password / App Password', type: 'password', secret: true, placeholder: 'App Password 16 หลัก', envKey: 'EMAIL_SMTP_PASS' },
      { key: 'outboundWebhookUrl', label: 'Outbound Webhook URL (ทางเลือกแทน SMTP)', type: 'url', secret: false, placeholder: 'https://hook.make.com/... (เว้นว่างหากใช้ SMTP)', envKey: 'EMAIL_OUTBOUND_WEBHOOK_URL' }
    ]
  },
  handleChallenge() { return { isChallenge: false }; },
  verifySignature({ headers, rawBody, channelCfg = {} }) {
    return verifyEmailWebhookSecret({ headers, rawBody, secret: channelCfg.webhookSecret || process.env.EMAIL_WEBHOOK_SECRET || '' });
  },
  normalizeInbound(payload, { channelCfg = {} } = {}) {
    const item = normalizeEmailInbound(payload, { ownFromEmail: channelCfg.fromEmail || process.env.EMAIL_FROM || '' });
    return item ? [buildNormalizedInbound({ ...item, externalUserId: item.emailAddress })] : [];
  },
  sendReply({ to, text, images = [], channelCfg = {}, businessName = '', meta = {} }) {
    return sendEmailReply({ to, subject: meta.subject || '', text, images, inReplyTo: meta.inReplyTo || meta.messageId || '', emailConfig: channelCfg, businessName });
  }
};

const adaptersMap = new Map();
const inflightMessageIds = new Set();

export function registerChannelAdapter(adapter) {
  validateAdapterContract(adapter);
  const id = String(adapter.meta.id).trim().toLowerCase();
  adaptersMap.set(id, adapter);
  return adapter;
}

[
  emailAdapter,
  instagramAdapter, shopifyAdapter, hubspotAdapter, wechatAdapter,
  discordAdapter, signalAdapter, viberAdapter, kakaotalkAdapter,
  slackAdapter, teamsAdapter, googleChatAdapter, larkAdapter, dingtalkAdapter,
  zohoSalesiqAdapter, crispAdapter, tidioAdapter
].forEach(registerChannelAdapter);

export const getChannelAdapter = (channelId = '') => adaptersMap.get(String(channelId || '').trim().toLowerCase()) || null;
export const listChannelAdapters = () => Array.from(adaptersMap.values());

export function getRegistrySecretFieldsMap() {
  const map = {};
  for (const adapter of adaptersMap.values()) {
    const secrets = (adapter.meta.fields || []).filter((f) => f.secret).map((f) => f.key);
    if (secrets.length > 0) map[adapter.meta.id] = secrets;
  }
  return map;
}

export function getRegistryDefaultChannelsConfig() {
  const defaults = {};
  for (const adapter of adaptersMap.values()) {
    const cfg = { enabled: false };
    for (const f of adapter.meta.fields || []) cfg[f.key] = (f.envKey && process.env[f.envKey]) || '';
    defaults[adapter.meta.id] = cfg;
  }
  return defaults;
}

function isChannelConfigured(desc, savedCfg = {}) {
  const requiredFields = (desc.fields || []).filter((f) => f.required);
  if (requiredFields.length === 0) return (desc.fields || []).some((f) => Boolean(String(savedCfg[f.key] || '').trim()));
  return requiredFields.every((f) => Boolean(String(savedCfg[f.key] || '').trim()));
}

export function getPublicChannelRegistryPayload(runtimeConfig = {}) {
  const savedChannels = runtimeConfig?.channels || {};
  const allDescriptors = [...CORE_CHANNEL_DESCRIPTORS, ...listChannelAdapters().map((a) => a.meta)];
  const seen = new Set();
  const channels = [];
  for (const desc of allDescriptors) {
    if (!desc?.id || seen.has(desc.id)) continue;
    seen.add(desc.id);
    const saved = savedChannels[desc.id] || {};
    channels.push({
      id: desc.id, wave: desc.wave || 'core', category: desc.category || 'messaging',
      label: desc.label || desc.id, shortLabel: desc.shortLabel || desc.id.toUpperCase(),
      badgeColor: desc.badgeColor || '#38bdf8', badgeBg: desc.badgeBg || 'rgba(56, 189, 248, 0.14)',
      iconSvg: desc.iconSvg || '', webhookPath: desc.webhookPath || `/webhook/${desc.id}`,
      supportsImages: desc.supportsImages !== false, supportsChallenge: Boolean(desc.supportsChallenge),
      enabled: Boolean(saved.enabled), configured: isChannelConfigured(desc, saved),
      fields: (desc.fields || []).map(({ envKey, ...safeField }) => safeField)
    });
  }
  return { ok: true, version: '11.0.0', webhookBasePath: '/webhook', groups: CHANNEL_GROUPS, channels };
}

function writeJson(res, status, obj) {
  if (res.writableEnded || res.destroyed) return;
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}

function parseWebhookPayload(rawBody, contentType = '', channelId = '') {
  const trimmed = rawBody.trim();
  if (!trimmed) return { ok: true, payload: {} };
  const ct = String(contentType || '').toLowerCase();
  if (ct.includes('application/x-www-form-urlencoded')) {
    return { ok: true, payload: Object.fromEntries(new URLSearchParams(rawBody)) };
  }
  if (ct.includes('xml') || (channelId === 'wechat' && trimmed.startsWith('<'))) {
    return { ok: true, payload: {} };
  }
  try {
    const parsed = JSON.parse(rawBody);
    if (parsed === null || typeof parsed !== 'object') return { ok: false, error: 'Webhook JSON payload must be an object or array' };
    return { ok: true, payload: parsed };
  } catch {
    return { ok: false, error: 'Invalid JSON webhook payload' };
  }
}

export async function handleUnifiedChannelWebhook(req, res, { channelId, parsedUrl, runtimeConfig, stateStore, config, queueUserTurn }) {
  const id = String(channelId || '').trim().toLowerCase();
  const adapter = getChannelAdapter(id);
  if (!adapter) return false;
  const channelCfg = runtimeConfig?.channels?.[id] || {};
  if (req.method === 'GET') {
    if (typeof adapter.handleChallenge === 'function') {
      const ch = await adapter.handleChallenge(req, channelCfg, parsedUrl);
      if (ch?.isChallenge) {
        if (!res.writableEnded && !res.destroyed) {
          res.writeHead(ch.status || 200, { 'Content-Type': ch.contentType || 'text/plain; charset=utf-8' });
          res.end(typeof ch.response === 'string' ? ch.response : JSON.stringify(ch.response));
        }
        return true;
      }
    }
    writeJson(res, 400, { ok: false, error: 'Unsupported GET request for this channel' });
    return true;
  }
  if (req.method !== 'POST') { writeJson(res, 405, { ok: false, error: 'Method Not Allowed' }); return true; }
  if (!channelCfg.enabled) { writeJson(res, 403, { ok: false, error: `Channel "${id}" is disabled` }); return true; }

  let rawBuf;
  try { rawBuf = await readRawBody(req); } catch (err) { writeJson(res, err.statusCode || 400, { ok: false, error: err.message }); return true; }
  const rawBody = rawBuf.toString('utf8');
  const sig = await adapter.verifySignature({ headers: req.headers, rawBody, rawBuf, channelCfg, reqUrl: req.url, parsedUrl });
  if (!sig?.valid) { writeJson(res, 401, { ok: false, error: sig?.reason || 'Unauthorized webhook signature' }); return true; }

  const parsed = parseWebhookPayload(rawBody, req.headers?.['content-type'], id);
  if (!parsed.ok) { writeJson(res, 400, { ok: false, error: parsed.error }); return true; }
  const payload = parsed.payload;

  if (typeof adapter.handleChallenge === 'function') {
    const postCh = await adapter.handleChallenge(req, channelCfg, parsedUrl, payload, rawBody);
    if (postCh?.isChallenge) {
      if (!res.writableEnded && !res.destroyed) {
        res.writeHead(postCh.status || 200, { 'Content-Type': postCh.contentType || 'application/json; charset=utf-8' });
        res.end(typeof postCh.response === 'string' ? postCh.response : JSON.stringify(postCh.response));
      }
      return true;
    }
  }

  const normalized = await adapter.normalizeInbound(payload, { headers: req.headers, rawBody, channelCfg, parsedUrl });
  const events = Array.isArray(normalized) ? normalized : normalized ? [normalized] : [];
  let accepted = 0;
  let syncHttpResponse = null;
  for (const ev of events) {
    if (!ev?.senderId) continue;
    const msgId = ev.messageId ? String(ev.messageId).trim() : '';
    const inflightKey = msgId ? `${id}:${msgId}` : '';
    if (msgId && (inflightMessageIds.has(inflightKey) || (stateStore.dedup instanceof Map && (stateStore.dedup.get(msgId) || 0) > Date.now()))) continue;
    if (inflightKey) inflightMessageIds.add(inflightKey);
    try {
      const imageAtts = (ev.attachments || []).filter((a) => a?.type === 'image' && (a.url || a.mediaId));
      const imageUrls = imageAtts.map((a) => a.url || `${id}-media:${a.mediaId}`).filter(Boolean);
      const turnImages = imageAtts.map((a) => ({
        platform: id, url: a.url || '',
        ...(a.mediaId ? { mediaId: a.mediaId } : {}),
        ...(a.mimeType ? { mimeType: a.mimeType } : {}),
        ...(a.requiresChannelAuth ? { requiresChannelAuth: a.requiresChannelAuth } : {})
      }));
      const channelMeta = ev.meta && typeof ev.meta === 'object' ? { ...ev.meta } : {};
      if (!stateStore.isPausedByHuman(ev.senderId)) {
        await queueUserTurn(ev.senderId, { platform: id, userId: ev.externalUserId, replyToken: ev.replyToken || null, eventTimestamp: ev.timestamp, text: ev.text, images: turnImages, isSticker: false, unsupportedMediaType: ev.unsupportedMediaType || '', mediaFileName: ev.mediaFileName || '', channelMeta });
      }
      stateStore.appendChatMessage(ev.senderId, { sender: 'customer', messageId: ev.messageId, text: ev.text, images: imageUrls, timestamp: ev.timestamp }, { platform: id, userId: ev.externalUserId, customerName: ev.senderName, channelMeta });
      const conv = stateStore.conversations?.get(ev.senderId);
      if (conv && ev.meta) conv.channelMeta = { ...(conv.channelMeta || {}), ...ev.meta };
      if (msgId) stateStore.isDuplicateAndMark(msgId, config?.dedupTtlMs);
      accepted += 1;
      if (ev.meta?.syncHttpResponse) syncHttpResponse = ev.meta.syncHttpResponse;
    } catch (err) {
      console.error(`[channel-registry:${id}] Failed processing inbound event:`, err.message);
      writeJson(res, 500, { ok: false, error: 'Failed to queue inbound message' });
      return true;
    } finally {
      if (inflightKey) inflightMessageIds.delete(inflightKey);
    }
  }
  writeJson(res, 200, syncHttpResponse || { ok: true, channel: id, received: accepted });
  return true;
}
