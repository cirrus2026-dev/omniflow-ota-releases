// gateway/src/modules/channels/lark-adapter.mjs
// Wave 3 Adapter: Lark / Feishu Open API (Strict Auth + SSRF-Guarded Domain + AES-256-CBC + Card/Text Reply)

import crypto from 'node:crypto';
import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

function resolveSafeLarkBaseUrl(channelCfg = {}) {
  const domain = String(channelCfg.domain || process.env.LARK_DOMAIN || 'https://open.larksuite.com').trim().replace(/\/+$/, '');
  const candidate = /^https?:\/\//i.test(domain) ? domain : `https://${domain}`;
  let parsed;
  try {
    parsed = new URL(candidate);
  } catch {
    throw new Error('Blocked unsafe Lark API domain (invalid URL)');
  }
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (
    parsed.protocol !== 'https:' ||
    parsed.username ||
    parsed.password ||
    !host ||
    BLOCKED_HOSTS.has(host) ||
    /\.(?:localhost|local|internal)$/i.test(host) ||
    (net.isIP(host) !== 0 && isPrivateOrReservedIp(host))
  ) {
    throw new Error('Blocked unsafe Lark API domain (must be public HTTPS)');
  }
  return `${parsed.origin}${parsed.pathname.replace(/\/+$/, '')}`;
}

function decryptLarkPayload(encryptB64 = '', encryptKey = '') {
  if (!encryptB64 || !encryptKey) return null;
  const key = crypto.createHash('sha256').update(String(encryptKey), 'utf8').digest();
  const raw = Buffer.from(String(encryptB64), 'base64');
  if (raw.length <= 16) throw new Error('Invalid encrypted Lark payload length');
  const iv = raw.subarray(0, 16);
  const cipherText = raw.subarray(16);
  const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
  const plain = Buffer.concat([decipher.update(cipherText), decipher.final()]).toString('utf8');
  return JSON.parse(plain);
}

async function getLarkTenantToken(channelCfg = {}) {
  const appId = String(channelCfg.appId || process.env.LARK_APP_ID || '').trim();
  const appSecret = String(channelCfg.appSecret || process.env.LARK_APP_SECRET || '').trim();
  const base = resolveSafeLarkBaseUrl(channelCfg);
  if (!appId || !appSecret) throw new Error('Missing Lark App ID or App Secret');

  return getCachedToken(
    `lark:${base}:${appId}`,
    async () => {
      const res = await fetchWithTimeout(`${base}/open-apis/auth/v3/tenant_access_token/internal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ app_id: appId, app_secret: appSecret })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.code !== 0 || !json.tenant_access_token) {
        throw new Error(`Lark Token Error (${json.code || res.status}): ${json.msg || ''}`);
      }
      return { token: json.tenant_access_token, expiresInSec: Number(json.expire || 7200) };
    },
    300
  );
}

const larkAdapter = {
  meta: {
    id: 'lark',
    wave: 'wave3',
    category: 'workplace',
    label: 'Lark / Feishu Workspace',
    shortLabel: 'LARK',
    badgeColor: '#00B6B3',
    badgeBg: 'rgba(0, 182, 179, 0.14)',
    webhookPath: '/webhook/lark',
    supportsImages: true,
    supportsChallenge: true,
    fields: [
      { key: 'appId', label: 'Lark App ID', type: 'text', secret: false, required: true, placeholder: 'cli_xxxxxxxxxx', envKey: 'LARK_APP_ID' },
      { key: 'domain', label: 'API Domain (Lark / Feishu)', type: 'text', secret: false, placeholder: 'https://open.larksuite.com หรือ https://open.feishu.cn', envKey: 'LARK_DOMAIN' },
      { key: 'appSecret', label: 'Lark App Secret', type: 'password', secret: true, required: true, placeholder: 'App Secret', envKey: 'LARK_APP_SECRET' },
      { key: 'verificationToken', label: 'Verification Token', type: 'password', secret: true, placeholder: 'Event Subscription Verification Token', envKey: 'LARK_VERIFICATION_TOKEN' },
      { key: 'encryptKey', label: 'Encrypt Key (ถ้าเปิดเข้ารหัส Event)', type: 'password', secret: true, placeholder: 'Encrypt Key สำหรับ AES-256-CBC', envKey: 'LARK_ENCRYPT_KEY' }
    ]
  },

  handleChallenge(req, channelCfg = {}, _parsedUrl, payload = {}) {
    if (req.method !== 'POST') return { isChallenge: false };
    let body = payload;
    const encKey = String(channelCfg.encryptKey || process.env.LARK_ENCRYPT_KEY || '').trim();
    if (body?.encrypt && encKey) {
      try { body = decryptLarkPayload(body.encrypt, encKey); } catch { return { isChallenge: false }; }
    }
    if (body?.type === 'url_verification' && body?.challenge) {
      const expectedToken = String(channelCfg.verificationToken || process.env.LARK_VERIFICATION_TOKEN || '').trim();
      if (expectedToken && body.token && !timingSafeEqualStr(String(body.token), expectedToken)) {
        return { isChallenge: false };
      }
      return {
        isChallenge: true,
        status: 200,
        contentType: 'application/json; charset=utf-8',
        response: { challenge: String(body.challenge) }
      };
    }
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const encKey = String(channelCfg.encryptKey || process.env.LARK_ENCRYPT_KEY || '').trim();
    const verToken = String(channelCfg.verificationToken || process.env.LARK_VERIFICATION_TOKEN || '').trim();

    if (encKey && h['x-lark-signature']) {
      const ts = h['x-lark-request-timestamp'] || '';
      const nonce = h['x-lark-request-nonce'] || '';
      const expected = crypto.createHash('sha256').update(`${ts}${nonce}${encKey}${rawBody}`, 'utf8').digest('hex');
      const ok = timingSafeEqualStr(h['x-lark-signature'], expected);
      return { valid: ok, mode: ok ? 'lark_sha256' : undefined, reason: ok ? undefined : 'Invalid Lark signature' };
    }

    if (verToken) {
      let bodyObj = {};
      try { bodyObj = JSON.parse(rawBody || '{}'); } catch {}
      if (bodyObj?.encrypt && encKey) {
        try {
          bodyObj = decryptLarkPayload(bodyObj.encrypt, encKey);
        } catch {
          return { valid: false, reason: 'Failed to decrypt Lark encrypted payload' };
        }
      }
      const token = String(bodyObj?.token || bodyObj?.header?.token || h['x-lark-token'] || '').trim();
      if (!token) return { valid: false, reason: 'Missing Lark verification token' };
      const ok = timingSafeEqualStr(token, verToken);
      return { valid: ok, mode: ok ? 'lark_token' : undefined, reason: ok ? undefined : 'Invalid Lark verification token' };
    }

    return {
      valid: false,
      reason: encKey ? 'Missing Lark x-lark-signature header' : 'Missing Lark verificationToken or encryptKey configuration'
    };
  },

  normalizeInbound(payload = {}, { channelCfg = {} } = {}) {
    let body = payload;
    const encKey = String(channelCfg.encryptKey || process.env.LARK_ENCRYPT_KEY || '').trim();
    if (body?.encrypt && encKey) {
      try { body = decryptLarkPayload(body.encrypt, encKey); } catch { return []; }
    }
    if (!body || body.type === 'url_verification') return [];

    const sender = body?.event?.sender || {};
    if (String(sender.sender_type || '').toLowerCase() === 'app') return [];

    const msg = body?.event?.message || {};
    const chatId = String(msg.chat_id || '').trim();
    const openId = String(sender.sender_id?.open_id || sender.sender_id?.user_id || '').trim();
    const extId = chatId || openId;
    if (!extId) return [];

    let parsedContent = {};
    if (typeof msg.content === 'string') {
      try { parsedContent = JSON.parse(msg.content); } catch { parsedContent = { text: msg.content }; }
    } else if (msg.content && typeof msg.content === 'object') {
      parsedContent = msg.content;
    }

    const msgType = String(msg.message_type || 'text').toLowerCase();
    const attachments = [];
    let text = String(parsedContent.text || '').replace(/@_user_\d+/g, '').trim();
    let unsupportedMediaType = '';

    if (msgType === 'image' && parsedContent.image_key) {
      attachments.push({ type: 'image', mediaId: String(parsedContent.image_key) });
    } else if (['file', 'audio', 'media'].includes(msgType)) {
      unsupportedMediaType = msgType === 'media' ? 'video' : msgType;
      text = text || `[ลูกค้าส่งสื่อทาง Lark: ${msgType}]`;
    }

    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];
    const receiveIdType = chatId ? 'chat_id' : 'open_id';

    return [
      buildNormalizedInbound({
        channel: 'lark',
        externalUserId: extId,
        senderName: `Lark (${(openId || extId).slice(-6)})`,
        text,
        messageId: String(msg.message_id || body?.header?.event_id || `lark_${Date.now()}`),
        attachments,
        timestamp: Number(msg.create_time || Date.now()),
        unsupportedMediaType,
        meta: { chatId, openId, receiveIdType, messageId: String(msg.message_id || '') }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, businessName = '', meta = {} }) {
    const token = await getLarkTenantToken(channelCfg);
    const base = resolveSafeLarkBaseUrl(channelCfg);
    const receiveId = String(meta.chatId || to || '').replace(/^lark:/i, '').trim();
    if (!receiveId) throw new Error('Missing Lark receiveId');

    const cleanText = String(text || '').trim();
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    if (!cleanText && mediaUrls.length === 0) throw new Error('Lark reply content cannot be empty');

    const receiveIdType = meta.receiveIdType || (receiveId.startsWith('oc_') ? 'chat_id' : 'open_id');
    const url = `${base}/open-apis/im/v1/messages?receive_id_type=${encodeURIComponent(receiveIdType)}`;
    const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

    let msgType = 'text';
    let contentObj = { text: cleanText };
    if (mediaUrls.length > 0) {
      msgType = 'interactive';
      const imgLines = mediaUrls.map((u, idx) => `🖼️ [ดูรูปภาพตัวอย่าง #${idx + 1}](${u})`);
      const mdBody = [cleanText, ...imgLines].filter(Boolean).join('\n\n');
      contentObj = {
        config: { wide_screen_mode: true },
        header: { title: { tag: 'plain_text', content: businessName || 'OmniFlow' } },
        elements: [{ tag: 'div', text: { tag: 'lark_md', content: mdBody } }]
      };
    }

    const res = await fetchWithTimeout(url, {
      method: 'POST',
      headers,
      body: JSON.stringify({ receive_id: receiveId, msg_type: msgType, content: JSON.stringify(contentObj) })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok || (json.code !== undefined && json.code !== 0)) {
      throw new Error(`Lark Send Error (${json.code || res.status}): ${json.msg || ''}`);
    }
    const messageId = String(json?.data?.message_id || '');
    return { ok: true, platform: 'lark', messageId: messageId || `lark_out_${Date.now()}`, mode: msgType === 'interactive' ? 'im_v1_card' : 'im_v1_text' };
  }
};

export default larkAdapter;
