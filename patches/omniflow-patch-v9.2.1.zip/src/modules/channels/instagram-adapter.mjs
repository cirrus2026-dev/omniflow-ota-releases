// gateway/src/modules/channels/instagram-adapter.mjs
// Wave 1 Adapter: Instagram Direct Messaging (Meta Graph API + X-Hub-Signature-256)

import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const GRAPH_VERSION = 'v19.0';

const instagramAdapter = {
  meta: {
    id: 'instagram',
    wave: 'wave1',
    category: 'social',
    label: 'Instagram Direct',
    shortLabel: 'IG',
    badgeColor: '#E1306C',
    badgeBg: 'rgba(225, 48, 108, 0.14)',
    webhookPath: '/webhook/instagram',
    supportsImages: true,
    supportsChallenge: true,
    fields: [
      { key: 'igAccountId', label: 'Instagram Business Account ID', type: 'text', secret: false, placeholder: '17841400000000000', envKey: 'IG_ACCOUNT_ID' },
      { key: 'pageAccessToken', label: 'Page / IG Access Token', type: 'password', secret: true, required: true, placeholder: 'EAA...', envKey: 'IG_PAGE_ACCESS_TOKEN' },
      { key: 'appSecret', label: 'Meta App Secret', type: 'password', secret: true, required: true, placeholder: 'App Secret (HMAC-SHA256)', envKey: 'IG_APP_SECRET' },
      { key: 'verifyToken', label: 'Webhook Verify Token', type: 'text', secret: false, required: true, placeholder: 'omniflow_ig_verify', envKey: 'IG_VERIFY_TOKEN' }
    ]
  },

  handleChallenge(req, channelCfg = {}, parsedUrl) {
    if (req.method !== 'GET' || !parsedUrl) return { isChallenge: false };
    const mode = parsedUrl.searchParams.get('hub.mode');
    const token = parsedUrl.searchParams.get('hub.verify_token') || '';
    const challenge = parsedUrl.searchParams.get('hub.challenge') || '';
    const expected = String(channelCfg.verifyToken || process.env.IG_VERIFY_TOKEN || '').trim();
    if (mode === 'subscribe' && expected && token === expected && challenge) {
      return { isChallenge: true, status: 200, contentType: 'text/plain; charset=utf-8', response: challenge };
    }
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const secret = String(channelCfg.appSecret || process.env.IG_APP_SECRET || '').trim();
    return verifyHmacTimingSafe({
      rawBody: rawBuf || rawBody,
      secret,
      signature: h['x-hub-signature-256'] || '',
      encoding: 'hex',
      prefix: 'sha256='
    });
  },

  normalizeInbound(payload = {}, { channelCfg = {} } = {}) {
    const ownId = String(channelCfg.igAccountId || process.env.IG_ACCOUNT_ID || '').trim();
    const out = [];
    for (const entry of Array.isArray(payload?.entry) ? payload.entry : []) {
      for (const evt of Array.isArray(entry?.messaging) ? entry.messaging : []) {
        const msg = evt?.message;
        const senderId = String(evt?.sender?.id || '').trim();
        if (!msg || !senderId || msg.is_echo || (ownId && senderId === ownId)) continue;

        const attachments = [];
        let unsupportedMediaType = '';
        for (const att of Array.isArray(msg.attachments) ? msg.attachments : []) {
          if (att?.type === 'image' && att?.payload?.url) {
            attachments.push({ type: 'image', url: String(att.payload.url) });
          } else if (['audio', 'video', 'file', 'share', 'story_mention'].includes(att?.type)) {
            unsupportedMediaType = att.type === 'share' ? 'file' : att.type;
          }
        }

        const text = String(msg.text || '').trim();
        if (!text && attachments.length === 0 && !unsupportedMediaType) continue;

        out.push(
          buildNormalizedInbound({
            channel: 'instagram',
            externalUserId: senderId,
            senderName: `IG (${senderId.slice(-6)})`,
            text: text || (unsupportedMediaType ? `[ลูกค้าส่งสื่อทาง Instagram: ${unsupportedMediaType}]` : ''),
            messageId: msg.mid || `ig_${evt.timestamp || Date.now()}`,
            attachments,
            timestamp: evt.timestamp || Date.now(),
            unsupportedMediaType,
            meta: { igAccountId: entry.id || ownId, recipientId: evt?.recipient?.id || '' }
          })
        );
      }
    }
    return out;
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const token = String(channelCfg.pageAccessToken || process.env.IG_PAGE_ACCESS_TOKEN || '').trim();
    if (!token) throw new Error('Missing Instagram Page/IG Access Token');
    const accountId = String(channelCfg.igAccountId || meta.igAccountId || process.env.IG_ACCOUNT_ID || 'me').trim();
    const endpoint = `https://graph.facebook.com/${GRAPH_VERSION}/${encodeURIComponent(accountId)}/messages`;
    const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
    let messageId = '';

    const cleanText = String(text || '').trim();
    if (cleanText) {
      const res = await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({ recipient: { id: to }, message: { text: cleanText.slice(0, 1000) } })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(`Instagram Send HTTP ${res.status}: ${json?.error?.message || ''}`);
      messageId = json?.message_id || '';
    }

    const mediaUrls = resolvePublicMediaUrls(images);
    for (const url of mediaUrls.slice(0, 4)) {
      const imgRes = await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({ recipient: { id: to }, message: { attachment: { type: 'image', payload: { url } } } })
      });
      if (imgRes.ok && !messageId) {
        const imgJson = await imgRes.json().catch(() => ({}));
        messageId = imgJson?.message_id || '';
      }
    }
    return { ok: true, platform: 'instagram', messageId, mode: 'graph_api' };
  }
};

export default instagramAdapter;
