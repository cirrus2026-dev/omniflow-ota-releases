// gateway/src/modules/channels/teams-adapter.mjs
// Wave 3 Adapter: Microsoft Teams Outgoing Webhook & Azure Bot Framework (Strict Auth + ServiceUrl Allowlist + Anti-Echo)

import crypto from 'node:crypto';
import net from 'node:net';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const ALLOWED_SERVICE_HOST_SUFFIXES = ['.botframework.com', '.trafficmanager.net'];

function isDevWebhookBypassEnabled() {
  return String(process.env.ALLOW_UNVERIFIED_WEBHOOK_DEV || '').trim().toLowerCase() === 'true';
}

function sanitizeTeamsServiceUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  if (parsed.port && parsed.port !== '443') return '';
  if (parsed.search || parsed.hash) return '';

  const host = parsed.hostname.toLowerCase().replace(/\.$/, '');
  if (!host || net.isIP(host) !== 0) return '';
  if (!/^[a-z0-9.-]+$/.test(host) || host.includes('..')) return '';

  const allowed = ALLOWED_SERVICE_HOST_SUFFIXES.some(
    (suffix) => host.length > suffix.length && host.endsWith(suffix)
  );
  if (!allowed) return '';

  const cleanPath = parsed.pathname.replace(/\/+$/, '');
  if (cleanPath.includes('..')) return '';
  return `${parsed.origin}${cleanPath}`;
}

async function getTeamsBotToken(channelCfg = {}) {
  const appId = String(channelCfg.appId || process.env.TEAMS_APP_ID || '').trim();
  const appPassword = String(channelCfg.appPassword || process.env.TEAMS_APP_PASSWORD || '').trim();
  if (!appId || !appPassword) return '';

  const tenant = String(channelCfg.tenantId || process.env.TEAMS_TENANT_ID || 'botframework.com').trim();
  if (!/^[a-zA-Z0-9.-]+$/.test(tenant)) throw new Error('Invalid Teams tenant ID');

  return getCachedToken(
    `teams:${tenant}:${appId}`,
    async () => {
      const url = `https://login.microsoftonline.com/${encodeURIComponent(tenant)}/oauth2/v2.0/token`;
      const res = await fetchWithTimeout(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'client_credentials',
          client_id: appId,
          client_secret: appPassword,
          scope: 'https://api.botframework.com/.default'
        })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.access_token) throw new Error(`Teams OAuth HTTP ${res.status}`);
      return { token: json.access_token, expiresInSec: Number(json.expires_in || 3600) };
    },
    200
  );
}

const teamsAdapter = {
  meta: {
    id: 'teams',
    wave: 'wave3',
    category: 'workplace',
    label: 'Microsoft Teams',
    shortLabel: 'TEAMS',
    badgeColor: '#6264A7',
    badgeBg: 'rgba(98, 100, 167, 0.14)',
    webhookPath: '/webhook/teams',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'appId', label: 'Bot / App ID', type: 'text', secret: false, placeholder: 'Azure Bot App ID', envKey: 'TEAMS_APP_ID' },
      { key: 'tenantId', label: 'Tenant ID (ค่าเริ่มต้น botframework.com)', type: 'text', secret: false, placeholder: 'botframework.com หรือ tenant-id', envKey: 'TEAMS_TENANT_ID' },
      { key: 'appPassword', label: 'Bot App Password / Client Secret', type: 'password', secret: true, placeholder: 'Azure Bot Secret', envKey: 'TEAMS_APP_PASSWORD' },
      { key: 'securityToken', label: 'Outgoing Webhook HMAC Security Token', type: 'password', secret: true, placeholder: 'Base64 HMAC token จาก Teams', envKey: 'TEAMS_SECURITY_TOKEN' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const secToken = String(channelCfg.securityToken || process.env.TEAMS_SECURITY_TOKEN || '').trim();
    if (!secToken) {
      if (isDevWebhookBypassEnabled()) return { valid: true, mode: 'mock_bypass' };
      return { valid: false, reason: 'Missing Teams webhook security token' };
    }

    const auth = String(h.authorization || '').trim();
    if (/^hmac\s+/i.test(auth)) {
      const providedB64 = auth.replace(/^hmac\s+/i, '').trim();
      const keyBuf = Buffer.from(secToken, 'base64');
      const secretKey = keyBuf.length > 0 ? keyBuf : Buffer.from(secToken, 'utf8');
      const payloadBuf = Buffer.isBuffer(rawBuf) ? rawBuf : Buffer.from(String(rawBody || ''), 'utf8');
      const expectedB64 = crypto.createHmac('sha256', secretKey).update(payloadBuf).digest('base64');
      const valid = timingSafeEqualStr(providedB64, expectedB64);
      return { valid, mode: valid ? 'teams_hmac_b64' : undefined, reason: valid ? undefined : 'Invalid Teams HMAC signature' };
    }

    const bearer = /^Bearer\s+/i.test(auth) ? auth.replace(/^Bearer\s+/i, '').trim() : '';
    const candidate = String(h['x-teams-signature'] || bearer || '').trim();
    if (!candidate) return { valid: false, reason: 'Missing Teams authorization header' };
    const ok = timingSafeEqualStr(candidate, secToken);
    return { valid: ok, mode: ok ? 'shared_secret' : undefined, reason: ok ? undefined : 'Invalid Teams token' };
  },

  normalizeInbound(payload = {}, { channelCfg = {} } = {}) {
    if (!payload || typeof payload !== 'object') return [];
    const activityType = String(payload.type || '').trim().toLowerCase();
    if (activityType && activityType !== 'message') return [];

    const fromObj = payload.from || {};
    const fromId = String(fromObj.id || '').trim();
    const fromRole = String(fromObj.role || '').trim().toLowerCase();
    const recipientId = String(payload.recipient?.id || '').trim();
    const ownAppId = String(channelCfg.appId || process.env.TEAMS_APP_ID || '').trim();

    if (fromRole === 'bot' || fromObj.isBot === true) return [];
    if (fromId && recipientId && fromId === recipientId) return [];
    if (ownAppId && fromId && (fromId === ownAppId || fromId === `28:${ownAppId}`)) return [];

    const convId = String(payload.conversation?.id || fromId).trim();
    if (!fromId && !convId) return [];

    const cleanedText = String(payload.text || '')
      .replace(/<at>[\s\S]*?<\/at>/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    const attachments = [];
    let unsupportedMediaType = '';
    let mediaFileName = '';
    for (const att of Array.isArray(payload.attachments) ? payload.attachments : []) {
      const cType = String(att?.contentType || '').toLowerCase();
      const url = String(att?.contentUrl || att?.content?.downloadUrl || '').trim();
      if ((cType.startsWith('image/') || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(url)) && url) {
        attachments.push({ type: 'image', url, mimeType: cType || 'image/png' });
      } else if (url || att?.name) {
        unsupportedMediaType = 'file';
        mediaFileName = mediaFileName || String(att?.name || 'attachment');
      }
    }

    if (!cleanedText && attachments.length === 0 && !unsupportedMediaType) return [];
    const extId = convId || fromId;
    const senderName = String(fromObj.name || `Teams (${(fromId || extId).slice(-6)})`).trim();
    const safeServiceUrl = sanitizeTeamsServiceUrl(payload.serviceUrl || '');

    return [
      buildNormalizedInbound({
        channel: 'teams',
        externalUserId: extId,
        senderName,
        text: cleanedText || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Teams: ${mediaFileName || unsupportedMediaType}]` : ''),
        messageId: String(payload.id || `teams_${extId}_${Date.now()}`),
        attachments,
        replyToken: safeServiceUrl,
        timestamp: Date.parse(payload.timestamp || '') || Date.now(),
        unsupportedMediaType,
        mediaFileName,
        meta: {
          serviceUrl: safeServiceUrl,
          conversationId: convId || extId,
          recipientId
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], replyToken = '', channelCfg = {}, meta = {} }) {
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const cleanText = String(text || '').trim();
    if (!cleanText && mediaUrls.length === 0) throw new Error('Teams reply message cannot be empty');

    const rawServiceUrl = String(replyToken || meta.serviceUrl || '').trim();
    const conversationId = String(meta.conversationId || to || '').replace(/^teams:/i, '').trim();

    if (rawServiceUrl) {
      const safeServiceUrl = sanitizeTeamsServiceUrl(rawServiceUrl);
      if (!safeServiceUrl) {
        throw new Error('Blocked untrusted Teams serviceUrl (must be https://*.botframework.com or https://*.trafficmanager.net)');
      }
      if (!conversationId) throw new Error('Missing Teams conversationId');

      const botToken = await getTeamsBotToken(channelCfg).catch(() => '');
      const url = `${safeServiceUrl}/v3/conversations/${encodeURIComponent(conversationId)}/activities`;
      const headers = { 'Content-Type': 'application/json', ...(botToken ? { Authorization: `Bearer ${botToken}` } : {}) };
      const activity = {
        type: 'message',
        ...(cleanText ? { text: cleanText } : {}),
        ...(mediaUrls.length > 0
          ? { attachments: mediaUrls.map((contentUrl) => ({ contentType: 'image/png', contentUrl })) }
          : {})
      };
      const res = await fetchWithTimeout(url, { method: 'POST', headers, body: JSON.stringify(activity) });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(`Teams Activity HTTP ${res.status}`);
      return { ok: true, platform: 'teams', messageId: String(json?.id || `teams_out_${Date.now()}`), mode: 'bot_activity_v3' };
    }

    return {
      ok: true,
      platform: 'teams',
      messageId: `teams_sync_${Date.now()}`,
      mode: 'outgoing_webhook_response',
      payload: { type: 'message', text: cleanText || mediaUrls[0] || '' }
    };
  }
};

export default teamsAdapter;
