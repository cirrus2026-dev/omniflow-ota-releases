// gateway/src/modules/channels/google-chat-adapter.mjs
// Wave 3 Adapter: Google Chat Bot REST API (Strict Token Auth + SSRF-Guarded OAuth/REST + cardsV2 Images)

import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  signJwtRs256,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const GCHAT_SCOPE = 'https://www.googleapis.com/auth/chat.bot';
const GCHAT_TOKEN_URL = 'https://oauth2.googleapis.com/token';
const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

function validateSafeHttpsUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return '';
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

async function getGoogleChatToken(channelCfg = {}) {
  const rawSa = String(channelCfg.serviceAccountJson || process.env.GCHAT_SERVICE_ACCOUNT_JSON || '').trim();
  if (!rawSa) return '';
  const sa = JSON.parse(rawSa);
  if (!sa.client_email || !sa.private_key) throw new Error('Invalid Google Chat Service Account JSON');

  const tokenUri = validateSafeHttpsUrl(sa.token_uri || GCHAT_TOKEN_URL);
  if (!tokenUri) throw new Error('Blocked unsafe Google Chat OAuth token_uri (must be public HTTPS)');

  return getCachedToken(
    `gchat:${sa.client_email}`,
    async () => {
      const nowSec = Math.floor(Date.now() / 1000);
      const assertion = signJwtRs256({
        payload: { iss: sa.client_email, scope: GCHAT_SCOPE, aud: tokenUri, iat: nowSec, exp: nowSec + 3600 },
        privateKey: sa.private_key
      });
      const res = await fetchWithTimeout(tokenUri, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.access_token) throw new Error(`Google Chat OAuth HTTP ${res.status}`);
      return { token: json.access_token, expiresInSec: Number(json.expires_in || 3599) };
    },
    300
  );
}

const googleChatAdapter = {
  meta: {
    id: 'google_chat',
    wave: 'wave3',
    category: 'workplace',
    label: 'Google Chat',
    shortLabel: 'GCHAT',
    badgeColor: '#00AC47',
    badgeBg: 'rgba(0, 172, 71, 0.14)',
    webhookPath: '/webhook/google_chat',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'projectNumber', label: 'Google Cloud Project Number', type: 'text', secret: false, placeholder: '123456789012', envKey: 'GCHAT_PROJECT_NUMBER' },
      { key: 'verificationToken', label: 'Webhook Verification Token', type: 'password', secret: true, placeholder: 'Token จาก Google Chat Bot Config', envKey: 'GCHAT_VERIFICATION_TOKEN' },
      { key: 'serviceAccountJson', label: 'Service Account JSON (สำหรับส่งข้อความออกผ่าน REST API)', type: 'textarea', secret: true, placeholder: '{"client_email":"...","private_key":"-----BEGIN PRIVATE KEY-----..."}', envKey: 'GCHAT_SERVICE_ACCOUNT_JSON' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, parsedUrl, channelCfg = {} }) {
    const expected = String(channelCfg.verificationToken || process.env.GCHAT_VERIFICATION_TOKEN || '').trim();
    if (!expected) return { valid: false, reason: 'Missing Google Chat verificationToken configuration' };

    const h = normalizeHeaders(headers);
    const bearer = (h.authorization || '').replace(/^Bearer\s+/i, '').trim();
    const candidate = h['x-goog-chat-token'] || h['x-verification-token'] || parsedUrl?.searchParams?.get('token') || bearer;
    if (!candidate) return { valid: false, reason: 'Missing Google Chat verification token' };

    const valid = timingSafeEqualStr(candidate, expected);
    return { valid, mode: valid ? 'bearer_or_token' : undefined, reason: valid ? undefined : 'Invalid Google Chat token' };
  },

  normalizeInbound(payload = {}) {
    if (!payload || typeof payload !== 'object') return [];
    const evtType = String(payload.type || '').toUpperCase();
    if (evtType === 'ADDED_TO_SPACE' || evtType === 'REMOVED_FROM_SPACE') return [];

    const msg = payload.message || {};
    const sender = msg.sender || payload.user || {};
    const senderType = String(sender.type || '').toUpperCase();
    if (senderType === 'BOT') return [];

    const rawUser = String(sender.name || sender.email || payload.user?.name || '').trim();
    const spaceName = String(msg.space?.name || payload.space?.name || '').trim();
    const extId = spaceName || rawUser;
    if (!extId) return [];

    const rawBody = String(msg.argumentText || msg.text || payload.text || '').trim();
    const cleanText = rawBody.replace(/^@\S+\s*/g, '').trim();

    const attachments = [];
    let unsupportedMediaType = '';
    let mediaFileName = '';
    for (const att of Array.isArray(msg.attachment) ? msg.attachment : []) {
      const mime = String(att?.contentType || '').toLowerCase();
      const url = String(att?.downloadUri || att?.thumbnailUri || '').trim();
      if (mime.startsWith('image/') && url) {
        attachments.push({ type: 'image', url, mimeType: mime });
      } else if (url || att?.name) {
        unsupportedMediaType = 'file';
        mediaFileName = mediaFileName || String(att?.name || 'attachment');
      }
    }

    if (!cleanText && attachments.length === 0 && !unsupportedMediaType) return [];
    const senderName = String(sender.displayName || `GChat (${rawUser.split('/').pop().slice(-6) || 'User'})`).trim();

    return [
      buildNormalizedInbound({
        channel: 'google_chat',
        externalUserId: extId,
        senderName,
        text: cleanText || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Google Chat: ${mediaFileName || unsupportedMediaType}]` : ''),
        messageId: String(msg.name || `gchat_${Date.now()}`),
        attachments,
        replyToken: String(msg.thread?.name || ''),
        timestamp: Date.parse(msg.createTime || payload.eventTime || '') || Date.now(),
        unsupportedMediaType,
        mediaFileName,
        meta: { spaceName, threadName: String(msg.thread?.name || '') }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], replyToken = '', channelCfg = {}, meta = {} }) {
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const cleanText = String(text || '').trim();
    if (!cleanText && mediaUrls.length === 0) throw new Error('Google Chat reply cannot be empty');

    const token = await getGoogleChatToken(channelCfg).catch(() => '');
    const space = String(meta.spaceName || to || '').replace(/^google_chat:/i, '').trim();
    const spacePath = space.startsWith('spaces/') ? space : space ? `spaces/${space}` : '';

    if (token && spacePath) {
      const url = validateSafeHttpsUrl(`https://chat.googleapis.com/v1/${spacePath}/messages`);
      if (!url) throw new Error('Blocked unsafe Google Chat API URL');
      const threadName = String(replyToken || meta.threadName || '').trim();
      const cardsV2 = mediaUrls.map((imageUrl, idx) => ({
        cardId: `card_${idx}`,
        card: {
          sections: [{ widgets: [{ image: { imageUrl, altText: 'Product preview' } }] }]
        }
      }));
      const body = {
        ...(cleanText ? { text: cleanText.slice(0, 4096) } : {}),
        ...(cardsV2.length > 0 ? { cardsV2 } : {}),
        ...(threadName ? { thread: { name: threadName } } : {})
      };
      const res = await fetchWithTimeout(url, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(`Google Chat Send HTTP ${res.status}`);
      return { ok: true, platform: 'google_chat', messageId: String(json?.name || `gchat_out_${Date.now()}`), mode: 'chat_rest_v1' };
    }

    return {
      ok: true,
      platform: 'google_chat',
      messageId: `gchat_sync_${Date.now()}`,
      mode: 'webhook_response',
      payload: { text: cleanText || mediaUrls[0] || '' }
    };
  }
};

export default googleChatAdapter;
