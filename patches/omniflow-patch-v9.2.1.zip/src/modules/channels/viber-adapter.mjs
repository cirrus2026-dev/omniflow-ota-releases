// gateway/src/modules/channels/viber-adapter.mjs
// Wave 2 Adapter: Viber Bot REST API (HMAC-SHA256 + Webhook Handshake + Text/Picture Dispatch)

import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const VIBER_SEND_URL = 'https://chatapi.viber.com/pa/send_message';

const viberAdapter = {
  meta: {
    id: 'viber',
    wave: 'wave2',
    category: 'messaging',
    label: 'Viber Bot',
    shortLabel: 'VIBER',
    badgeColor: '#7360F2',
    badgeBg: 'rgba(115, 96, 242, 0.14)',
    webhookPath: '/webhook/viber',
    supportsImages: true,
    supportsChallenge: true,
    fields: [
      { key: 'senderName', label: 'ชื่อผู้ส่งบอท (Sender Name ≤ 28 ตัวอักษร)', type: 'text', secret: false, placeholder: 'OmniFlow Support', envKey: 'VIBER_SENDER_NAME' },
      { key: 'senderAvatarUrl', label: 'URL รูปโปรไฟล์บอท (ไม่บังคับ)', type: 'url', secret: false, placeholder: 'https://yourdomain.com/logo.jpg', envKey: 'VIBER_SENDER_AVATAR_URL' },
      { key: 'authToken', label: 'Viber Bot Auth Token', type: 'password', secret: true, required: true, placeholder: 'X-Viber-Auth-Token', envKey: 'VIBER_AUTH_TOKEN' }
    ]
  },

  handleChallenge(req, _channelCfg = {}, _parsedUrl, payload = {}) {
    if (req.method === 'POST' && String(payload?.event || '').toLowerCase() === 'webhook') {
      return {
        isChallenge: true,
        status: 200,
        contentType: 'application/json; charset=utf-8',
        response: { status: 0, status_message: 'ok' }
      };
    }
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', parsedUrl, channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const token = String(channelCfg.authToken || process.env.VIBER_AUTH_TOKEN || '').trim();
    const signature = h['x-viber-content-signature'] || parsedUrl?.searchParams?.get('sig') || '';
    return verifyHmacTimingSafe({
      rawBody: rawBuf || rawBody,
      secret: token,
      signature,
      encoding: 'hex'
    });
  },

  normalizeInbound(payload = {}) {
    if (String(payload?.event || '').toLowerCase() !== 'message') return [];
    const sender = payload.sender || {};
    const msg = payload.message || {};
    const senderId = String(sender.id || '').trim();
    if (!senderId) return [];

    const msgType = String(msg.type || 'text').toLowerCase();
    const attachments = [];
    let text = String(msg.text || '').trim();
    let unsupportedMediaType = '';
    let mediaFileName = '';

    if (msgType === 'picture' && msg.media) {
      attachments.push({ type: 'image', url: String(msg.media) });
    } else if (msgType === 'sticker') {
      text = text || '[ส่งสติกเกอร์]';
    } else if (['file', 'video', 'location', 'contact'].includes(msgType)) {
      unsupportedMediaType = msgType === 'contact' ? 'file' : msgType;
      mediaFileName = String(msg.file_name || '');
      text = text || `[ลูกค้าส่งสื่อทาง Viber: ${mediaFileName || msgType}]`;
    }

    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];

    return [
      buildNormalizedInbound({
        channel: 'viber',
        externalUserId: senderId,
        senderName: String(sender.name || `Viber (${senderId.slice(-6)})`).trim(),
        text,
        messageId: String(payload.message_token || `viber_${senderId}_${Date.now()}`),
        attachments,
        timestamp: Number(payload.timestamp || Date.now()),
        unsupportedMediaType,
        mediaFileName,
        meta: {
          senderAvatar: sender.avatar || '',
          language: sender.language || '',
          country: sender.country || ''
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, businessName = '' }) {
    const authToken = String(channelCfg.authToken || process.env.VIBER_AUTH_TOKEN || '').trim();
    if (!authToken) throw new Error('Missing Viber Auth Token');
    const receiver = String(to || '').replace(/^viber:/i, '').trim();
    if (!receiver) throw new Error('Missing Viber receiver ID');

    const senderObj = {
      name: String(channelCfg.senderName || process.env.VIBER_SENDER_NAME || businessName || 'OmniFlow').trim().slice(0, 28)
    };
    const avatar = String(channelCfg.senderAvatarUrl || process.env.VIBER_SENDER_AVATAR_URL || '').trim();
    if (/^https?:\/\//i.test(avatar)) senderObj.avatar = avatar;

    const headers = { 'X-Viber-Auth-Token': authToken, 'Content-Type': 'application/json' };
    let lastMsgToken = '';

    const cleanText = String(text || '').trim();
    if (cleanText) {
      const res = await fetchWithTimeout(VIBER_SEND_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify({ receiver, min_api_version: 1, sender: senderObj, type: 'text', text: cleanText.slice(0, 7000) })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || (json.status !== undefined && json.status !== 0)) {
        throw new Error(`Viber Send Error (${json.status ?? res.status}): ${json.status_message || ''}`);
      }
      lastMsgToken = String(json.message_token || '');
    }

    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    for (const url of mediaUrls) {
      const picRes = await fetchWithTimeout(VIBER_SEND_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify({ receiver, min_api_version: 1, sender: senderObj, type: 'picture', text: '', media: url })
      });
      const picJson = await picRes.json().catch(() => ({}));
      if (picRes.ok && picJson.status === 0 && !lastMsgToken) {
        lastMsgToken = String(picJson.message_token || '');
      }
    }

    return { ok: true, platform: 'viber', messageId: lastMsgToken || `viber_out_${Date.now()}`, mode: 'viber_pa_api' };
  }
};

export default viberAdapter;
