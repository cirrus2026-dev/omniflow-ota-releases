// gateway/src/modules/channels/dingtalk-adapter.mjs
// Wave 3 Adapter: DingTalk Robot Webhook & OpenAPI (Strict HMAC + SSRF-Guarded sessionWebhook Markdown Reply)

import crypto from 'node:crypto';
import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const DINGTALK_OPEN_BASE = 'https://api.dingtalk.com';
const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

function validateSafeHttpsUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return '';
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

async function getDingTalkToken(channelCfg = {}) {
  const appKey = String(channelCfg.appKey || process.env.DINGTALK_APP_KEY || '').trim();
  const appSecret = String(channelCfg.appSecret || process.env.DINGTALK_APP_SECRET || '').trim();
  if (!appKey || !appSecret) throw new Error('Missing DingTalk AppKey or AppSecret');

  return getCachedToken(
    `dingtalk:${appKey}`,
    async () => {
      const res = await fetchWithTimeout(`${DINGTALK_OPEN_BASE}/v1.0/oauth2/accessToken`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ appKey, appSecret })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.accessToken) throw new Error(`DingTalk OAuth HTTP ${res.status}`);
      return { token: json.accessToken, expiresInSec: Number(json.expireIn || 7200) };
    },
    300
  );
}

const dingtalkAdapter = {
  meta: {
    id: 'dingtalk',
    wave: 'wave3',
    category: 'workplace',
    label: 'DingTalk Robot',
    shortLabel: 'DINGTALK',
    badgeColor: '#007FFF',
    badgeBg: 'rgba(0, 127, 255, 0.14)',
    webhookPath: '/webhook/dingtalk',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'appKey', label: 'App Key / Client ID', type: 'text', secret: false, required: true, placeholder: 'DingTalk AppKey', envKey: 'DINGTALK_APP_KEY' },
      { key: 'robotCode', label: 'Robot Code', type: 'text', secret: false, placeholder: 'DingTalk RobotCode', envKey: 'DINGTALK_ROBOT_CODE' },
      { key: 'appSecret', label: 'App Secret', type: 'password', secret: true, required: true, placeholder: 'ใช้ตรวจ sign และขอ Access Token', envKey: 'DINGTALK_APP_SECRET' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, parsedUrl, channelCfg = {} }) {
    const secret = String(channelCfg.appSecret || process.env.DINGTALK_APP_SECRET || '').trim();
    if (!secret) return { valid: false, reason: 'Missing DingTalk appSecret configuration' };

    const h = normalizeHeaders(headers);
    const tsRaw = h.timestamp || parsedUrl?.searchParams?.get('timestamp') || '';
    const sign = h.sign || parsedUrl?.searchParams?.get('sign') || '';
    const tsMs = Number(tsRaw);
    if (!Number.isFinite(tsMs) || Math.abs(Date.now() - tsMs) > 3600000) {
      return { valid: false, reason: 'DingTalk timestamp expired (>1 hour)' };
    }
    if (!sign) return { valid: false, reason: 'Missing DingTalk sign parameter' };

    const expected = crypto.createHmac('sha256', secret).update(`${tsRaw}\n${secret}`, 'utf8').digest('base64');
    const valid = timingSafeEqualStr(sign, expected);
    return { valid, mode: valid ? 'dingtalk_hmac_b64' : undefined, reason: valid ? undefined : 'Invalid DingTalk sign' };
  },

  normalizeInbound(payload = {}) {
    if (!payload || typeof payload !== 'object') return [];
    const senderId = String(payload.senderStaffId || payload.senderId || '').trim();
    const convId = String(payload.conversationId || senderId).trim();
    if (!senderId && !convId) return [];

    const msgType = String(payload.msgtype || 'text').toLowerCase();
    const rawText = String(payload.text?.content || payload.content?.text || payload.text || '').trim();
    const downloadCode = String(payload.content?.downloadCode || '').trim();

    const attachments = [];
    let unsupportedMediaType = '';
    if (downloadCode || msgType === 'picture') {
      attachments.push({ type: 'image', mediaId: downloadCode || 'dingtalk_img' });
    } else if (['file', 'audio', 'video'].includes(msgType)) {
      unsupportedMediaType = msgType;
    }

    if (!rawText && attachments.length === 0 && !unsupportedMediaType) return [];
    const extId = convId || senderId;
    const sessionWebhook = validateSafeHttpsUrl(payload.sessionWebhook || '');

    return [
      buildNormalizedInbound({
        channel: 'dingtalk',
        externalUserId: extId,
        senderName: String(payload.senderNick || `DingTalk (${(senderId || extId).slice(-6)})`).trim(),
        text: rawText || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง DingTalk: ${unsupportedMediaType}]` : '[ลูกค้าส่งรูปภาพทาง DingTalk]'),
        messageId: String(payload.msgId || `dt_${extId}_${Date.now()}`),
        attachments,
        replyToken: sessionWebhook,
        timestamp: Number(payload.createAt || Date.now()),
        unsupportedMediaType,
        meta: {
          sessionWebhook,
          sessionWebhookExpiredTime: Number(payload.sessionWebhookExpiredTime || 0),
          conversationId: convId || extId,
          senderStaffId: senderId
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], replyToken = '', channelCfg = {}, businessName = '', meta = {} }) {
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const cleanText = String(text || '').trim();
    if (!cleanText && mediaUrls.length === 0) throw new Error('DingTalk reply cannot be empty');

    const mdLines = [];
    if (cleanText) mdLines.push(cleanText);
    for (const url of mediaUrls) mdLines.push(`![preview](${url})`);
    const mdText = mdLines.join('\n\n');

    const rawHookUrl = String(replyToken || meta.sessionWebhook || '').trim();
    const hookUrl = validateSafeHttpsUrl(rawHookUrl);
    const notExpired = !meta.sessionWebhookExpiredTime || Date.now() < Number(meta.sessionWebhookExpiredTime) - 5000;
    if (rawHookUrl && !hookUrl) {
      throw new Error('Blocked unsafe DingTalk sessionWebhook URL (must be public HTTPS)');
    }
    if (hookUrl && notExpired) {
      const res = await fetchWithTimeout(hookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ msgtype: 'markdown', markdown: { title: businessName || 'OmniFlow', text: mdText } })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || (json.errcode !== undefined && json.errcode !== 0)) {
        throw new Error(`DingTalk sessionWebhook HTTP ${res.status}`);
      }
      return { ok: true, platform: 'dingtalk', messageId: `dt_hook_${Date.now()}`, mode: 'session_webhook' };
    }

    const token = await getDingTalkToken(channelCfg);
    const robotCode = String(channelCfg.robotCode || process.env.DINGTALK_ROBOT_CODE || '').trim();
    const convId = String(meta.conversationId || to || '').replace(/^dingtalk:/i, '').trim();
    if (!robotCode || !convId) throw new Error('Missing DingTalk sessionWebhook or robotCode/conversationId');

    const res = await fetchWithTimeout(`${DINGTALK_OPEN_BASE}/v1.0/robot/groupMessages/send`, {
      method: 'POST',
      headers: { 'x-acs-dingtalk-access-token': token, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        msgParam: JSON.stringify({ title: businessName || 'OmniFlow', text: mdText }),
        msgKey: 'sampleMarkdown',
        openConversationId: convId,
        robotCode
      })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`DingTalk OpenAPI HTTP ${res.status}`);
    return { ok: true, platform: 'dingtalk', messageId: String(json?.processQueryKey || `dt_api_${Date.now()}`), mode: 'openapi_v1' };
  }
};

export default dingtalkAdapter;
