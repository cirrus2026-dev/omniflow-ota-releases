// gateway/src/modules/channels/wechat-adapter.mjs
// Wave 1 Adapter: WeChat Official Account (Strict SHA1 Verify + Zero-Dep XML Parser + Cached Access Token)

import {
  verifySha1SortedTokens,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

function extractXmlTag(xml = '', tagName = '') {
  const re = new RegExp(`<${tagName}>\\s*(?:<!\\[CDATA\\[([\\s\\S]*?)\\]\\]>|([^<]*))\\s*</${tagName}>`, 'i');
  const m = String(xml || '').match(re);
  return m ? String(m[1] ?? m[2] ?? '').trim() : '';
}

async function getWeChatAccessToken(channelCfg = {}) {
  const appId = String(channelCfg.appId || process.env.WECHAT_APP_ID || '').trim();
  const appSecret = String(channelCfg.appSecret || process.env.WECHAT_APP_SECRET || '').trim();
  if (!appId || !appSecret) throw new Error('Missing WeChat AppID or AppSecret');

  return getCachedToken(
    `wechat:${appId}`,
    async () => {
      const url = `https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=${encodeURIComponent(appId)}&secret=${encodeURIComponent(appSecret)}`;
      const res = await fetchWithTimeout(url, { method: 'GET' });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.access_token) {
        throw new Error(`WeChat Token Error (${json.errcode || res.status}): ${json.errmsg || ''}`);
      }
      return { token: json.access_token, expiresInSec: Number(json.expires_in || 7200) };
    },
    300
  );
}

const wechatAdapter = {
  meta: {
    id: 'wechat',
    wave: 'wave1',
    category: 'messaging',
    label: 'WeChat Official Account',
    shortLabel: 'WECHAT',
    badgeColor: '#07C160',
    badgeBg: 'rgba(7, 193, 96, 0.14)',
    webhookPath: '/webhook/wechat',
    supportsImages: true,
    supportsChallenge: true,
    fields: [
      { key: 'appId', label: 'WeChat AppID', type: 'text', secret: false, required: true, placeholder: 'wx1234567890abcdef', envKey: 'WECHAT_APP_ID' },
      { key: 'verifyToken', label: 'Webhook Token', type: 'text', secret: false, required: true, placeholder: 'Token ใน WeChat MP', envKey: 'WECHAT_VERIFY_TOKEN' },
      { key: 'appSecret', label: 'WeChat AppSecret', type: 'password', secret: true, required: true, placeholder: 'AppSecret', envKey: 'WECHAT_APP_SECRET' },
      { key: 'encodingAesKey', label: 'EncodingAESKey (ถ้าเปิดโหมดเข้ารหัส)', type: 'password', secret: true, placeholder: 'Optional 43-char key', envKey: 'WECHAT_ENCODING_AES_KEY' }
    ]
  },

  handleChallenge(req, channelCfg = {}, parsedUrl) {
    if (req.method !== 'GET' || !parsedUrl) return { isChallenge: false };
    const token = String(channelCfg.verifyToken || process.env.WECHAT_VERIFY_TOKEN || '').trim();
    const signature = parsedUrl.searchParams.get('signature') || '';
    const timestamp = parsedUrl.searchParams.get('timestamp') || '';
    const nonce = parsedUrl.searchParams.get('nonce') || '';
    const echostr = parsedUrl.searchParams.get('echostr') || '';
    if (!token || !echostr) return { isChallenge: false };

    const check = verifySha1SortedTokens({ tokens: [token, timestamp, nonce], signature });
    if (check.valid) {
      return { isChallenge: true, status: 200, contentType: 'text/plain; charset=utf-8', response: echostr };
    }
    return { isChallenge: false };
  },

  verifySignature({ parsedUrl, channelCfg = {} }) {
    const token = String(channelCfg.verifyToken || process.env.WECHAT_VERIFY_TOKEN || '').trim();
    if (!token) return { valid: false, reason: 'Missing WeChat verifyToken configuration' };
    const signature = parsedUrl?.searchParams?.get('signature') || '';
    const timestamp = parsedUrl?.searchParams?.get('timestamp') || '';
    const nonce = parsedUrl?.searchParams?.get('nonce') || '';
    return verifySha1SortedTokens({ tokens: [token, timestamp, nonce], signature });
  },

  normalizeInbound(payload = {}, { rawBody = '' } = {}) {
    const isXml = typeof rawBody === 'string' && rawBody.trim().startsWith('<');
    const getField = (xmlTag, jsonKey) =>
      isXml ? extractXmlTag(rawBody, xmlTag) : String(payload?.[xmlTag] ?? payload?.[jsonKey] ?? '').trim();

    const msgType = getField('MsgType', 'msgType').toLowerCase();
    const fromUser = getField('FromUserName', 'fromUser');
    if (!fromUser || msgType === 'event') return [];

    const toUser = getField('ToUserName', 'toUser');
    const msgId = getField('MsgId', 'msgId') || `wx_${fromUser}_${Date.now()}`;
    const createTime = Number(getField('CreateTime', 'createTime')) || Math.floor(Date.now() / 1000);
    const attachments = [];
    let text = '';
    let unsupportedMediaType = '';

    if (msgType === 'text' || !msgType) {
      text = getField('Content', 'text');
    } else if (msgType === 'image') {
      const picUrl = getField('PicUrl', 'picUrl');
      const mediaId = getField('MediaId', 'mediaId');
      if (picUrl) attachments.push({ type: 'image', url: picUrl, mediaId });
    } else if (['voice', 'video', 'shortvideo', 'location', 'file'].includes(msgType)) {
      unsupportedMediaType = msgType === 'voice' ? 'audio' : msgType === 'shortvideo' ? 'video' : msgType;
      text = `[ลูกค้าส่งสื่อทาง WeChat: ${msgType}]`;
    }

    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];

    return [
      buildNormalizedInbound({
        channel: 'wechat',
        externalUserId: fromUser,
        senderName: `WeChat (${fromUser.slice(-6)})`,
        text,
        messageId: msgId,
        attachments,
        timestamp: createTime,
        unsupportedMediaType,
        meta: { toUser, msgType }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, businessName = '' }) {
    const token = await getWeChatAccessToken(channelCfg);
    const endpoint = `https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=${encodeURIComponent(token)}`;
    const cleanText = String(text || '').trim();

    if (cleanText) {
      const res = await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ touser: to, msgtype: 'text', text: { content: cleanText.slice(0, 2000) } })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || (json.errcode && json.errcode !== 0)) {
        throw new Error(`WeChat Send Error (${json.errcode || res.status}): ${json.errmsg || ''}`);
      }
    }

    const mediaUrls = resolvePublicMediaUrls(images);
    if (mediaUrls.length > 0) {
      await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          touser: to,
          msgtype: 'news',
          news: {
            articles: mediaUrls.slice(0, 4).map((url, idx) => ({
              title: `${businessName || 'OmniFlow'} — ตัวอย่างสินค้า #${idx + 1}`,
              description: 'คลิกเพื่อดูภาพขนาดเต็ม',
              url,
              picurl: url
            }))
          }
        })
      });
    }

    return { ok: true, platform: 'wechat', messageId: `wx_out_${Date.now()}`, mode: 'customer_service_api' };
  }
};

export default wechatAdapter;
