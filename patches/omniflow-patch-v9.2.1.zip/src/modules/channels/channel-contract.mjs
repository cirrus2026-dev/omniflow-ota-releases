// gateway/src/modules/channels/channel-contract.mjs
// Zero-Dependency Omnichannel Standard Contract & Shared Crypto/Token Utilities

import crypto from 'node:crypto';
import net from 'node:net';
import { fetchSafe, isPrivateOrReservedIp } from '../fetch-safe.mjs';

export const CHANNEL_INTERFACE_METHODS = [
  'handleChallenge',
  'verifySignature',
  'normalizeInbound',
  'sendReply'
];

const ED25519_SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');
const MAX_TOKEN_CACHE_ENTRIES = 200;
const BLOCKED_MEDIA_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);
const tokenCacheStore = new Map();

function isDevBypass() {
  return String(process.env.ALLOW_UNVERIFIED_WEBHOOK_DEV || '').trim().toLowerCase() === 'true';
}

export function normalizeHeaders(headers = {}) {
  const out = {};
  for (const [k, v] of Object.entries(headers || {})) {
    out[String(k).toLowerCase()] = Array.isArray(v) ? v.join(',') : String(v ?? '').trim();
  }
  return out;
}

export function timingSafeEqualStr(a = '', b = '') {
  const bufA = Buffer.from(String(a || ''), 'utf8');
  const bufB = Buffer.from(String(b || ''), 'utf8');
  if (bufA.length === 0 || bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

export function readRawBody(req, maxBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const err413 = () => Object.assign(new Error('Payload too large'), { statusCode: 413 });
    if (Number(req.headers?.['content-length'] || 0) > maxBytes) {
      req.destroy();
      return reject(err413());
    }
    const chunks = [];
    let total = 0;
    let settled = false;
    const fail = (err) => {
      if (settled) return;
      settled = true;
      chunks.length = 0;
      reject(err);
    };
    req.on('data', (chunk) => {
      if (settled) return;
      total += chunk.length;
      if (total > maxBytes) {
        fail(err413());
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      resolve(Buffer.concat(chunks));
    });
    req.on('aborted', () => fail(Object.assign(new Error('Request aborted'), { statusCode: 400 })));
    req.on('error', fail);
  });
}

export function verifyHmacTimingSafe({
  rawBody = '',
  secret = '',
  signature = '',
  encoding = 'hex',
  prefix = '',
  algorithm = 'sha256',
  baseString = null,
  allowMockBypass = isDevBypass()
} = {}) {
  const key = String(secret || '').trim();
  if (!key) {
    return allowMockBypass
      ? { valid: true, mode: 'mock_bypass' }
      : { valid: false, reason: 'Missing webhook signing secret' };
  }
  const rawSig = String(signature || '').trim();
  if (!rawSig) return { valid: false, reason: 'Missing signature header' };

  const cleanSig = prefix && rawSig.toLowerCase().startsWith(prefix.toLowerCase())
    ? rawSig.slice(prefix.length).trim()
    : rawSig;
  const payload = baseString !== null && baseString !== undefined ? baseString : rawBody;
  const digest = crypto.createHmac(algorithm, key).update(payload).digest(encoding);
  const valid = timingSafeEqualStr(cleanSig, digest);
  return { valid, mode: valid ? `hmac_${algorithm}` : undefined, reason: valid ? undefined : 'Invalid HMAC signature' };
}

export function verifySha1SortedTokens({ tokens = [], signature = '' } = {}) {
  const cleanSig = String(signature || '').trim().toLowerCase();
  if (!cleanSig) return { valid: false, reason: 'Missing SHA1 signature' };
  const joined = tokens.map((t) => String(t ?? '')).sort().join('');
  const expected = crypto.createHash('sha1').update(joined, 'utf8').digest('hex');
  const valid = timingSafeEqualStr(cleanSig, expected);
  return { valid, mode: valid ? 'sha1_sorted' : undefined, reason: valid ? undefined : 'Invalid SHA1 signature' };
}

export function verifyEd25519Signature({ timestamp = '', rawBody = '', signatureHex = '', publicKeyHex = '', maxSkewSec = 300 } = {}) {
  const pubHex = String(publicKeyHex || '').trim();
  const sigHex = String(signatureHex || '').trim();
  const ts = String(timestamp || '').trim();
  if (!pubHex || !sigHex || !ts) return { valid: false, reason: 'Missing Ed25519 signature parameters' };
  const tsSec = Number(ts);
  if (!Number.isFinite(tsSec) || Math.abs(Math.floor(Date.now() / 1000) - tsSec) > maxSkewSec) {
    return { valid: false, reason: `Ed25519 timestamp outside ${maxSkewSec}s replay window` };
  }
  if (!/^[0-9a-f]{64}$/i.test(pubHex) || !/^[0-9a-f]{128}$/i.test(sigHex)) {
    return { valid: false, reason: 'Invalid Ed25519 key or signature length' };
  }
  try {
    const rawKey = Buffer.from(pubHex, 'hex');
    const sigBuf = Buffer.from(sigHex, 'hex');
    const pubKey = crypto.createPublicKey({ key: Buffer.concat([ED25519_SPKI_PREFIX, rawKey]), format: 'der', type: 'spki' });
    const bodyBuf = Buffer.isBuffer(rawBody) ? rawBody : Buffer.from(String(rawBody || ''), 'utf8');
    const msgBuf = Buffer.concat([Buffer.from(ts, 'utf8'), bodyBuf]);
    const valid = crypto.verify(null, msgBuf, pubKey, sigBuf);
    return { valid, mode: valid ? 'ed25519' : undefined, reason: valid ? undefined : 'Invalid Ed25519 signature' };
  } catch (err) {
    return { valid: false, reason: `Ed25519 verify error: ${err.message}` };
  }
}

export function signJwtRs256({ header = { alg: 'RS256', typ: 'JWT' }, payload = {}, privateKey = '' } = {}) {
  if (!privateKey) throw new Error('Missing RSA private key');
  const h64 = Buffer.from(JSON.stringify(header)).toString('base64url');
  const p64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const unsigned = `${h64}.${p64}`;
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(unsigned);
  return `${unsigned}.${signer.sign(privateKey, 'base64url')}`;
}

function normalizeCacheKey(cacheKey) {
  if (Array.isArray(cacheKey)) {
    const parts = cacheKey.map((p) => String(p ?? '').trim());
    return parts.some(Boolean) ? JSON.stringify(parts) : '';
  }
  return String(cacheKey ?? '').trim();
}

function pruneTokenCache(now = Date.now()) {
  for (const [k, entry] of tokenCacheStore) {
    if (!entry.inflightPromise && entry.expiresAt <= now) tokenCacheStore.delete(k);
  }
  while (tokenCacheStore.size >= MAX_TOKEN_CACHE_ENTRIES) {
    const oldestKey = tokenCacheStore.keys().next().value;
    if (oldestKey === undefined) break;
    tokenCacheStore.delete(oldestKey);
  }
}

export async function getCachedToken(cacheKey, fetcherFn, refreshBufferSec = 120) {
  const key = normalizeCacheKey(cacheKey);
  if (!key) throw new Error('Missing token cache key');
  const now = Date.now();
  const entry = tokenCacheStore.get(key);
  if (entry?.token && entry.expiresAt > now) {
    tokenCacheStore.delete(key);
    tokenCacheStore.set(key, entry);
    return entry.token;
  }
  if (entry?.inflightPromise) return entry.inflightPromise;

  pruneTokenCache(now);
  const inflightPromise = Promise.resolve()
    .then(() => fetcherFn())
    .then((res) => {
      const token = String(res?.token || res?.access_token || res?.tenant_access_token || '').trim();
      const ttlSec = Math.max(60, Number(res?.expiresInSec || res?.expires_in || res?.expire || 3600));
      if (!token) throw new Error(`Empty token returned for ${key}`);
      const expiresAt = Date.now() + Math.max(30, ttlSec - refreshBufferSec) * 1000;
      if (tokenCacheStore.get(key)?.inflightPromise === inflightPromise) {
        tokenCacheStore.set(key, { token, expiresAt, inflightPromise: null });
      }
      return token;
    })
    .catch((err) => {
      if (tokenCacheStore.get(key)?.inflightPromise === inflightPromise) tokenCacheStore.delete(key);
      throw err;
    });

  tokenCacheStore.set(key, { token: '', expiresAt: 0, inflightPromise });
  return inflightPromise;
}

export function clearCachedToken(cacheKey) {
  if (cacheKey === undefined) {
    tokenCacheStore.clear();
    return true;
  }
  const key = normalizeCacheKey(cacheKey);
  return key ? tokenCacheStore.delete(key) : false;
}

function isPublicHttpUrl(rawUrl) {
  try {
    const parsed = new URL(String(rawUrl || '').trim());
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return false;
    if (parsed.username || parsed.password) return false;
    const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
    if (!host || BLOCKED_MEDIA_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return false;
    if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return false;
    return true;
  } catch {
    return false;
  }
}

export function resolvePublicMediaUrls(images = [], publicBaseUrl = '') {
  const cleanBase = String(publicBaseUrl || process.env.PUBLIC_BASE_URL || '').trim().replace(/\/+$/, '');
  const usableBase = cleanBase && isPublicHttpUrl(cleanBase) ? cleanBase : '';
  const urls = [];
  for (const img of Array.isArray(images) ? images : []) {
    const raw = String(typeof img === 'string' ? img : img?.url || '').trim();
    if (!raw) continue;
    if (/^https?:\/\//i.test(raw)) {
      if (isPublicHttpUrl(raw)) urls.push(raw);
    } else if (raw.startsWith('/') && !raw.startsWith('//') && usableBase) {
      const joined = `${usableBase}${raw}`;
      if (isPublicHttpUrl(joined)) urls.push(joined);
    }
  }
  return [...new Set(urls)];
}

export function fetchWithTimeout(url, options = {}, timeoutMs = 12000) {
  const { timeoutMs: optTimeout, allowHttp = false, ...rest } = options || {};
  return fetchSafe(url, { ...rest, allowHttp, timeoutMs: optTimeout ?? timeoutMs });
}

function normalizeTimestamp(input) {
  if (input === undefined || input === null || input === '') return Date.now();
  if (input instanceof Date) {
    const ms = input.getTime();
    return Number.isFinite(ms) && ms > 0 ? ms : Date.now();
  }
  if (typeof input === 'string' && !/^-?\d+(?:\.\d+)?$/.test(input.trim())) {
    const parsed = Date.parse(input);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : Date.now();
  }
  const n = Number(input);
  if (!Number.isFinite(n) || n <= 0) return Date.now();
  if (n >= 1e17) return Math.floor(n / 1e6);
  if (n >= 1e14) return Math.floor(n / 1e3);
  return n < 1e11 ? Math.round(n * 1000) : Math.round(n);
}

export function buildNormalizedInbound(item = {}) {
  const channel = String(item.channel || '').trim().toLowerCase();
  const rawSender = String(String(item.externalUserId ?? '').trim() || String(item.senderId ?? '').trim()).trim();
  const prefix = channel ? `${channel}:` : '';
  const hasPrefix = Boolean(prefix) && rawSender.toLowerCase().startsWith(prefix);
  const externalUserId = hasPrefix ? rawSender.slice(prefix.length).trim() : rawSender;
  const senderId = channel && externalUserId ? `${channel}:${externalUserId}` : externalUserId;
  return {
    channel,
    senderId,
    externalUserId,
    senderName: String(item.senderName || externalUserId || 'Customer').trim(),
    text: String(item.text || '').trim(),
    messageId: String(item.messageId || `${channel || 'msg'}_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`),
    attachments: Array.isArray(item.attachments) ? item.attachments : [],
    replyToken: String(item.replyToken || ''),
    timestamp: normalizeTimestamp(item.timestamp),
    unsupportedMediaType: String(item.unsupportedMediaType || ''),
    mediaFileName: String(item.mediaFileName || ''),
    meta: item.meta && typeof item.meta === 'object' ? item.meta : {}
  };
}

export function validateAdapterContract(adapter) {
  if (!adapter || typeof adapter !== 'object') throw new Error('Channel adapter must be an object');
  if (!adapter.meta?.id) throw new Error('Channel adapter missing meta.id');
  for (const fn of ['verifySignature', 'normalizeInbound', 'sendReply']) {
    if (typeof adapter[fn] !== 'function') throw new Error(`Adapter "${adapter.meta.id}" missing ${fn}()`);
  }
  return true;
}
