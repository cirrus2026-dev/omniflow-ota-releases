// gateway/src/modules/channels/whatsapp-adapter.mjs
// WhatsApp Business Cloud API Webhook Verification, Normalizer & Outbound Text/Image Reply Adapter

import crypto from 'node:crypto';
import { normalizePublicHttpsUrl } from '../../dispatch-utils.mjs';

const WA_TEXT_LIMIT = 4096;
const WA_IMAGE_LIMIT = 5;

export function verifyWhatsAppSignature({ signature, rawBody, appSecret }) {
  if (!appSecret) {
    return { valid: true, mode: 'mock_bypass' };
  }
  if (!signature || !rawBody) {
    return { valid: false, reason: 'Missing WhatsApp X-Hub-Signature-256 header or raw body' };
  }

  const expectedHex = crypto
    .createHmac('sha256', String(appSecret))
    .update(Buffer.isBuffer(rawBody) ? rawBody : String(rawBody), 'utf8')
    .digest('hex');

  const expected = `sha256=${expectedHex}`;
  const normalizedSig = String(signature).trim();

  const sigBuf = Buffer.from(normalizedSig, 'utf8');
  const expBuf = Buffer.from(expected, 'utf8');
  if (sigBuf.length !== expBuf.length) {
    return { valid: false, reason: 'WhatsApp signature length mismatch' };
  }

  const match = crypto.timingSafeEqual(sigBuf, expBuf);
  return { valid: match, reason: match ? null : 'Invalid WhatsApp HMAC-SHA256 signature' };
}

export function handleWhatsAppChallenge(req, expectedVerifyToken = '') {
  let mode = req.query?.['hub.mode'];
  let token = req.query?.['hub.verify_token'];
  let challenge = req.query?.['hub.challenge'];

  if (mode === undefined && req.url) {
    try {
      const urlObj = new URL(req.url, `http://${req.headers?.host || 'localhost'}`);
      mode = urlObj.searchParams.get('hub.mode');
      token = urlObj.searchParams.get('hub.verify_token');
      challenge = urlObj.searchParams.get('hub.challenge');
    } catch {
      return { isChallenge: false };
    }
  }

  if (!mode && !challenge) {
    return { isChallenge: false };
  }

  const tokenMatched = !expectedVerifyToken || token === expectedVerifyToken;
  if (mode === 'subscribe' && tokenMatched && challenge) {
    return { isChallenge: true, verified: true, status: 200, response: String(challenge) };
  }

  return { isChallenge: true, verified: false, status: 403, response: 'Forbidden: Invalid WhatsApp verify_token' };
}

export function normalizeWhatsAppInbound(payload = {}) {
  const value = payload?.entry?.[0]?.changes?.[0]?.value;
  const msg = value?.messages?.[0];
  if (!msg) return null;

  const contact = value?.contacts?.[0] || {};
  const rawPhone = String(msg.from || contact.wa_id || '').trim();
  if (!rawPhone) return null;

  const senderId = rawPhone.startsWith('whatsapp:') ? rawPhone : `whatsapp:${rawPhone}`;
  const senderName = contact?.profile?.name || `WhatsApp User (${rawPhone.slice(-6)})`;

  let text = '';
  const attachments = [];

  if (msg.type === 'text' && typeof msg.text?.body === 'string') {
    text = msg.text.body.trim();
  } else if (msg.type === 'image') {
    text = String(msg.image?.caption || '').trim();
    if (msg.image?.id) {
      attachments.push({ type: 'image', mediaId: String(msg.image.id), mimeType: msg.image.mime_type || 'image/jpeg' });
    }
  } else if (msg.type === 'document') {
    text = String(msg.document?.caption || msg.document?.filename || '').trim();
    if (msg.document?.id) {
      attachments.push({ type: 'document', mediaId: String(msg.document.id), mimeType: msg.document.mime_type || 'application/octet-stream' });
    }
  } else if (msg.type === 'interactive') {
    text = String(msg.interactive?.button_reply?.title || msg.interactive?.list_reply?.title || '').trim();
  } else if (msg.type === 'button') {
    text = String(msg.button?.text || '').trim();
  }

  if (!text && attachments.length === 0) return null;

  const messageId = String(msg.id || `wa_${Date.now()}`);
  const rawTs = Number(msg.timestamp || Date.now());
  const timestamp = rawTs < 1e12 ? rawTs * 1000 : rawTs;

  return {
    channel: 'whatsapp',
    senderId,
    senderName,
    text,
    messageId,
    attachments,
    replyToken: rawPhone,
    timestamp,
    meta: {
      phoneNumberId: String(value?.metadata?.phone_number_id || ''),
      displayPhoneNumber: String(value?.metadata?.display_phone_number || ''),
      messageId,
      messageType: msg.type || 'text',
    },
  };
}

async function postWhatsAppGraphMessage(endpoint, accessToken, payload) {
  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = data?.error?.error_data?.details || data?.error?.message || `WhatsApp Graph API HTTP ${res.status}`;
    return { ok: false, messageId: '', data, error: detail };
  }
  return { ok: true, messageId: String(data?.messages?.[0]?.id || ''), data, error: '' };
}

export async function sendWhatsAppReply({ to, text = '', images = [], phoneNumberId, accessToken, graphVersion = 'v21.0' }) {
  const recipient = String(to || '').replace(/^whatsapp:/i, '').trim();
  let bodyText = String(text || '').trim();
  const cleanPhoneId = String(phoneNumberId || '').trim();
  const cleanToken = String(accessToken || '').trim();

  if (!recipient) throw new Error('Missing WhatsApp recipient phone number');
  if (!cleanPhoneId || !cleanToken) throw new Error('Missing WhatsApp phoneNumberId or accessToken');

  const validImages = [];
  const skippedImages = [];
  const failedImages = [];
  const seenUrls = new Set();

  for (const img of Array.isArray(images) ? images : []) {
    const rawUrl = typeof img === 'string' ? img.trim() : String(img?.url || '').trim();
    const caption = typeof img === 'object' && img ? String(img.caption || '').trim() : '';
    if (!rawUrl) continue;
    const safeUrl = normalizePublicHttpsUrl(rawUrl);
    if (!safeUrl) {
      const reason = rawUrl.startsWith('/') && !rawUrl.startsWith('//')
        ? 'relative URL without PUBLIC_BASE_URL'
        : 'WhatsApp image URL must be a public HTTPS URL';
      skippedImages.push({ url: rawUrl, reason });
      continue;
    }
    if (seenUrls.has(safeUrl)) continue;
    seenUrls.add(safeUrl);
    validImages.push({ url: safeUrl, caption });
  }

  if (!bodyText && validImages.length === 0) {
    throw new Error(skippedImages[0]?.reason || 'Missing WhatsApp message text or valid public HTTPS image URL');
  }

  const endpoint = `https://graph.facebook.com/${encodeURIComponent(graphVersion)}/${encodeURIComponent(cleanPhoneId)}/messages`;
  let firstMessageId = '';
  let firstSuccessData = null;
  let textSent = false;
  const imagesSent = [];
  const errors = skippedImages.map((s) => s.reason);

  if (bodyText) {
    if (bodyText.length > WA_TEXT_LIMIT) {
      console.warn(`[Dispatcher:WA] Truncating text from ${bodyText.length} to ${WA_TEXT_LIMIT} chars`);
      bodyText = bodyText.slice(0, WA_TEXT_LIMIT);
    }
    const textRes = await postWhatsAppGraphMessage(endpoint, cleanToken, {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: recipient,
      type: 'text',
      text: { preview_url: false, body: bodyText },
    });
    textSent = textRes.ok;
    if (textRes.ok) {
      firstMessageId = textRes.messageId;
      firstSuccessData = textRes.data;
    } else {
      errors.push(textRes.error);
    }
  }

  const toSend = validImages.slice(0, WA_IMAGE_LIMIT);
  const overflow = validImages.slice(WA_IMAGE_LIMIT);

  for (const item of toSend) {
    const imageObj = {
      link: item.url,
      ...(item.caption ? { caption: item.caption.slice(0, 1024) } : {}),
    };
    const imgRes = await postWhatsAppGraphMessage(endpoint, cleanToken, {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: recipient,
      type: 'image',
      image: imageObj,
    });
    if (imgRes.ok) {
      imagesSent.push(item.url);
      if (!firstMessageId && imgRes.messageId) firstMessageId = imgRes.messageId;
      if (!firstSuccessData) firstSuccessData = imgRes.data;
    } else {
      failedImages.push({ url: item.url, error: imgRes.error });
      errors.push(imgRes.error);
    }
  }

  for (const extra of overflow) {
    const reason = 'limit';
    failedImages.push({ url: extra.url, reason, error: `WhatsApp ${WA_IMAGE_LIMIT}-image limit exceeded` });
    errors.push(`WhatsApp ${WA_IMAGE_LIMIT}-image limit exceeded`);
  }

  if (!textSent && imagesSent.length === 0) {
    throw new Error(errors[0] || 'WhatsApp Graph API send failed');
  }

  const allOk = (!bodyText || textSent) && failedImages.length === 0 && skippedImages.length === 0;
  return {
    ok: allOk,
    platform: 'whatsapp',
    messageId: firstMessageId,
    textSent,
    imagesSent,
    ...(failedImages.length > 0 ? { failedImages } : {}),
    ...(skippedImages.length > 0 ? { skippedImages } : {}),
    ...(errors.length > 0 ? { error: errors.join('; ') } : {}),
    data: firstSuccessData,
  };
}
