// gateway/src/modules/channels/crisp-adapter.mjs
// Wave 4 Adapter: Crisp Live Chat (Strict HMAC [ts;rawBody] + User Anti-Echo + Plugin Basic Auth Reply)

import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const CRISP_API_BASE = 'https://api.crisp.chat/v1';

const crispAdapter = {
  meta: {
    id: 'crisp',
    wave: 'wave4',
    category: 'livechat',
    label: 'Crisp Live Chat',
    shortLabel: 'CRISP',
    badgeColor: '#1972F5',
    badgeBg: 'rgba(25, 114, 245, 0.14)',
    webhookPath: '/webhook/crisp',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'websiteId', label: 'Crisp Website ID', type: 'text', secret: false, required: true, placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', envKey: 'CRISP_WEBSITE_ID' },
      { key: 'pluginIdentifier', label: 'Plugin Token Identifier', type: 'text', secret: false, required: true, placeholder: 'Crisp Marketplace Identifier', envKey: 'CRISP_PLUGIN_IDENTIFIER' },
      { key: 'pluginKey', label: 'Plugin Token Key', type: 'password', secret: true, required: true, placeholder: 'Crisp Plugin Key', envKey: 'CRISP_PLUGIN_KEY' },
      { key: 'webhookSecret', label: 'Webhook Signing Secret', type: 'password', secret: true, placeholder: 'Crisp Webhook Signing Secret', envKey: 'CRISP_WEBHOOK_SECRET' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBody = '', channelCfg = {} }) {
    const secret = String(channelCfg.webhookSecret || process.env.CRISP_WEBHOOK_SECRET || '').trim();
    if (!secret) return { valid: false, reason: 'Missing Crisp webhookSecret configuration' };

    const h = normalizeHeaders(headers);
    const sig = h['x-crisp-signature'] || '';
    const ts = h['x-crisp-request-timestamp'] || '';
    if (!sig || !ts) return { valid: false, reason: 'Missing Crisp signature or timestamp header' };

    return verifyHmacTimingSafe({
      secret,
      signature: sig,
      encoding: 'hex',
      baseString: `[${ts};${rawBody}]`,
      allowMockBypass: false
    });
  },

  normalizeInbound(payload = {}) {
    if (!payload || typeof payload !== 'object') return [];
    if (String(payload.event || '').toLowerCase() !== 'message:send') return [];

    const data = payload.data;
    if (!data || typeof data !== 'object') return [];
    // Anti-Echo Guard: รับเฉพาะข้อความจากฝั่งลูกค้า (user) ห้ามรับข้อความจาก operator
    if (String(data.from || '').toLowerCase() !== 'user') return [];

    const sessionId = String(data.session_id || '').trim();
    const websiteId = String(payload.website_id || data.website_id || '').trim();
    if (!sessionId) return [];

    const msgType = String(data.type || 'text').toLowerCase();
    const attachments = [];
    let text = '';
    let unsupportedMediaType = '';
    let mediaFileName = '';

    if (msgType === 'text') {
      text = String(data.content || '').trim();
    } else if (msgType === 'file' && data.content && typeof data.content === 'object') {
      const url = String(data.content.url || '').trim();
      const mime = String(data.content.type || '').toLowerCase();
      if (url && (mime.startsWith('image/') || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(url))) {
        attachments.push({ type: 'image', url, mimeType: mime || 'image/jpeg' });
      } else if (url || data.content.name) {
        unsupportedMediaType = 'file';
        mediaFileName = String(data.content.name || 'attachment');
        text = `[ลูกค้าส่งไฟล์ทาง Crisp: ${mediaFileName}]`;
      }
    } else if (msgType === 'audio') {
      unsupportedMediaType = 'audio';
      text = '[ลูกค้าส่งคลิปเสียงทาง Crisp]';
    }

    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];
    const senderName = String(data.user?.nickname || `Crisp (${sessionId.slice(-6)})`).trim();

    return [
      buildNormalizedInbound({
        channel: 'crisp',
        externalUserId: sessionId,
        senderName,
        text,
        messageId: String(data.fingerprint || `crisp_${sessionId}_${Date.now()}`),
        attachments,
        timestamp: Number(data.timestamp || payload.timestamp || Date.now()),
        unsupportedMediaType,
        mediaFileName,
        meta: { websiteId, sessionId }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const websiteId = String(meta.websiteId || channelCfg.websiteId || process.env.CRISP_WEBSITE_ID || '').trim();
    const identifier = String(channelCfg.pluginIdentifier || process.env.CRISP_PLUGIN_IDENTIFIER || '').trim();
    const pluginKey = String(channelCfg.pluginKey || process.env.CRISP_PLUGIN_KEY || '').trim();
    if (!websiteId || !identifier || !pluginKey) {
      throw new Error('Missing Crisp websiteId, pluginIdentifier, or pluginKey');
    }

    const sessionId = String(meta.sessionId || to || '').replace(/^crisp:/i, '').trim();
    if (!sessionId) throw new Error('Missing Crisp sessionId');

    const basicAuth = Buffer.from(`${identifier}:${pluginKey}`, 'utf8').toString('base64');
    const endpoint = `${CRISP_API_BASE}/website/${encodeURIComponent(websiteId)}/conversation/${encodeURIComponent(sessionId)}/message`;
    const headers = {
      Authorization: `Basic ${basicAuth}`,
      'X-Crisp-Tier': 'plugin',
      'Content-Type': 'application/json'
    };

    const cleanText = String(text || '').trim();
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    if (!cleanText && mediaUrls.length === 0) throw new Error('Crisp reply content cannot be empty');

    let lastFp = '';
    if (cleanText) {
      const res = await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({ type: 'text', from: 'operator', origin: 'chat', content: cleanText.slice(0, 4000) })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || json.error) throw new Error(`Crisp Send HTTP ${res.status}: ${json.reason || ''}`);
      lastFp = String(json?.data?.fingerprint || '');
    }

    for (let i = 0; i < mediaUrls.length; i++) {
      const imgRes = await fetchWithTimeout(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          type: 'file',
          from: 'operator',
          origin: 'chat',
          content: { url: mediaUrls[i], type: 'image/jpeg', name: `preview_${i + 1}.jpg` }
        })
      });
      if (imgRes.ok && !lastFp) {
        const imgJson = await imgRes.json().catch(() => ({}));
        lastFp = String(imgJson?.data?.fingerprint || '');
      }
    }

    return { ok: true, platform: 'crisp', messageId: lastFp || `crisp_out_${Date.now()}`, mode: 'crisp_plugin_v1' };
  }
};

export default crispAdapter;
