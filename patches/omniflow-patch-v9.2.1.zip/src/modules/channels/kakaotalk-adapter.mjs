// gateway/src/modules/channels/kakaotalk-adapter.mjs
// Wave 2 Adapter: KakaoTalk Channel OpenBuilder Skill v2.0 (Strict Auth + SSRF-Guarded Callback & TTL Fallback)

import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  timingSafeEqualStr,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

function validateSafeHttpsUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return '';
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

function extractKakaoImageUrls(payload = {}) {
  const urls = [];
  const seen = new Set();
  const pushIfImage = (val) => {
    const s = String(val || '').trim();
    if (/^https?:\/\//i.test(s) && !seen.has(s)) {
      seen.add(s);
      urls.push(s);
    }
  };

  const detailParams = payload?.action?.detailParams || {};
  for (const param of Object.values(detailParams)) {
    const origin = param?.origin || param?.value;
    if (typeof origin === 'string' && /^https?:\/\/.+\.(?:png|jpe?g|webp|gif)/i.test(origin)) {
      pushIfImage(origin);
    }
  }
  const media = payload?.userRequest?.params?.media;
  if (media?.type === 'image' && media?.url) pushIfImage(media.url);
  for (const att of Array.isArray(payload?.attachments) ? payload.attachments : []) {
    if (att?.url) pushIfImage(att.url);
  }
  return urls;
}

const kakaotalkAdapter = {
  meta: {
    id: 'kakaotalk',
    wave: 'wave2',
    category: 'messaging',
    label: 'KakaoTalk Channel (OpenBuilder)',
    shortLabel: 'KAKAO',
    badgeColor: '#FEE500',
    badgeBg: 'rgba(254, 229, 0, 0.16)',
    webhookPath: '/webhook/kakaotalk',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'botId', label: 'OpenBuilder Bot ID', type: 'text', secret: false, placeholder: 'Kakao Bot ID', envKey: 'KAKAO_BOT_ID' },
      { key: 'channelPublicId', label: 'Channel Public ID', type: 'text', secret: false, placeholder: '_xXxXxX', envKey: 'KAKAO_CHANNEL_PUBLIC_ID' },
      { key: 'skillSecret', label: 'Skill Webhook Secret', type: 'password', secret: true, placeholder: 'Header X-Kakao-Bot-Secret', envKey: 'KAKAO_SKILL_SECRET' },
      { key: 'restApiKey', label: 'Kakao REST API Key (KakaoAK)', type: 'password', secret: true, placeholder: 'REST API Key (ทางเลือก)', envKey: 'KAKAO_REST_API_KEY' },
      { key: 'outboundWebhookUrl', label: 'BizMessage Outbound Bridge URL (ทางเลือก)', type: 'url', secret: false, placeholder: 'https://... (สำหรับส่งนอกเวลา 60 วินาที)', envKey: 'KAKAO_OUTBOUND_WEBHOOK_URL' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const expectedSecret = String(channelCfg.skillSecret || process.env.KAKAO_SKILL_SECRET || '').trim();
    const expectedBotId = String(channelCfg.botId || process.env.KAKAO_BOT_ID || '').trim();

    if (!expectedSecret && !expectedBotId) {
      return { valid: false, reason: 'Missing KakaoTalk skillSecret or botId configuration' };
    }

    if (expectedSecret) {
      const candidate =
        h['x-kakao-bot-secret'] ||
        (h.authorization || '').replace(/^(?:Bearer|KakaoAK)\s+/i, '').trim();
      if (!candidate || !timingSafeEqualStr(candidate, expectedSecret)) {
        return { valid: false, reason: 'Invalid KakaoTalk skill secret header' };
      }
    }

    if (expectedBotId) {
      if (!rawBody) {
        return { valid: false, reason: 'Missing KakaoTalk payload for bot.id verification' };
      }
      try {
        const parsed = JSON.parse(rawBody);
        const incomingBotId = String(parsed?.bot?.id || '').trim();
        if (!incomingBotId || !timingSafeEqualStr(incomingBotId, expectedBotId)) {
          return { valid: false, reason: 'KakaoTalk bot.id missing or mismatch' };
        }
      } catch {
        return { valid: false, reason: 'Invalid KakaoTalk JSON payload' };
      }
    }

    return { valid: true, mode: expectedSecret ? 'kakao_skill_secret' : 'kakao_bot_id' };
  },

  normalizeInbound(payload = {}) {
    const reqObj = payload?.userRequest;
    if (!reqObj || typeof reqObj !== 'object') return [];
    const user = reqObj.user || {};
    const props = user.properties || {};
    const extUserId = String(user.id || props.plusfriendUserKey || props.appUserId || '').trim();
    if (!extUserId) return [];

    const text = String(reqObj.utterance || '').trim();
    const imgUrls = extractKakaoImageUrls(payload);
    const attachments = imgUrls.map((url) => ({ type: 'image', url }));
    if (!text && attachments.length === 0) return [];

    const safeCallbackUrl = validateSafeHttpsUrl(reqObj.callbackUrl || '');
    const syncHttpResponse = safeCallbackUrl
      ? { version: '2.0', useCallback: true }
      : { version: '2.0', template: { outputs: [{ simpleText: { text: 'รับข้อความเรียบร้อยแล้วค่ะ' } }] } };

    const msgId = String(payload?.action?.id || `kakao_${extUserId}_${Date.now()}`);

    return [
      buildNormalizedInbound({
        channel: 'kakaotalk',
        externalUserId: extUserId,
        senderName: String(props.nickname || `Kakao (${extUserId.slice(-6)})`).trim(),
        text,
        messageId: msgId,
        attachments,
        replyToken: safeCallbackUrl,
        timestamp: Date.now(),
        meta: {
          botId: String(payload?.bot?.id || ''),
          callbackUrl: safeCallbackUrl,
          callbackExpiresAt: safeCallbackUrl ? Date.now() + 58000 : 0,
          syncHttpResponse
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], replyToken = '', channelCfg = {}, meta = {} }) {
    const cleanText = String(text || '').trim();
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 3);
    if (!cleanText && mediaUrls.length === 0) throw new Error('KakaoTalk reply content cannot be empty');

    const outputs = [];
    if (cleanText) outputs.push({ simpleText: { text: cleanText.slice(0, 1000) } });
    for (const url of mediaUrls) {
      outputs.push({ simpleImage: { imageUrl: url, altText: 'Product preview' } });
    }

    const skillBody = { version: '2.0', template: { outputs } };
    const rawCbUrl = String(replyToken || meta.callbackUrl || '').trim();
    const expiresAt = Number(meta.callbackExpiresAt || 0);
    const isCallbackActive = !expiresAt || Date.now() < expiresAt;

    if (rawCbUrl && isCallbackActive) {
      const safeCbUrl = validateSafeHttpsUrl(rawCbUrl);
      if (!safeCbUrl) {
        throw new Error('Blocked unsafe KakaoTalk callbackUrl (must be public HTTPS)');
      }
      const res = await fetchWithTimeout(safeCbUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(skillBody)
      });
      if (!res.ok) throw new Error(`Kakao Callback HTTP ${res.status}`);
      return { ok: true, platform: 'kakaotalk', messageId: `kakao_cb_${Date.now()}`, mode: 'openbuilder_callback' };
    }

    const rawBridgeUrl = String(channelCfg.outboundWebhookUrl || process.env.KAKAO_OUTBOUND_WEBHOOK_URL || '').trim();
    if (rawBridgeUrl) {
      const safeBridgeUrl = validateSafeHttpsUrl(rawBridgeUrl);
      if (!safeBridgeUrl) {
        throw new Error('Blocked unsafe KakaoTalk Outbound Bridge URL (must be public HTTPS)');
      }
      const headers = { 'Content-Type': 'application/json' };
      const apiKey = String(channelCfg.restApiKey || process.env.KAKAO_REST_API_KEY || '').trim();
      if (apiKey) headers.Authorization = `KakaoAK ${apiKey}`;
      const res = await fetchWithTimeout(safeBridgeUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify({ to, channelPublicId: channelCfg.channelPublicId || '', ...skillBody })
      });
      if (!res.ok) throw new Error(`Kakao Bridge HTTP ${res.status}`);
      return { ok: true, platform: 'kakaotalk', messageId: `kakao_bridge_${Date.now()}`, mode: 'bizmessage_bridge' };
    }

    throw new Error('KakaoTalk requires an active callbackUrl (60s TTL) or BizMessage Outbound Bridge URL');
  }
};

export default kakaotalkAdapter;
