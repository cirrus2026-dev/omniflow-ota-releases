// gateway/src/modules/channels/tidio-adapter.mjs
// Wave 4 Adapter: Tidio Live Chat (Strict t=<ts>,s=<hex> / Raw Hex HMAC + Visitor-Only Guard + OpenAPI Reply)

import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const TIDIO_API_BASE = 'https://api.tidio.com';

const tidioAdapter = {
  meta: {
    id: 'tidio',
    wave: 'wave4',
    category: 'livechat',
    label: 'Tidio Live Chat',
    shortLabel: 'TIDIO',
    badgeColor: '#0566FF',
    badgeBg: 'rgba(5, 102, 255, 0.14)',
    webhookPath: '/webhook/tidio',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'clientId', label: 'Tidio OpenAPI Client ID', type: 'text', secret: false, required: true, placeholder: 'X-Tidio-Openapi-Client-Id', envKey: 'TIDIO_CLIENT_ID' },
      { key: 'botAgentId', label: 'Bot / Operator ID (ไม่บังคับ)', type: 'text', secret: false, placeholder: 'Operator ID สำหรับส่งข้อความ', envKey: 'TIDIO_BOT_AGENT_ID' },
      { key: 'clientSecret', label: 'Tidio OpenAPI Client Secret', type: 'password', secret: true, required: true, placeholder: 'X-Tidio-Openapi-Client-Secret', envKey: 'TIDIO_CLIENT_SECRET' },
      { key: 'webhookSecret', label: 'Webhook Signing Secret', type: 'password', secret: true, placeholder: 'สำหรับตรวจ x-tidio-signature', envKey: 'TIDIO_WEBHOOK_SECRET' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const secret = String(channelCfg.webhookSecret || process.env.TIDIO_WEBHOOK_SECRET || '').trim();
    if (!secret) return { valid: false, reason: 'Missing Tidio webhookSecret configuration' };

    const h = normalizeHeaders(headers);
    const sigHeader = h['x-tidio-signature'] || '';
    if (!sigHeader) return { valid: false, reason: 'Missing Tidio signature header' };

    const structured = sigHeader.match(/t=([^,\s]+)\s*,\s*s=([a-f0-9]+)/i);
    if (structured) {
      const ts = structured[1].trim();
      const sigHex = structured[2].trim();
      const res = verifyHmacTimingSafe({
        secret,
        signature: sigHex,
        encoding: 'hex',
        baseString: `${ts}.${rawBody}`,
        allowMockBypass: false
      });
      return { valid: res.valid, mode: res.valid ? 'tidio_ts_hmac' : undefined, reason: res.reason };
    }

    const rawRes = verifyHmacTimingSafe({
      rawBody: rawBuf || rawBody,
      secret,
      signature: sigHeader,
      encoding: 'hex',
      prefix: 'sha256=',
      allowMockBypass: false
    });
    return { valid: rawRes.valid, mode: rawRes.valid ? 'tidio_raw_hmac' : undefined, reason: rawRes.reason };
  },

  normalizeInbound(payload = {}) {
    if (!payload || typeof payload !== 'object') return [];
    const data = payload.data && typeof payload.data === 'object' ? payload.data : payload;
    const msg = data.message && typeof data.message === 'object' ? data.message : payload.message || data;
    const author = msg.author || data.author || payload.author || {};

    // Anti-Echo Guard: รับเฉพาะข้อความจาก visitor เท่านั้น
    if (String(author.type || '').toLowerCase() !== 'visitor') return [];

    const contactId = String(data.contact_id || payload.contact_id || author.id || '').trim();
    if (!contactId) return [];

    const text = String(msg.content || msg.text || data.text || '').trim();
    const attachments = [];
    let unsupportedMediaType = '';
    let mediaFileName = '';

    const rawAtts = Array.isArray(msg.attachments) ? msg.attachments : Array.isArray(data.attachments) ? data.attachments : [];
    for (const att of rawAtts) {
      const url = String(att?.url || '').trim();
      const mime = String(att?.mime_type || att?.content_type || att?.type || '').toLowerCase();
      if (url && (mime.startsWith('image/') || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(url))) {
        attachments.push({ type: 'image', url, mimeType: mime || 'image/jpeg' });
      } else if (url || att?.name) {
        unsupportedMediaType = 'file';
        mediaFileName = mediaFileName || String(att?.name || 'attachment');
      }
    }

    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];
    const visitor = data.visitor || payload.visitor || author;
    const senderName = String(visitor.name || visitor.email || `Tidio (${contactId.slice(-6)})`).trim();

    return [
      buildNormalizedInbound({
        channel: 'tidio',
        externalUserId: contactId,
        senderName,
        text: text || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Tidio: ${mediaFileName || unsupportedMediaType}]` : ''),
        messageId: String(msg.id || payload.event_id || `tidio_${contactId}_${Date.now()}`),
        attachments,
        timestamp: Number(msg.time_sent || payload.timestamp || Date.now()),
        unsupportedMediaType,
        mediaFileName,
        meta: {
          contactId,
          conversationId: String(data.conversation_id || contactId),
          visitorEmail: String(visitor.email || '')
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const clientId = String(channelCfg.clientId || process.env.TIDIO_CLIENT_ID || '').trim();
    const clientSecret = String(channelCfg.clientSecret || process.env.TIDIO_CLIENT_SECRET || '').trim();
    if (!clientId || !clientSecret) throw new Error('Missing Tidio OpenAPI Client ID or Client Secret');

    const contactId = String(meta.contactId || to || '').replace(/^tidio:/i, '').trim();
    if (!contactId) throw new Error('Missing Tidio contactId');

    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const cleanText = String(text || '').trim();
    const fullText = mediaUrls.length > 0 ? [cleanText, ...mediaUrls].filter(Boolean).join('\n') : cleanText;
    if (!fullText) throw new Error('Tidio reply content cannot be empty');

    const botAgentId = String(channelCfg.botAgentId || process.env.TIDIO_BOT_AGENT_ID || '').trim();
    const url = `${TIDIO_API_BASE}/conversations/${encodeURIComponent(contactId)}/messages`;
    const res = await fetchWithTimeout(url, {
      method: 'POST',
      headers: {
        'X-Tidio-Openapi-Client-Id': clientId,
        'X-Tidio-Openapi-Client-Secret': clientSecret,
        Accept: 'application/json; version=1',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        content: fullText.slice(0, 4000),
        ...(botAgentId ? { operator_id: botAgentId } : {})
      })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Tidio Send HTTP ${res.status}: ${json?.message || ''}`);
    return {
      ok: true,
      platform: 'tidio',
      messageId: String(json?.id || json?.message_id || `tidio_out_${Date.now()}`),
      mode: 'tidio_openapi_v1'
    };
  }
};

export default tidioAdapter;
