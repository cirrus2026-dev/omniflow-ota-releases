// gateway/src/modules/channels/tiktok-adapter.mjs
// Phase 9.3: TikTok Shop Open Platform SHA256 Signature Verification (Strict Fail-Closed) & Inbound Message Normalizer

import crypto from 'node:crypto';

export function verifyTikTokSignature({ signature, rawBody, appKey, appSecret }) {
  const secret = String(appSecret || '').trim();
  if (!secret) {
    return { valid: false, reason: 'Missing TikTok appSecret configuration' };
  }
  if (!signature || !rawBody) {
    return { valid: false, reason: 'Missing TikTok Authorization/Signature header or raw body' };
  }

  const baseString = `${appKey || ''}${rawBody}`;
  const expected = crypto
    .createHmac('sha256', secret)
    .update(baseString, 'utf8')
    .digest('hex');

  const sigClean = String(signature).replace(/^sha256=/i, '').trim();
  const sigBuf = Buffer.from(sigClean, 'utf8');
  const expBuf = Buffer.from(expected, 'utf8');

  if (sigBuf.length !== expBuf.length) {
    return { valid: false, reason: 'TikTok signature length mismatch' };
  }

  const match = crypto.timingSafeEqual(sigBuf, expBuf);
  return { valid: match, reason: match ? null : 'Invalid TikTok SHA256 signature' };
}

export function normalizeTikTokInbound(payload = {}) {
  const data = payload.data || payload;
  const shopId = String(payload.shop_id || data.shop_id || '');

  const senderObj = data.sender || {};
  const rawSenderId =
    senderObj.im_user_id ||
    senderObj.user_id ||
    data.buyer_user_id ||
    data.sender_id ||
    payload.senderId ||
    'tiktok_guest';

  const senderId = String(rawSenderId).startsWith('tiktok:')
    ? String(rawSenderId)
    : `tiktok:${rawSenderId}`;

  const senderName =
    senderObj.nickname ||
    data.buyer_nickname ||
    data.sender_name ||
    payload.senderName ||
    `TikTok Customer (${String(rawSenderId).slice(-6)})`;

  let parsedContent = data.content || {};
  if (typeof parsedContent === 'string') {
    try {
      parsedContent = JSON.parse(parsedContent);
    } catch {
      parsedContent = { content: parsedContent };
    }
  }

  let text = '';
  const attachments = [];

  if (typeof parsedContent.content === 'string') {
    text = parsedContent.content.trim();
  } else if (typeof parsedContent.text === 'string') {
    text = parsedContent.text.trim();
  } else if (typeof data.text === 'string') {
    text = data.text.trim();
  } else if (typeof payload.text === 'string') {
    text = payload.text.trim();
  }

  const imageUrl =
    parsedContent.url ||
    parsedContent.image_url ||
    data.image_url ||
    (Array.isArray(data.attachments) ? data.attachments[0]?.url : null);

  if (imageUrl) {
    attachments.push({
      type: 'image',
      url: String(imageUrl)
    });
  }

  if (Array.isArray(payload.attachments)) {
    for (const att of payload.attachments) {
      if (att?.url && !attachments.some((a) => a.url === att.url)) {
        attachments.push({
          type: att.type || 'image',
          url: String(att.url)
        });
      }
    }
  }

  if (!text && !attachments.length && (data.order_id || payload.order_id)) {
    const orderId = data.order_id || payload.order_id;
    const orderStatus = data.order_status || payload.order_status || 'UPDATED';
    text = `[TikTok Order #${orderId}] สถานะคำสั่งซื้อ: ${orderStatus}`;
  }

  const conversationId = data.conversation_id || payload.conversation_id || '';
  const timestamp = Number(payload.timestamp || data.create_time || Date.now());

  if (!text && attachments.length === 0) {
    return null;
  }

  return {
    channel: 'tiktok',
    senderId,
    senderName,
    text,
    attachments,
    replyToken: conversationId || `tiktok_conv_${rawSenderId}`,
    timestamp: timestamp < 1e12 ? timestamp * 1000 : timestamp,
    meta: {
      shopId,
      conversationId,
      eventType: payload.type || data.type || 'IM_MESSAGE',
      messageId: data.message_id || payload.tts_notification_id || `tt_${Date.now()}`
    }
  };
}
