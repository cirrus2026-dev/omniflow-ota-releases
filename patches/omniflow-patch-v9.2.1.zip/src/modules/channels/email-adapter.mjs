// gateway/src/modules/channels/email-adapter.mjs
// Omnichannel Email Chat Adapter (Inbound Webhook + Zero-Dep SMTP/Webhook Outbound)

import crypto from 'node:crypto';
import net from 'node:net';
import tls from 'node:tls';

const sanitizeHeader = (v = '') => String(v || '').replace(/[\r\n]+/g, ' ').trim();
const encodeMimeWord = (v = '') => `=?UTF-8?B?${Buffer.from(sanitizeHeader(v), 'utf8').toString('base64')}?=`;
const toBase64Lines = (t = '') =>
  Buffer.from(String(t || ''), 'utf8').toString('base64').replace(/.{1,76}/g, '$&\r\n').trim();

export function parseEmailAddress(raw = '') {
  const s = String(raw || '').trim();
  const angle = s.match(/^(.*?)\s*<([^<>\s]+@[^<>\s]+)>/);
  if (angle) return { name: angle[1].replace(/^["']|["']$/g, '').trim(), email: angle[2].trim().toLowerCase() };
  const plain = s.match(/([^\s<>,"']+@[^\s<>,"']+)/);
  return { name: '', email: plain ? plain[1].trim().toLowerCase() : '' };
}

function stripHtmlAndQuotes(text = '', html = '') {
  let body = String(text || '').trim();
  if (!body && html) {
    body = String(html)
      .replace(/<(?:style|script)[\s\S]*?<\/(?:style|script)>/gi, ' ')
      .replace(/<br\s*\/?>|<\/(?:p|div|li|tr)>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&').replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .trim();
  }
  const clean = [];
  for (const line of body.replace(/\r\n/g, '\n').split('\n')) {
    if (/^(?:On .+ wrote:|-----Original Message-----|From:\s.+|เมื่อ .+ เขียนว่า:)/i.test(line.trim())) break;
    if (!line.trim().startsWith('>')) clean.push(line);
  }
  return clean.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

export function verifyEmailWebhookSecret({ headers = {}, rawBody = '', secret = '' } = {}) {
  const expected = String(secret || '').trim();
  if (!expected) return { valid: true, mode: 'no_secret_bypass' };
  const h = Object.fromEntries(Object.entries(headers || {}).map(([k, v]) => [String(k).toLowerCase(), String(v || '').trim()]));
  const direct = h['x-email-webhook-secret'] || h['x-webhook-secret'] || (h.authorization || '').replace(/^Bearer\s+/i, '').trim();
  if (direct) {
    const a = crypto.createHash('sha256').update(direct).digest();
    const b = crypto.createHash('sha256').update(expected).digest();
    if (crypto.timingSafeEqual(a, b)) return { valid: true, mode: 'header_secret' };
  }
  const sig = (h['x-email-signature'] || h['x-hub-signature-256'] || '').replace(/^sha256=/i, '').trim();
  if (sig && rawBody) {
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(crypto.createHmac('sha256', expected).update(rawBody).digest('hex'), 'utf8');
    if (a.length === b.length && crypto.timingSafeEqual(a, b)) return { valid: true, mode: 'hmac_sha256' };
  }
  return { valid: false, reason: 'Invalid Email webhook secret or signature' };
}

export function normalizeEmailInbound(payload = {}, options = {}) {
  const data = payload?.data && typeof payload.data === 'object' ? payload.data : payload || {};
  const headers = data.headers && typeof data.headers === 'object' ? data.headers : {};
  const { name: parsedName, email: fromEmail } = parseEmailAddress(data.from || data.sender || data.fromEmail || data.envelope?.from || '');
  if (!fromEmail) return null;
  const ownEmail = String(options.ownFromEmail || '').trim().toLowerCase();
  const autoHeader = String(headers['auto-submitted'] || headers['Auto-Submitted'] || data.autoSubmitted || '').toLowerCase();
  if ((ownEmail && fromEmail === ownEmail) || /^(?:mailer-daemon|postmaster|no-?reply)@/i.test(fromEmail) || (autoHeader && autoHeader !== 'no')) return null;

  const senderName = String(data.fromName || data.senderName || parsedName || fromEmail.split('@')[0]).trim();
  const subject = sanitizeHeader(data.subject || headers.subject || headers.Subject || '');
  const cleanBody = stripHtmlAndQuotes(data.text || data['body-plain'] || data.body || '', data.html || data['body-html'] || '');

  const attachments = [];
  let unsupportedMediaType = '';
  let mediaFileName = '';
  for (const att of Array.isArray(data.attachments) ? data.attachments : []) {
    const url = String(att?.url || att?.contentUrl || '').trim();
    const mime = String(att?.contentType || att?.type || '').toLowerCase();
    const fname = String(att?.filename || att?.name || '').trim();
    if (url && (mime.startsWith('image/') || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(url))) attachments.push({ type: 'image', url });
    else if (fname || url) { unsupportedMediaType = 'file'; mediaFileName = mediaFileName || fname || 'attachment'; }
  }

  const text = cleanBody || (subject ? `[หัวข้ออีเมล] ${subject}` : '');
  if (!text && attachments.length === 0 && !unsupportedMediaType) return null;
  const rawMsgId = String(data.messageId || headers['message-id'] || headers['Message-ID'] || data.id || '').trim();
  const messageId = rawMsgId || `email_${crypto.createHash('sha256').update(`${fromEmail}|${subject}|${text.slice(0, 120)}`).digest('hex').slice(0, 20)}`;
  const inReplyTo = sanitizeHeader(data.inReplyTo || headers['in-reply-to'] || headers['In-Reply-To'] || rawMsgId);
  const rawTs = Number(data.timestamp || Date.parse(data.date || '') || Date.now());
  const timestamp = Number.isFinite(rawTs) ? (rawTs < 1e12 ? rawTs * 1000 : rawTs) : Date.now();
  return {
    channel: 'email', senderId: `email:${fromEmail}`, emailAddress: fromEmail, senderName, subject, text,
    attachments, unsupportedMediaType, mediaFileName, messageId, inReplyTo, timestamp,
    meta: { subject, messageId, inReplyTo, fromEmail }
  };
}

function createSmtpSession(initialSocket) {
  let socket = initialSocket;
  let buf = '';
  let fatalErr = null;
  let waiter = null;
  const queue = [];
  const onData = (chunk) => {
    buf += chunk.toString('utf8');
    const lines = buf.split(/\r?\n/);
    buf = lines.pop() || '';
    for (const line of lines) {
      if (!/^\d{3} /.test(line)) continue;
      const item = { code: Number(line.slice(0, 3)), line };
      if (waiter) { const w = waiter; waiter = null; w.resolve(item); } else queue.push(item);
    }
  };
  const onError = (err) => { fatalErr = err; if (waiter) { const w = waiter; waiter = null; w.reject(err); } };
  const bind = (sock) => { socket.off('data', onData); socket.off('error', onError); socket = sock; socket.on('data', onData); socket.on('error', onError); };
  socket.on('data', onData);
  socket.on('error', onError);
  const nextResponse = (timeoutMs = 12000) => {
    if (fatalErr) return Promise.reject(fatalErr);
    if (queue.length > 0) return Promise.resolve(queue.shift());
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { waiter = null; reject(new Error('SMTP response timeout')); }, timeoutMs);
      waiter = { resolve: (v) => { clearTimeout(timer); resolve(v); }, reject: (e) => { clearTimeout(timer); reject(e); } };
    });
  };
  const cmd = async (line, okCodes) => {
    const p = nextResponse();
    socket.write(`${line}\r\n`);
    const res = await p;
    if (!okCodes.includes(res.code)) throw new Error(`SMTP ${res.code}: ${res.line}`);
    return res;
  };
  return { bind, nextResponse, cmd, close: () => socket.destroy() };
}

async function sendViaSmtp({ host, port, user, pass, fromEmail, fromName, to, subject, text, inReplyTo }) {
  const portNum = Number(port) || 587;
  const implicitTls = portNum === 465;
  const rawSock = implicitTls ? tls.connect({ host, port: portNum, servername: host, timeout: 12000 }) : net.connect({ host, port: portNum, timeout: 12000 });
  const smtp = createSmtpSession(rawSock);
  try {
    const greet = await smtp.nextResponse();
    if (greet.code !== 220) throw new Error(`SMTP greeting ${greet.code}`);
    await smtp.cmd('EHLO omniflow.local', [250]);
    if (!implicitTls) {
      await smtp.cmd('STARTTLS', [220]);
      const tlsSock = tls.connect({ socket: rawSock, servername: host });
      await new Promise((res, rej) => { tlsSock.once('secureConnect', res); tlsSock.once('error', rej); });
      smtp.bind(tlsSock);
      await smtp.cmd('EHLO omniflow.local', [250]);
    }
    if (user && pass) {
      await smtp.cmd('AUTH LOGIN', [334]);
      await smtp.cmd(Buffer.from(user, 'utf8').toString('base64'), [334]);
      await smtp.cmd(Buffer.from(pass, 'utf8').toString('base64'), [235]);
    }
    await smtp.cmd(`MAIL FROM:<${sanitizeHeader(fromEmail)}>`, [250]);
    await smtp.cmd(`RCPT TO:<${sanitizeHeader(to)}>`, [250, 251]);
    await smtp.cmd('DATA', [354]);
    const msgId = `<omniflow-${Date.now()}-${crypto.randomBytes(4).toString('hex')}@omniflow.local>`;
    const fromHdr = fromName ? `${encodeMimeWord(fromName)} <${sanitizeHeader(fromEmail)}>` : sanitizeHeader(fromEmail);
    const mimeHeaders = [
      `From: ${fromHdr}`, `To: <${sanitizeHeader(to)}>`, `Subject: ${encodeMimeWord(subject)}`,
      `Date: ${new Date().toUTCString()}`, `Message-ID: ${msgId}`,
      inReplyTo ? `In-Reply-To: ${sanitizeHeader(inReplyTo)}` : '', inReplyTo ? `References: ${sanitizeHeader(inReplyTo)}` : '',
      'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64'
    ].filter(Boolean);
    await smtp.cmd(`${mimeHeaders.join('\r\n')}\r\n\r\n${toBase64Lines(text)}\r\n.`, [250]);
    await smtp.cmd('QUIT', [221, 250]).catch(() => {});
    return { ok: true, mode: 'smtp', messageId: msgId };
  } finally {
    smtp.close();
  }
}

export async function sendEmailReply({ to, subject = '', text = '', images = [], inReplyTo = '', emailConfig = {}, businessName = '' } = {}) {
  const { email: toEmail } = parseEmailAddress(to);
  if (!toEmail) throw new Error('Invalid recipient email address');
  const imgLinks = (Array.isArray(images) ? images : []).map((img) => (typeof img === 'string' ? img : img?.url || '')).filter((u) => /^https?:\/\//i.test(u));
  const fullText = imgLinks.length > 0 ? `${String(text || '').trim()}\n\nรูปภาพอ้างอิง:\n${imgLinks.join('\n')}` : String(text || '').trim();
  if (!fullText) throw new Error('Email reply body cannot be empty');

  const cleanSubj = sanitizeHeader(subject);
  const replySubject = cleanSubj ? (/^re:/i.test(cleanSubj) ? cleanSubj : `Re: ${cleanSubj}`) : `ตอบกลับจาก ${businessName || 'OmniFlow'}`;
  const fromEmail = String(emailConfig.fromEmail || emailConfig.smtpUser || '').trim();
  const fromName = String(emailConfig.fromName || businessName || 'OmniFlow').trim();

  if (emailConfig.outboundWebhookUrl) {
    const headers = { 'Content-Type': 'application/json' };
    if (emailConfig.webhookSecret) headers['X-Webhook-Secret'] = String(emailConfig.webhookSecret);
    const res = await fetch(String(emailConfig.outboundWebhookUrl).trim(), {
      method: 'POST', headers, signal: AbortSignal.timeout(15000),
      body: JSON.stringify({ to: toEmail, from: fromEmail, fromName, subject: replySubject, text: fullText, images: imgLinks, inReplyTo, sentAt: new Date().toISOString() })
    });
    if (!res.ok) throw new Error(`Email Outbound Webhook HTTP ${res.status}`);
    return { ok: true, platform: 'email', mode: 'outbound_webhook', messageId: `email_wh_${Date.now()}` };
  }
  if (!emailConfig.smtpHost || !fromEmail) throw new Error('Missing Email SMTP Host/From Email or Outbound Webhook URL');
  const smtpRes = await sendViaSmtp({
    host: String(emailConfig.smtpHost).trim(), port: emailConfig.smtpPort || 587,
    user: String(emailConfig.smtpUser || fromEmail).trim(), pass: String(emailConfig.smtpPass || ''),
    fromEmail, fromName, to: toEmail, subject: replySubject, text: fullText, inReplyTo
  });
  return { ...smtpRes, platform: 'email' };
}
