// gateway/src/modules/channels/discord-adapter.mjs
// Wave 2 Adapter: Discord Interactions & Bot REST API (Native Ed25519 + PING + Embed Images)

import {
  normalizeHeaders,
  verifyEd25519Signature,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const DISCORD_API_BASE = 'https://discord.com/api/v10';

function extractInteractionText(data = {}) {
  const parts = [];
  if (Array.isArray(data?.options)) {
    for (const opt of data.options) {
      if (opt?.value !== undefined && opt?.value !== null && String(opt.value).trim()) {
        parts.push(String(opt.value).trim());
      }
    }
  }
  if (parts.length > 0) return parts.join(' ');
  return String(data?.custom_id || data?.name || '').trim();
}

const discordAdapter = {
  meta: {
    id: 'discord',
    wave: 'wave2',
    category: 'messaging',
    label: 'Discord Bot & Interactions',
    shortLabel: 'DISCORD',
    badgeColor: '#5865F2',
    badgeBg: 'rgba(88, 101, 242, 0.14)',
    webhookPath: '/webhook/discord',
    supportsImages: true,
    supportsChallenge: true,
    fields: [
      { key: 'applicationId', label: 'Application ID', type: 'text', secret: false, required: true, placeholder: 'Discord Application ID', envKey: 'DISCORD_APPLICATION_ID' },
      { key: 'publicKey', label: 'Public Key (Ed25519 Hex)', type: 'text', secret: false, required: true, placeholder: '64-char hex public key', envKey: 'DISCORD_PUBLIC_KEY' },
      { key: 'botToken', label: 'Bot Token', type: 'password', secret: true, required: true, placeholder: 'Discord Bot Token', envKey: 'DISCORD_BOT_TOKEN' }
    ]
  },

  handleChallenge(req, _channelCfg = {}, _parsedUrl, payload = {}) {
    if (req.method === 'POST' && Number(payload?.type) === 1) {
      return {
        isChallenge: true,
        status: 200,
        contentType: 'application/json; charset=utf-8',
        response: { type: 1 }
      };
    }
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const h = normalizeHeaders(headers);
    const publicKeyHex = String(channelCfg.publicKey || process.env.DISCORD_PUBLIC_KEY || '').trim();
    if (!publicKeyHex) {
      return { valid: false, reason: 'Missing Discord Public Key (Ed25519 verification required)' };
    }
    return verifyEd25519Signature({
      timestamp: h['x-signature-timestamp'] || '',
      rawBody: rawBuf || rawBody,
      signatureHex: h['x-signature-ed25519'] || '',
      publicKeyHex
    });
  },

  normalizeInbound(payload = {}, { channelCfg = {} } = {}) {
    if (!payload || typeof payload !== 'object' || Number(payload.type) === 1) return [];
    const appId = String(channelCfg.applicationId || process.env.DISCORD_APPLICATION_ID || payload.application_id || '').trim();

    // Case A: Discord Interactions Webhook (Slash Command / Component)
    if (Number(payload.type) === 2 || Number(payload.type) === 3) {
      const user = payload.member?.user || payload.user || {};
      if (!user.id || user.bot === true || (appId && String(user.id) === appId)) return [];
      const text = extractInteractionText(payload.data);
      if (!text) return [];

      const channelId = String(payload.channel_id || user.id).trim();
      const senderName = String(user.global_name || user.username || `Discord (${String(user.id).slice(-6)})`).trim();
      return [
        buildNormalizedInbound({
          channel: 'discord',
          externalUserId: channelId,
          senderName,
          text,
          messageId: String(payload.id || `dc_int_${Date.now()}`),
          attachments: [],
          replyToken: String(payload.token || ''),
          timestamp: Date.now(),
          meta: {
            channelId,
            userId: String(user.id),
            applicationId: appId,
            interactionToken: String(payload.token || ''),
            interactionExpiresAt: Date.now() + 14 * 60 * 1000,
            syncHttpResponse: { type: 5 }
          }
        })
      ];
    }

    // Case B: Discord Relayed Message Event
    const msg = payload.d && typeof payload.d === 'object' ? payload.d : payload;
    const author = msg.author || {};
    if (!author.id || author.bot === true || msg.webhook_id || (appId && String(author.id) === appId)) return [];

    const channelId = String(msg.channel_id || author.id).trim();
    const text = String(msg.content || '').trim();
    const attachments = [];
    let unsupportedMediaType = '';
    let mediaFileName = '';

    for (const att of Array.isArray(msg.attachments) ? msg.attachments : []) {
      const url = String(att?.url || att?.proxy_url || '').trim();
      const mime = String(att?.content_type || '').toLowerCase();
      if (url && (mime.startsWith('image/') || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(url))) {
        attachments.push({ type: 'image', url, mimeType: mime || 'image/jpeg' });
      } else if (url) {
        unsupportedMediaType = mime.startsWith('audio/') ? 'audio' : mime.startsWith('video/') ? 'video' : 'file';
        mediaFileName = mediaFileName || String(att?.filename || 'attachment');
      }
    }
    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];

    const senderName = String(author.global_name || author.username || `Discord (${String(author.id).slice(-6)})`).trim();
    return [
      buildNormalizedInbound({
        channel: 'discord',
        externalUserId: channelId,
        senderName,
        text: text || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Discord: ${mediaFileName || unsupportedMediaType}]` : ''),
        messageId: String(msg.id || `dc_${channelId}_${Date.now()}`),
        attachments,
        timestamp: Date.parse(msg.timestamp || '') || Date.now(),
        unsupportedMediaType,
        mediaFileName,
        meta: { channelId, userId: String(author.id), applicationId: appId }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], replyToken = '', channelCfg = {}, meta = {} }) {
    const botToken = String(channelCfg.botToken || process.env.DISCORD_BOT_TOKEN || '').trim();
    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 10);
    const cleanText = String(text || '').trim().slice(0, 2000);
    if (!cleanText && mediaUrls.length === 0) throw new Error('Discord reply content cannot be empty');

    const body = {
      ...(cleanText ? { content: cleanText } : {}),
      ...(mediaUrls.length > 0 ? { embeds: mediaUrls.map((url) => ({ image: { url } })) } : {})
    };

    const appId = String(meta.applicationId || channelCfg.applicationId || process.env.DISCORD_APPLICATION_ID || '').trim();
    const intToken = String(replyToken || meta.interactionToken || '').trim();
    const canUseFollowup = Boolean(appId && intToken && (!meta.interactionExpiresAt || Date.now() < Number(meta.interactionExpiresAt)));

    if (canUseFollowup) {
      const followupUrl = `${DISCORD_API_BASE}/webhooks/${encodeURIComponent(appId)}/${encodeURIComponent(intToken)}`;
      const fRes = await fetchWithTimeout(followupUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      if (fRes.ok) {
        const fJson = await fRes.json().catch(() => ({}));
        return { ok: true, platform: 'discord', messageId: String(fJson?.id || `dc_fu_${Date.now()}`), mode: 'interaction_followup' };
      }
    }

    if (!botToken) throw new Error('Missing Discord Bot Token');
    const channelId = String(meta.channelId || to || '').trim();
    if (!channelId) throw new Error('Missing Discord channelId');

    const url = `${DISCORD_API_BASE}/channels/${encodeURIComponent(channelId)}/messages`;
    const res = await fetchWithTimeout(url, {
      method: 'POST',
      headers: { Authorization: `Bot ${botToken}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Discord Send HTTP ${res.status}: ${json?.message || ''}`);
    return { ok: true, platform: 'discord', messageId: String(json?.id || `dc_out_${Date.now()}`), mode: 'bot_rest_v10' };
  }
};

export default discordAdapter;
