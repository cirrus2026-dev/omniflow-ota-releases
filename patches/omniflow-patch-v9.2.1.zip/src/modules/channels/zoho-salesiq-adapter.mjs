// gateway/src/modules/channels/zoho-salesiq-adapter.mjs
// Wave 4 Adapter: Zoho SalesIQ Live Chat (Strict HMAC + SSRF-Guarded Multi-DC OAuth & v2 Reply)

import net from 'node:net';
import { isPrivateOrReservedIp } from '../fetch-safe.mjs';
import {
  normalizeHeaders,
  verifyHmacTimingSafe,
  getCachedToken,
  resolvePublicMediaUrls,
  fetchWithTimeout,
  buildNormalizedInbound
} from './channel-contract.mjs';

const ALLOWED_ZOHO_DCS = new Set(['com', 'eu', 'in', 'com.au', 'jp', 'com.cn']);
const BLOCKED_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data'
]);

function validateSafeHttpsUrl(rawUrl = '') {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) return '';
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

function resolveZohoDc(rawDc = '') {
  const clean = String(rawDc || process.env.ZOHO_SIQ_DATA_CENTER || 'com').trim().toLowerCase().replace(/^\.+/, '');
  return ALLOWED_ZOHO_DCS.has(clean) ? clean : 'com';
}

async function getZohoSalesIqToken(channelCfg = {}) {
  const dc = resolveZohoDc(channelCfg.dataCenter);
  const clientId = String(channelCfg.clientId || process.env.ZOHO_SIQ_CLIENT_ID || '').trim();
  const clientSecret = String(channelCfg.clientSecret || process.env.ZOHO_SIQ_CLIENT_SECRET || '').trim();
  const refreshToken = String(channelCfg.refreshToken || process.env.ZOHO_SIQ_REFRESH_TOKEN || '').trim();
  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error('Missing Zoho SalesIQ OAuth credentials (clientId, clientSecret, refreshToken)');
  }

  const url = validateSafeHttpsUrl(`https://accounts.zoho.${dc}/oauth/v2/token`);
  if (!url) throw new Error('Blocked unsafe Zoho OAuth URL (must be public HTTPS)');

  return getCachedToken(
    `zoho_siq:${dc}:${clientId}`,
    async () => {
      const res = await fetchWithTimeout(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          refresh_token: refreshToken,
          client_id: clientId,
          client_secret: clientSecret
        })
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok || !json.access_token) {
        throw new Error(`Zoho OAuth HTTP ${res.status}: ${json.error || ''}`);
      }
      return { token: json.access_token, expiresInSec: Number(json.expires_in || 3600) };
    },
    300
  );
}

const zohoSalesiqAdapter = {
  meta: {
    id: 'zoho_salesiq',
    wave: 'wave4',
    category: 'livechat',
    label: 'Zoho SalesIQ',
    shortLabel: 'ZOHO',
    badgeColor: '#E42527',
    badgeBg: 'rgba(228, 37, 39, 0.14)',
    webhookPath: '/webhook/zoho_salesiq',
    supportsImages: true,
    supportsChallenge: false,
    fields: [
      { key: 'screenName', label: 'Portal Screen Name', type: 'text', secret: false, required: true, placeholder: 'เช่น yourcompany', envKey: 'ZOHO_SIQ_SCREEN_NAME' },
      { key: 'dataCenter', label: 'Zoho Data Center (com / eu / in)', type: 'text', secret: false, placeholder: 'com', envKey: 'ZOHO_SIQ_DATA_CENTER' },
      { key: 'clientId', label: 'OAuth Client ID', type: 'text', secret: false, required: true, placeholder: '1000.XXXXXXXXXX', envKey: 'ZOHO_SIQ_CLIENT_ID' },
      { key: 'webhookSecret', label: 'Webhook Secret (x-siq-signature)', type: 'password', secret: true, placeholder: 'Webhook Signing Key', envKey: 'ZOHO_SIQ_WEBHOOK_SECRET' },
      { key: 'clientSecret', label: 'OAuth Client Secret', type: 'password', secret: true, required: true, placeholder: 'Zoho Client Secret', envKey: 'ZOHO_SIQ_CLIENT_SECRET' },
      { key: 'refreshToken', label: 'OAuth Refresh Token', type: 'password', secret: true, required: true, placeholder: '1000.xxxx.xxxx', envKey: 'ZOHO_SIQ_REFRESH_TOKEN' }
    ]
  },

  handleChallenge() {
    return { isChallenge: false };
  },

  verifySignature({ headers = {}, rawBuf, rawBody = '', channelCfg = {} }) {
    const secret = String(channelCfg.webhookSecret || process.env.ZOHO_SIQ_WEBHOOK_SECRET || '').trim();
    if (!secret) return { valid: false, reason: 'Missing Zoho SalesIQ webhookSecret configuration' };

    const h = normalizeHeaders(headers);
    const sig = h['x-siq-signature'] || h['x-zoho-signature'] || '';
    if (!sig) return { valid: false, reason: 'Missing Zoho SalesIQ signature header' };

    const payload = rawBuf || rawBody;
    const hexRes = verifyHmacTimingSafe({ rawBody: payload, secret, signature: sig, encoding: 'hex', allowMockBypass: false });
    if (hexRes.valid) return { valid: true, mode: 'zoho_hmac_hex' };

    const b64Res = verifyHmacTimingSafe({ rawBody: payload, secret, signature: sig, encoding: 'base64', allowMockBypass: false });
    if (b64Res.valid) return { valid: true, mode: 'zoho_hmac_b64' };

    return { valid: false, reason: 'Invalid Zoho SalesIQ HMAC signature' };
  },

  normalizeInbound(payload = {}) {
    if (!payload || typeof payload !== 'object') return [];
    const entity = payload.entity && typeof payload.entity === 'object' ? payload.entity : payload.data || payload;
    const msg = entity.message && typeof entity.message === 'object' ? entity.message : payload.message || entity;

    const senderType = String(msg?.sender?.type || entity?.sender?.type || payload?.sender_type || '').toLowerCase();
    if (senderType === 'operator' || senderType === 'bot' || senderType === 'system' || payload.is_echo) return [];

    const convId = String(entity.conversation_id || entity.id || payload.conversation_id || '').trim();
    if (!convId) return [];

    const visitor = entity.visitor || payload.visitor || {};
    const text = String(msg?.text || msg?.content || entity?.text || '').trim();
    const attachments = [];
    let unsupportedMediaType = '';
    let mediaFileName = '';

    const fileObj = msg?.file || entity?.file;
    const attList = [
      ...(fileObj ? [fileObj] : []),
      ...(Array.isArray(msg?.attachments) ? msg.attachments : [])
    ];
    for (const att of attList) {
      const url = String(att?.url || att?.download_url || '').trim();
      const mime = String(att?.content_type || att?.type || '').toLowerCase();
      if (url && (mime.startsWith('image/') || /\.(?:png|jpe?g|webp|gif)(?:\?|$)/i.test(url))) {
        attachments.push({ type: 'image', url, mimeType: mime || 'image/jpeg' });
      } else if (url || att?.name) {
        unsupportedMediaType = 'file';
        mediaFileName = mediaFileName || String(att?.name || 'attachment');
      }
    }

    if (!text && attachments.length === 0 && !unsupportedMediaType) return [];
    const senderName = String(visitor.name || msg?.sender?.name || `Zoho (${convId.slice(-6)})`).trim();

    return [
      buildNormalizedInbound({
        channel: 'zoho_salesiq',
        externalUserId: convId,
        senderName,
        text: text || (unsupportedMediaType ? `[ลูกค้าส่งไฟล์ทาง Zoho SalesIQ: ${mediaFileName || unsupportedMediaType}]` : ''),
        messageId: String(msg?.id || payload.event_id || `zoho_${convId}_${Date.now()}`),
        attachments,
        timestamp: Number(msg?.time || payload.timestamp || Date.now()),
        unsupportedMediaType,
        mediaFileName,
        meta: {
          conversationId: convId,
          visitorEmail: String(visitor.email || ''),
          visitorPhone: String(visitor.phone || '')
        }
      })
    ];
  },

  async sendReply({ to, text = '', images = [], channelCfg = {}, meta = {} }) {
    const dc = resolveZohoDc(channelCfg.dataCenter);
    const screenName = String(channelCfg.screenName || process.env.ZOHO_SIQ_SCREEN_NAME || '').trim();
    if (!screenName) throw new Error('Missing Zoho SalesIQ screenName');

    const convId = String(meta.conversationId || to || '').replace(/^zoho_salesiq:/i, '').trim();
    if (!convId) throw new Error('Missing Zoho SalesIQ conversationId');

    const mediaUrls = resolvePublicMediaUrls(images).slice(0, 4);
    const cleanText = String(text || '').trim();
    const fullText = mediaUrls.length > 0 ? [cleanText, ...mediaUrls].filter(Boolean).join('\n') : cleanText;
    if (!fullText) throw new Error('Zoho SalesIQ reply text cannot be empty');

    const token = await getZohoSalesIqToken(channelCfg);
    const url = validateSafeHttpsUrl(
      `https://salesiq.zoho.${dc}/api/v2/${encodeURIComponent(screenName)}/conversations/${encodeURIComponent(convId)}/messages`
    );
    if (!url) throw new Error('Blocked unsafe Zoho SalesIQ API URL (must be public HTTPS)');

    const res = await fetchWithTimeout(url, {
      method: 'POST',
      headers: {
        Authorization: `Zoho-oauthtoken ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ text: fullText.slice(0, 4000) })
    });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(`Zoho SalesIQ Send HTTP ${res.status}: ${json?.error?.message || ''}`);
    return {
      ok: true,
      platform: 'zoho_salesiq',
      messageId: String(json?.data?.id || json?.id || `zoho_out_${Date.now()}`),
      mode: 'salesiq_v2'
    };
  }
};

export default zohoSalesiqAdapter;
