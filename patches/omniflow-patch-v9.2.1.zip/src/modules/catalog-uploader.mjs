// Phase 8.4 Modular Plugin: Live Catalog Uploader (Synced with Local DB & Orphan Cleanup)
// Flow: validate -> save image{next}.{ext} into /app/images_web -> upload to GitHub (Contents API)
//       -> append 9 columns to Google Sheets "Price_List" -> sync to local-db-manager.mjs -> invalidate caches.
// All server dependencies are injected via `deps` so this module has no hidden globals.
import fs from 'node:fs';
import path from 'node:path';
import { addCatalogItem, getAllCatalogItems } from './local-db-manager.mjs';
import { clearStonePreviewCache } from './stone-preview.mjs';

const GITHUB_REPO = (process.env.CATALOG_IMAGE_REPO || process.env.STONE_IMAGE_REPO || '').trim();
const GITHUB_BRANCH = (process.env.CATALOG_IMAGE_BRANCH || process.env.STONE_IMAGE_BRANCH || 'main').trim();
const RAW_CDN_BASE = GITHUB_REPO ? `https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/` : '';
const PRICE_LIST_SHEET = process.env.PRICE_LIST_SHEET_NAME || 'Price_List';
const MAX_IMAGE_BYTES = 8 * 1024 * 1024; // 8 MB
const IMAGES_DIR_CANDIDATES = [
  process.env.GATEWAY_IMAGES_DIR,
  '/app/images_web',
  path.resolve(process.cwd(), 'images_web'),
].filter(Boolean);
const SA_FILE_CANDIDATES = [
  process.env.GOOGLE_SA_FILE,
  '/app/secrets/google-service-account.json',
  '/app/data/google-service-account.json',
].filter(Boolean);

function resolveImagesDir() {
  return IMAGES_DIR_CANDIDATES.find((p) => fs.existsSync(p)) || IMAGES_DIR_CANDIDATES[0];
}

function detectImageExtension(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return '.jpg';
  if (
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
    buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a
  ) return '.png';
  if (
    buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buf.subarray(8, 12).toString('ascii') === 'WEBP'
  ) return '.webp';
  return null;
}

function findNextImageNumber(imagesDir, catalogRows, localItems = []) {
  let maxNum = 0;
  const bump = (str) => {
    const m = String(str || '').match(/image(\d+)\.(?:jpg|jpeg|png|webp)/i);
    if (m) maxNum = Math.max(maxNum, Number(m[1]) || 0);
  };
  try {
    fs.readdirSync(imagesDir).forEach(bump);
  } catch {
    // Directory may be empty or missing; catalog rows still provide a floor
  }
  (catalogRows || []).forEach((r) => bump(r?.imgRaw || r?.imageUrl));
  (localItems || []).forEach((r) => bump(r?.imageUrl || r?.imgRaw));
  return maxNum + 1;
}

function writeLocalImageExclusive(imagesDir, startNum, ext, imageBuffer) {
  fs.mkdirSync(imagesDir, { recursive: true });
  for (let offset = 0; offset < 25; offset += 1) {
    const fileName = `image${startNum + offset}${ext}`;
    const localFilePath = path.join(imagesDir, fileName);
    try {
      fs.writeFileSync(localFilePath, imageBuffer, { flag: 'wx' });
      return { fileName, localFilePath };
    } catch (err) {
      if (err?.code === 'EEXIST') continue;
      throw err;
    }
  }
  throw new Error('ไม่สามารถจัดสรรชื่อไฟล์รูปภาพใหม่ได้ (ไฟล์ชนกันหลายครั้ง)');
}

function cleanupOrphanFile(filePath) {
  if (!filePath) return;
  try {
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  } catch {
    // Best-effort cleanup of orphaned local image
  }
}

async function uploadToGithub(fileName, base64Data, stoneName) {
  const token = process.env.GITHUB_TOKEN || process.env.GH_TOKEN || '';
  if (!GITHUB_REPO || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(GITHUB_REPO)) {
    return { ok: false, reason: 'ยังไม่ได้ตั้งค่า CATALOG_IMAGE_REPO ให้ถูกต้องใน gateway/.env' };
  }
  if (!token) {
    return { ok: false, reason: 'ยังไม่ได้ตั้งค่า GITHUB_TOKEN ใน gateway/.env' };
  }
  const res = await fetch(
    `https://api.github.com/repos/${GITHUB_REPO}/contents/${encodeURIComponent(fileName)}`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
        'Content-Type': 'application/json',
        'User-Agent': 'OmniFlow-Gateway',
      },
      body: JSON.stringify({ message: `Add new stone ${stoneName}`, content: base64Data, branch: GITHUB_BRANCH }),
      signal: AbortSignal.timeout(25000),
    }
  );
  if (res.ok) return { ok: true };
  const detail = await res.text().catch(() => '');
  return { ok: false, reason: `GitHub API HTTP ${res.status} ${detail.slice(0, 120)}` };
}

async function appendPriceListRow(row, deps) {
  const saFile = SA_FILE_CANDIDATES.find((p) => fs.existsSync(p) && !fs.statSync(p).isDirectory());
  if (!saFile) return { ok: false, reason: 'ไม่พบไฟล์ Service Account (/app/secrets/google-service-account.json)' };

  const token = await deps.getGoogleServiceAccountToken?.(saFile);
  if (!token) return { ok: false, reason: 'ขอ OAuth token จาก Service Account ไม่สำเร็จ' };
  if (!deps.spreadsheetId) return { ok: false, reason: 'ยังไม่ได้ตั้งค่า spreadsheetId สำหรับ Price_List' };

  const range = encodeURIComponent(`${PRICE_LIST_SHEET}!A:I`);
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(
    deps.spreadsheetId
  )}/values/${range}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ values: [row] }),
    signal: AbortSignal.timeout(10000),
  });
  if (res.ok) return { ok: true };
  return { ok: false, reason: res.status === 403 ? 'Service Account ไม่มีสิทธิ์ Editor บนชีต' : `Sheets HTTP ${res.status}` };
}

/**
 * @param {object} payload { imageBase64, category, stoneName, size, unit, slabPrice, cutPrice, note, blockCode }
 * @param {object} deps { getCatalogRows, clearCatalogCache, getGoogleServiceAccountToken, spreadsheetId, priceCacheFile, addCatalogItem }
 */
export async function uploadNewStoneToCatalogAndGithub(payload = {}, deps = {}) {
  const category = String(payload.category || '').trim();
  const stoneName = String(payload.stoneName || '').trim();
  const size = String(payload.size || '').trim() || 'แผ่นมาตรฐาน / สั่งตัด';
  const unit = String(payload.unit || '').trim() || 'ตร.ม.';
  const note = String(payload.note || '').trim() || 'ราคาเฉพาะแผ่นหิน';
  const blockCode = String(payload.blockCode || '').trim();
  const toPrice = (v) => {
    const n = Number(String(v ?? '').replace(/,/g, '').trim());
    return String(v ?? '').trim() !== '' && Number.isFinite(n) && n > 0 ? n : '';
  };
  const slabPrice = toPrice(payload.slabPrice);
  const cutPrice = toPrice(payload.cutPrice);

  if (!category || !stoneName) throw new Error('กรุณาระบุ "ชนิดสินค้า" และ "ชื่อสินค้า / สี" ให้ครบ');
  if (slabPrice === '' && cutPrice === '') throw new Error('กรุณาใส่ราคาอย่างน้อย 1 แบบ (ยกสแลป หรือ สั่งตัด)');

  const base64Data = String(payload.imageBase64 || '')
    .replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '')
    .replace(/\s+/g, '')
    .trim();
  const estimatedBytes = Math.floor((base64Data.length * 3) / 4);
  if (estimatedBytes > MAX_IMAGE_BYTES + 1024) {
    throw new Error('ขนาดไฟล์รูปภาพเกินกำหนด (สูงสุด 8 MB)');
  }
  const imageBuffer = Buffer.from(base64Data, 'base64');
  if (imageBuffer.length < 64) throw new Error('กรุณาเลือกรูปภาพหิน (ไฟล์ว่างหรือไม่ถูกต้อง)');
  if (imageBuffer.length > MAX_IMAGE_BYTES) throw new Error('ขนาดไฟล์รูปภาพเกินกำหนด (สูงสุด 8 MB)');

  const ext = detectImageExtension(imageBuffer);
  if (!ext) {
    throw new Error('ไฟล์รูปภาพไม่ถูกต้อง (ตรวจ Magic Bytes ไม่ผ่าน — รองรับเฉพาะ JPG, PNG, WebP)');
  }

  // 1. Save image{next}.{ext} locally with exclusive lock to prevent collisions
  const imagesDir = resolveImagesDir();
  const existingRows = typeof deps.getCatalogRows === 'function' ? await deps.getCatalogRows(false) : [];
  const localItems = await getAllCatalogItems().catch(() => []);
  const nextNum = findNextImageNumber(imagesDir, existingRows, localItems);
  const { fileName, localFilePath } = writeLocalImageExclusive(imagesDir, nextNum, ext, imageBuffer);
  const localImageUrl = `/images_web/${fileName}`;

  try {
    // 2. Upload to GitHub. Clean up local file if it fails so no orphan remains on disk.
    const gh = await uploadToGithub(fileName, base64Data, stoneName);
    if (!gh.ok) {
      throw new Error(`อัปโหลดรูป ${fileName} ขึ้น GitHub ไม่สำเร็จ (${gh.reason}) — ลบไฟล์ชั่วคราวในเครื่องและยกเลิกการบันทึกแล้ว`);
    }
    const cdnUrl = `${RAW_CDN_BASE}${fileName}`;

    // 3. Append 9 columns to Google Sheets "Price_List"
    const row = [category, stoneName, size, unit, slabPrice, cutPrice, note, blockCode, cdnUrl];
    const sheet = await appendPriceListRow(row, deps);
    if (!sheet.ok) {
      throw new Error(`อัปรูป ${fileName} ขึ้น GitHub แล้ว แต่บันทึก Price_List ไม่สำเร็จ (${sheet.reason}) — ลบไฟล์ชั่วคราวในเครื่องแล้ว`);
    }

    // 4. Sync uploaded product into local-db-manager.mjs to eliminate Dual Catalog Split-Brain
    const syncLocalCatalog = typeof deps.addCatalogItem === 'function' ? deps.addCatalogItem : addCatalogItem;
    const localItem = await syncLocalCatalog({
      category,
      name: stoneName,
      size,
      unit,
      slabPrice: slabPrice === '' ? null : slabPrice,
      cutPrice: cutPrice === '' ? null : cutPrice,
      note,
      blockCode,
      imageUrl: localImageUrl,
    });

    // 5. Invalidate caches so bot + dashboard + hover preview see the new stone immediately
    deps.clearCatalogCache?.();
    clearStonePreviewCache();
    try {
      if (deps.priceCacheFile && fs.existsSync(deps.priceCacheFile)) fs.unlinkSync(deps.priceCacheFile);
    } catch {
      // Non-fatal
    }

    return { ok: true, fileName, cdnUrl, localImageUrl, localItem, row };
  } catch (err) {
    cleanupOrphanFile(localFilePath);
    throw err;
  }
}
