// gateway/src/modules/zip-reader.mjs
// Safe Pure-Node ZIP Reader & Patch Archive Parser (Zip-Bomb Cap, Root-Only Manifest, Path Traversal & Symlink Guard)

import zlib from 'node:zlib';
import fs from 'node:fs/promises';
import path from 'node:path';

export const MAX_ZIP_ENTRIES = 200;
export const MAX_ZIP_OUTPUT_BYTES = 25 * 1024 * 1024;
export const MAX_ZIP_ENTRY_BYTES = 10 * 1024 * 1024;

const MAX_BASE64_OUTPUT_LEN = Math.ceil((MAX_ZIP_OUTPUT_BYTES * 4) / 3) + 64;
const MAX_BASE64_ENTRY_LEN = Math.ceil((MAX_ZIP_ENTRY_BYTES * 4) / 3) + 64;
const EOCD_SIG = 0x06054b50;
const CD_SIG = 0x02014b50;
const LFH_SIG = 0x04034b50;
const UNIX_TYPE_MASK = 0o170000;
const UNIX_SYMLINK_TYPE = 0o120000;
const UNIX_REG_TYPE = 0o100000;
const UNIX_DIR_TYPE = 0o040000;

function isArchiveRootManifest(entryName) {
  let clean = String(entryName || '').replace(/\\/g, '/').replace(/^(?:\.\/)+/, '');
  if (clean.toLowerCase().startsWith('gateway/')) {
    clean = clean.slice('gateway/'.length);
  }
  const lower = clean.toLowerCase();
  return lower === 'manifest.json' || lower === 'patch.json';
}

export function assertSafeZipEntryPath(rawName) {
  const raw = String(rawName || '');
  if (!raw || raw.includes('\0') || /[\r\n]/.test(raw)) {
    throw new Error(`ตรวจพบชื่อไฟล์ไม่ปลอดภัยใน .zip: ${rawName}`);
  }
  const normalized = raw.replace(/\\/g, '/');
  if (normalized.startsWith('/') || /^[a-zA-Z]:/.test(normalized)) {
    throw new Error(`ไม่อนุญาต Absolute Path ใน .zip: ${rawName}`);
  }
  if (normalized.split('/').some((seg) => seg === '..')) {
    throw new Error(`ตรวจพบ Path Traversal (..) ใน .zip: ${rawName}`);
  }
  const cleaned = normalized.replace(/^(?:\.\/)+/, '').replace(/\/+$/, '');
  if (!cleaned || cleaned.startsWith('/') || /^[a-zA-Z]:/.test(cleaned)) {
    throw new Error(`พาธไฟล์ใน .zip ไม่ถูกต้อง: ${rawName}`);
  }
  return cleaned;
}

export async function assertNoSymlinkPath(baseDir, targetAbsPath) {
  const resolvedBase = path.resolve(baseDir);
  const resolvedTarget = path.resolve(targetAbsPath);
  if (resolvedTarget !== resolvedBase && !resolvedTarget.startsWith(resolvedBase + path.sep)) {
    throw new Error(`ตรวจพบการออกนอกขอบเขตโฟลเดอร์ที่อนุญาต: ${targetAbsPath}`);
  }
  const rel = path.relative(resolvedBase, resolvedTarget);
  if (!rel) return resolvedTarget;

  let current = resolvedBase;
  for (const seg of rel.split(path.sep)) {
    if (!seg || seg === '.') continue;
    current = path.join(current, seg);
    try {
      const stat = await fs.lstat(current);
      if (stat.isSymbolicLink()) throw new Error(`ไม่อนุญาต Symlink เพื่อความปลอดภัย: ${rel}`);
    } catch (err) {
      if (err?.code === 'ENOENT') break;
      throw err;
    }
  }
  return resolvedTarget;
}

export function extractZipEntries(zipBuffer, options = {}) {
  if (!Buffer.isBuffer(zipBuffer) || zipBuffer.length < 22) {
    throw new Error('ไฟล์ .zip ไม่ถูกต้องหรือขนาดเล็กเกินไป');
  }
  const maxEntries = Math.min(MAX_ZIP_ENTRIES, Math.max(1, Number(options.maxEntries) || MAX_ZIP_ENTRIES));
  const maxOutputLength = Math.min(MAX_ZIP_OUTPUT_BYTES, Math.max(1024, Number(options.maxOutputLength) || MAX_ZIP_OUTPUT_BYTES));
  const maxEntryBytes = Math.min(maxOutputLength, Math.max(1024, Number(options.maxEntryBytes) || MAX_ZIP_ENTRY_BYTES));

  if (zipBuffer.length > maxOutputLength) {
    throw new Error(`Zip-Bomb Guard: ขนาดไฟล์ .zip (${zipBuffer.length} bytes) เกินเพดานที่อนุญาต`);
  }

  let eocdOffset = -1;
  const minOffset = Math.max(0, zipBuffer.length - 65557);
  for (let i = zipBuffer.length - 22; i >= minOffset; i--) {
    if (zipBuffer.readUInt32LE(i) === EOCD_SIG) {
      eocdOffset = i;
      break;
    }
  }
  if (eocdOffset === -1) throw new Error('ไม่พบโครงสร้าง ZIP Header ที่ถูกต้อง');

  const totalEntries = zipBuffer.readUInt16LE(eocdOffset + 10);
  const cdOffset = zipBuffer.readUInt32LE(eocdOffset + 16);
  if (totalEntries === 0xffff || cdOffset === 0xffffffff) {
    throw new Error('ไม่รองรับไฟล์ ZIP64 หรือขนาดเกินขอบเขตความปลอดภัย');
  }
  if (totalEntries > maxEntries) {
    throw new Error(`Zip-Bomb Guard: จำนวนไฟล์ใน .zip (${totalEntries}) เกินเพดานสูงสุด (${maxEntries})`);
  }

  const entries = [];
  const seenNames = new Set();
  let totalUncompressed = 0;
  let pos = cdOffset;

  for (let i = 0; i < totalEntries; i++) {
    if (pos + 46 > zipBuffer.length || zipBuffer.readUInt32LE(pos) !== CD_SIG) {
      throw new Error('โครงสร้าง Central Directory ในไฟล์ .zip เสียหาย');
    }
    const flags = zipBuffer.readUInt16LE(pos + 8);
    const method = zipBuffer.readUInt16LE(pos + 10);
    const compSize = zipBuffer.readUInt32LE(pos + 20);
    const uncompSize = zipBuffer.readUInt32LE(pos + 24);
    const nameLen = zipBuffer.readUInt16LE(pos + 28);
    const extraLen = zipBuffer.readUInt16LE(pos + 30);
    const commentLen = zipBuffer.readUInt16LE(pos + 32);
    const extAttr = zipBuffer.readUInt32LE(pos + 38);
    const localHeaderOffset = zipBuffer.readUInt32LE(pos + 42);

    if ((flags & 0x01) !== 0) throw new Error('ไม่อนุญาตไฟล์ .zip ที่เข้ารหัสด้วยรหัสผ่าน');
    if (compSize === 0xffffffff || uncompSize === 0xffffffff || localHeaderOffset === 0xffffffff) {
      throw new Error('ไม่รองรับรายการ ZIP64 ในไฟล์แพตช์');
    }
    if (pos + 46 + nameLen + extraLen + commentLen > zipBuffer.length) {
      throw new Error('ข้อมูล Central Directory ในไฟล์ .zip เกินขนาดบัฟเฟอร์');
    }

    const rawName = zipBuffer.subarray(pos + 46, pos + 46 + nameLen).toString('utf8');
    pos += 46 + nameLen + extraLen + commentLen;

    const unixFileType = ((extAttr >>> 16) & 0xffff) & UNIX_TYPE_MASK;
    if (unixFileType === UNIX_SYMLINK_TYPE) throw new Error(`ไม่อนุญาต Symlink ในไฟล์ .zip: ${rawName}`);
    if (unixFileType !== 0 && unixFileType !== UNIX_REG_TYPE && unixFileType !== UNIX_DIR_TYPE) {
      throw new Error(`ไม่อนุญาตไฟล์พิเศษใน .zip: ${rawName}`);
    }

    if (!rawName || rawName.startsWith('__MACOSX/')) continue;
    if (rawName.endsWith('/')) {
      const dirPart = rawName.replace(/\/+$/, '');
      if (dirPart) assertSafeZipEntryPath(dirPart);
      continue;
    }

    const safeName = assertSafeZipEntryPath(rawName);
    if (seenNames.has(safeName)) throw new Error(`ตรวจพบชื่อไฟล์ซ้ำใน .zip: ${safeName}`);
    seenNames.add(safeName);
    if (entries.length >= maxEntries) {
      throw new Error(`Zip-Bomb Guard: จำนวนไฟล์ที่แตกเกินเพดานสูงสุด (${maxEntries})`);
    }

    if (localHeaderOffset + 30 > zipBuffer.length || zipBuffer.readUInt32LE(localHeaderOffset) !== LFH_SIG) {
      throw new Error(`Local Header เสียหายที่ไฟล์: ${safeName}`);
    }
    const lhNameLen = zipBuffer.readUInt16LE(localHeaderOffset + 26);
    const lhExtraLen = zipBuffer.readUInt16LE(localHeaderOffset + 28);
    const dataStart = localHeaderOffset + 30 + lhNameLen + lhExtraLen;
    if (dataStart + compSize > zipBuffer.length) {
      throw new Error(`ข้อมูลไฟล์บีบอัดเสียหายหรือเกินขนาดบัฟเฟอร์: ${safeName}`);
    }

    const remainingBytes = maxOutputLength - totalUncompressed;
    const entryCap = Math.min(maxEntryBytes, remainingBytes);
    if (uncompSize > entryCap || (entryCap < 1 && (compSize > 0 || uncompSize > 0))) {
      throw new Error(`Zip-Bomb Guard: ขนาดหลังแตกไฟล์ของ "${safeName}" เกินเพดานที่อนุญาต`);
    }

    const compSlice = zipBuffer.subarray(dataStart, dataStart + compSize);
    let contentBuf;
    if (compSize === 0 && uncompSize === 0) {
      contentBuf = Buffer.alloc(0);
    } else if (method === 0) {
      if (compSlice.length > entryCap) throw new Error(`Zip-Bomb Guard: ขนาดไฟล์ "${safeName}" เกินเพดานที่อนุญาต`);
      contentBuf = Buffer.from(compSlice);
    } else if (method === 8) {
      try {
        contentBuf = zlib.inflateRawSync(compSlice, { maxOutputLength: Math.max(1, entryCap) });
      } catch (err) {
        if (err?.code === 'ERR_BUFFER_TOO_LARGE') {
          throw new Error(`Zip-Bomb Guard: ข้อมูลหลังแตกไฟล์เกินเพดาน ${maxOutputLength} bytes (${safeName})`);
        }
        throw new Error(`แตกไฟล์ .zip ไม่สำเร็จ (${safeName}): ${err.message}`);
      }
    } else {
      throw new Error(`ไม่รองรับวิธีบีบอัด ZIP Method ${method} (${safeName})`);
    }

    totalUncompressed += contentBuf.length;
    if (totalUncompressed > maxOutputLength) {
      throw new Error(`Zip-Bomb Guard: ขนาดรวมหลังแตกไฟล์เกินเพดาน ${maxOutputLength} bytes`);
    }
    entries.push({ name: safeName, buffer: contentBuf });
  }
  return entries;
}

export function normalizeJsonPatch(obj, normalizePathFn) {
  if (!obj || typeof obj !== 'object') throw new Error('รูปแบบไฟล์ Patch JSON ไม่ถูกต้อง');
  const files = [];
  const seenPaths = new Set();
  let totalBytes = 0;

  const pushValidatedEntry = (rawPath, content, encoding = 'utf-8') => {
    if (files.length >= MAX_ZIP_ENTRIES) {
      throw new Error(`Zip-Bomb Guard: จำนวนไฟล์ใน Patch JSON เกินเพดานสูงสุด (${MAX_ZIP_ENTRIES})`);
    }
    const relPath = normalizePathFn(rawPath);
    if (seenPaths.has(relPath)) {
      throw new Error(`ตรวจพบพาธไฟล์ซ้ำใน Patch JSON: ${relPath}`);
    }
    let buf;
    if (encoding === 'base64') {
      const b64Str = String(content || '');
      if (b64Str.length > MAX_BASE64_ENTRY_LEN) {
        throw new Error(`Zip-Bomb Guard: ขนาดไฟล์ "${relPath}" เกินเพดานสูงสุดต่อไฟล์ (${MAX_ZIP_ENTRY_BYTES} bytes)`);
      }
      buf = Buffer.from(b64Str, 'base64');
    } else {
      const utf8Str = String(content ?? '');
      if (Buffer.byteLength(utf8Str, 'utf-8') > MAX_ZIP_ENTRY_BYTES) {
        throw new Error(`Zip-Bomb Guard: ขนาดไฟล์ "${relPath}" เกินเพดานสูงสุดต่อไฟล์ (${MAX_ZIP_ENTRY_BYTES} bytes)`);
      }
      buf = Buffer.from(utf8Str, 'utf-8');
    }
    if (buf.length > MAX_ZIP_ENTRY_BYTES) {
      throw new Error(`Zip-Bomb Guard: ขนาดไฟล์ "${relPath}" เกินเพดานสูงสุดต่อไฟล์ (${MAX_ZIP_ENTRY_BYTES} bytes)`);
    }
    totalBytes += buf.length;
    if (totalBytes > MAX_ZIP_OUTPUT_BYTES) {
      throw new Error(`Zip-Bomb Guard: ขนาดรวมไฟล์ใน Patch JSON เกินเพดานสูงสุด (${MAX_ZIP_OUTPUT_BYTES} bytes)`);
    }
    seenPaths.add(relPath);
    files.push({ relPath, buffer: buf });
  };

  if (Array.isArray(obj.files)) {
    for (const f of obj.files) {
      if (!f || !f.path) continue;
      pushValidatedEntry(f.path, f.content, f.encoding === 'base64' ? 'base64' : 'utf-8');
    }
  } else if (obj.files && typeof obj.files === 'object') {
    for (const [rawPath, content] of Object.entries(obj.files)) {
      pushValidatedEntry(rawPath, content, 'utf-8');
    }
  }

  return {
    version: String(obj.version || '').trim(),
    changelog: Array.isArray(obj.changelog) ? obj.changelog : [],
    schemaMigrations: obj.schemaMigrations || obj.schema || {},
    files
  };
}

export function parsePatchPackage({ filename = '', contentBase64 = '', buffer = null, patchJson = null }, normalizePathFn) {
  if (patchJson && typeof patchJson === 'object') return normalizeJsonPatch(patchJson, normalizePathFn);
  const cleanName = String(filename || '').toLowerCase();
  const rawB64 = String(contentBase64 || '').includes(',') ? String(contentBase64).split(',')[1] : String(contentBase64 || '');
  if (!Buffer.isBuffer(buffer) && rawB64.length > MAX_BASE64_OUTPUT_LEN) {
    throw new Error(`ขนาดไฟล์แพตช์เกินเพดานสูงสุด (${MAX_ZIP_OUTPUT_BYTES} bytes)`);
  }
  const fileBuf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(rawB64, 'base64');
  if (fileBuf.length === 0) throw new Error('ไฟล์แพตช์ว่างเปล่า');
  if (fileBuf.length > MAX_ZIP_OUTPUT_BYTES) throw new Error(`ขนาดไฟล์แพตช์เกินเพดานสูงสุด (${MAX_ZIP_OUTPUT_BYTES} bytes)`);

  const isZip = cleanName.endsWith('.zip') ||
    (fileBuf.length >= 4 && fileBuf[0] === 0x50 && fileBuf[1] === 0x4b && fileBuf[2] === 0x03 && fileBuf[3] === 0x04);
  if (!isZip) return normalizeJsonPatch(JSON.parse(fileBuf.toString('utf-8')), normalizePathFn);

  const zipEntries = extractZipEntries(fileBuf);
  let manifest = {};
  const files = [];
  const seenPaths = new Set();
  let totalBytes = 0;

  for (const entry of zipEntries) {
    if (isArchiveRootManifest(entry.name)) {
      manifest = JSON.parse(entry.buffer.toString('utf-8'));
      continue;
    }
    const relPath = normalizePathFn(entry.name);
    if (seenPaths.has(relPath)) {
      throw new Error(`ตรวจพบพาธไฟล์ซ้ำใน .zip: ${relPath}`);
    }
    seenPaths.add(relPath);
    totalBytes += entry.buffer.length;
    files.push({ relPath, buffer: entry.buffer });
  }

  if (manifest.files) {
    for (const f of normalizeJsonPatch(manifest, normalizePathFn).files) {
      if (seenPaths.has(f.relPath)) continue;
      if (files.length >= MAX_ZIP_ENTRIES) {
        throw new Error(`Zip-Bomb Guard: จำนวนไฟล์รวมเกินเพดานสูงสุด (${MAX_ZIP_ENTRIES})`);
      }
      totalBytes += f.buffer.length;
      if (totalBytes > MAX_ZIP_OUTPUT_BYTES) {
        throw new Error(`Zip-Bomb Guard: ขนาดรวมไฟล์แพตช์เกินเพดานสูงสุด (${MAX_ZIP_OUTPUT_BYTES} bytes)`);
      }
      seenPaths.add(f.relPath);
      files.push(f);
    }
  }

  return {
    version: String(manifest.version || '').trim(),
    changelog: Array.isArray(manifest.changelog) ? manifest.changelog : [],
    schemaMigrations: manifest.schemaMigrations || manifest.schema || {},
    files
  };
}
