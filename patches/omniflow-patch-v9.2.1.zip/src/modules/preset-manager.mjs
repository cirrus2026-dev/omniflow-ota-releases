/**
 * OmniFlow Standalone - On-Demand Business Preset Pack Manager (Layer 2)
 * File: gateway/src/modules/preset-manager.mjs
 * Description: Modular Layer 1 Core + Layer 2 Business Packs Installer, Switcher & Reset Engine.
 *              Integrates directly with OTABackupManager for Auto-Backup (.bak), Healthcheck & Auto-Rollback.
 */

import fs from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import otaBackupManager from './ota-backup-manager.mjs';
import { fetchSafe } from './fetch-safe.mjs';
import { writeFileAtomicAsync, writeJsonAtomicAsync } from './atomic-write.mjs';
import { reloadLocalDatabases } from './local-db-manager.mjs';

const MAX_PRESET_ARCHIVE_BYTES = 10 * 1024 * 1024; // 10 MB (.json / .zip upload)
const MAX_REMOTE_PRESET_BYTES = 5 * 1024 * 1024;   // 5 MB (Remote JSON pack)

const CLEAN_CORE_PERSONA = {
  businessTagline: 'Omnichannel AI Sales & Smart Operations',
  greetingMessage:
    'สวัสดีค่ะ ยินดีต้อนรับ สนใจสอบถามข้อมูลสินค้า ราคา หรือรายละเอียดบริการ แจ้งเข้ามาได้เลยนะคะ',
  systemPrompt: [
    'คุณคือผู้ช่วยฝ่ายขายและบริการลูกค้าอัตโนมัติของระบบ OmniFlow Core',
    'กฎการทำงานพื้นฐาน:',
    '1. ตอบกลับลูกค้าอย่างสุภาพ กระชับ ชัดเจน และเป็นมิตร',
    '2. อ้างอิงข้อมูลสินค้า ราคา และรายละเอียดจากฐานข้อมูลของร้านเท่านั้น ห้ามแต่งข้อมูลเอง',
    '3. หากลูกค้าสอบถามข้อมูลนอกเหนือจากที่มีในระบบ ให้แจ้งอย่างสุภาพว่าจะประสานงานแอดมินตรวจสอบให้ทันที'
  ].join('\n')
};

const SUPPORTED_MADE_TO_MEASURE_INDUSTRIES = [
  '🪨 ร้านหินแกรนิต หินอ่อน หินควอตซ์ & งานทรายล้าง',
  '🪵 ร้านท็อปเคาน์เตอร์ครัว / หินสังเคราะห์ / ไม้สังเคราะห์ (WPC)',
  '🧱 ร้านกระเบื้องปูพื้น-ผนัง / พื้นไม้ SPC / ลามิเนต / กระเบื้องยาง',
  '🪟 ร้านกระจกและอลูมิเนียมสั่งตัดตามขนาด',
  '🧵 ร้านผ้าม่าน / วอลเปเปอร์ / มู่ลี่สั่งตัด',
  '🌿 ร้านหญ้าเทียม / พรมปูพื้นคำนวณตามตารางเมตร'
];

const BUILTIN_PRESET_PACKS = {
  'stone-materials': {
    packId: 'stone-materials',
    version: '3.7.0',
    layer: 2,
    icon: '🪨',
    name: 'วัสดุก่อสร้างสั่งตัดตามขนาด (Made-to-Measure Construction & Interior Materials)',
    subtitle: 'Made-to-Measure Natural Stone & Custom Area Fabrication Engine',
    category: 'made-to-measure',
    fileHint: 'stone-materials-pack.json',
    preserveExistingEngine: true,
    description:
      'ตรรกะมาตรฐานธุรกิจวัสดุก่อสร้างสั่งตัด (Master System Prompt v3.7 + 3 Flowise Custom Tools) รองรับการค้นหาราคา/รูปภาพจากคลัง, คำนวณพื้นที่ กว้างxยาว (ตร.ม.) พร้อม Hard Guard, เปรียบเทียบยกสแลป vs สั่งตัด และบันทึกออเดอร์เข้า CRM Webhook โดยสามารถนำไปใช้กับธุรกิจสั่งตัดพื้นที่ได้ทุกสายงานในกลุ่มเดียวกัน',
    highlights: [
      'Master System Prompt v3.7 (Language & Persona Lock)',
      '3 Flowise Custom Tools (lookup_price_memory, calc_quote, send_to_activepieces)',
      'Hybrid Stone Search (Phonetic Folding + Synonym Mapping)',
      'รองรับธุรกิจสั่งตัด/คำนวณพื้นที่ ตร.ม. ร่วมกันได้ทันที'
    ],
    supportedIndustries: SUPPORTED_MADE_TO_MEASURE_INDUSTRIES,
    toolNames: ['lookup_price_memory', 'calc_quote', 'send_to_activepieces'],
    persona: {
      businessTagline: 'ศูนย์จำหน่ายหินแกรนิต หินอ่อน และงานทรายล้าง มาตรฐานสั่งตัด',
      greetingMessage: '',
      systemPrompt: ''
    },
    customTools: [],
    catalog: { modeDefault: 'keep', items: [] },
    searchLogic: {
      stopwords: ['หินแกรนิต', 'หินอ่อน', 'หินควอตซ์', 'หิน', 'สี', 'ลาย', 'ราคา', 'ตร.ม.', 'ตารางเมตร'],
      synonyms: {
        ทราเวอร์ทีน: ['ทาเวอทีน', 'travertine'],
        ขาวจีน: ['china white', '601', '602', '603'],
        ดำอินเดีย: ['indian black', 'black india'],
        ดำเกล็ดทอง: ['black galaxy', 'galaxy', 'แบล็คกาแล็คซี่'],
        แบล็คฟอเรสต์: ['black forest', 'ฟอเรสต์'],
        คาราร่า: ['white carrara', 'carrara', 'ขาวคาราร่า']
      },
      pricingLabels: { primary: 'ราคายกสแลป', secondary: 'ราคาสั่งตัดจากโรงงาน' }
    }
  }
};

export class PresetManager {
  constructor(options = {}) {
    this.appRoot = options.appRoot || otaBackupManager.appRoot || path.resolve(process.cwd());
    this.dataDir = options.dataDir || otaBackupManager.dataDir || path.resolve(this.appRoot, 'data');
    this.presetsDir = options.presetsDir || path.join(this.dataDir, 'presets');
    this.activePresetFile = path.join(this.dataDir, 'active-business-preset.json');
    this.configFile = path.join(this.dataDir, 'gateway-config.json');
    this.catalogFile = path.join(this.dataDir, 'catalog-db.json');
    this.customToolsFile = path.join(this.dataDir, 'custom-tools-db.json');
    this.customRequestsFile = path.join(this.dataDir, 'custom-business-requests.json');
  }

  async _ensureDirs() {
    await fs.mkdir(this.dataDir, { recursive: true });
    await fs.mkdir(this.presetsDir, { recursive: true });
  }

  async _readJsonSafe(filePath, fallback) {
    try {
      if (!existsSync(filePath)) return structuredClone(fallback);
      const raw = await fs.readFile(filePath, 'utf-8');
      return JSON.parse(raw);
    } catch {
      return structuredClone(fallback);
    }
  }

  async _writeJsonAtomic(filePath, data) {
    await writeJsonAtomicAsync(filePath, data);
  }

  /**
   * อ่านไฟล์แพ็กเกจ .json ทั้งหมดที่วางอยู่ใน data/presets/
   */
  async _loadDiskPacks() {
    await this._ensureDirs();
    const map = new Map();
    const entries = await fs.readdir(this.presetsDir, { withFileTypes: true }).catch(() => []);
    for (const ent of entries) {
      if (!ent.isFile() || !ent.name.toLowerCase().endsWith('.json')) continue;
      try {
        const raw = await fs.readFile(path.join(this.presetsDir, ent.name), 'utf-8');
        const pack = JSON.parse(raw);
        if (pack?.packId) {
          map.set(pack.packId, { ...pack, _sourceFile: ent.name });
        }
      } catch (err) {
        console.warn(`[PresetManager] Skipping invalid preset JSON (${ent.name}):`, err.message);
      }
    }
    return map;
  }

  /**
   * ดึงสถานะ Layer 2 ปัจจุบัน (หากยังไม่ติดตั้งจะคืนค่า core-default)
   */
  async getActivePreset() {
    const active = await this._readJsonSafe(this.activePresetFile, null);
    if (!active || !active.packId) {
      return {
        packId: 'core-default',
        layer: 1,
        name: 'OmniFlow Clean Core (Default)',
        icon: '⚡',
        version: await otaBackupManager.getCurrentVersion(),
        installedAt: null,
        searchLogic: { stopwords: [], synonyms: {}, pricingLabels: { primary: 'ราคาปกติ', secondary: 'ราคาพิเศษ' } }
      };
    }
    return active;
  }

  /**
   * แสดงรายการ Business Packs ทั้งหมด (ผสานระหว่างไฟล์ใน data/presets/ และ Built-in Packs)
   */
  async listPresets() {
    const diskPacks = await this._loadDiskPacks();
    const mergedMap = new Map();

    for (const [id, builtin] of Object.entries(BUILTIN_PRESET_PACKS)) {
      mergedMap.set(id, structuredClone(builtin));
    }
    for (const [id, diskPack] of diskPacks.entries()) {
      mergedMap.set(id, diskPack);
    }

    const active = await this.getActivePreset();
    const existingTools = await this._readJsonSafe(this.customToolsFile, []);
    const liveToolNames = Array.isArray(existingTools) ? existingTools.map((t) => t?.name).filter(Boolean) : [];

    const presets = Array.from(mergedMap.values()).map((p) => {
      const packToolNames =
        Array.isArray(p.customTools) && p.customTools.length > 0
          ? p.customTools.map((t) => t?.name).filter(Boolean)
          : Array.isArray(p.toolNames) && p.toolNames.length > 0
          ? p.toolNames
          : p.preserveExistingEngine
          ? liveToolNames
          : [];
      return {
        packId: p.packId,
        version: p.version || '1.0.0',
        icon: p.icon || '📦',
        name: p.name || p.packId,
        subtitle: p.subtitle || '',
        category: p.category || 'general',
        description: p.description || '',
        highlights: Array.isArray(p.highlights) ? p.highlights : [],
        supportedIndustries: Array.isArray(p.supportedIndustries) ? p.supportedIndustries : [],
        toolNames: packToolNames,
        preserveExistingEngine: Boolean(p.preserveExistingEngine),
        catalogModeDefault: p.catalog?.modeDefault || 'keep',
        source: p._sourceFile ? `file:${p._sourceFile}` : 'builtin',
        counts: {
          tools: packToolNames.length,
          catalogItems: Array.isArray(p.catalog?.items) ? p.catalog.items.length : 0,
          codeFiles: Array.isArray(p.codeFiles) ? p.codeFiles.length : 0
        },
        isInstalled: active.packId === p.packId
      };
    });

    return {
      ok: true,
      activePreset: active,
      presets
    };
  }

  /**
   * แกะและตรวจสอบความถูกต้องของแพ็กเกจ (รองรับ presetId, Remote URL ผ่าน fetchSafe, JSON หรือ ZIP ผ่าน OTA Engine)
   */
  async resolvePresetPackage(options = {}) {
    if (options.packJson && typeof options.packJson === 'object') {
      return this._validatePackObject(options.packJson);
    }

    if (options.contentBase64) {
      const cleanName = String(options.filename || '').toLowerCase();
      const rawInput = String(options.contentBase64);
      const commaIdx = rawInput.indexOf(',');
      const rawB64 = (commaIdx >= 0 ? rawInput.slice(commaIdx + 1) : rawInput).replace(/\s+/g, '');
      const estimatedBytes = Math.floor((rawB64.length * 3) / 4);
      if (estimatedBytes > MAX_PRESET_ARCHIVE_BYTES + 1024) {
        throw new Error(`ไฟล์ Business Pack มีขนาดใหญ่เกินกำหนด (สูงสุด ${Math.round(MAX_PRESET_ARCHIVE_BYTES / (1024 * 1024))} MB)`);
      }

      const buf = Buffer.from(rawB64, 'base64');
      if (buf.length === 0) throw new Error('ไฟล์ Business Pack ว่างเปล่า');
      if (buf.length > MAX_PRESET_ARCHIVE_BYTES) {
        throw new Error(`ไฟล์ Business Pack มีขนาดใหญ่เกินกำหนด (สูงสุด ${Math.round(MAX_PRESET_ARCHIVE_BYTES / (1024 * 1024))} MB)`);
      }

      const isZip =
        cleanName.endsWith('.zip') ||
        (buf.length >= 4 && buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04);

      if (!isZip) {
        return this._validatePackObject(JSON.parse(buf.toString('utf-8')));
      }

      const entries = otaBackupManager._extractZipEntries(buf);
      let manifest = null;
      const zipCodeFiles = [];

      for (const entry of entries) {
        const base = path.posix.basename(entry.name).toLowerCase();
        if (base === 'preset.json' || base === 'manifest.json' || base.endsWith('-pack.json')) {
          manifest = JSON.parse(entry.buffer.toString('utf-8'));
          continue;
        }
        const relPath = otaBackupManager._normalizePatchTargetPath(entry.name);
        zipCodeFiles.push({
          path: relPath,
          encoding: 'base64',
          content: entry.buffer.toString('base64')
        });
      }

      if (!manifest) {
        throw new Error('ไม่พบไฟล์ preset.json หรือ *-pack.json ภายในไฟล์ .zip');
      }
      manifest.codeFiles = [...(Array.isArray(manifest.codeFiles) ? manifest.codeFiles : []), ...zipCodeFiles];
      return this._validatePackObject(manifest);
    }

    if (options.remoteUrl) {
      const targetUrl = String(options.remoteUrl).trim();
      const res = await fetchSafe(targetUrl, {
        headers: { Accept: 'application/json' },
        timeoutMs: 15000,
        signal: AbortSignal.timeout(15000)
      });
      if (!res.ok) throw new Error(`ดาวน์โหลด Business Pack จาก URL ไม่สำเร็จ (HTTP ${res.status})`);

      const contentLen = Number(res.headers?.get?.('content-length'));
      if (Number.isFinite(contentLen) && contentLen > MAX_REMOTE_PRESET_BYTES) {
        throw new Error(`ไฟล์ Business Pack จาก URL มีขนาดใหญ่เกินกำหนด (สูงสุด ${Math.round(MAX_REMOTE_PRESET_BYTES / (1024 * 1024))} MB)`);
      }

      const rawText = await res.text();
      if (Buffer.byteLength(rawText, 'utf8') > MAX_REMOTE_PRESET_BYTES) {
        throw new Error(`ไฟล์ Business Pack จาก URL มีขนาดใหญ่เกินกำหนด (สูงสุด ${Math.round(MAX_REMOTE_PRESET_BYTES / (1024 * 1024))} MB)`);
      }

      const remoteObj = JSON.parse(rawText);
      return this._validatePackObject(remoteObj);
    }

    const packId = String(options.presetId || '').trim();
    if (!packId) throw new Error('กรุณาระบุ presetId หรืออัปโหลดไฟล์ Business Pack (.json/.zip)');

    const diskPacks = await this._loadDiskPacks();
    if (diskPacks.has(packId)) {
      return this._validatePackObject(diskPacks.get(packId));
    }
    if (BUILTIN_PRESET_PACKS[packId]) {
      return this._validatePackObject(structuredClone(BUILTIN_PRESET_PACKS[packId]));
    }
    throw new Error(`ไม่พบ Business Preset Pack รหัส "${packId}"`);
  }

  _validatePackObject(pack) {
    if (!pack || typeof pack !== 'object') {
      throw new Error('รูปแบบไฟล์ Business Preset Pack ไม่ถูกต้อง');
    }
    const packId = String(pack.packId || '').trim().toLowerCase().replace(/[^a-z0-9-_]/g, '');
    if (!packId || packId === 'core-default') {
      throw new Error('packId ไม่ถูกต้อง หรือชนกับสงวนชื่อ core-default');
    }
    if (!pack.persona || typeof pack.persona !== 'object') {
      throw new Error('แพ็กเกจขาดส่วน "persona" (System Prompt & Greeting)');
    }

    const normalizedCodeFiles = [];
    if (Array.isArray(pack.codeFiles)) {
      for (const cf of pack.codeFiles) {
        if (!cf?.path) continue;
        const safeRel = otaBackupManager._normalizePatchTargetPath(cf.path);
        const buf =
          cf.encoding === 'base64'
            ? Buffer.from(String(cf.content || ''), 'base64')
            : Buffer.from(String(cf.content ?? ''), 'utf-8');
        normalizedCodeFiles.push({ relPath: safeRel, buffer: buf });
      }
    }

    return {
      packId,
      version: String(pack.version || '1.0.0').trim(),
      layer: 2,
      icon: String(pack.icon || '📦'),
      name: String(pack.name || packId).trim(),
      subtitle: String(pack.subtitle || '').trim(),
      category: String(pack.category || 'general').trim(),
      description: String(pack.description || '').trim(),
      highlights: Array.isArray(pack.highlights) ? pack.highlights : [],
      supportedIndustries: Array.isArray(pack.supportedIndustries) ? pack.supportedIndustries : [],
      toolNames: Array.isArray(pack.toolNames) ? pack.toolNames : [],
      preserveExistingEngine: Boolean(pack.preserveExistingEngine),
      persona: {
        businessTagline: String(pack.persona.businessTagline || '').trim(),
        greetingMessage: String(pack.persona.greetingMessage || '').trim(),
        systemPrompt: String(pack.persona.systemPrompt || '').trim()
      },
      customTools: Array.isArray(pack.customTools) ? pack.customTools : [],
      catalog: {
        modeDefault: pack.catalog?.modeDefault || 'keep',
        schema: pack.catalog?.schema || {},
        items: Array.isArray(pack.catalog?.items) ? pack.catalog.items : []
      },
      searchLogic: pack.searchLogic && typeof pack.searchLogic === 'object' ? pack.searchLogic : {},
      uiConfig: pack.uiConfig && typeof pack.uiConfig === 'object' ? pack.uiConfig : {},
      codeFiles: normalizedCodeFiles
    };
  }

  /**
   * ติดตั้งหรือสลับ Business Pack ผ่าน OTA Engine (Auto-Backup .bak -> Atomic Install -> Reload DB Cache -> Healthcheck -> Auto-Rollback)
   */
  async installPreset(options = {}) {
    await this._ensureDirs();
    const pack = await this.resolvePresetPackage(options);
    const catalogMode = ['merge', 'replace', 'keep'].includes(options.catalogMode)
      ? options.catalogMode
      : pack.catalog.modeDefault || 'merge';
    const updateTagline = options.updateTagline !== false;

    // 1. กฎเหล็ก OTA Safety: Auto-Backup ข้อมูลเดิมทั้งหมดเป็น .bak + Code Snapshot ก่อนแตะต้องระบบเสมอ
    const targetCodeRelPaths = pack.codeFiles.map((f) => f.relPath);
    const backupName = await otaBackupManager.createBackup(targetCodeRelPaths);
    const writtenCodeAbsPaths = [];
    const resolvedAppRoot = path.resolve(this.appRoot);

    try {
      // 2. หากแพ็กมีไฟล์โค้ดเสริม (Layer 2 Plugins ใน src/ หรือ public/) เขียนแบบ Atomic ภายใน appRoot เท่านั้น
      for (const fileItem of pack.codeFiles) {
        const absDest = path.resolve(resolvedAppRoot, fileItem.relPath);
        if (!absDest.startsWith(`${resolvedAppRoot}${path.sep}`)) {
          throw new Error(`ไม่อนุญาตให้เขียนไฟล์นอกขอบเขตระบบ: ${fileItem.relPath}`);
        }
        await writeFileAtomicAsync(absDest, fileItem.buffer);
        writtenCodeAbsPaths.push(absDest);
      }

      // 3. อัปเดต gateway-config.json (เฉพาะ Prompt/Greeting/Tagline/activePreset — ห้ามทับ Keys/Channels/Providers/PIN)
      // หากแพ็กเกจใช้ตรรกะหลักของร้านหินอยู่แล้ว (preserveExistingEngine) และระบบมี Prompt ที่ตั้งค่าไว้แล้ว ให้คง Prompt เดิมไว้ 100% เว้นแต่ forceOverwritePrompt
      const currentCfg = await this._readJsonSafe(this.configFile, {});
      const existingPrompt = String(currentCfg.brain?.systemPrompt || '').trim();
      const isCoreOrEmptyPrompt =
        !existingPrompt || existingPrompt === CLEAN_CORE_PERSONA.systemPrompt.trim();

      let candidatePrompt = pack.persona.systemPrompt || '';
      if (!candidatePrompt && pack.preserveExistingEngine && isCoreOrEmptyPrompt) {
        const diskPacks = await this._loadDiskPacks();
        candidatePrompt = String(diskPacks.get('stone-materials')?.persona?.systemPrompt || '').trim();
      }

      const shouldKeepExistingPrompt =
        pack.preserveExistingEngine && !isCoreOrEmptyPrompt && !options.forceOverwritePrompt;
      const nextSystemPrompt = shouldKeepExistingPrompt
        ? existingPrompt
        : candidatePrompt || existingPrompt;
      const nextGreetingMessage = shouldKeepExistingPrompt
        ? (currentCfg.brain?.greetingMessage ?? '')
        : (pack.persona.greetingMessage ?? '');

      const nextCfg = {
        ...currentCfg,
        business: {
          ...(currentCfg.business || {}),
          ...(updateTagline && pack.persona.businessTagline
            ? { businessTagline: pack.persona.businessTagline }
            : {})
        },
        brain: {
          ...(currentCfg.brain || {}),
          greetingMessage: nextGreetingMessage,
          systemPrompt: nextSystemPrompt
        },
        activePreset: {
          packId: pack.packId,
          name: pack.name,
          icon: pack.icon,
          version: pack.version,
          installedAt: new Date().toISOString(),
          backupName
        }
      };
      await this._writeJsonAtomic(this.configFile, nextCfg);

      // 4. ติดตั้ง Custom Tools ของแพ็ก (คง Tool เดิมไว้ครบเมื่อ customTools ว่าง หรือเมื่อชื่อ/ID ตรงกับ Tool ที่มีอยู่แล้ว)
      const existingTools = await this._readJsonSafe(this.customToolsFile, []);
      const existingList = Array.isArray(existingTools) ? existingTools : [];
      const userOwnedTools = existingList.filter((t) => t && t.source !== 'preset-pack');
      const nowIso = new Date().toISOString();

      let effectivePackTools = Array.isArray(pack.customTools) ? pack.customTools : [];
      if (effectivePackTools.length === 0 && pack.preserveExistingEngine && existingList.length === 0) {
        const diskPacks = await this._loadDiskPacks();
        effectivePackTools = Array.isArray(diskPacks.get('stone-materials')?.customTools)
          ? diskPacks.get('stone-materials').customTools
          : [];
      }

      let finalToolsList = existingList;
      let packToolsCount = existingList.length;

      if (effectivePackTools.length > 0) {
        const syncedTools = effectivePackTools.map((t, idx) => {
          const tName = String(t.name || `pack_tool_${idx + 1}`).trim();
          const tId = String(t.id || `preset_${pack.packId}_tool_${idx + 1}`).trim();
          const matchedExisting = existingList.find(
            (ex) => ex && ((ex.id && ex.id === tId) || (ex.name && ex.name === tName))
          );
          if (matchedExisting && !options.forceOverwriteTools) {
            return matchedExisting;
          }
          return {
            id: tId,
            name: tName,
            description: String(t.description || '').trim(),
            color: t.color || 'linear-gradient(135deg, #06b6d4, #2563eb)',
            iconSrc: t.iconSrc || '',
            schema: typeof t.schema === 'string' ? t.schema : JSON.stringify(t.schema || []),
            func: String(t.func || ''),
            source: 'preset-pack',
            packId: pack.packId,
            createdDate: t.createdDate || nowIso,
            updatedDate: nowIso
          };
        });
        const syncedNames = new Set(syncedTools.map((t) => t.name));
        const retainedOtherTools = existingList.filter(
          (t) => t && t.source !== 'preset-pack' && !syncedNames.has(t.name)
        );
        finalToolsList = [...retainedOtherTools, ...syncedTools];
        packToolsCount = syncedTools.length;
        await this._writeJsonAtomic(this.customToolsFile, finalToolsList);
      }

      // 5. จัดการ Catalog ตัวอย่างตาม catalogMode (merge / replace / keep)
      const existingCatalogRaw = await this._readJsonSafe(this.catalogFile, []);
      const isWrappedCatalog = !Array.isArray(existingCatalogRaw) && Array.isArray(existingCatalogRaw?.items);
      const existingItems = isWrappedCatalog
        ? existingCatalogRaw.items
        : Array.isArray(existingCatalogRaw)
        ? existingCatalogRaw
        : [];

      let nextCatalogItems = existingItems;
      let catalogAdded = 0;

      if (catalogMode !== 'keep' && pack.catalog.items.length > 0) {
        const taggedPackItems = pack.catalog.items.map((item, idx) => ({
          ...item,
          id: item.id || `preset_${pack.packId}_item_${idx + 1}`,
          source: 'preset-pack',
          packId: pack.packId
        }));

        if (catalogMode === 'replace') {
          nextCatalogItems = taggedPackItems;
          catalogAdded = taggedPackItems.length;
        } else {
          // โหมด merge: เก็บสินค้าของลูกค้าไว้ครบ ล้างเฉพาะสินค้าตัวอย่างของแพ็กเก่าอื่น แล้วเติมของแพ็กใหม่
          const retained = existingItems.filter(
            (it) => it && (it.source !== 'preset-pack' || it.packId === pack.packId)
          );
          const existingIds = new Set(retained.map((it) => it.id));
          const toAppend = taggedPackItems.filter((it) => !existingIds.has(it.id));
          nextCatalogItems = [...retained, ...toAppend];
          catalogAdded = toAppend.length;
        }

        const nextCatalogPayload = isWrappedCatalog
          ? { ...existingCatalogRaw, updatedAt: nowIso, items: nextCatalogItems }
          : nextCatalogItems;
        await this._writeJsonAtomic(this.catalogFile, nextCatalogPayload);
      }

      // 6. บันทึก Layer 2 Active Preset State (Search Normalization, Synonyms, UI Config)
      const activePresetState = {
        packId: pack.packId,
        layer: 2,
        name: pack.name,
        subtitle: pack.subtitle,
        icon: pack.icon,
        version: pack.version,
        category: pack.category,
        installedAt: nowIso,
        backupName,
        catalogMode,
        catalogSchema: pack.catalog.schema || {},
        searchLogic: pack.searchLogic || {},
        uiConfig: pack.uiConfig || {}
      };
      await this._writeJsonAtomic(this.activePresetFile, activePresetState);

      // 7. เก็บสำเนาไฟล์แพ็กเกจที่อัปโหลดลง data/presets/ เพื่อให้สลับกลับมาใช้ซ้ำได้ในอนาคต
      if (options.saveUploadedPack !== false && (options.contentBase64 || options.packJson || options.remoteUrl)) {
        const cachedPackPath = path.join(this.presetsDir, `${pack.packId}-pack.json`);
        const storable = { ...pack, codeFiles: undefined };
        await this._writeJsonAtomic(cachedPackPath, storable).catch(() => {});
      }

      // 8. Safety Healthcheck ผ่าน OTA Engine -> หากไม่ผ่านทำ Auto-Rollback ทันที
      const healthcheck = await otaBackupManager.verifySystemHealth(writtenCodeAbsPaths);
      if (!healthcheck.ok) {
        throw new Error(`Safety Healthcheck ไม่ผ่าน: ${healthcheck.errors.join(' | ')}`);
      }

      // 9. รีโหลดแคช Local DB จากดิสก์ทันทีเพื่อป้องกัน Split-Brain Cache
      await reloadLocalDatabases(true);

      const requiresRestart = targetCodeRelPaths.some((p) => p.startsWith('src/'));
      return {
        ok: true,
        backupName,
        activePreset: activePresetState,
        stats: {
          toolsInstalled: packToolsCount,
          userToolsPreserved: userOwnedTools.length,
          promptPreserved: shouldKeepExistingPrompt,
          catalogMode,
          catalogAdded,
          totalCatalogItems: nextCatalogItems.length,
          codeFilesUpdated: targetCodeRelPaths.length
        },
        healthcheck,
        requiresRestart,
        message: `ติดตั้งชุดธุรกิจ "${pack.name}" สำเร็จ (สำรองข้อมูลเดิมไว้ที่ ${backupName} และผ่าน Healthcheck 100%)`
      };
    } catch (err) {
      console.error(`[PresetManager] Install failed, triggering OTA Auto-Rollback (${backupName}):`, err.message);
      let rolledBack = false;
      try {
        await otaBackupManager.rollback(backupName);
        await reloadLocalDatabases(true).catch(() => {});
        rolledBack = true;
      } catch (rbErr) {
        console.error('[PresetManager] Auto-Rollback error:', rbErr.message);
      }
      const wrapped = new Error(
        `ติดตั้งชุดธุรกิจไม่สำเร็จ: ${err.message} — ${
          rolledBack
            ? `ระบบทำ Auto-Rollback กลับไปจุดสำรอง "${backupName}" เรียบร้อยแล้ว`
            : 'Auto-Rollback ล้มเหลว กรุณากู้คืนจากแท็บ OTA Safety'
        }`
      );
      wrapped.rolledBack = rolledBack;
      wrapped.backupName = backupName;
      throw wrapped;
    }
  }

  /**
   * รีเซ็ตระบบกลับเป็น Layer 1 Clean Core (Auto-Backup .bak ก่อนเสมอ และคงข้อมูลคีย์/ออเดอร์ของลูกค้าไว้ครบ)
   */
  async resetToCore(options = {}) {
    await this._ensureDirs();
    const clearPresetCatalog = Boolean(options.clearPresetCatalog);
    const backupName = await otaBackupManager.createBackup();

    try {
      const nowIso = new Date().toISOString();

      // 1. คืนค่า Prompt & Greeting เป็น Clean Core Default (ไม่แตะ Channels/Providers/PIN)
      const currentCfg = await this._readJsonSafe(this.configFile, {});
      const nextCfg = {
        ...currentCfg,
        business: {
          ...(currentCfg.business || {}),
          businessTagline: CLEAN_CORE_PERSONA.businessTagline
        },
        brain: {
          ...(currentCfg.brain || {}),
          greetingMessage: CLEAN_CORE_PERSONA.greetingMessage,
          systemPrompt: CLEAN_CORE_PERSONA.systemPrompt
        },
        activePreset: {
          packId: 'core-default',
          name: 'OmniFlow Clean Core (Default)',
          icon: '⚡',
          version: currentCfg.version || '1.0.0',
          installedAt: nowIso,
          backupName
        }
      };
      await this._writeJsonAtomic(this.configFile, nextCfg);

      // 2. ถอดเฉพาะ Custom Tools ที่มากับ Preset Pack (คง Tool ที่ลูกค้าเขียนเองไว้)
      const existingTools = await this._readJsonSafe(this.customToolsFile, []);
      const userOwnedTools = Array.isArray(existingTools)
        ? existingTools.filter((t) => t && t.source !== 'preset-pack')
        : [];
      await this._writeJsonAtomic(this.customToolsFile, userOwnedTools);

      // 3. หากเลือก clearPresetCatalog ให้ลบเฉพาะรายการตัวอย่างของแพ็ก (ไม่ลบสินค้าที่ลูกค้าเพิ่มเอง)
      let removedCatalogCount = 0;
      if (clearPresetCatalog) {
        const rawCat = await this._readJsonSafe(this.catalogFile, []);
        const isWrapped = !Array.isArray(rawCat) && Array.isArray(rawCat?.items);
        const list = isWrapped ? rawCat.items : Array.isArray(rawCat) ? rawCat : [];
        const kept = list.filter((it) => it && it.source !== 'preset-pack');
        removedCatalogCount = list.length - kept.length;
        const payload = isWrapped ? { ...rawCat, updatedAt: nowIso, items: kept } : kept;
        await this._writeJsonAtomic(this.catalogFile, payload);
      }

      // 4. รีเซ็ต active-business-preset.json เป็น Layer 1 Clean Core
      const coreState = {
        packId: 'core-default',
        layer: 1,
        name: 'OmniFlow Clean Core (Default)',
        icon: '⚡',
        version: currentCfg.version || '1.0.0',
        installedAt: nowIso,
        backupName,
        searchLogic: { stopwords: [], synonyms: {}, pricingLabels: { primary: 'ราคาปกติ', secondary: 'ราคาพิเศษ' } },
        uiConfig: {}
      };
      await this._writeJsonAtomic(this.activePresetFile, coreState);

      const healthcheck = await otaBackupManager.verifySystemHealth();
      if (!healthcheck.ok) {
        throw new Error(`Safety Healthcheck ไม่ผ่าน: ${healthcheck.errors.join(' | ')}`);
      }

      // 5. รีโหลดแคช Local DB จากดิสก์ทันทีหลังรีเซ็ต
      await reloadLocalDatabases(true);

      return {
        ok: true,
        backupName,
        activePreset: coreState,
        removedCatalogCount,
        userToolsPreserved: userOwnedTools.length,
        healthcheck,
        message: `รีเซ็ตระบบกลับเป็น OmniFlow Clean Core สำเร็จ (สำรองข้อมูลเดิมไว้ที่ ${backupName})`
      };
    } catch (err) {
      await otaBackupManager.rollback(backupName).catch(() => {});
      await reloadLocalDatabases(true).catch(() => {});
      throw new Error(`รีเซ็ตระบบไม่สำเร็จ: ${err.message} (กู้คืนจุดสำรอง ${backupName} แล้ว)`);
    }
  }

  /**
   * กล่องรับความต้องการสายธุรกิจใหม่จากผู้ใช้งานหน้างานจริง (แทนการให้ AI เดาตรรกะ)
   */
  async listCustomBusinessRequests() {
    await this._ensureDirs();
    const list = await this._readJsonSafe(this.customRequestsFile, []);
    return {
      ok: true,
      requests: Array.isArray(list) ? list : []
    };
  }

  async saveCustomBusinessRequest(payload = {}) {
    await this._ensureDirs();
    const businessType = String(payload.businessType || '').trim().slice(0, 200);
    const pricingLogic = String(payload.pricingLogic || '').trim().slice(0, 4000);
    const requiredTools = String(payload.requiredTools || '').trim().slice(0, 2000);
    const contactInfo = String(payload.contactInfo || '').trim().slice(0, 500);

    if (!businessType || !pricingLogic) {
      throw new Error('กรุณาระบุชื่อประเภทธุรกิจ และวิธีคิดราคา/ตรรกะหน้างานจริง');
    }

    const existing = await this._readJsonSafe(this.customRequestsFile, []);
    const list = Array.isArray(existing) ? existing : [];
    const entry = {
      id: `req_${Date.now().toString(36)}`,
      businessType,
      pricingLogic,
      requiredTools,
      contactInfo,
      status: 'pending_review',
      createdAt: new Date().toISOString()
    };

    const nextList = [entry, ...list].slice(0, 50);
    await this._writeJsonAtomic(this.customRequestsFile, nextList);

    return {
      ok: true,
      request: entry,
      requests: nextList,
      message: `บันทึกความต้องการสำหรับสายธุรกิจ "${businessType}" เรียบร้อยแล้ว`
    };
  }

  /**
   * Business-Specific Search Normalization Helper สำหรับให้ Layer 1 AI Brain เรียกใช้แบบ Dynamic
   */
  async normalizeQueryWithActivePreset(rawQuery = '') {
    const active = await this.getActivePreset();
    const logic = active.searchLogic || {};
    let normalized = String(rawQuery || '').toLowerCase().trim();

    if (Array.isArray(logic.stopwords)) {
      for (const sw of logic.stopwords) {
        if (!sw) continue;
        normalized = normalized.split(String(sw).toLowerCase()).join(' ');
      }
    }

    const expandedTokens = new Set(
      normalized
        .split(/[\s,\/\-]+/)
        .map((t) => t.trim())
        .filter((t) => t.length >= 2)
    );

    if (logic.synonyms && typeof logic.synonyms === 'object') {
      const lowerRaw = String(rawQuery || '').toLowerCase();
      for (const [canonical, aliases] of Object.entries(logic.synonyms)) {
        const list = [canonical, ...(Array.isArray(aliases) ? aliases : [])].map((s) =>
          String(s).toLowerCase()
        );
        if (list.some((alias) => alias && lowerRaw.includes(alias))) {
          for (const a of list) expandedTokens.add(a);
        }
      }
    }

    return {
      packId: active.packId,
      normalizedText: normalized.replace(/\s+/g, ' ').trim(),
      expandedTokens: Array.from(expandedTokens),
      pricingLabels: logic.pricingLabels || { primary: 'ราคาปกติ', secondary: 'ราคาพิเศษ' }
    };
  }
}

export default new PresetManager();
