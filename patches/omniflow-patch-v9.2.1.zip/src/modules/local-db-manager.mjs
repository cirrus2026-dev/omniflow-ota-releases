// gateway/src/modules/local-db-manager.mjs
// Phase 10: Standalone Local Database Manager (Catalog DB, Orders & Leads DB, Local Media Storage)
// Zero external dependency on Google Sheets, GitHub Token, or Activepieces

import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { sendAdminLeadNotification } from './settings-vault.mjs';
import { writeJsonAtomicAsync } from './atomic-write.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = process.env.GATEWAY_DATA_DIR || path.resolve(__dirname, '../../data');
const IMAGES_DIR = process.env.GATEWAY_IMAGES_DIR || '/app/images_web';
const LOCAL_IMAGES_FALLBACK_DIR = path.resolve(__dirname, '../../images_web');

const CATALOG_DB_PATH = path.join(DATA_DIR, 'catalog-db.json');
const ORDERS_DB_PATH = path.join(DATA_DIR, 'orders-db.json');

const DEFAULT_MAX_BODY_BYTES = 1 * 1024 * 1024;       // 1 MB (JSON CRUD)
const MAX_CSV_IMPORT_BYTES = 5 * 1024 * 1024;         // 5 MB (CSV Import)
const MAX_MEDIA_BODY_BYTES = 12 * 1024 * 1024;        // 12 MB (Base64 payload)
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;              // 8 MB (Decoded image binary)
const ORDER_NOTIFY_DEDUPE_MS = 15_000;
const MAX_NOTIFY_DEDUPE_ENTRIES = 500;

const SEED_CSV_CANDIDATES = [
  path.join(DATA_DIR, 'price-list-cache.csv'),
  path.resolve(__dirname, '../../price-list-cache.csv'),
  '/app/data/price-list-cache.csv',
  '/app/price-list-cache.csv'
];

function getEffectiveImagesDir() {
  if (fsSync.existsSync('/app') || process.env.GATEWAY_IMAGES_DIR) {
    return IMAGES_DIR;
  }
  return LOCAL_IMAGES_FALLBACK_DIR;
}

function parseCsvLine(line) {
  const res = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === '"') {
      if (inQuotes && line[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      res.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  res.push(cur.trim());
  return res;
}

function escapeCsvCell(val) {
  const s = String(val ?? '');
  if (/[",\r\n]/.test(s)) {
    return `"${s.replace(/"/g, '""')}"`;
  }
  return s;
}

function parsePositiveNumber(val) {
  if (val === null || val === undefined || val === '') return null;
  const cleaned = String(val).replace(/,/g, '').trim();
  const num = Number(cleaned);
  return cleaned !== '' && Number.isFinite(num) && num > 0 ? num : null;
}

function sanitizeImageUrlInput(rawUrl) {
  const s = String(rawUrl || '').trim();
  if (!s) return '';
  if (/^(?:javascript|vbscript|data):/i.test(s)) {
    throw new Error('URL รูปภาพไม่ปลอดภัย');
  }
  if (/^\/(?!\/)/.test(s)) return s;
  try {
    const parsed = new URL(s);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return s;
    }
  } catch {
    // fall through to reject
  }
  throw new Error('รูปแบบ URL รูปภาพไม่ถูกต้อง (รองรับเฉพาะ http/https หรือ /images_web/...)');
}

function formatBangkokTimestamp(ts = Date.now()) {
  const d = new Date(ts);
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Bangkok',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  }).formatToParts(d);
  const get = (t) => parts.find((p) => p.type === t)?.value || '00';
  return `${get('year')}-${get('month')}-${get('day')} ${get('hour')}:${get('minute')}:${get('second')}`;
}

function normalizeImageUrlToLocalOrKeep(rawUrl) {
  if (!rawUrl) return '';
  const s = String(rawUrl).trim().replace(/^["']|["']$/g, '');
  if (!s || s === '-' || s.toLowerCase() === 'none') return '';
  if (s.startsWith('/images_web/')) return s;
  const match = s.match(/(image\d+)\.(?:png|jpg|jpeg|webp)/i);
  if (match) {
    const stem = match[1].toLowerCase();
    const imgDir = getEffectiveImagesDir();
    for (const ext of ['.jpg', '.png', '.webp', '.jpeg']) {
      const localFile = `${stem}${ext}`;
      if (fsSync.existsSync(path.join(imgDir, localFile))) {
        return `/images_web/${localFile}`;
      }
    }
  }
  return s;
}

function detectImageFormatByMagicBytes(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 12) return null;
  // JPEG: FF D8 FF
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) {
    return { ext: '.jpg', mime: 'image/jpeg' };
  }
  // PNG: 89 50 4E 47 0D 0A 1A 0A
  if (
    buf[0] === 0x89 &&
    buf[1] === 0x50 &&
    buf[2] === 0x4e &&
    buf[3] === 0x47 &&
    buf[4] === 0x0d &&
    buf[5] === 0x0a &&
    buf[6] === 0x1a &&
    buf[7] === 0x0a
  ) {
    return { ext: '.png', mime: 'image/png' };
  }
  // WebP: RIFF....WEBP
  if (
    buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
    buf.subarray(8, 12).toString('ascii') === 'WEBP'
  ) {
    return { ext: '.webp', mime: 'image/webp' };
  }
  return null;
}

function extractCatalogArray(parsed) {
  if (Array.isArray(parsed)) return parsed;
  if (parsed && typeof parsed === 'object' && Array.isArray(parsed.items)) {
    return parsed.items;
  }
  return null;
}

export function parseCatalogCsvText(csvText) {
  const lines = String(csvText || '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  if (lines.length <= 1) return [];

  const items = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = parseCsvLine(lines[i]);
    if (cols.length < 2) continue;

    const is9Col = cols.length >= 9;
    const category = cols[0] || 'หินแกรนิต';
    const name = cols[1] || '';
    const size = cols[2] || '';
    const unit = cols[3] || 'ตร.ม.';
    const slabPrice = parsePositiveNumber(cols[4]);
    const cutPrice = is9Col ? parsePositiveNumber(cols[5]) : null;
    const note = is9Col ? cols[6] || '' : cols[5] || '';
    const blockCode = is9Col ? cols[7] || '' : cols[6] || '';
    const rawImg = is9Col ? cols[8] || '' : cols[7] || '';
    const imageUrl = normalizeImageUrlToLocalOrKeep(rawImg);

    if (!name) continue;

    items.push({
      id: `stone_${String(i).padStart(3, '0')}_${Date.now().toString(36)}`,
      category,
      name,
      size,
      unit,
      slabPrice,
      cutPrice,
      note,
      blockCode,
      imageUrl,
      updatedAt: new Date().toISOString()
    });
  }
  return items;
}

const FALLBACK_DEFAULT_CATALOG = [
  {
    id: 'stone_001',
    category: 'หินแกรนิต',
    name: 'หินแกรนิตดำอินเดีย (Indian Black)',
    size: '60x60 / สแลป',
    unit: 'ตร.ม.',
    slabPrice: 1850,
    cutPrice: 2250,
    note: 'ดำสนิทเนื้อละเอียด เงางามสูง',
    blockCode: 'BK-IND-01',
    imageUrl: '',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stone_002',
    category: 'หินแกรนิต',
    name: 'หินแกรนิตดำเกล็ดทอง (Black Galaxy)',
    size: '60x60 / สแลป',
    unit: 'ตร.ม.',
    slabPrice: 2490,
    cutPrice: 2890,
    note: 'พื้นดำประกายเกล็ดทองระยิบระยับ',
    blockCode: 'BK-GLX-02',
    imageUrl: '',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stone_003',
    category: 'หินแกรนิต',
    name: 'หินแกรนิตแบล็คฟอเรสต์ (Black Forest)',
    size: 'สแลปใหญ่',
    unit: 'ตร.ม.',
    slabPrice: 2290,
    cutPrice: 2690,
    note: 'พื้นดำลายริ้วเส้นแร่สีขาวธรรมชาติ',
    blockCode: 'BK-FRS-03',
    imageUrl: '',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stone_004',
    category: 'หินแกรนิต',
    name: 'หินแกรนิตขาวจีน 601 (G601 White)',
    size: '60x60 / สแลป',
    unit: 'ตร.ม.',
    slabPrice: 890,
    cutPrice: 1190,
    note: 'ขาวเทาจุดละเอียด แข็งแกร่งทนทาน',
    blockCode: 'WH-601-04',
    imageUrl: '',
    updatedAt: new Date().toISOString()
  },
  {
    id: 'stone_005',
    category: 'หินอ่อน',
    name: 'หินอ่อนขาวคาราร่า (White Carrara)',
    size: 'สแลปใหญ่',
    unit: 'ตร.ม.',
    slabPrice: 2650,
    cutPrice: 3100,
    note: 'พื้นขาวลายเส้นแร่สีเทาอ่อนสไตล์อิตาลี',
    blockCode: 'MB-CRR-05',
    imageUrl: '',
    updatedAt: new Date().toISOString()
  }
];

let catalogCache = null;
let ordersCache = null;
let initPromise = null;

// ============================================================================
// Write Queue Mutex, Image Allocation Queue & Order Notification Dedupe
// ============================================================================
const fileWriteQueues = new Map();
let imageUploadQueue = Promise.resolve();
const recentOrderNotifications = new Map(); // dedupeKey -> expiresAt

async function waitForPendingWrites() {
  const pending = Array.from(fileWriteQueues.values());
  if (pending.length === 0) return;
  await Promise.allSettled(pending);
}

function dispatchAdminLeadNotificationOnce(order, opts = {}) {
  if (!order) return false;
  if (opts.skipNotify === true || opts.notifyAdmin === false) return false;
  if (String(process.env.LOCAL_DB_DISABLE_ORDER_NOTIFY || '').toLowerCase() === 'true') {
    return false;
  }

  const now = Date.now();
  for (const [key, exp] of recentOrderNotifications) {
    if (exp <= now) recentOrderNotifications.delete(key);
  }

  const mode = opts.isAmendment ? 'amend' : 'create';
  const idKey = `${mode}:id:${order.id}`;
  const sigKey = `${mode}:sig:${order.userKey || order.phone || ''}:${order.productName || ''}:${order.estimatedTotal || ''}`;

  if (
    (recentOrderNotifications.get(idKey) || 0) > now ||
    (recentOrderNotifications.get(sigKey) || 0) > now
  ) {
    return false;
  }

  const exp = now + ORDER_NOTIFY_DEDUPE_MS;
  recentOrderNotifications.set(idKey, exp);
  recentOrderNotifications.set(sigKey, exp);

  while (recentOrderNotifications.size > MAX_NOTIFY_DEDUPE_ENTRIES) {
    const oldestKey = recentOrderNotifications.keys().next().value;
    if (oldestKey === undefined) break;
    recentOrderNotifications.delete(oldestKey);
  }

  const notifyOptions = opts.isAmendment ? { isAmendment: true } : undefined;
  sendAdminLeadNotification(order, notifyOptions).catch((err) => {
    console.warn(
      `[LocalDB] Admin ${opts.isAmendment ? 'amend' : 'lead'} webhook notification warning:`,
      err?.message || err
    );
  });
  return true;
}

async function ensureDirectories() {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.mkdir(getEffectiveImagesDir(), { recursive: true });
}

export async function initLocalDatabases(options = {}) {
  const force = Boolean(options?.force);
  const allowEmptyCatalog = Boolean(options?.allowEmptyCatalog);

  if (!force && catalogCache !== null && ordersCache !== null) {
    return {
      catalogCount: catalogCache.length,
      ordersCount: ordersCache.length,
      dataDir: DATA_DIR,
      imagesDir: getEffectiveImagesDir()
    };
  }
  if (!force && initPromise) return initPromise;

  if (force && initPromise) {
    await initPromise.catch(() => {});
  }

  const task = (async () => {
    await ensureDirectories();
    if (force) {
      await waitForPendingWrites();
    }

    // 1. Initialize or Seed Catalog DB
    try {
      const raw = await fs.readFile(CATALOG_DB_PATH, 'utf8');
      const parsed = JSON.parse(raw);
      const list = extractCatalogArray(parsed);
      if (list && (list.length > 0 || allowEmptyCatalog)) {
        catalogCache = list;
      } else {
        throw new Error('Empty catalog-db.json');
      }
    } catch {
      let seededItems = [];
      for (const csvCandidate of SEED_CSV_CANDIDATES) {
        try {
          if (fsSync.existsSync(csvCandidate)) {
            const csvContent = await fs.readFile(csvCandidate, 'utf8');
            seededItems = parseCatalogCsvText(csvContent);
            if (seededItems.length > 0) {
              console.log(`[LocalDB] Seeded ${seededItems.length} items from ${csvCandidate}`);
              break;
            }
          }
        } catch (e) {
          console.warn(`[LocalDB] Seed CSV read warning (${csvCandidate}):`, e.message);
        }
      }

      if (seededItems.length === 0) {
        seededItems = structuredClone(FALLBACK_DEFAULT_CATALOG);
        console.log('[LocalDB] Seeded default starter catalog (price-list-cache.csv not found)');
      }

      catalogCache = seededItems;
      await saveCatalogDb(catalogCache);
    }

    // 2. Initialize Orders & Leads DB
    try {
      const rawOrders = await fs.readFile(ORDERS_DB_PATH, 'utf8');
      const parsedOrders = JSON.parse(rawOrders);
      ordersCache = Array.isArray(parsedOrders) ? parsedOrders : [];
    } catch {
      ordersCache = [];
      await saveOrdersDb(ordersCache);
    }

    return {
      catalogCount: catalogCache.length,
      ordersCount: ordersCache.length,
      dataDir: DATA_DIR,
      imagesDir: getEffectiveImagesDir()
    };
  })();

  initPromise = task.finally(() => {
    if (initPromise === task) {
      initPromise = null;
    }
  });

  return initPromise;
}

/**
 * โหลดแคช Catalog และ Orders ซ้ำจากดิสก์เพื่อป้องกัน Split-Brain Cache
 * หลังการสลับ Business Preset, Reset to Core หรือ OTA Rollback
 */
export async function reloadLocalDatabases(force = true) {
  if (!force && catalogCache !== null && ordersCache !== null) {
    return {
      reloaded: false,
      catalogCount: catalogCache.length,
      ordersCount: ordersCache.length,
      dataDir: DATA_DIR,
      imagesDir: getEffectiveImagesDir()
    };
  }

  await waitForPendingWrites();
  if (initPromise) {
    await initPromise.catch(() => {});
  }
  catalogCache = null;
  ordersCache = null;

  const stats = await initLocalDatabases({ force: true, allowEmptyCatalog: true });
  return {
    reloaded: true,
    ...stats
  };
}

/**
 * จัดคิวการเขียนไฟล์แบบ FIFO แยกตาม filePath (Per-File Mutex)
 * และเขียนลงไฟล์ชั่วคราว (.tmp) -> fsync -> rename แบบ Atomic
 */
export async function writeJsonAtomicQueued(filePath, data) {
  const resolvedPath = path.resolve(filePath);
  const prevTask = fileWriteQueues.get(resolvedPath) || Promise.resolve();

  const currentTask = prevTask
    .catch(() => {
      // ป้องกันคิวค้าง (Deadlock) หากงานก่อนหน้าเกิด Error
    })
    .then(async () => {
      await ensureDirectories();
      await writeJsonAtomicAsync(resolvedPath, data);
    });

  fileWriteQueues.set(resolvedPath, currentTask);
  currentTask.finally(() => {
    if (fileWriteQueues.get(resolvedPath) === currentTask) {
      fileWriteQueues.delete(resolvedPath);
    }
  });

  return currentTask;
}

async function saveCatalogDb(items) {
  catalogCache = items;
  await writeJsonAtomicQueued(CATALOG_DB_PATH, items);
}

async function saveOrdersDb(orders) {
  ordersCache = orders;
  await writeJsonAtomicQueued(ORDERS_DB_PATH, orders);
}

// ============================================================================
// CATALOG CRUD & CSV IMPORT/EXPORT
// ============================================================================

export async function getAllCatalogItems() {
  if (!catalogCache) await initLocalDatabases();
  return catalogCache;
}

export async function addCatalogItem(payload = {}) {
  await getAllCatalogItems();
  const name = String(payload.name || '').trim();
  if (!name) throw new Error('กรุณาระบุชื่อรุ่นหิน');

  let imageUrl = payload.imageUrl ? sanitizeImageUrlInput(payload.imageUrl) : '';
  if (payload.imageBase64) {
    const savedMedia = await saveLocalStoneImage(payload.imageBase64, payload.imageFilename);
    imageUrl = savedMedia.url;
  }

  const newItem = {
    id: `stone_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    category: String(payload.category || 'หินแกรนิต').trim(),
    name,
    size: String(payload.size || '').trim(),
    unit: String(payload.unit || 'ตร.ม.').trim(),
    slabPrice: parsePositiveNumber(payload.slabPrice),
    cutPrice: parsePositiveNumber(payload.cutPrice),
    note: String(payload.note || '').trim(),
    blockCode: String(payload.blockCode || '').trim(),
    imageUrl,
    updatedAt: new Date().toISOString()
  };

  // Read latest synchronous catalogCache after all awaits to prevent lost updates
  const latestItems = catalogCache || [];
  const next = [newItem, ...latestItems];
  await saveCatalogDb(next);
  return newItem;
}

export async function updateCatalogItem(id, updates = {}) {
  await getAllCatalogItems();
  if (!(catalogCache || []).some((it) => it.id === id)) {
    throw new Error('ไม่พบรหัสสินค้าในฐานข้อมูล');
  }

  let savedImageUrl = null;
  if (updates.imageBase64) {
    const savedMedia = await saveLocalStoneImage(updates.imageBase64, updates.imageFilename);
    savedImageUrl = savedMedia.url;
  } else if (updates.imageUrl !== undefined) {
    savedImageUrl = updates.imageUrl ? sanitizeImageUrlInput(updates.imageUrl) : '';
  }

  // Re-read latest synchronous catalogCache after async media upload
  const latestItems = catalogCache || [];
  const idx = latestItems.findIndex((it) => it.id === id);
  if (idx === -1) throw new Error('ไม่พบรหัสสินค้าในฐานข้อมูล');

  const current = { ...latestItems[idx] };
  if (updates.category !== undefined) current.category = String(updates.category).trim();
  if (updates.name !== undefined && String(updates.name).trim()) {
    current.name = String(updates.name).trim();
  }
  if (updates.size !== undefined) current.size = String(updates.size).trim();
  if (updates.unit !== undefined) current.unit = String(updates.unit).trim() || 'ตร.ม.';
  if (updates.slabPrice !== undefined) current.slabPrice = parsePositiveNumber(updates.slabPrice);
  if (updates.cutPrice !== undefined) current.cutPrice = parsePositiveNumber(updates.cutPrice);
  if (updates.note !== undefined) current.note = String(updates.note).trim();
  if (updates.blockCode !== undefined) current.blockCode = String(updates.blockCode).trim();
  if (savedImageUrl !== null) {
    current.imageUrl = savedImageUrl;
  }
  current.updatedAt = new Date().toISOString();

  const next = [...latestItems];
  next[idx] = current;
  await saveCatalogDb(next);
  return current;
}

export async function deleteCatalogItem(id) {
  await getAllCatalogItems();
  const latestItems = catalogCache || [];
  const next = latestItems.filter((it) => it.id !== id);
  if (next.length === latestItems.length) {
    throw new Error('ไม่พบรหัสสินค้าที่ต้องการลบ');
  }
  await saveCatalogDb(next);
  return { deletedId: id, remaining: next.length };
}

export async function exportCatalogToCsv() {
  const items = await getAllCatalogItems();
  const header = [
    'หมวดหมู่',
    'ชื่อรุ่นหิน',
    'ขนาด',
    'หน่วย',
    'ราคายกสแลป',
    'ราคาสั่งตัด',
    'หมายเหตุ',
    'รหัสบล็อก',
    'ลิงก์รูปภาพ'
  ];
  const rows = [header.map(escapeCsvCell).join(',')];
  for (const it of items) {
    rows.push(
      [
        it.category,
        it.name,
        it.size,
        it.unit,
        it.slabPrice ?? '',
        it.cutPrice ?? '',
        it.note,
        it.blockCode,
        it.imageUrl
      ]
        .map(escapeCsvCell)
        .join(',')
    );
  }
  return '\uFEFF' + rows.join('\r\n');
}

export async function importCatalogFromCsv(csvText, mode = 'replace') {
  const parsed = parseCatalogCsvText(csvText);
  if (parsed.length === 0) {
    throw new Error('ไฟล์ CSV ไม่มีข้อมูลสินค้าที่ถูกต้อง (ต้องมีอย่างน้อย 2 คอลัมน์)');
  }
  if (mode === 'append') {
    const existing = await getAllCatalogItems();
    await saveCatalogDb([...parsed, ...existing]);
  } else {
    await saveCatalogDb(parsed);
  }
  return { importedCount: parsed.length, totalCount: catalogCache.length };
}

// ============================================================================
// LOCAL MEDIA STORAGE (/app/images_web/image{next}.{ext}) - MAGIC BYTES + LOCK
// ============================================================================

export async function saveLocalStoneImage(base64OrDataUrl, _originalName = '') {
  const raw = String(base64OrDataUrl || '').trim();
  const commaIdx = raw.indexOf(',');
  const base64Clean = (commaIdx >= 0 ? raw.slice(commaIdx + 1) : raw).replace(/\s+/g, '');
  if (!base64Clean) {
    throw new Error('ข้อมูลไฟล์รูปภาพไม่ถูกต้อง');
  }

  // Pre-check decoded size before allocating Buffer to prevent memory DoS
  const estimatedBytes = Math.floor((base64Clean.length * 3) / 4);
  if (estimatedBytes > MAX_IMAGE_BYTES + 1024) {
    const err = new Error(`ขนาดไฟล์รูปภาพเกินกำหนด (สูงสุด ${Math.round(MAX_IMAGE_BYTES / (1024 * 1024))} MB)`);
    err.statusCode = 413;
    throw err;
  }

  const buffer = Buffer.from(base64Clean, 'base64');
  if (buffer.length === 0) {
    throw new Error('ไฟล์รูปภาพว่างเปล่า');
  }
  if (buffer.length > MAX_IMAGE_BYTES) {
    const err = new Error(`ขนาดไฟล์รูปภาพเกินกำหนด (สูงสุด ${Math.round(MAX_IMAGE_BYTES / (1024 * 1024))} MB)`);
    err.statusCode = 413;
    throw err;
  }

  const detected = detectImageFormatByMagicBytes(buffer);
  if (!detected) {
    throw new Error('ไฟล์ไม่ใช่รูปภาพที่รองรับ (ตรวจ Magic Bytes ไม่ผ่าน — รองรับเฉพาะ JPG, PNG, WebP เท่านั้น)');
  }

  // Serialize sequential filename allocation across concurrent uploads
  const saveTask = imageUploadQueue
    .catch(() => {})
    .then(async () => {
      await ensureDirectories();
      const imgDir = getEffectiveImagesDir();

      const existingFiles = await fs.readdir(imgDir).catch(() => []);
      let maxIndex = 0;
      for (const fname of existingFiles) {
        const m = fname.match(/^image(\d+)\.(?:jpg|jpeg|png|webp)$/i);
        if (m) {
          const n = Number(m[1]);
          if (Number.isFinite(n) && n > maxIndex) maxIndex = n;
        }
      }

      for (let attempt = 1; attempt <= 25; attempt += 1) {
        const nextNum = maxIndex + attempt;
        const filename = `image${nextNum}${detected.ext}`;
        const targetPath = path.join(imgDir, filename);
        try {
          // Exclusive create (wx) prevents cross-process filename collision
          await fs.writeFile(targetPath, buffer, { flag: 'wx' });
          const publicUrl = `/images_web/${filename}`;
          console.log(`[LocalMedia] Saved image locally: ${targetPath} -> ${publicUrl}`);
          return {
            filename,
            filePath: targetPath,
            url: publicUrl,
            bytes: buffer.length,
            mime: detected.mime
          };
        } catch (err) {
          if (err?.code === 'EEXIST') continue;
          throw err;
        }
      }

      throw new Error('ไม่สามารถจัดสรรชื่อไฟล์รูปภาพใหม่ได้ (ไฟล์ชนกันหลายครั้ง)');
    });

  imageUploadQueue = saveTask.catch(() => {});
  return saveTask;
}

// ============================================================================
// ORDERS & LEADS DB (Replaces Activepieces :8080 & Google Sheets CRM)
// ============================================================================

export async function getAllOrders() {
  if (!ordersCache) await initLocalDatabases();
  return ordersCache;
}

export async function addOrderLead(payload = {}, options = {}) {
  await getAllOrders();
  const now = Date.now();
  const newOrder = {
    id: `ord_${now}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: formatBangkokTimestamp(now),
    createdAtMs: now,
    channel: String(payload.channel || payload.platform || 'direct').toLowerCase(),
    userKey: String(payload.userKey || '').trim(),
    customerName: String(payload.customerName || 'ลูกค้าหน้าร้าน').trim(),
    productName: String(payload.productName || payload.stoneName || '-').trim(),
    dimensions: String(payload.dimensions || '').trim(),
    quantity: payload.quantity ?? '',
    estimatedTotal: payload.estimatedTotal ?? '',
    items: Array.isArray(payload.items) ? payload.items : [],
    phone: String(payload.phone || '-').trim(),
    address: String(payload.address || '-').trim(),
    imageUrl: String(payload.imageUrl || '').trim(),
    note: String(payload.note || '').trim(),
    status: String(payload.status || 'pending').trim() // pending | deposit_paid | shipped | cancelled
  };

  // Read latest synchronous ordersCache immediately before constructing next & updating cache
  const latestOrders = ordersCache || [];
  const next = [newOrder, ...latestOrders];
  await saveOrdersDb(next);

  // Single-point, deduplicated admin notification (respects { skipNotify } from caller/payload)
  const skipNotify = Boolean(
    options?.skipNotify === true ||
    payload?.skipNotify === true ||
    options?.notifyAdmin === false ||
    payload?.notifyAdmin === false ||
    payload?.alreadyNotified === true
  );
  if (!skipNotify) {
    dispatchAdminLeadNotificationOnce(newOrder, { isAmendment: false });
  }

  return newOrder;
}

export async function updateOrderStatus(id, updates = {}) {
  await getAllOrders();
  const latestOrders = ordersCache || [];
  const idx = latestOrders.findIndex((o) => o.id === id);
  if (idx === -1) throw new Error('ไม่พบรายการออเดอร์ในฐานข้อมูล');

  const current = { ...latestOrders[idx] };
  if (updates.status !== undefined) current.status = String(updates.status).trim();
  if (updates.phone !== undefined) current.phone = String(updates.phone).trim();
  if (updates.address !== undefined) current.address = String(updates.address).trim();
  if (updates.productName !== undefined) current.productName = String(updates.productName).trim();
  if (updates.dimensions !== undefined) current.dimensions = String(updates.dimensions).trim();
  if (updates.quantity !== undefined) current.quantity = updates.quantity;
  if (updates.estimatedTotal !== undefined) current.estimatedTotal = String(updates.estimatedTotal).trim();
  if (Array.isArray(updates.items)) current.items = updates.items;
  if (updates.amendAcked !== undefined) current.amendAcked = Boolean(updates.amendAcked);
  if (updates.note !== undefined) current.note = String(updates.note).trim();
  current.updatedAt = formatBangkokTimestamp(Date.now());

  const next = [...latestOrders];
  next[idx] = current;
  await saveOrdersDb(next);
  return current;
}

/**
 * Find the most recent amendable order for a userKey within windowMs (only if status is still pending/pending_unconfirmed).
 * Orders that are already deposit_paid, shipped, completed, or cancelled will NOT be amended (a new order is created instead).
 */
export async function findRecentAmendableOrder(userKey, windowMs = 15 * 60 * 1000) {
  const key = String(userKey || '').trim();
  if (!key) return null;
  await getAllOrders();
  const now = Date.now();
  const latestOrders = ordersCache || [];
  return (
    latestOrders.find((o) => {
      if (String(o.userKey || '').trim() !== key) return false;
      const st = String(o.status || 'pending').toLowerCase();
      if (st !== 'pending' && st !== 'pending_unconfirmed') return false;
      const ageMs = now - Number(o.createdAtMs || 0);
      return ageMs >= 0 && ageMs <= windowMs;
    }) || null
  );
}

/**
 * Amend an existing order within the 15-min window: append items, update totals, mark amendedAtMs/amendedAtLabel, and notify admin.
 */
export async function amendOrderLead(orderId, patch = {}, options = {}) {
  await getAllOrders();
  const latestOrders = ordersCache || [];
  const idx = latestOrders.findIndex((o) => o.id === orderId);
  if (idx === -1) throw new Error('ไม่พบออเดอร์เดิมสำหรับอัปเดต');

  const now = Date.now();
  const hhmm = new Intl.DateTimeFormat('th-TH', {
    timeZone: 'Asia/Bangkok',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false
  }).format(new Date(now));

  const current = { ...latestOrders[idx] };
  if (patch.productName !== undefined) current.productName = String(patch.productName).trim();
  if (patch.dimensions !== undefined) current.dimensions = String(patch.dimensions).trim();
  if (patch.quantity !== undefined) current.quantity = patch.quantity;
  if (patch.estimatedTotal !== undefined) current.estimatedTotal = String(patch.estimatedTotal).trim();
  if (Array.isArray(patch.items)) current.items = patch.items;
  if (patch.status !== undefined) current.status = String(patch.status).trim();
  if (patch.address !== undefined && String(patch.address).trim()) {
    current.address = String(patch.address).trim();
  }

  const amendNote = String(patch.amendNote || '').trim() || `[อัปเดต ${hhmm}] ลูกค้าสั่งเพิ่ม/แก้ไขรายการ`;
  current.note = current.note ? `${current.note}\n${amendNote}` : amendNote;
  current.amendedAtMs = now;
  current.amendedAtLabel = hhmm;
  current.amendAcked = false;
  current.updatedAt = formatBangkokTimestamp(now);

  const next = [...latestOrders];
  next[idx] = current;
  await saveOrdersDb(next);

  const skipNotify = Boolean(
    options?.skipNotify === true ||
    patch?.skipNotify === true ||
    options?.notifyAdmin === false ||
    patch?.notifyAdmin === false ||
    patch?.alreadyNotified === true
  );
  if (!skipNotify) {
    dispatchAdminLeadNotificationOnce(current, { isAmendment: true });
  }

  return current;
}

export async function deleteOrderLead(id) {
  await getAllOrders();
  const latestOrders = ordersCache || [];
  const next = latestOrders.filter((o) => o.id !== id);
  if (next.length === latestOrders.length) {
    throw new Error('ไม่พบรายการออเดอร์ที่ต้องการลบ');
  }
  await saveOrdersDb(next);
  return { deletedId: id, totalCount: next.length };
}

export async function exportOrdersToCsv() {
  const orders = await getAllOrders();
  const statusMap = {
    pending: 'รอดำเนินการ',
    pending_unconfirmed: 'รอทวนยอด (ยังไม่กดยืนยัน)',
    deposit_paid: 'มัดจำแล้ว',
    shipped: 'ส่งของแล้ว',
    completed: 'ปิดงานแล้ว',
    cancelled: 'ยกเลิก'
  };
  const header = [
    'รหัสออเดอร์',
    'วันเวลา',
    'ช่องทาง',
    'ชื่อลูกค้า',
    'สินค้า',
    'ขนาด/จำนวน',
    'ยอดประเมิน',
    'เบอร์โทร',
    'ที่อยู่จัดส่ง',
    'รูปภาพแนบ',
    'สถานะออเดอร์',
    'หมายเหตุ'
  ];
  const rows = [header.map(escapeCsvCell).join(',')];
  for (const o of orders) {
    rows.push(
      [
        o.id,
        o.timestamp,
        o.channel,
        o.customerName,
        o.productName,
        `${o.dimensions} ${o.quantity ? `(${o.quantity})` : ''}`.trim(),
        o.estimatedTotal,
        o.phone,
        o.address,
        o.imageUrl,
        statusMap[o.status] || o.status,
        o.note
      ]
        .map(escapeCsvCell)
        .join(',')
    );
  }
  return '\uFEFF' + rows.join('\r\n');
}

/**
 * LTD.md ข้อ 3.2: สรุปมินิแดชบอร์ด KPI ประจำวัน (Daily KPI Summary)
 */
export async function getDailyKpiSummary(conversationsList = []) {
  const orders = await getAllOrders();
  const now = Date.now();
  const bkkDateStr = (ts) =>
    new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Bangkok',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    }).format(new Date(ts || now));

  const todayKey = bkkDateStr(now);
  const todayOrders = orders.filter((o) => bkkDateStr(o.createdAtMs || Date.parse(o.timestamp || '')) === todayKey);

  let pendingOrdersToday = 0;
  let confirmedRevenueToday = 0;
  let pipelineRevenueToday = 0;
  const productCounts = new Map();

  for (const o of todayOrders) {
    const st = String(o.status || '').toLowerCase();
    const isPending = ['pending', 'pending_unconfirmed', 'cooking', 'lead', 'quoted'].includes(st);
    const isConfirmed = ['deposit_paid', 'shipped', 'completed', 'served'].includes(st);
    if (isPending) pendingOrdersToday += 1;

    const rawTotal = String(o.estimatedTotal ?? '').replace(/,/g, '');
    const numMatch = rawTotal.match(/-?\d+(?:\.\d+)?/);
    const amt = numMatch ? Number(numMatch[0]) : 0;
    if (Number.isFinite(amt) && amt > 0 && st !== 'cancelled') {
      if (isConfirmed) {
        confirmedRevenueToday += amt;
      } else {
        pipelineRevenueToday += amt;
      }
    }

    if (Array.isArray(o.items) && o.items.length > 0) {
      for (const it of o.items) {
        const itemName = String(it?.name || '').trim();
        if (itemName && itemName !== '-') {
          productCounts.set(itemName, (productCounts.get(itemName) || 0) + 1);
        }
      }
    } else {
      const rawProd = String(o.productName || '').trim();
      if (rawProd && rawProd !== '-') {
        for (const part of rawProd.split(',').map((s) => s.replace(/\s*x\d+\s*$/i, '').trim()).filter(Boolean)) {
          productCounts.set(part, (productCounts.get(part) || 0) + 1);
        }
      }
    }
  }

  const estimatedRevenueToday = confirmedRevenueToday + pipelineRevenueToday;

  let conversationsToday = 0;
  for (const conv of Array.isArray(conversationsList) ? conversationsList : []) {
    const convTs =
      conv.updatedAt ||
      (Array.isArray(conv.messages) && conv.messages.length
        ? conv.messages[conv.messages.length - 1].timestamp
        : 0);
    if (convTs && bkkDateStr(convTs) === todayKey) {
      conversationsToday += 1;
    }
    if (Array.isArray(conv.stoneHints)) {
      for (const hint of conv.stoneHints) {
        const cleanHint = String(hint || '').trim();
        if (cleanHint) {
          productCounts.set(cleanHint, (productCounts.get(cleanHint) || 0) + 1);
        }
      }
    }
  }

  let topDemandedProduct = '-';
  let topCount = 0;
  for (const [prod, cnt] of productCounts.entries()) {
    if (cnt > topCount) {
      topCount = cnt;
      topDemandedProduct = prod;
    }
  }

  return {
    date: todayKey,
    conversationsToday,
    pendingOrdersToday,
    confirmedRevenueToday,
    pipelineRevenueToday,
    estimatedRevenueToday,
    topDemandedProduct,
    topDemandedCount: topCount,
    totalOrdersToday: todayOrders.length
  };
}

// ============================================================================
// HTTP ROUTE HANDLERS (Compatible with both Node http.createServer & Express)
// ============================================================================

function sendJson(res, statusCode, payload, extraHeaders = {}) {
  if (typeof res.status === 'function' && typeof res.json === 'function') {
    return res.status(statusCode).json(payload);
  }
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    ...extraHeaders
  });
  res.end(JSON.stringify(payload));
}

function createPayloadTooLargeError(maxBytes) {
  const mbLabel = Math.round((maxBytes / (1024 * 1024)) * 10) / 10;
  const err = new Error(`ขนาดข้อมูล Request เกินกำหนด (สูงสุด ${mbLabel} MB)`);
  err.statusCode = 413;
  return err;
}

async function readBodyUniversal(req, maxBytes = DEFAULT_MAX_BODY_BYTES) {
  const limit =
    Number.isFinite(Number(maxBytes)) && Number(maxBytes) > 0
      ? Math.floor(Number(maxBytes))
      : DEFAULT_MAX_BODY_BYTES;

  if (req.body && typeof req.body === 'object') {
    return req.body;
  }

  const contentLengthHeader = Number(req.headers?.['content-length']);
  if (Number.isFinite(contentLengthHeader) && contentLengthHeader > limit) {
    throw createPayloadTooLargeError(limit);
  }

  return new Promise((resolve, reject) => {
    const chunks = [];
    let totalBytes = 0;
    let settled = false;

    const fail = (err) => {
      if (settled) return;
      settled = true;
      req.off('data', onData);
      req.off('end', onEnd);
      req.off('error', onError);
      if (typeof req.pause === 'function') req.pause();
      reject(err);
    };

    const onData = (chunk) => {
      if (settled) return;
      const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      totalBytes += buf.length;
      if (totalBytes > limit) {
        fail(createPayloadTooLargeError(limit));
        return;
      }
      chunks.push(buf);
    };

    const onEnd = () => {
      if (settled) return;
      settled = true;
      try {
        const raw = Buffer.concat(chunks, totalBytes).toString('utf8').trim();
        resolve(raw ? JSON.parse(raw) : {});
      } catch {
        const err = new Error('รูปแบบ JSON ไม่ถูกต้อง');
        err.statusCode = 400;
        reject(err);
      }
    };

    const onError = (err) => fail(err);

    req.on('data', onData);
    req.on('end', onEnd);
    req.on('error', onError);
  });
}

/**
 * Handle /images_web/* static file serving & /api/local-db/* endpoints
 */
export async function handleLocalDbHttpRequest(req, res, parsedUrl, corsHeaders = {}) {
  const pathname = parsedUrl.pathname;

  // 1. Static Local Media Server: GET /images_web/image1.jpg
  if (req.method === 'GET' && pathname.startsWith('/images_web/')) {
    const safeFilename = path.basename(pathname);
    if (!/^image\d+\.(jpg|jpeg|png|webp)$/i.test(safeFilename)) {
      res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Invalid image filename');
      return true;
    }
    const baseDir = path.resolve(getEffectiveImagesDir());
    const filePath = path.resolve(baseDir, safeFilename);
    if (!filePath.startsWith(`${baseDir}${path.sep}`) || !fsSync.existsSync(filePath)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Image not found');
      return true;
    }
    const ext = path.extname(safeFilename).toLowerCase();
    const mime =
      ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
    res.writeHead(200, {
      'Content-Type': mime,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0',
      ...corsHeaders
    });
    const stream = fsSync.createReadStream(filePath);
    stream.on('error', () => {
      if (!res.headersSent) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      }
      res.end();
    });
    stream.pipe(res);
    return true;
  }

  // 2. Catalog DB APIs
  if (pathname === '/api/local-db/catalog' && req.method === 'GET') {
    const items = await getAllCatalogItems();
    sendJson(res, 200, { ok: true, total: items.length, items }, corsHeaders);
    return true;
  }

  if (pathname === '/api/local-db/catalog' && req.method === 'POST') {
    try {
      const body = await readBodyUniversal(req, MAX_MEDIA_BODY_BYTES);
      const created = await addCatalogItem(body);
      sendJson(res, 200, { ok: true, item: created }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  if (pathname.startsWith('/api/local-db/catalog/') && req.method === 'PUT') {
    try {
      const id = decodeURIComponent(pathname.slice('/api/local-db/catalog/'.length));
      const body = await readBodyUniversal(req, MAX_MEDIA_BODY_BYTES);
      const updated = await updateCatalogItem(id, body);
      sendJson(res, 200, { ok: true, item: updated }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  if (pathname.startsWith('/api/local-db/catalog/') && req.method === 'DELETE') {
    try {
      const id = decodeURIComponent(pathname.slice('/api/local-db/catalog/'.length));
      const result = await deleteCatalogItem(id);
      sendJson(res, 200, { ok: true, ...result }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  if (pathname === '/api/local-db/catalog-export.csv' && req.method === 'GET') {
    const csv = await exportCatalogToCsv();
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="aether-catalog.csv"',
      ...corsHeaders
    });
    res.end(csv);
    return true;
  }

  if (pathname === '/api/local-db/catalog-import' && req.method === 'POST') {
    try {
      const body = await readBodyUniversal(req, MAX_CSV_IMPORT_BYTES);
      const result = await importCatalogFromCsv(body.csvText || '', body.mode || 'replace');
      sendJson(res, 200, { ok: true, ...result }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  // 3. Local Media Upload API (Replaces GitHub Upload)
  if (pathname === '/api/local-db/upload-image' && req.method === 'POST') {
    try {
      const body = await readBodyUniversal(req, MAX_MEDIA_BODY_BYTES);
      const saved = await saveLocalStoneImage(body.imageBase64, body.filename);
      sendJson(res, 200, { ok: true, ...saved }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  // 4. Orders & Leads CRM APIs
  if (pathname === '/api/local-db/orders' && req.method === 'GET') {
    const orders = await getAllOrders();
    sendJson(res, 200, { ok: true, total: orders.length, orders }, corsHeaders);
    return true;
  }

  if (pathname === '/api/local-db/orders' && req.method === 'POST') {
    try {
      const body = await readBodyUniversal(req, DEFAULT_MAX_BODY_BYTES);
      const order = await addOrderLead(body, { skipNotify: body?.skipNotify === true });
      sendJson(res, 200, { ok: true, order }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  if (pathname.startsWith('/api/local-db/orders/') && req.method === 'PUT') {
    try {
      const id = decodeURIComponent(pathname.slice('/api/local-db/orders/'.length));
      const body = await readBodyUniversal(req, DEFAULT_MAX_BODY_BYTES);
      const updated = await updateOrderStatus(id, body);
      sendJson(res, 200, { ok: true, order: updated }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  if (pathname.startsWith('/api/local-db/orders/') && req.method === 'DELETE') {
    try {
      const id = decodeURIComponent(pathname.slice('/api/local-db/orders/'.length));
      const result = await deleteOrderLead(id);
      sendJson(res, 200, { ok: true, ...result }, corsHeaders);
    } catch (err) {
      sendJson(res, err?.statusCode || 400, { ok: false, error: err.message }, corsHeaders);
    }
    return true;
  }

  if (pathname === '/api/local-db/orders-export.csv' && req.method === 'GET') {
    const csv = await exportOrdersToCsv();
    res.writeHead(200, {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': 'attachment; filename="aether-orders-crm.csv"',
      ...corsHeaders
    });
    res.end(csv);
    return true;
  }

  return false;
}
