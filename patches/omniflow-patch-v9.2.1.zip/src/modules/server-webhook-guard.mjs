// gateway/src/modules/server-webhook-guard.mjs
// Hardened Inbound Webhook Handlers: Bounded Destroy-on-Overflow readRawBody, Pre-Parse HMAC, POST-only Guard & Dedup

import { isChannelEnabled } from './server-security-guard.mjs';

const DEFAULT_WEBHOOK_MAX_BYTES = 1 * 1024 * 1024;

export function readRawBody(req, maxBytes = DEFAULT_WEBHOOK_MAX_BYTES) {
  return new Promise((resolve, reject) => {
    const contentLen = Number(req?.headers?.['content-length'] || 0);
    if (contentLen > maxBytes) {
      if (typeof req.destroy === 'function') req.destroy();
      reject(Object.assign(new Error(`Payload too large (max ${Math.round(maxBytes / 1024)} KB)`), { statusCode: 413 }));
      return;
    }
    const chunks = [];
    let received = 0;
    let settled = false;
    req.on('data', (chunk) => {
      if (settled) return;
      received += chunk.length;
      if (received > maxBytes) {
        settled = true;
        chunks.length = 0;
        if (typeof req.destroy === 'function') req.destroy();
        reject(Object.assign(new Error(`Payload too large (max ${Math.round(maxBytes / 1024)} KB)`), { statusCode: 413 }));
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      resolve(Buffer.concat(chunks));
    });
    req.on('error', (err) => {
      if (settled) return;
      settled = true;
      reject(err);
    });
  });
}

function sendJson(res, status, payload) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function extractDedupId(normalized) {
  return String(normalized?.messageId || normalized?.meta?.messageId || '').trim();
}

function resolveRuntimeSecret(channelCfg, fieldName, fallbackValue) {
  if (channelCfg && typeof channelCfg === 'object' && Object.prototype.hasOwnProperty.call(channelCfg, fieldName)) {
    return String(channelCfg[fieldName] ?? '').trim();
  }
  return String(fallbackValue || '').trim();
}

export async function handleWhatsAppWebhookRoute(req, res, deps) {
  const { config, stateStore, queueUserTurn, getRuntimeConfig, handleWhatsAppChallenge, verifyWhatsAppSignature, normalizeWhatsAppInbound } = deps;
  const cfg = typeof getRuntimeConfig === 'function' ? getRuntimeConfig() : {};
  const waCfg = cfg.channels?.whatsapp || {};
  const verifyToken = resolveRuntimeSecret(waCfg, 'verifyToken', process.env.WHATSAPP_VERIFY_TOKEN);
  const appSecret = resolveRuntimeSecret(waCfg, 'appSecret', process.env.WHATSAPP_APP_SECRET);

  if (req.method === 'GET') {
    const challengeRes = handleWhatsAppChallenge(req, verifyToken);
    if (challengeRes.isChallenge) {
      res.writeHead(challengeRes.status, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(challengeRes.response);
      return;
    }
    res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Bad Request');
    return;
  }

  if (req.method !== 'POST') return sendJson(res, 405, { ok: false, error: 'Method Not Allowed' });
  if (!isChannelEnabled(cfg, 'whatsapp')) return sendJson(res, 403, { ok: false, error: 'WhatsApp channel is disabled' });

  let rawBody;
  try {
    rawBody = await readRawBody(req);
  } catch (err) {
    return sendJson(res, err.statusCode || 400, { ok: false, error: err.message });
  }

  const sigResult = verifyWhatsAppSignature({ signature: req.headers['x-hub-signature-256'], rawBody, appSecret });
  if (!sigResult.valid) return sendJson(res, 401, { ok: false, error: sigResult.reason });

  let body;
  try {
    body = JSON.parse(rawBody.toString('utf8') || '{}');
  } catch {
    return sendJson(res, 400, { ok: false, error: 'Invalid JSON' });
  }

  const normalized = normalizeWhatsAppInbound(body);
  if (!normalized) return sendJson(res, 200, { ok: true, ignored: true });

  const dedupId = extractDedupId(normalized);
  if (dedupId && stateStore.isDuplicateAndMark(dedupId, config.dedupTtlMs)) {
    return sendJson(res, 200, { ok: true, duplicate: true });
  }

  const phone = normalized.replyToken;
  const waImages = (normalized.attachments || []).filter((a) => a && a.type === 'image' && (a.url || a.mediaId));
  stateStore.appendChatMessage(
    normalized.senderId,
    {
      sender: 'customer',
      messageId: dedupId,
      text: normalized.text,
      images: waImages.map((a) => a.url || `whatsapp-media:${a.mediaId}`).filter(Boolean),
      timestamp: normalized.timestamp
    },
    { platform: 'whatsapp', userId: phone, customerName: normalized.senderName }
  );

  sendJson(res, 200, { ok: true, channel: 'whatsapp', senderId: normalized.senderId });

  if (!stateStore.isPausedByHuman(normalized.senderId)) {
    queueUserTurn(normalized.senderId, {
      platform: 'whatsapp',
      userId: phone,
      eventTimestamp: normalized.timestamp,
      text: normalized.text,
      images: waImages.map((a) => ({ platform: 'whatsapp', url: a.url || '', mediaId: a.mediaId || '' })),
      isSticker: false
    });
  }
}

export async function handleLegacyUnifiedWebhookRoute(req, res, deps) {
  const { config, getRuntimeConfig, verifyLineSignature, verifyFacebookSignature, handleLinePayload, handleFacebookPayload } = deps;
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method Not Allowed' });

  const lineSig = req.headers['x-line-signature'];
  const fbSig = req.headers['x-hub-signature-256'];
  if (lineSig === undefined && fbSig === undefined) {
    return sendJson(res, 401, { error: 'Missing webhook signature header' });
  }

  let rawBody;
  try {
    rawBody = await readRawBody(req);
  } catch (err) {
    return sendJson(res, err.statusCode || 400, { error: err.message });
  }

  const runtimeCfg = typeof getRuntimeConfig === 'function' ? getRuntimeConfig() : {};

  if (lineSig !== undefined) {
    if (!isChannelEnabled(runtimeCfg, 'line')) return sendJson(res, 403, { ok: false, error: 'LINE channel is disabled' });
    const lineSecret = resolveRuntimeSecret(runtimeCfg?.channels?.line, 'channelSecret', config?.lineChannelSecret);
    if (!verifyLineSignature(rawBody, lineSig, lineSecret)) return sendJson(res, 401, { error: 'Invalid LINE signature' });

    let body;
    try {
      body = JSON.parse(rawBody.toString('utf8') || '{}');
    } catch {
      return sendJson(res, 400, { error: 'Invalid JSON' });
    }
    sendJson(res, 200, { status: 'ok', platform: 'line' });
    Promise.resolve(handleLinePayload(body)).catch((err) => {
      console.error('[webhook/line] Async handler error:', err?.message || err);
    });
    return;
  }

  if (fbSig !== undefined) {
    if (!isChannelEnabled(runtimeCfg, 'facebook')) return sendJson(res, 403, { ok: false, error: 'Facebook channel is disabled' });
    const fbSecret = resolveRuntimeSecret(runtimeCfg?.channels?.facebook, 'appSecret', config?.fbAppSecret);
    if (!verifyFacebookSignature(rawBody, fbSig, fbSecret)) return sendJson(res, 401, { error: 'Invalid Facebook signature' });

    let body;
    try {
      body = JSON.parse(rawBody.toString('utf8') || '{}');
    } catch {
      return sendJson(res, 400, { error: 'Invalid JSON' });
    }
    sendJson(res, 200, { status: 'ok', platform: 'facebook' });
    Promise.resolve(handleFacebookPayload(body)).catch((err) => {
      console.error('[webhook/facebook] Async handler error:', err?.message || err);
    });
    return;
  }

  sendJson(res, 200, { status: 'ignored' });
}

export async function handleShopeeWebhookRoute(req, res, parsedUrl, deps) {
  const { config, stateStore, queueUserTurn, getRuntimeConfig, handleShopeeChallenge, verifyShopeeSignature, normalizeShopeeInbound } = deps;

  if (req.method !== 'POST') {
    if (req.method === 'GET') {
      const challengeCheck = handleShopeeChallenge({ query: Object.fromEntries(parsedUrl.searchParams) });
      if (challengeCheck.isChallenge) {
        res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
        res.end(challengeCheck.response);
        return;
      }
    }
    return sendJson(res, 405, { error: 'Method Not Allowed' });
  }

  const cfg = typeof getRuntimeConfig === 'function' ? getRuntimeConfig() : {};
  if (!isChannelEnabled(cfg, 'shopee')) return sendJson(res, 403, { ok: false, error: 'Shopee channel is disabled' });

  try {
    const rawBody = (await readRawBody(req)).toString('utf8');
    const partnerKey = resolveRuntimeSecret(cfg.channels?.shopee, 'partnerKey', process.env.SHOPEE_PARTNER_KEY);
    const cfgBase = String(cfg?.publicBaseUrl || '').trim().replace(/\/+$/, '');
    const fullUrl = /^https:\/\//i.test(cfgBase)
      ? `${cfgBase}${req.url}`
      : `https://${req.headers.host || 'localhost'}${req.url}`;
    const sigResult = verifyShopeeSignature({ signature: req.headers['authorization'], webhookUrl: fullUrl, rawBody, partnerKey });
    if (!sigResult.valid) return sendJson(res, 401, { ok: false, error: sigResult.reason });

    let parsedBody;
    try {
      parsedBody = JSON.parse(rawBody || '{}');
    } catch {
      return sendJson(res, 400, { ok: false, error: 'Invalid JSON' });
    }
    const normalized = normalizeShopeeInbound(parsedBody);
    if (!normalized) return sendJson(res, 200, { ok: true, ignored: true });

    const dedupId = extractDedupId(normalized);
    if (dedupId && stateStore.isDuplicateAndMark(dedupId, config.dedupTtlMs)) {
      return sendJson(res, 200, { ok: true, duplicate: true });
    }

    const userKey = normalized.senderId;
    const extId = userKey.replace(/^shopee:/, '');
    stateStore.appendChatMessage(
      userKey,
      { sender: 'customer', messageId: dedupId, text: normalized.text, images: (normalized.attachments || []).map((a) => a.url).filter(Boolean), timestamp: normalized.timestamp || Date.now() },
      { platform: 'shopee', customerName: normalized.senderName, userId: extId }
    );

    if (!stateStore.isPausedByHuman(userKey)) {
      queueUserTurn(userKey, {
        platform: 'shopee',
        userId: extId,
        replyToken: normalized.replyToken,
        eventTimestamp: normalized.timestamp,
        text: normalized.text,
        images: (normalized.attachments || []).map((a) => ({ url: a.url })).filter((a) => a.url)
      });
    }
    sendJson(res, 200, { ok: true, channel: 'shopee', userKey });
  } catch (err) {
    console.error('[webhook/shopee] Error:', err);
    sendJson(res, err.statusCode || 500, { ok: false, error: err.message });
  }
}

export async function handleTikTokWebhookRoute(req, res, deps) {
  const { config, stateStore, queueUserTurn, getRuntimeConfig, verifyTikTokSignature, normalizeTikTokInbound } = deps;
  if (req.method !== 'POST') return sendJson(res, 405, { error: 'Method Not Allowed' });
  const cfg = typeof getRuntimeConfig === 'function' ? getRuntimeConfig() : {};
  if (!isChannelEnabled(cfg, 'tiktok')) return sendJson(res, 403, { ok: false, error: 'TikTok channel is disabled' });

  try {
    const rawBody = (await readRawBody(req)).toString('utf8');
    const appKey = resolveRuntimeSecret(cfg.channels?.tiktok, 'appKey', process.env.TIKTOK_APP_KEY);
    const appSecret = resolveRuntimeSecret(cfg.channels?.tiktok, 'appSecret', process.env.TIKTOK_APP_SECRET);
    const signature = req.headers['x-tts-signature'] || req.headers['authorization'] || '';
    const sigResult = verifyTikTokSignature({ signature, rawBody, appKey, appSecret });
    if (!sigResult.valid) return sendJson(res, 401, { ok: false, error: sigResult.reason });

    let parsedBody;
    try {
      parsedBody = JSON.parse(rawBody || '{}');
    } catch {
      return sendJson(res, 400, { ok: false, error: 'Invalid JSON' });
    }
    const normalized = normalizeTikTokInbound(parsedBody);
    if (!normalized) return sendJson(res, 200, { ok: true, ignored: true });

    const dedupId = extractDedupId(normalized);
    if (dedupId && stateStore.isDuplicateAndMark(dedupId, config.dedupTtlMs)) {
      return sendJson(res, 200, { ok: true, duplicate: true });
    }

    const userKey = normalized.senderId;
    const extId = userKey.replace(/^tiktok:/, '');
    stateStore.appendChatMessage(
      userKey,
      { sender: 'customer', messageId: dedupId, text: normalized.text, images: (normalized.attachments || []).map((a) => a.url).filter(Boolean), timestamp: normalized.timestamp || Date.now() },
      { platform: 'tiktok', customerName: normalized.senderName, userId: extId }
    );

    if (!stateStore.isPausedByHuman(userKey)) {
      queueUserTurn(userKey, {
        platform: 'tiktok',
        userId: extId,
        replyToken: normalized.replyToken,
        eventTimestamp: normalized.timestamp,
        text: normalized.text,
        images: (normalized.attachments || []).map((a) => ({ url: a.url })).filter((a) => a.url)
      });
    }
    sendJson(res, 200, { ok: true, channel: 'tiktok', userKey });
  } catch (err) {
    console.error('[webhook/tiktok] Error:', err);
    sendJson(res, err.statusCode || 500, { ok: false, error: err.message });
  }
}
