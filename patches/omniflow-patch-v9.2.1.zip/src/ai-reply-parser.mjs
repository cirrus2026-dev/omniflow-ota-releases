const TAG_PATTERNS = [
  /\[IMAGE_URL:\s*(https?:\/\/[^\s\]\)]+|\/images_web\/[^\s\]\)]+)\s*\]/gi,
  /\[\[IMG:\s*(https?:\/\/[^\s\]]+|\/images_web\/[^\s\]]+)\s*\]\]/gi,
  /!\[[^\]]*\]\((https?:\/\/[^\s\)]+|\/images_web\/[^\s\)]+)\)/gi,
];

const BARE_CDN_URL_REGEX = /https?:\/\/(?:cdn\.jsdelivr\.net\/gh\/[a-zA-Z0-9_\-\.\/]+|raw\.githubusercontent\.com\/[a-zA-Z0-9_\-\.\/]+)\.(?:jpg|jpeg|png|webp|gif)/gi;

export function sanitizeCdnUrl(rawUrl) {
  if (!rawUrl) return '';
  const trimmed = rawUrl.trim().replace(/[.,;!?]+$/, '');
  try {
    const u = new URL(trimmed);
    return u.toString();
  } catch {
    return trimmed.replace(/ /g, '%20');
  }
}

export function getGithubImageMirrors(url) {
  if (!url || typeof url !== 'string') return [];
  const trimmed = url.trim();
  const relMatch = trimmed.match(/^\/images_web\/(image\d+\.(?:jpg|jpeg|png|webp|gif))$/i);
  if (!relMatch) return [];
  const owner = (process.env.GITHUB_REPO_OWNER || '').trim();
  const repo = (process.env.GITHUB_REPO_NAME || '').trim();
  if (!owner || !repo) return [];
  const fileName = relMatch[1].toLowerCase();
  return [
    `https://raw.githubusercontent.com/${owner}/${repo}/main/${fileName}`,
    `https://cdn.jsdelivr.net/gh/${owner}/${repo}@main/${fileName}`,
  ];
}

export function buildMirrorUrl(url) {
  if (!url || typeof url !== 'string') return null;
  const ghMirrors = getGithubImageMirrors(url);
  if (ghMirrors.length > 0) {
    return ghMirrors[0];
  }
  const jsdelivrPrefix = 'https://cdn.jsdelivr.net/gh/';
  const rawGithubPrefix = 'https://raw.githubusercontent.com/';
  if (url.startsWith(jsdelivrPrefix)) {
    const part = url.slice(jsdelivrPrefix.length);
    const atIdx = part.indexOf('@');
    if (atIdx !== -1) {
      const repo = part.slice(0, atIdx);
      const rest = part.slice(atIdx + 1);
      return `${rawGithubPrefix}${repo}/${rest}`;
    }
  } else if (url.startsWith(rawGithubPrefix)) {
    const part = url.slice(rawGithubPrefix.length);
    const segments = part.split('/');
    if (segments.length >= 3) {
      const [owner, repo, branch, ...rest] = segments;
      return `${jsdelivrPrefix}${owner}/${repo}@${branch}/${rest.join('/')}`;
    }
  }
  return null;
}

export function parseAiReply(aiResponse, options = {}) {
  const maxImages = options.maxImages ?? 3;
  const allowedHosts = (options.allowedImageHosts || []).map((h) =>
    h.toLowerCase()
  );

  const rawText =
    typeof aiResponse === 'string'
      ? aiResponse
      : aiResponse?.text || aiResponse?.answer || aiResponse?.output || '';

  const foundUrls = [];
  const addUrl = (candidate) => {
    if (!candidate) return;
    const trimmed = candidate.trim().replace(/[.,;!?]+$/, '');
    if (trimmed.startsWith('/images_web/')) {
      if (!foundUrls.includes(trimmed) && foundUrls.length < maxImages) {
        foundUrls.push(trimmed);
      }
      return;
    }
    const clean = sanitizeCdnUrl(trimmed);
    if (!clean) return;
    try {
      const parsed = new URL(clean);
      if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') return;
      const host = parsed.hostname.toLowerCase();
      if (allowedHosts.length > 0 && !allowedHosts.includes(host)) return;
      if (!foundUrls.includes(clean) && foundUrls.length < maxImages) {
        foundUrls.push(clean);
      }
    } catch {
      // Ignore malformed URLs
    }
  };

  for (const regex of TAG_PATTERNS) {
    let match;
    regex.lastIndex = 0;
    while ((match = regex.exec(rawText)) !== null) {
      addUrl(match[1]);
    }
  }

  let bareMatch;
  BARE_CDN_URL_REGEX.lastIndex = 0;
  while ((bareMatch = BARE_CDN_URL_REGEX.exec(rawText)) !== null) {
    addUrl(bareMatch[0]);
  }

  let cleanedText = rawText;
  for (const regex of TAG_PATTERNS) {
    cleanedText = cleanedText.replace(regex, '');
  }
  cleanedText = cleanedText
    .replace(BARE_CDN_URL_REGEX, '')
    .replace(/\(\s*\)/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  return {
    text: cleanedText,
    images: foundUrls.map((url) => ({
      url,
      mirrorUrl: buildMirrorUrl(url),
    })),
  };
}