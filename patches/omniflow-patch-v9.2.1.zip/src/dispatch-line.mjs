// gateway/src/dispatch-line.mjs
// LINE Messaging API Outbound Dispatcher (Reply Bundle, Push Fallback, Hot-Reload & Real HTTP Status Reporting)

import { getGithubImageMirrors } from './ai-reply-parser.mjs';
import { getRuntimeConfig } from './modules/settings-vault.mjs';
import {
  normalizePublicHttpsUrl,
  resolvePublicImageWithReason,
} from './dispatch-utils.mjs';

const LINE_LOADING_URL = 'https://api.line.me/v2/bot/chat/loading/start';
const LINE_REPLY_URL = 'https://api.line.me/v2/bot/message/reply';
const LINE_PUSH_URL = 'https://api.line.me/v2/bot/message/push';
const LINE_TEXT_LIMIT = 4900;

function resolveLineChannelAccessToken(config = {}) {
  let runtimeCfg = {};
  try {
    runtimeCfg = getRuntimeConfig() || {};
  } catch {
    runtimeCfg = {};
  }
  return String(
    runtimeCfg?.channels?.line?.channelAccessToken || config?.lineChannelAccessToken || ''
  ).trim();
}

function buildLineHeaders(token) {
  return {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
  };
}

function buildLineMessages(text, images = [], config = {}) {
  const messages = [];
  let cleanText = String(text || '').trim();
  const hasText = Boolean(cleanText);
  if (hasText) {
    if (cleanText.length > LINE_TEXT_LIMIT) {
      console.warn(`[Dispatcher:LINE] Truncating text from ${cleanText.length} to ${LINE_TEXT_LIMIT} chars`);
      cleanText = cleanText.slice(0, LINE_TEXT_LIMIT);
    }
    messages.push({ type: 'text', text: cleanText });
  }

  const resolvedImages = [];
  const skippedImages = [];
  const seenUrls = new Set();

  for (const img of Array.isArray(images) ? images : []) {
    const rawUrl = typeof img === 'string' ? img.trim() : String(img?.url || '').trim();
    const mirrorUrl = typeof img === 'object' && img ? String(img.mirrorUrl || '').trim() : '';
    if (!rawUrl && !mirrorUrl) continue;

    const ghMirror = rawUrl
      ? getGithubImageMirrors(rawUrl).map((m) => normalizePublicHttpsUrl(m)).find(Boolean) || ''
      : '';
    const primary = resolvePublicImageWithReason(rawUrl, config);
    const mirror = mirrorUrl ? resolvePublicImageWithReason(mirrorUrl, config) : { url: '', reason: '' };
    const fullUrl = ghMirror || primary.url || mirror.url;

    if (!fullUrl) {
      const reason = primary.reason || mirror.reason || 'Image URL must be a public HTTPS URL';
      console.warn(`[Dispatcher:LINE] Skipping image (${reason}): ${rawUrl || mirrorUrl}`);
      skippedImages.push({ url: rawUrl || mirrorUrl, reason });
      continue;
    }
    if (seenUrls.has(fullUrl)) continue;
    if (messages.length >= 5) {
      skippedImages.push({ url: fullUrl, reason: 'LINE 5-message limit reached' });
      continue;
    }
    seenUrls.add(fullUrl);
    messages.push({
      type: 'image',
      originalContentUrl: fullUrl,
      previewImageUrl: fullUrl,
    });
    resolvedImages.push(fullUrl);
  }

  return { messages, hasText, resolvedImages, skippedImages };
}

export async function sendLineTypingIndicator(userId, config) {
  const token = resolveLineChannelAccessToken(config);
  if (!token || !userId) return;
  await fetch(LINE_LOADING_URL, {
    method: 'POST',
    headers: buildLineHeaders(token),
    body: JSON.stringify({ chatId: userId, loadingSeconds: 15 }),
    signal: AbortSignal.timeout(3000),
  }).catch(() => {});
}

export async function dispatchLine(ctx, parsedReply = {}, config = {}) {
  const token = resolveLineChannelAccessToken(config);
  if (!token) {
    return { ok: false, platform: 'line', messageId: '', textSent: false, imagesSent: [], error: 'Missing LINE_CHANNEL_ACCESS_TOKEN' };
  }

  const { messages, hasText, resolvedImages, skippedImages } = buildLineMessages(
    parsedReply.text || '',
    parsedReply.images || [],
    config
  );
  if (messages.length === 0) {
    return {
      ok: false,
      platform: 'line',
      messageId: '',
      textSent: false,
      imagesSent: [],
      ...(skippedImages.length > 0 ? { skippedImages } : {}),
      error: skippedImages[0]?.reason || 'No valid text or public image URL to send via LINE',
    };
  }

  const headers = buildLineHeaders(token);
  const elapsedMs = Date.now() - (ctx.eventTimestamp || Date.now());
  const canUseReplyToken = Boolean(ctx.replyToken) && elapsedMs < (config.lineReplyTokenTtlMs || 55000);

  if (canUseReplyToken && config.lineDeliveryMode === 'bundle') {
    try {
      const res = await fetch(LINE_REPLY_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify({ replyToken: ctx.replyToken, messages }),
        signal: AbortSignal.timeout(15000),
      });
      if (res.ok) {
        const replyJson = await res.json().catch(() => ({}));
        const messageId = String(replyJson?.sentMessages?.[0]?.id || '');
        return {
          ok: true,
          platform: 'line',
          mode: 'reply_bundle',
          messageId,
          textSent: hasText,
          imagesSent: resolvedImages,
          ...(skippedImages.length > 0 ? { skippedImages } : {}),
        };
      }
      console.warn(`[Dispatcher:LINE] Reply bundle HTTP ${res.status}, falling back to Push API...`);
    } catch (err) {
      console.warn(`[Dispatcher:LINE] Reply bundle error (${err?.message || err}), falling back to Push API...`);
    }
  }

  try {
    const pushRes = await fetch(LINE_PUSH_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify({ to: ctx.userId, messages }),
      signal: AbortSignal.timeout(15000),
    });

    if (!pushRes.ok) {
      const errBody = await pushRes.text().catch(() => '');
      const error = `LINE Push API HTTP ${pushRes.status}: ${errBody.slice(0, 200)}`;
      console.error(`[Dispatcher:LINE] ${error}`);
      return {
        ok: false,
        platform: 'line',
        mode: 'push_fallback',
        messageId: '',
        textSent: false,
        imagesSent: [],
        ...(skippedImages.length > 0 ? { skippedImages } : {}),
        error,
      };
    }

    const pushJson = await pushRes.json().catch(() => ({}));
    const pushMessageId = String(pushJson?.sentMessages?.[0]?.id || '');
    return {
      ok: true,
      platform: 'line',
      mode: 'push_fallback',
      messageId: pushMessageId,
      textSent: hasText,
      imagesSent: resolvedImages,
      ...(skippedImages.length > 0 ? { skippedImages } : {}),
    };
  } catch (err) {
    const error = err?.message || 'LINE Push API request failed';
    console.error(`[Dispatcher:LINE] Push exception: ${error}`);
    return {
      ok: false,
      platform: 'line',
      mode: 'push_fallback',
      messageId: '',
      textSent: false,
      imagesSent: [],
      ...(skippedImages.length > 0 ? { skippedImages } : {}),
      error,
    };
  }
}

export async function sendLineAdminReply(userId, text, images = [], config = {}) {
  const token = resolveLineChannelAccessToken(config);
  if (!token) throw new Error('Missing LINE_CHANNEL_ACCESS_TOKEN');

  const { messages, hasText, resolvedImages, skippedImages } = buildLineMessages(text, images, config);
  if (messages.length === 0) {
    throw new Error(skippedImages[0]?.reason || 'No valid text or public image URL to send via LINE');
  }

  const res = await fetch(LINE_PUSH_URL, {
    method: 'POST',
    headers: buildLineHeaders(token),
    body: JSON.stringify({ to: userId, messages }),
    signal: AbortSignal.timeout(15000),
  });

  if (!res.ok) {
    const errBody = await res.text().catch(() => '');
    throw new Error(`LINE Push API HTTP ${res.status}: ${errBody.slice(0, 200)}`);
  }

  const json = await res.json().catch(() => ({}));
  const messageId = String(json?.sentMessages?.[0]?.id || '');
  return {
    ok: true,
    platform: 'line',
    messageId,
    textSent: hasText,
    imagesSent: resolvedImages,
    ...(skippedImages.length > 0 ? { skippedImages } : {}),
  };
}
