﻿export function parseCsvRows(csvText = '') {
  const lines = String(csvText || '')
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);

  return lines.map((line) => {
    const cells = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        cells.push(cur.trim());
        cur = '';
      } else {
        cur += ch;
      }
    }
    cells.push(cur.trim());
    return cells;
  });
}

export function parseBotStatusCsv(csvText = '') {
  const rows = parseCsvRows(csvText);
  if (rows.length === 0) {
    return { found: false, enabled: true, rawValue: 'ON (empty_sheet_default)' };
  }

  for (const row of rows) {
    const colA = String(row[0] || '').replace(/^["']|["']$/g, '').trim().toUpperCase();
    const colB = String(row[1] || '').replace(/^["']|["']$/g, '').trim().toUpperCase();

    if (colA === 'BOT_STATUS' || colA === 'STATUS' || colA === 'สถานะบอท') {
      const isOff = ['OFF', 'FALSE', '0', 'CLOSE', 'CLOSED', 'DISABLE', 'DISABLED', 'PAUSE', 'ปิด'].includes(colB);
      return {
        found: true,
        enabled: !isOff,
        rawValue: colB || 'ON',
      };
    }
  }

  // Fallback if user placed ON/OFF directly in A1
  const firstCell = String(rows[0][0] || '').replace(/^["']|["']$/g, '').trim().toUpperCase();
  if (['ON', 'OFF', 'TRUE', 'FALSE', 'เปิด', 'ปิด'].includes(firstCell)) {
    const isOff = ['OFF', 'FALSE', 'ปิด'].includes(firstCell);
    return {
      found: true,
      enabled: !isOff,
      rawValue: firstCell,
    };
  }

  return { found: false, enabled: true, rawValue: 'ON (not_found_default)' };
}

export class BotStatusController {
  constructor(config) {
    this.config = config;
    this.cachedEnabled = true;
    this.cachedRawValue = 'ON';
    this.cachedAt = 0;
    this.lastSource = 'init_default';
    this.lastError = null;
    this.manualOverride = null; // null | true | false
  }

  setManualOverride(val) {
    this.manualOverride = val;
  }

  getSnapshot() {
    return {
      enabled: this.manualOverride !== null ? this.manualOverride : this.cachedEnabled,
      rawValue: this.manualOverride !== null ? (this.manualOverride ? 'ON (MANUAL)' : 'OFF (MANUAL)') : this.cachedRawValue,
      source: this.manualOverride !== null ? 'manual_override' : this.lastSource,
      checkedAt: this.cachedAt ? new Date(this.cachedAt).toISOString() : null,
      error: this.lastError,
    };
  }

  async checkStatus(forceRefresh = false) {
    if (this.manualOverride !== null) {
      return this.getSnapshot();
    }

    const now = Date.now();
    if (!forceRefresh && this.cachedAt > 0 && now - this.cachedAt < this.config.botStatusCacheTtlMs) {
      return {
        ...this.getSnapshot(),
        source: 'memory_cache',
      };
    }

    if (!this.config.botConfigCsvUrl) {
      this.cachedAt = now;
      this.lastSource = 'no_url_default';
      return this.getSnapshot();
    }

    const sep = this.config.botConfigCsvUrl.includes('?') ? '&' : '?';
    const url = `${this.config.botConfigCsvUrl}${sep}t=${now}`;

    try {
      const res = await fetch(url, {
        headers: { 'Cache-Control': 'no-cache' },
        signal: AbortSignal.timeout(this.config.botStatusFetchTimeoutMs || 5000),
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const csvText = await res.text();
      const parsed = parseBotStatusCsv(csvText);

      this.cachedEnabled = parsed.enabled;
      this.cachedRawValue = parsed.rawValue;
      this.cachedAt = now;
      this.lastSource = 'google_sheets_csv';
      this.lastError = null;
      return this.getSnapshot();
    } catch (err) {
      this.lastError = err.message;
      this.cachedAt = now;
      this.lastSource = 'fallback_last_known';
      console.warn(`[BotStatus] CSV check failed (${err.message}), keeping last known status=${this.cachedEnabled}`);
      return this.getSnapshot();
    }
  }

  async isBotEnabled(forceRefresh = false) {
    const status = await this.checkStatus(forceRefresh);
    return status.enabled;
  }
}
