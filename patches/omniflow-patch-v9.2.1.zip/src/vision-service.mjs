export async function downloadImageAsBase64(imageSource, config) {
  let res;
  if (imageSource.platform === 'line' && imageSource.messageId) {
    const lineContentUrl = `https://api-data.line.me/v2/bot/message/${imageSource.messageId}/content`;
    res = await fetch(lineContentUrl, {
      headers: { Authorization: `Bearer ${config.lineChannelAccessToken}` },
      signal: AbortSignal.timeout(15000),
    });
  } else if (imageSource.url) {
    res = await fetch(imageSource.url, {
      signal: AbortSignal.timeout(15000),
    });
  } else {
    throw new Error('No valid image URL or LINE messageId provided');
  }

  if (!res.ok) {
    throw new Error(`Image download failed with HTTP ${res.status}`);
  }
  const contentType = res.headers.get('content-type') || 'image/jpeg';
  const arrayBuffer = await res.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);
  return {
    buffer,
    contentType,
    base64: buffer.toString('base64'),
    dataUrl: `data:${contentType};base64,${buffer.toString('base64')}`,
  };
}

export async function queryOpenClip(imageSource, downloaded, config) {
  try {
    const payload = {
      top_k: 3,
      ...(imageSource.url ? { image_url: imageSource.url } : {}),
      ...(downloaded?.base64 ? { image_base64: downloaded.base64 } : {}),
    };

    const res = await fetch(`${config.openClipUrl}/search-stone`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(15000),
    });

    if (!res.ok) return null;
    const data = await res.json();
    const matches = data.matches || data.results || (Array.isArray(data) ? data : []);
    if (!matches.length) return null;

    const top = matches[0];
    const score = Number(top.score ?? top.similarity ?? 0);
    const stoneName = top.stone_name || top.name || top.filename || '';
    const cdnUrl = top.cdn_url || top.image_url || top.url || '';

    return {
      score,
      stoneName: stoneName.replace(/\.(jpg|jpeg|png|webp)$/i, ''),
      cdnUrl,
      matches,
    };
  } catch (err) {
    console.warn('[VisionService] OpenCLIP query warning:', err.message);
    return null;
  }
}

export async function analyzeWithVisionLLM(downloaded, config) {
  const systemPrompt =
    'คุณคือผู้เชี่ยวญคัดแยกภาพของร้านขายหินแกรนิตและหินอ่อน ให้ตอบเป็น JSON เท่านั้น: ' +
    '{"category":"SITE_OR_STONE|PAYMENT_SLIP|DOC_OR_MAP|UNRELATED","description":"บรรยายสีหิน ลวดลาย เม็ดแร่ เช่น หินแกรนิตสีดำเกล็ดทอง หรือหินอ่อนสีขาวลายเทา แบบกระชับเพื่อใช้ค้นหาในตารางราคา","colorKeywords":"คำค้นสีและลายหลัก"}';

  if (config.groqApiKey) {
    for (const model of [config.groqVisionModel, config.groqVisionFallbackModel]) {
      if (!model) continue;
      try {
        const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${config.groqApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model,
            temperature: 0.1,
            max_tokens: 300,
            messages: [
              { role: 'system', content: systemPrompt },
              {
                role: 'user',
                content: [
                  { type: 'text', text: 'วิเคราะห์ภาพนี้และตอบเป็น JSON' },
                  { type: 'image_url', image_url: { url: downloaded.dataUrl } },
                ],
              },
            ],
          }),
          signal: AbortSignal.timeout(15000),
        });

        if (res.ok) {
          const json = await res.json();
          const content = json.choices?.[0]?.message?.content || '';
          const parsed = extractVisionJson(content);
          if (parsed) return { ...parsed, provider: `groq:${model}` };
        }
      } catch (err) {
        console.warn(`[VisionService] Groq (${model}) failed:`, err.message);
      }
    }
  }

  // Only attempt Local Ollama Vision if OLLAMA_VISION_MODEL is explicitly configured
  if (config.ollamaVisionModel) {
    try {
      const res = await fetch(`${config.ollamaBaseUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: config.ollamaVisionModel,
          stream: false,
          messages: [
            {
              role: 'user',
              content: `${systemPrompt}\nวิเคราะห์ภาพนี้และตอบเป็น JSON`,
              images: [downloaded.base64],
            },
          ],
        }),
        signal: AbortSignal.timeout(20000),
      });
      if (res.ok) {
        const json = await res.json();
        const content = json.message?.content || '';
        const parsed = extractVisionJson(content);
        if (parsed) return { ...parsed, provider: `ollama:${config.ollamaVisionModel}` };
      }
    } catch (err) {
      console.warn('[VisionService] Ollama Vision fallback warning:', err.message);
    }
  }

  return {
    category: 'SITE_OR_STONE',
    description: 'ภาพตัวอย่างหินจากลูกค้า',
    colorKeywords: 'หินแกรนิต หินอ่อน',
    provider: 'default',
  };
}

function extractVisionJson(text = '') {
  try {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return null;
    const obj = JSON.parse(match[0]);
    return {
      category: obj.category || 'SITE_OR_STONE',
      description: obj.description || 'ภาพตัวอย่างหิน',
      colorKeywords: obj.colorKeywords || obj.description || '',
    };
  } catch {
    return null;
  }
}

export async function inspectCustomerImage(imageSource, config) {
  const downloaded = await downloadImageAsBase64(imageSource, config);
  const [clipResult, visionResult] = await Promise.all([
    queryOpenClip(imageSource, downloaded, config),
    analyzeWithVisionLLM(downloaded, config),
  ]);

  const clipScore = clipResult?.score ?? 0;
  const isHighConfidence = clipScore >= config.openClipThreshold;

  return {
    category: visionResult.category || 'SITE_OR_STONE',
    visionDescription: visionResult.description,
    colorKeywords: visionResult.colorKeywords,
    clipScore,
    isHighConfidence,
    matchedStone: isHighConfidence ? clipResult?.stoneName : null,
    closestClipStone: clipResult?.stoneName || null,
    cdnUrl: isHighConfidence ? clipResult?.cdnUrl : null,
    closestClipCdnUrl: clipResult?.cdnUrl || null,
    customerImageUrl: imageSource.url || '',
  };
}