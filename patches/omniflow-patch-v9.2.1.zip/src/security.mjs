// gateway/src/security.mjs
// Hardened Timing-Safe Webhook Signature Verifiers (No Silent Bypass on Empty Secrets)

import crypto from 'node:crypto';

function isUnverifiedWebhookDevAllowed() {
  return String(process.env.ALLOW_UNVERIFIED_WEBHOOK_DEV || '').trim().toLowerCase() === 'true';
}

function toRawBuffer(rawBody) {
  if (Buffer.isBuffer(rawBody)) return rawBody;
  return Buffer.from(String(rawBody ?? ''), 'utf8');
}

export function verifyFacebookSignature(rawBody, signatureHeader, appSecret) {
  const secret = String(appSecret || '').trim();
  if (!secret) return isUnverifiedWebhookDevAllowed();
  const sig = String(signatureHeader || '').trim();
  if (!sig || !sig.startsWith('sha256=')) return false;
  const expected = 'sha256=' + crypto.createHmac('sha256', secret).update(toRawBuffer(rawBody)).digest('hex');
  try {
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(expected, 'utf8');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export function verifyLineSignature(rawBody, signatureHeader, channelSecret) {
  const secret = String(channelSecret || '').trim();
  if (!secret) return isUnverifiedWebhookDevAllowed();
  const sig = String(signatureHeader || '').trim();
  if (!sig) return false;
  const expected = crypto.createHmac('sha256', secret).update(toRawBuffer(rawBody)).digest('base64');
  try {
    const a = Buffer.from(sig, 'utf8');
    const b = Buffer.from(expected, 'utf8');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}
