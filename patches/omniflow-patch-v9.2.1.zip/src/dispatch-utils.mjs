// gateway/src/dispatch-utils.mjs
// Shared Public HTTPS Image URL Validator & Resolver for Outbound Dispatchers (FB, LINE, WhatsApp)

import net from 'node:net';
import { getGithubImageMirrors } from './ai-reply-parser.mjs';
import { isPrivateOrReservedIp } from './modules/fetch-safe.mjs';

const BLOCKED_IMAGE_HOSTS = new Set([
  'localhost',
  'localhost.localdomain',
  'host.docker.internal',
  'metadata.google.internal',
  'metadata.goog',
  'instance-data',
]);

export function normalizePublicHttpsUrl(rawUrl) {
  const trimmed = String(rawUrl || '').trim();
  if (!trimmed) return '';
  let parsed;
  try {
    parsed = new URL(trimmed);
  } catch {
    return '';
  }
  if (parsed.protocol !== 'https:') return '';
  if (parsed.username || parsed.password) return '';
  const host = parsed.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host || BLOCKED_IMAGE_HOSTS.has(host) || /\.(?:localhost|local|internal)$/i.test(host)) {
    return '';
  }
  if (net.isIP(host) !== 0 && isPrivateOrReservedIp(host)) return '';
  return parsed.toString();
}

export function isUsablePublicBaseUrl(rawBase) {
  return Boolean(normalizePublicHttpsUrl(rawBase));
}

export function resolvePublicImageWithReason(url, config = {}) {
  if (!url || typeof url !== 'string') {
    return { url: '', reason: 'Empty or invalid image URL' };
  }
  const trimmed = url.trim();
  if (!trimmed) {
    return { url: '', reason: 'Empty image URL' };
  }

  if (trimmed.startsWith('/') && !trimmed.startsWith('//')) {
    const rawBase = String(config?.publicBaseUrl || process.env.PUBLIC_BASE_URL || '').trim().replace(/\/+$/, '');
    const safeBase = normalizePublicHttpsUrl(rawBase).replace(/\/+$/, '');
    if (safeBase) {
      const joined = normalizePublicHttpsUrl(`${safeBase}${trimmed}`);
      if (joined) return { url: joined, reason: '' };
    }
    const ghMirrors = getGithubImageMirrors(trimmed)
      .map((m) => normalizePublicHttpsUrl(m))
      .filter(Boolean);
    if (ghMirrors.length > 0) {
      return { url: ghMirrors[0], reason: '' };
    }
    return { url: '', reason: 'relative URL without PUBLIC_BASE_URL' };
  }

  const safe = normalizePublicHttpsUrl(trimmed);
  if (safe) {
    return { url: safe, reason: '' };
  }
  return { url: '', reason: 'Image URL must be a public HTTPS URL (localhost/private IP/HTTP blocked)' };
}

export function resolvePublicImageUrl(url, config = {}) {
  return resolvePublicImageWithReason(url, config).url;
}

export function dedupePublicHttpsUrls(urls = []) {
  const seen = new Set();
  const out = [];
  for (const raw of Array.isArray(urls) ? urls : []) {
    const safe = normalizePublicHttpsUrl(raw);
    if (!safe || seen.has(safe)) continue;
    seen.add(safe);
    out.push(safe);
  }
  return out;
}
