// gateway/public/modules/channel-icons.js
// Compact Vector SVG Brand Icons (18x18px) for Omnichannel Inbox Badges

const wrap = (bg, svg) =>
  `<span class="inline-flex items-center justify-center w-[18px] h-[18px] rounded-[5px] shrink-0 shadow-sm" style="background:${bg};">${svg}</span>`;

export const PLATFORM_ICON_SVGS = {
  line: wrap('#06C755', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M12 4C6.9 4 2.8 7.3 2.8 11.4c0 3.6 3.2 6.6 7.5 7.2.3.1.7.2.8.5.1.3.1.7 0 1l-.1.8c0 .2-.2.9.8.5s5.1-3 7-5.2c1.4-1.5 2.2-3.2 2.2-4.8C21.2 7.3 17.1 4 12 4Z" fill="#fff"/><text x="12" y="13.2" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="5.5" fill="#06C755">LINE</text></svg>'),

  whatsapp: wrap('linear-gradient(180deg,#39F16E 0%,#12B83B 100%)', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M12 3.5A8.5 8.5 0 0 0 4.6 16.2L3.5 20.5l4.4-1.1A8.5 8.5 0 1 0 12 3.5Z" stroke="#fff" stroke-width="2" stroke-linejoin="round"/><path d="M9.6 8.8c-.2-.4-.4-.4-.6-.4h-.5c-.2 0-.5.1-.7.3-.2.3-.9.9-.9 2.1s.9 2.5 1 2.7c.1.2 1.8 2.8 4.4 3.8 2.1.8 2.6.7 3 .6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.1-1.2-.1-.1-.2-.2-.5-.3l-1.5-.7c-.2-.1-.4-.1-.6.1-.2.3-.6.8-.8.9-.1.2-.3.2-.5.1-.3-.1-1.1-.4-2-1.3-.8-.7-1.3-1.5-1.4-1.8-.2-.2 0-.4.1-.5l.4-.5c.1-.1.2-.3.3-.4.1-.2 0-.3 0-.5l-.7-1.7Z" fill="#fff"/></svg>'),

  facebook: wrap('linear-gradient(180deg,#2D8CFF 0%,#0E63E6 100%)', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M15.2 13.5l.5-3.2h-3.1V8.2c0-.9.4-1.7 1.8-1.7h1.4V3.8s-1.3-.2-2.5-.2c-2.6 0-4.2 1.5-4.2 4.3v2.4H6.3v3.2h2.8V21h3.5v-7.5h2.6Z" fill="#fff"/></svg>'),

  shopee: wrap('#EE4D2D', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M8.5 8a3.5 3.5 0 0 1 7 0" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/><rect x="5" y="8" width="14" height="12.5" rx="2" fill="#fff"/><text x="12" y="17.5" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="9.5" fill="#EE4D2D">S</text></svg>'),

  tiktok: wrap('#111827', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M14.5 4v9.2a3.3 3.3 0 1 1-2.5-3.2V7.2a6 6 0 1 0 5.3 6V8.6a6.4 6.4 0 0 0 3.7 1.2V7.1a3.7 3.7 0 0 1-3.7-3.1h-2.8Z" fill="#25F4EE" transform="translate(-0.6,-0.4)"/><path d="M14.5 4v9.2a3.3 3.3 0 1 1-2.5-3.2V7.2a6 6 0 1 0 5.3 6V8.6a6.4 6.4 0 0 0 3.7 1.2V7.1a3.7 3.7 0 0 1-3.7-3.1h-2.8Z" fill="#FE2C55" transform="translate(0.6,0.4)"/><path d="M14.5 4v9.2a3.3 3.3 0 1 1-2.5-3.2V7.2a6 6 0 1 0 5.3 6V8.6a6.4 6.4 0 0 0 3.7 1.2V7.1a3.7 3.7 0 0 1-3.7-3.1h-2.8Z" fill="#fff"/></svg>'),

  lazada: wrap('linear-gradient(180deg,#0F4CE6 0%,#061B70 100%)', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M12 19.5L4.5 14.5V8l3.8-2.4L12 8.2l3.7-2.6L19.5 8v6.5L12 19.5Z" fill="url(#lzG)"/><defs><linearGradient id="lzG" x1="4" y1="6" x2="20" y2="18"><stop stop-color="#FF7A00"/><stop offset="1" stop-color="#FF0080"/></linearGradient></defs><text x="12" y="13.8" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="5.8" fill="#fff">Laz</text></svg>'),

  email: wrap('#0EA5E9', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><rect x="3.5" y="5.5" width="17" height="13" rx="2.2" fill="#fff"/><path d="M4.5 7l7.5 5.5L19.5 7" stroke="#0EA5E9" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'),

  instagram: wrap('linear-gradient(45deg,#F58529 0%,#DD2A7B 50%,#8134AF 100%)', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><rect x="4.5" y="4.5" width="15" height="15" rx="4.2" stroke="#fff" stroke-width="2"/><circle cx="12" cy="12" r="3.4" stroke="#fff" stroke-width="2"/><circle cx="16.5" cy="7.5" r="1.1" fill="#fff"/></svg>'),

  shopify: wrap('#95BF47', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M8.5 7.5a3.5 3.5 0 0 1 7 0" stroke="#fff" stroke-width="1.8"/><path d="M6 7.5h12l1 12.5H5L6 7.5Z" fill="#5E8E3E"/><text x="12" y="16.8" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="9.5" fill="#fff">S</text></svg>'),

  hubspot: wrap('#FF7A59', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><circle cx="13.5" cy="12.5" r="3.2" stroke="#fff" stroke-width="2"/><path d="M13.5 9.3V6.5M11 10.6L7.2 8M11 14.4L8.2 17" stroke="#fff" stroke-width="1.8" stroke-linecap="round"/><circle cx="13.5" cy="5.5" r="1.4" fill="#fff"/><circle cx="6.2" cy="7.3" r="1.6" fill="#fff"/><circle cx="7.4" cy="17.8" r="1.4" fill="#fff"/></svg>'),

  wechat: wrap('#07C160', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><ellipse cx="9.8" cy="10.2" rx="6.2" ry="5" fill="#fff"/><circle cx="7.8" cy="9.6" r=".8" fill="#07C160"/><circle cx="11.5" cy="9.6" r=".8" fill="#07C160"/><ellipse cx="15" cy="14.5" rx="5" ry="4" fill="#fff" stroke="#07C160" stroke-width="1"/><circle cx="13.5" cy="14" r=".7" fill="#07C160"/><circle cx="16.4" cy="14" r=".7" fill="#07C160"/></svg>'),

  discord: wrap('#5865F2', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M18.5 7.2a12 12 0 0 0-3-.9l-.4.8a11 11 0 0 0-6.2 0l-.4-.8a12 12 0 0 0-3 .9C3.6 10 3.1 12.8 3.4 15.5a12 12 0 0 0 3.7 1.9l.8-1.3c-.4-.2-.9-.4-1.3-.7l.3-.2a8.6 8.6 0 0 0 10.2 0l.3.2c-.4.3-.9.5-1.3.7l.8 1.3a12 12 0 0 0 3.7-1.9c.3-3-.5-5.8-2.1-8.3ZM9.4 13.8c-.7 0-1.3-.7-1.3-1.5s.6-1.5 1.3-1.5 1.3.7 1.3 1.5-.6 1.5-1.3 1.5Zm5.2 0c-.7 0-1.3-.7-1.3-1.5s.6-1.5 1.3-1.5 1.3.7 1.3 1.5-.6 1.5-1.3 1.5Z" fill="#fff"/></svg>'),

  signal: wrap('#3A76F0', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><circle cx="12" cy="12" r="8.5" stroke="#fff" stroke-width="1.5" stroke-dasharray="2.4 2"/><path d="M12 5.5a6.5 6.5 0 0 0-5.7 9.6l-.8 2.9 3-.8A6.5 6.5 0 1 0 12 5.5Z" fill="#fff"/></svg>'),

  viber: wrap('#7360F2', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M6.5 5.5h11a2.5 2.5 0 0 1 2.5 2.5v7a2.5 2.5 0 0 1-2.5 2.5H10l-3 2.5v-2.5H6.5A2.5 2.5 0 0 1 4 15V8a2.5 2.5 0 0 1 2.5-2.5Z" stroke="#fff" stroke-width="1.8"/><path d="M9.5 9c1.2 2.4 2.9 4.1 5.3 5.3l1.2-1.2 1.8.8-.8 1.8c-3.5-.4-6.4-3.3-6.8-6.8l1.8-.8.8 1.8-1.2 1.2Z" fill="#fff"/></svg>'),

  kakaotalk: wrap('#FEE500', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M12 4.5c-4.8 0-8.6 3-8.6 6.7 0 2.3 1.5 4.4 3.8 5.6l-.9 3.2 3.6-2.4c.7.1 1.4.2 2.1.2 4.8 0 8.6-3 8.6-6.7S16.8 4.5 12 4.5Z" fill="#191919"/><text x="12" y="13" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="4.8" fill="#FEE500">TALK</text></svg>'),

  slack: wrap('#ffffff', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><rect x="9.8" y="3.5" width="2.2" height="5.5" rx="1.1" fill="#36C5F0"/><rect x="3.5" y="9.8" width="5.5" height="2.2" rx="1.1" fill="#36C5F0"/><rect x="12" y="9.8" width="5.5" height="2.2" rx="1.1" fill="#2EB67D"/><rect x="12" y="3.5" width="2.2" height="5.5" rx="1.1" fill="#2EB67D"/><rect x="12" y="15" width="2.2" height="5.5" rx="1.1" fill="#ECB22E"/><rect x="15" y="12" width="5.5" height="2.2" rx="1.1" fill="#ECB22E"/><rect x="6.5" y="12" width="5.5" height="2.2" rx="1.1" fill="#E01E5A"/><rect x="9.8" y="15" width="2.2" height="5.5" rx="1.1" fill="#E01E5A"/></svg>'),

  teams: wrap('#5059C9', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><circle cx="16.8" cy="8.2" r="2.1" fill="#C4C9FF"/><path d="M14.5 11.2h4.2c.7 0 1.3.6 1.3 1.3v3.5a2 2 0 0 1-2 2h-3.5v-6.8Z" fill="#C4C9FF"/><rect x="4" y="6.5" width="10.5" height="11" rx="1.6" fill="#fff"/><text x="9.2" y="14.5" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="8.2" fill="#5059C9">T</text></svg>'),

  google_chat: wrap('#ffffff', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M5 4.5h10.5L19 8v9a2 2 0 0 1-2 2H9.5L5 22v-3a2 2 0 0 1-2-2V6.5a2 2 0 0 1 2-2Z" fill="#00AC47"/><rect x="4.5" y="4.5" width="3.5" height="11" fill="#2684FC"/><rect x="8" y="4.5" width="7.5" height="3.5" fill="#FFBA00"/><path d="M15.5 4.5L19 8h-3.5V4.5Z" fill="#EA4335"/><rect x="8" y="8" width="7.5" height="6.5" rx="1" fill="#fff"/></svg>'),

  lark: wrap('#ffffff', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M5.5 5.5h7.2c1.8 2 3 4.5 3.4 7.3-3-1.2-6.5-3.6-10.6-7.3Z" fill="#00D6B9"/><path d="M3.5 9.5c3.5 3.4 7 5.2 10.6 5.2 2.4 0 4.5-.8 6.4-2.3-1.5 4.2-4.8 7.1-9.4 7.1-4.2 0-7.6-2.5-7.6-6.2V9.5Z" fill="#3370FF"/><path d="M9.5 14.3c2.4-2.8 5-4.3 8.1-4.3 1.1 0 2 .2 2.9.6-1.4 2.6-3.8 4.2-6.7 4.2-1.6 0-3-.2-4.3-.5Z" fill="#133C9A"/></svg>'),

  dingtalk: wrap('linear-gradient(180deg,#3BA8FF 0%,#007FFF 100%)', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M6.5 5.5c4.5 1 9 2.2 11.2 4.2.9.8.8 2.2 0 3.2l-2.3 2.5h2.6L12.5 21l1.2-3.8H11c-1.8 0-3-.9-3.8-2.3 1.2.2 2.4.1 3.3-.2-2.2-.5-3.9-1.6-4.7-3.2 1.4.2 2.8.1 4-.3-2.5-.8-3.8-2.5-3.3-5.7Z" fill="#fff"/></svg>'),

  zoho_salesiq: wrap('#E42527', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M12 4.5a7.5 7.5 0 1 0 5.3 12.8H20l-2.1-2.1A7.5 7.5 0 0 0 12 4.5Z" stroke="#fff" stroke-width="2" stroke-linejoin="round"/><path d="M14.5 13.8a3.4 3.4 0 1 1 0-3.6M11.5 11.5l6.5 6.5M11.5 11.5h2.5M11.5 11.5v2.5" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'),

  crisp: wrap('linear-gradient(180deg,#2AB6FF 0%,#0B66FF 100%)', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M4.5 6.5l14.5-1.2.8 9.2-5 .5-2.6 3.5-2.4-3-4.5.4-.8-9.4Z" fill="#fff"/></svg>'),

  tidio: wrap('#ffffff', '<svg viewBox="0 0 24 24" class="w-3.5 h-3.5" fill="none"><path d="M11 6a6 6 0 0 1 6 6v4.5h-4.5A6 6 0 0 1 11 6Z" fill="#2563EB"/><path d="M6.5 10.5A5.5 5.5 0 0 1 12 16v3.5H6.5V10.5Z" fill="#38BDF8" fill-opacity="0.88"/></svg>')
};
