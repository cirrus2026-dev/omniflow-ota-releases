/**
 * OmniFlow - Inbox 3-Column Resizable Layout & Customer Info Panel
 * Pure Frontend UI Module (No backend changes required)
 */

const STORAGE_LEFT_WIDTH = 'omniflow_inbox_left_w';
const STORAGE_RIGHT_WIDTH = 'omniflow_inbox_right_w';
const STORAGE_RIGHT_COLLAPSED = 'omniflow_inbox_right_collapsed';
const STORAGE_NOTES_PREFIX = 'omniflow_customer_note_';

function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

function escapeHtml(str) {
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function initResizablePanes() {
  const leftPane = document.getElementById('inboxLeftPane');
  const rightPane = document.getElementById('inboxCustomerInfoPane');
  const resizerLeft = document.getElementById('inboxResizerLeft');
  const resizerRight = document.getElementById('inboxResizerRight');
  const toggleBtn = document.getElementById('toggleCustomerInfoBtn');

  if (!leftPane || !rightPane) return;

  // Restore saved widths
  const savedLeft = Number(localStorage.getItem(STORAGE_LEFT_WIDTH));
  if (savedLeft >= 240 && savedLeft <= 560) {
    leftPane.style.width = `${savedLeft}px`;
  }
  const savedRight = Number(localStorage.getItem(STORAGE_RIGHT_WIDTH));
  if (savedRight >= 240 && savedRight <= 480) {
    rightPane.style.width = `${savedRight}px`;
  }

  const applyRightCollapsed = (collapsed) => {
    if (collapsed) {
      rightPane.classList.add('hidden');
      resizerRight?.classList.add('hidden');
    } else {
      rightPane.classList.remove('hidden');
      resizerRight?.classList.remove('hidden');
    }
    localStorage.setItem(STORAGE_RIGHT_COLLAPSED, collapsed ? '1' : '0');
  };

  if (localStorage.getItem(STORAGE_RIGHT_COLLAPSED) === '1') {
    applyRightCollapsed(true);
  }

  toggleBtn?.addEventListener('click', () => {
    const isHidden = rightPane.classList.contains('hidden');
    applyRightCollapsed(!isHidden);
  });

  // Left Resizer
  if (resizerLeft) {
    resizerLeft.addEventListener('mousedown', (e) => {
      e.preventDefault();
      const startX = e.clientX;
      const startWidth = leftPane.getBoundingClientRect().width;
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';

      const onMove = (ev) => {
        const nextW = clamp(startWidth + (ev.clientX - startX), 240, 560);
        leftPane.style.width = `${nextW}px`;
      };
      const onUp = () => {
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        localStorage.setItem(STORAGE_LEFT_WIDTH, String(Math.round(leftPane.getBoundingClientRect().width)));
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });
  }

  // Right Resizer
  if (resizerRight) {
    resizerRight.addEventListener('mousedown', (e) => {
      e.preventDefault();
      const startX = e.clientX;
      const startWidth = rightPane.getBoundingClientRect().width;
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';

      const onMove = (ev) => {
        const nextW = clamp(startWidth - (ev.clientX - startX), 240, 480);
        rightPane.style.width = `${nextW}px`;
      };
      const onUp = () => {
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        localStorage.setItem(STORAGE_RIGHT_WIDTH, String(Math.round(rightPane.getBoundingClientRect().width)));
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    });
  }
}

function syncCustomerInfoPanel() {
  const userKeyEl = document.getElementById('activeUserKey');
  const nameEl = document.getElementById('activeCustomerName');
  const badgeEl = document.getElementById('activePlatformBadge');
  const avatarEl = document.getElementById('activeAvatar');
  const modeEl = document.getElementById('activeModeBadge');
  const kanbanEl = document.getElementById('kanbanStatusSelect');
  const feedEl = document.getElementById('chatMessageFeed');

  const infoEmpty = document.getElementById('customerInfoEmpty');
  const infoBody = document.getElementById('customerInfoBody');
  const infoAvatar = document.getElementById('infoCustomerAvatar');
  const infoName = document.getElementById('infoCustomerName');
  const infoChannel = document.getElementById('infoCustomerChannel');
  const infoStatus = document.getElementById('infoCustomerStatus');
  const infoMode = document.getElementById('infoCustomerMode');
  const infoLastMsg = document.getElementById('infoCustomerLastMsg');
  const infoMsgCount = document.getElementById('infoCustomerMsgCount');
  const noteInput = document.getElementById('customerInternalNoteInput');
  const noteSavedBadge = document.getElementById('customerNoteSavedBadge');

  if (!infoEmpty || !infoBody) return;

  const userKey = userKeyEl?.textContent?.trim() || '';
  const activePane = document.getElementById('chatActivePane');
  const isChatOpen = activePane && !activePane.classList.contains('hidden') && userKey && userKey !== 'line:...';

  if (!isChatOpen) {
    infoEmpty.classList.remove('hidden');
    infoBody.classList.add('hidden');
    return;
  }

  infoEmpty.classList.add('hidden');
  infoBody.classList.remove('hidden');

  if (infoName) infoName.textContent = nameEl?.textContent?.trim() || 'ลูกค้า';
  if (infoChannel) infoChannel.textContent = `${badgeEl?.textContent?.trim() || 'CHAT'} • ${userKey}`;
  if (infoMode) infoMode.textContent = modeEl?.textContent?.trim() || 'AI บอทกำลังดูแล';

  if (infoStatus && kanbanEl) {
    const selectedOpt = kanbanEl.options[kanbanEl.selectedIndex];
    infoStatus.textContent = selectedOpt ? selectedOpt.textContent : 'สนใจถามราคา (Lead)';
  }

  // Sync Avatar (supports image URL if available, else styled initials badge per platform)
  if (infoAvatar && avatarEl) {
    const imgInside = avatarEl.querySelector('img');
    if (imgInside && imgInside.src) {
      infoAvatar.innerHTML = `<img src="${imgInside.src}" alt="avatar" class="w-full h-full object-cover rounded-full" />`;
    } else {
      const cname = (nameEl?.textContent?.trim() || 'C').replace(/[^a-zA-Z0-9ก-ฮ]/g, ' ').trim();
      const parts = cname.split(/\s+/).filter(Boolean);
      const initials = parts.length >= 2
        ? (parts[0][0] + parts[1][0]).toUpperCase()
        : (cname.slice(0, 2) || 'C').toUpperCase();
      const isLine = userKey.startsWith('line:');
      const isFb = userKey.startsWith('facebook:');
      const grad = isLine
        ? 'from-emerald-500/35 to-cyan-500/35 border-emerald-400/60 text-emerald-200'
        : isFb
        ? 'from-blue-500/35 to-indigo-500/35 border-blue-400/60 text-blue-200'
        : 'from-purple-500/35 to-cyan-500/35 border-purple-400/60 text-purple-200';
      infoAvatar.className = `w-16 h-16 rounded-full bg-gradient-to-br ${grad} border-2 flex items-center justify-center text-xl font-bold overflow-hidden mb-2.5 shadow-lg`;
      infoAvatar.textContent = initials;
    }
  }

  // Extract latest customer message & message count from feed
  if (feedEl) {
    if (infoMsgCount) {
      const msgCount = feedEl.children ? feedEl.children.length : 0;
      infoMsgCount.textContent = `${msgCount} ข้อความ`;
    }
    if (infoLastMsg) {
      const text = feedEl.lastElementChild?.innerText?.trim() || 'กำลังสนทนา...';
      infoLastMsg.textContent = text.length > 140 ? `${text.slice(0, 140)}...` : text;
    }
  }

  // Load Internal Note for this userKey
  if (noteInput && noteInput.dataset.boundKey !== userKey) {
    noteInput.dataset.boundKey = userKey;
    noteInput.value = localStorage.getItem(`${STORAGE_NOTES_PREFIX}${userKey}`) || '';
    if (noteSavedBadge) noteSavedBadge.classList.add('hidden');
  }
}

function initCustomerNoteAutoSave() {
  const noteInput = document.getElementById('customerInternalNoteInput');
  const noteSavedBadge = document.getElementById('customerNoteSavedBadge');
  if (!noteInput) return;

  noteInput.addEventListener('input', () => {
    const key = noteInput.dataset.boundKey;
    if (!key) return;
    localStorage.setItem(`${STORAGE_NOTES_PREFIX}${key}`, noteInput.value);
    if (noteSavedBadge) {
      noteSavedBadge.classList.remove('hidden');
      clearTimeout(noteInput._saveTimer);
      noteInput._saveTimer = setTimeout(() => {
        noteSavedBadge.classList.add('hidden');
      }, 1500);
    }
  });
}

function initInboxObserver() {
  const targetIds = ['activeUserKey', 'activeCustomerName', 'activeModeBadge', 'chatActivePane', 'chatMessageFeed'];
  const observer = new MutationObserver(() => {
    syncCustomerInfoPanel();
  });

  targetIds.forEach((id) => {
    const el = document.getElementById(id);
    if (el) {
      observer.observe(el, { childList: true, characterData: true, attributes: true, subtree: true });
    }
  });

  document.getElementById('kanbanStatusSelect')?.addEventListener('change', syncCustomerInfoPanel);
}

const STORAGE_SEEN_ORDERS = 'omniflow_seen_order_ids';

function getSeenOrderIds() {
  try {
    const raw = JSON.parse(localStorage.getItem(STORAGE_SEEN_ORDERS) || '[]');
    return new Set(Array.isArray(raw) ? raw : []);
  } catch {
    return new Set();
  }
}

function markOrdersAsSeen(ids = []) {
  const seen = getSeenOrderIds();
  ids.forEach((id) => {
    if (id) seen.add(id);
  });
  localStorage.setItem(STORAGE_SEEN_ORDERS, JSON.stringify([...seen].slice(-200)));
}

async function syncDashboardOrderAlerts() {
  try {
    const res = await fetch('/api/local-db/orders');
    if (!res.ok) return;
    const data = await res.json();
    const orders = Array.isArray(data.orders) ? data.orders : [];
    const seenIds = getSeenOrderIds();
    const pendingOrders = orders.filter(
      (o) =>
        (!o.status || o.status === 'pending' || o.status === 'pending_unconfirmed') &&
        (!seenIds.has(o.id) || (o.amendedAtMs && !o.amendAcked))
    );

    const alertBtn = document.getElementById('dashLatestOrderAlert');
    const alertText = document.getElementById('dashLatestOrderAlertText');
    if (alertBtn && alertText) {
      if (pendingOrders.length > 0) {
        const latest = pendingOrders[0];
        const prefix = latest.amendedAtMs && !latest.amendAcked ? 'อัปเดตออเดอร์เพิ่มเติม' : 'มีออเดอร์ใหม่';
        alertText.textContent = `${prefix} (${pendingOrders.length}): ${latest.customerName || 'ลูกค้า'} • ${latest.productName || 'สั่งซื้อสินค้า'}`;
        alertBtn.classList.remove('hidden');
        alertBtn.onclick = () => {
          markOrdersAsSeen(pendingOrders.map((o) => o.id));
          alertBtn.classList.add('hidden');
          syncDashboardOrderAlerts();
          if (typeof window.switchView === 'function') window.switchView('orders');
        };
      } else {
        alertBtn.classList.add('hidden');
      }
    }

    const alertBox = document.getElementById('dashPendingOrdersAlertBox');
    if (alertBox) {
      if (pendingOrders.length > 0) {
        alertBox.innerHTML = `
          <div class="pt-2 border-t border-cyan-500/20 flex items-center justify-between text-[11px] font-mono text-amber-300">
            <span class="inline-flex items-center gap-1.5"><i data-lucide="bell" class="w-3.5 h-3.5 shrink-0"></i><span>แจ้งเตือนออเดอร์รอดำเนินการ (เรียงตามอันดับ)</span></span>
            <span class="px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-400/35">${pendingOrders.length} รายการ</span>
          </div>
          ${pendingOrders
            .slice(0, 5)
            .map(
              (o, idx) => `
            <div data-alert-order-id="${escapeHtml(o.id)}" class="dash-order-alert-item cursor-pointer p-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-400/30 flex items-center justify-between gap-2 transition">
              <div class="min-w-0">
                <div class="text-xs font-bold text-amber-200 truncate flex items-center gap-1.5"><span>#${idx + 1}</span><i data-lucide="bell" class="w-3.5 h-3.5 shrink-0"></i><span class="truncate">${escapeHtml(o.customerName || 'ลูกค้าแชต')}</span></div>
                <div class="text-[11px] text-slate-300 truncate">${escapeHtml(o.productName || 'สอบถามสั่งซื้อ')} ${o.dimensions ? `(${escapeHtml(o.dimensions)})` : ''}</div>
              </div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900/80 text-emerald-300 border border-emerald-500/30 shrink-0">${escapeHtml(o.phone || 'ดูรายละเอียด')}</span>
            </div>`
            )
            .join('')}
        `;
        if (window.lucide) window.lucide.createIcons();
        alertBox.querySelectorAll('.dash-order-alert-item').forEach((item) => {
          item.addEventListener('click', () => {
            const oid = item.getAttribute('data-alert-order-id');
            if (oid) markOrdersAsSeen([oid]);
            syncDashboardOrderAlerts();
            if (typeof window.switchView === 'function') window.switchView('orders');
          });
        });
      } else {
        alertBox.innerHTML = '';
      }
    }
  } catch (err) {
    console.warn('[InboxLayout] background alert poll error:', err);
  }
}

function bootstrapInboxLayoutUI() {
  initResizablePanes();
  initCustomerNoteAutoSave();
  initInboxObserver();
  syncCustomerInfoPanel();
  syncDashboardOrderAlerts();
  setInterval(syncDashboardOrderAlerts, 15000);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', bootstrapInboxLayoutUI);
} else {
  bootstrapInboxLayoutUI();
}
