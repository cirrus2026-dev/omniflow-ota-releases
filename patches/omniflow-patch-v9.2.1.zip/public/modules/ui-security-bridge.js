// gateway/public/modules/ui-security-bridge.js
// Unified Fetch Security Bridge, Admin PIN Modal (/api/admin/auth/pin), DOM XSS Guard & CRM Note Migration

(() => {
  'use strict';
  if (window.__omniSecurityBridgeReady) return;
  window.__omniSecurityBridgeReady = true;

  const PIN_MODAL_ID = 'omniSecurityPinModal';
  const AUTH_ENDPOINT = '/api/admin/auth/pin';
  const LEGACY_AUTH_PATHS = new Set(['/api/auth/login', '/api/auth/admin-pin']);
  const AUTH_BYPASS_PATHS = new Set(['/api/admin/auth/pin', '/api/auth/login', '/api/auth/admin-pin', '/api/auth/session', '/api/auth/logout', '/health']);
  const POLL_PATHS = new Set(['/api/chat/conversations', '/api/local-db/orders', '/api/dashboard/kpi-summary']);
  const SAFE_DATA_IMAGE_RE = /^data:image\/(?:png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i;
  const SAFE_GUARD_SELECTORS = ['#chatMessageFeed', '#activeAvatar', '#infoCustomerAvatar', '#stoneGalleryGrid', '#entCatalogTableBody', '#entEditCatImgPreviewWrap', '#entOrdersTableBody'];

  window.__omniAuthBlocked = false;
  let lockoutTimer = null;

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function isSafeUrl(rawUrl, { allowDataImage = false } = {}) {
    const s = String(rawUrl ?? '').trim();
    if (!s) return false;
    if (/^(?:javascript|vbscript):/i.test(s)) return false;
    if (/^data:/i.test(s)) return allowDataImage && SAFE_DATA_IMAGE_RE.test(s);
    if (/^\/(?!\/)/.test(s)) return true;
    try {
      const parsed = new URL(s, window.location.origin);
      return parsed.protocol === 'https:' || parsed.protocol === 'http:';
    } catch {
      return false;
    }
  }

  function sanitizeUrl(rawUrl, opts) {
    return isSafeUrl(rawUrl, opts) ? String(rawUrl).trim() : '';
  }

  window.escapeHtml = window.escapeHtml || escapeHtml;
  window.isSafeUrl = isSafeUrl;
  window.sanitizeUrl = sanitizeUrl;

  function migrateLegacyCrmNotes() {
    try {
      const legacyPrefix = 'omniflow_customer_note_';
      const targetPrefix = 'omniflow_crm_note_';
      for (let i = 0; i < localStorage.length; i += 1) {
        const key = localStorage.key(i);
        if (!key || !key.startsWith(legacyPrefix)) continue;
        const targetKey = `${targetPrefix}${key.slice(legacyPrefix.length)}`;
        if (!localStorage.getItem(targetKey)) {
          const val = localStorage.getItem(key);
          if (val) localStorage.setItem(targetKey, val);
        }
      }
    } catch {}
  }

  function buildPinModal() {
    let modal = document.getElementById(PIN_MODAL_ID);
    if (modal) return modal;
    modal = document.createElement('div');
    modal.id = PIN_MODAL_ID;
    modal.className = 'fixed inset-0 z-[10050] hidden items-center justify-center bg-slate-950/85 backdrop-blur-md p-4';
    modal.innerHTML = `
      <div class="w-full max-w-md rounded-2xl bg-[#0a1024] border border-cyan-500/40 shadow-2xl p-6 text-slate-100 space-y-4">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-300"><i data-lucide="lock" class="w-5 h-5 shrink-0"></i></div>
          <div>
            <h3 class="text-base font-bold text-cyan-300">ยืนยันรหัสผ่าน Admin PIN</h3>
            <p class="text-xs text-slate-400">Session แอดมินหมดอายุหรือเข้าใช้งานฟังก์ชันที่ต้องยืนยันสิทธิ์</p>
          </div>
        </div>
        <form id="omniPinModalForm" class="space-y-3">
          <input id="omniPinModalInput" type="password" inputmode="numeric" autocomplete="current-password" placeholder="กรอก Admin PIN" required
            class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 focus:border-cyan-400 text-white text-sm tracking-widest outline-none" />
          <div id="omniPinModalError" class="hidden px-3 py-2 rounded-lg bg-rose-950/70 border border-rose-500/45 text-rose-200 text-xs"></div>
          <button id="omniPinModalSubmit" type="submit"
            class="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm transition inline-flex items-center justify-center gap-1.5">
            <i data-lucide="unlock" class="w-4 h-4 shrink-0"></i><span>ปลดล็อกเข้าใช้งานระบบ</span>
          </button>
        </form>
      </div>`;
    document.body.appendChild(modal);
    if (window.lucide) window.lucide.createIcons();
    modal.querySelector('#omniPinModalForm').addEventListener('submit', handlePinSubmit);
    return modal;
  }

  function showLockoutCountdown(errEl, btnEl, seconds) {
    if (lockoutTimer) clearInterval(lockoutTimer);
    let left = Math.max(1, Math.ceil(Number(seconds) || 60));
    const tick = () => {
      if (left <= 0) {
        clearInterval(lockoutTimer);
        lockoutTimer = null;
        if (btnEl) btnEl.disabled = false;
        if (errEl) errEl.textContent = 'สามารถลองกรอกรหัส PIN ใหม่ได้แล้ว';
        return;
      }
      if (btnEl) btnEl.disabled = true;
      if (errEl) {
        errEl.classList.remove('hidden');
        errEl.textContent = `ลองรหัส PIN ผิดเกินกำหนด กรุณารอ ${left} วินาที`;
      }
      left -= 1;
    };
    tick();
    lockoutTimer = setInterval(tick, 1000);
  }

  function openOmniPinModal(opts = {}) {
    if (!document.body) {
      document.addEventListener('DOMContentLoaded', () => openOmniPinModal(opts), { once: true });
      return;
    }
    document.getElementById('omniAuthBanner')?.remove();
    const modal = buildPinModal();
    const errEl = modal.querySelector('#omniPinModalError');
    const btnEl = modal.querySelector('#omniPinModalSubmit');
    const inputEl = modal.querySelector('#omniPinModalInput');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    if (opts.locked && opts.retryAfterSec) {
      showLockoutCountdown(errEl, btnEl, opts.retryAfterSec);
    } else if (opts.message && errEl) {
      errEl.textContent = String(opts.message);
      errEl.classList.remove('hidden');
    }
    setTimeout(() => inputEl?.focus(), 40);
  }
  window.openOmniPinModal = openOmniPinModal;

  const origFetch = window.fetch.bind(window);

  async function handlePinSubmit(e) {
    e.preventDefault();
    const inputEl = document.getElementById('omniPinModalInput');
    const errEl = document.getElementById('omniPinModalError');
    const btnEl = document.getElementById('omniPinModalSubmit');
    const pin = String(inputEl?.value || '').trim();
    if (!pin) return;
    if (btnEl) {
      btnEl.disabled = true;
      btnEl.textContent = '⏳ กำลังตรวจสอบ PIN...';
    }
    errEl?.classList.add('hidden');
    try {
      const res = await origFetch(AUTH_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ pin })
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 429 || data.locked) {
        showLockoutCountdown(errEl, btnEl, data.retryAfterSec || 60);
        return;
      }
      if (!res.ok || !data.ok) {
        if (errEl) {
          errEl.textContent = data.error || 'รหัส PIN ไม่ถูกต้อง';
          errEl.classList.remove('hidden');
        }
        inputEl?.select();
        return;
      }
      window.__omniAuthBlocked = false;
      document.getElementById(PIN_MODAL_ID)?.classList.add('hidden');
      document.getElementById('omniAuthBanner')?.remove();
      window.location.reload();
    } catch {
      if (errEl) {
        errEl.textContent = 'เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ กรุณาลองใหม่';
        errEl.classList.remove('hidden');
      }
    } finally {
      if (btnEl && !lockoutTimer) {
        btnEl.disabled = false;
        btnEl.innerHTML = '<i data-lucide="unlock" class="w-4 h-4 shrink-0"></i><span>ปลดล็อกเข้าใช้งานระบบ</span>';
        if (window.lucide) window.lucide.createIcons();
      }
    }
  }

  function shouldPromptPin(status, data) {
    if (status === 401) return true;
    if (status === 429) return Boolean(data?.locked || data?.requirePin);
    if (status === 403) {
      const msg = String(data?.error || '');
      if (/sandbox|disabled in production/i.test(msg)) return false;
      return Boolean(data?.requirePin || /forbidden|unauthorized|localhost|session|pin/i.test(msg));
    }
    return false;
  }

  async function wrappedFetch(input, init) {
    const rawUrl = input instanceof Request ? input.url : String(input ?? '');
    let parsed = null;
    try {
      parsed = new URL(rawUrl, window.location.origin);
    } catch {
      return origFetch(input, init);
    }
    if (parsed.origin !== window.location.origin) return origFetch(input, init);

    let target = input;
    if (LEGACY_AUTH_PATHS.has(parsed.pathname) && !(input instanceof Request)) {
      target = `${AUTH_ENDPOINT}${parsed.search || ''}`;
      parsed = new URL(target, window.location.origin);
    }

    if (window.__omniAuthBlocked && POLL_PATHS.has(parsed.pathname)) {
      return new Response(JSON.stringify({ ok: false, error: 'Unauthorized', requirePin: true }), {
        status: 401,
        headers: { 'Content-Type': 'application/json; charset=utf-8' }
      });
    }

    const nextInit = Object.assign({}, init || {});
    if (!nextInit.credentials) nextInit.credentials = 'same-origin';
    const res = await origFetch(target, nextInit);

    const isProtected = (parsed.pathname.startsWith('/api/') || parsed.pathname === '/canary') && !AUTH_BYPASS_PATHS.has(parsed.pathname);
    if (isProtected && (res.status === 401 || res.status === 403 || res.status === 429)) {
      const data = await res.clone().json().catch(() => null);
      if (shouldPromptPin(res.status, data)) {
        window.__omniAuthBlocked = true;
        openOmniPinModal({ message: data?.error || '', locked: Boolean(data?.locked), retryAfterSec: Number(data?.retryAfterSec || 0) });
      }
    }
    return res;
  }
  wrappedFetch.__omniSecurityBridgeWrapped = true;
  window.fetch = wrappedFetch;

  window.apiFetch = async function apiFetchBridge(path, { timeoutMs = 8000, ...options } = {}) {
    const res = await window.fetch(path, {
      credentials: 'same-origin',
      ...options,
      signal: options.signal || AbortSignal.timeout(timeoutMs)
    });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.ok === false) {
      throw Object.assign(new Error(data?.error || `HTTP ${res.status}`), { status: res.status, data });
    }
    return data;
  };

  function sanitizeContainerDom(root, allowDataImage = false) {
    if (!root || typeof root.querySelectorAll !== 'function') return;
    root.querySelectorAll('script, iframe, object, embed, base').forEach((n) => n.remove());
    root.querySelectorAll('img').forEach((img) => {
      const src = img.getAttribute('src');
      if (src && !isSafeUrl(src, { allowDataImage })) {
        img.removeAttribute('src');
        img.setAttribute('data-xss-blocked', '1');
      }
    });
    root.querySelectorAll('a').forEach((a) => {
      const href = a.getAttribute('href');
      if (href && !isSafeUrl(href)) a.removeAttribute('href');
      if (a.getAttribute('target') === '_blank') a.setAttribute('rel', 'noopener noreferrer');
    });
  }

  function initDomGuards() {
    migrateLegacyCrmNotes();
    const bodyObs = new MutationObserver(() => {
      const legacyBanner = document.getElementById('omniAuthBanner');
      if (legacyBanner) {
        legacyBanner.remove();
        openOmniPinModal();
      }
    });
    bodyObs.observe(document.body, { childList: true });

    SAFE_GUARD_SELECTORS.forEach((sel) => {
      const el = document.querySelector(sel);
      if (!el) return;
      const allowData = sel === '#entEditCatImgPreviewWrap';
      sanitizeContainerDom(el, allowData);
      new MutationObserver(() => sanitizeContainerDom(el, allowData)).observe(el, { childList: true, subtree: true });
    });

    document.addEventListener('change', (e) => {
      const input = e.target;
      if (!(input instanceof HTMLInputElement) || input.type !== 'file' || !input.files?.length) return;
      const hasSvg = Array.from(input.files).some((f) => /\.svg$/i.test(f.name) || /svg/i.test(f.type));
      if (hasSvg && /image/i.test(input.accept || '')) {
        input.value = '';
        alert('ไม่อนุญาตให้อัปโหลดไฟล์ SVG เพื่อป้องกันช่องโหว่ XSS (รองรับ PNG, JPG, WEBP, GIF เท่านั้น)');
      }
    }, true);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initDomGuards);
  else initDomGuards();
})();
