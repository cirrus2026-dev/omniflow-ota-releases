// gateway/public/modules/catalog-manager-ui.js
// Phase 10: Standalone Price List & Local Catalog Manager UI (Inline Edit, Local Image Upload, CSV Import/Export)

const TAB_BTN_ID = 'tabBtnCatalog';
const VIEW_ID = 'viewCatalogManager';

let catalogItems = [];
let searchQuery = '';
let selectedCategory = 'ALL';

function escapeHtml(str) {
  if (typeof window.escapeHtml === 'function') return window.escapeHtml(str);
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isSafeUrl(rawUrl) {
  if (typeof window.isSafeUrl === 'function') return window.isSafeUrl(rawUrl);
  const s = String(rawUrl ?? '').trim();
  if (!s || /^(?:javascript|vbscript|data):/i.test(s)) return false;
  if (/^\/(?!\/)/.test(s)) return true;
  try {
    const parsed = new URL(s, window.location.origin);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

async function apiJson(path, options = {}) {
  const bridge =
    typeof window.apiFetch === 'function'
      ? window.apiFetch
      : typeof window.omniApiFetch === 'function'
      ? window.omniApiFetch
      : null;
  if (bridge) return bridge(path, options);
  const res = await fetch(path, { credentials: 'same-origin', ...options });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || data.ok === false) {
    throw new Error(data?.error || `HTTP ${res.status}`);
  }
  return data;
}

function notifyCatalog(msg, isError = false) {
  const existing = document.getElementById('rwCatalogToast');
  if (existing) existing.remove();
  const el = document.createElement('div');
  el.id = 'rwCatalogToast';
  el.className = `fixed bottom-5 right-5 z-[10000] px-4 py-3 rounded-xl border text-xs font-semibold shadow-2xl transition ${
    isError
      ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
      : 'bg-emerald-950/95 border-emerald-400/50 text-emerald-100'
  }`;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 3000);
}

function injectCatalogNavAndView() {
  const nav =
    document.querySelector('header nav') ||
    document.querySelector('nav.flex.items-center') ||
    document.querySelector('nav');
  if (nav && !document.getElementById(TAB_BTN_ID)) {
    const btn = document.createElement('button');
    btn.id = TAB_BTN_ID;
    btn.type = 'button';
    btn.className =
      'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition text-slate-400 hover:text-cyan-200 border border-transparent';
    btn.innerHTML = '<i data-lucide="gem" class="w-4 h-4 shrink-0"></i><span>คลังสินค้า &amp; ราคา</span>';
    btn.addEventListener('click', () => {
      if (typeof window.switchView === 'function') {
        window.switchView('catalog');
      } else {
        activateCatalogView();
      }
    });

    const settingsBtn = document.getElementById('rwOpenSettingsBtn');
    if (settingsBtn && settingsBtn.parentElement === nav) {
      nav.insertBefore(btn, settingsBtn);
    } else {
      nav.appendChild(btn);
    }
  }

  if (!document.getElementById(VIEW_ID)) {
    const section = document.createElement('section');
    section.id = VIEW_ID;
    section.className = 'hidden max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-5';
    section.innerHTML = `
      <div class="aether-panel rounded-2xl p-5 border-cyan-500/25 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 class="text-lg font-bold text-white flex items-center gap-2">
              <i data-lucide="gem" class="w-5 h-5 text-cyan-400 shrink-0"></i>
              <span>จัดการคลังสินค้า &amp; ตารางราคากลาง (Local Catalog DB)</span>
              <span id="catTotalBadge" class="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/35">0 รายการ</span>
            </h2>
            <p class="text-xs text-slate-400 mt-0.5">แก้ไขราคาปกติ / ราคาพิเศษได้ทันทีในตาราง • อัปโหลดรูปลงเครื่องโดยตรงไม่ต้องใช้คลาวด์ภายนอก</p>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <button type="button" id="btnOpenAddStoneModal" class="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition inline-flex items-center gap-1.5">
              <i data-lucide="plus" class="w-4 h-4 shrink-0"></i><span>เพิ่มสินค้า/บริการใหม่</span>
            </button>
            <a href="/api/local-db/catalog-export.csv" download="omniflow-catalog.csv" class="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/35 text-xs font-semibold transition inline-flex items-center gap-1.5">
              <i data-lucide="download" class="w-4 h-4 shrink-0"></i><span>Export CSV</span>
            </a>
            <label class="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-amber-300 border border-amber-500/35 text-xs font-semibold cursor-pointer transition inline-flex items-center gap-1.5">
              <i data-lucide="upload" class="w-4 h-4 shrink-0"></i><span>Import CSV</span>
              <input type="file" id="inputImportCatalogCsv" accept=".csv,text/csv" class="hidden" />
            </label>
          </div>
        </div>

        <!-- Filter & Search Row -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2 border-t border-slate-800/80">
          <div class="md:col-span-7">
            <input id="catSearchInput" type="text" placeholder="ค้นหาชื่อสินค้า/บริการ, รหัสสินค้า (SKU), หรือหมายเหตุ..." class="w-full px-3.5 py-2 rounded-xl bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs text-slate-100" />
          </div>
          <div class="md:col-span-5 flex items-center gap-2">
            <span class="text-xs text-slate-400 shrink-0">หมวดหมู่:</span>
            <select id="catCategoryFilter" class="w-full px-3 py-2 rounded-xl bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs text-slate-100">
              <option value="ALL">ทั้งหมดทุกหมวดหมู่</option>
            </select>
          </div>
        </div>

        <!-- Catalog Table -->
        <div class="overflow-x-auto rounded-xl border border-slate-800/90 max-h-[65vh]">
          <table class="w-full text-left border-collapse">
            <thead class="sticky top-0 z-10 bg-slate-950 text-[11px] font-mono uppercase text-slate-400 border-b border-slate-800">
              <tr>
                <th class="py-2.5 px-3 w-16">รูป</th>
                <th class="py-2.5 px-3">หมวดหมู่</th>
                <th class="py-2.5 px-3">ชื่อสินค้า / บริการ</th>
                <th class="py-2.5 px-3">ขนาด / หน่วย</th>
                <th class="py-2.5 px-3 w-32">ราคาปกติ (บ.)</th>
                <th class="py-2.5 px-3 w-32">ราคาพิเศษ (บ.)</th>
                <th class="py-2.5 px-3">หมายเหตุ / รหัสสินค้า</th>
                <th class="py-2.5 px-3 text-right w-36">จัดการ</th>
              </tr>
            </thead>
            <tbody id="catTableBody" class="divide-y divide-slate-800/70 text-xs">
              <tr><td colspan="8" class="py-10 text-center text-slate-400">กำลังโหลดข้อมูลคลังสินค้า...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Add New Product Modal -->
      <div id="addStoneLocalModal" class="hidden fixed inset-0 z-[9995] items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
        <div class="w-full max-w-xl rounded-2xl bg-[#0a1024] border border-cyan-500/35 p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-cyan-300 flex items-center gap-2"><i data-lucide="plus-circle" class="w-4 h-4 shrink-0"></i><span>เพิ่มสินค้า/บริการใหม่ลงคลัง (บันทึกลงเครื่องทันที)</span></h3>
            <button type="button" id="btnCloseAddStoneModal" class="text-slate-400 hover:text-rose-300 text-sm inline-flex items-center"><i data-lucide="x" class="w-4 h-4 shrink-0"></i></button>
          </div>
          <form id="formAddStoneLocal" class="space-y-3 text-xs">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block text-slate-300 mb-1">หมวดหมู่</label>
                <input name="category" type="text" placeholder="เช่น คอร์สความงาม, อาหาร, สินค้าทั่วไป" required class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">ชื่อสินค้า / บริการ *</label>
                <input name="name" type="text" placeholder="เช่น โปรแกรมเลเซอร์หน้าใส / เมนูพิเศษ" required class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label class="block text-slate-300 mb-1">ขนาด / รูปแบบ</label>
                <input name="size" type="text" placeholder="เช่น 1 ครั้ง / กล่อง / ไซส์ M" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">หน่วยนับ</label>
                <input name="unit" type="text" value="ชิ้น" placeholder="ชิ้น / ครั้ง / ตร.ม." class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">รหัสสินค้า (SKU)</label>
                <input name="blockCode" type="text" placeholder="เช่น SKU-001" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label class="block text-slate-300 mb-1">ราคาปกติ (บาท)</label>
                <input name="slabPrice" type="number" step="1" min="0" placeholder="1990" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-emerald-300 font-mono" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">ราคาพิเศษ / โปรโมชั่น (บาท)</label>
                <input name="cutPrice" type="number" step="1" min="0" placeholder="1490" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-cyan-300 font-mono" />
              </div>
            </div>
            <div>
              <label class="block text-slate-300 mb-1">รายละเอียด / หมายเหตุเพิ่มเติม</label>
              <input name="note" type="text" placeholder="เช่น รวมค่าบริการ / โปรโมชั่นเดือนนี้" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
            </div>
            <div>
              <label class="block text-slate-300 mb-1">เลือกรูปภาพจากเครื่อง (บันทึกลง /images_web/ อัตโนมัติ)</label>
              <input id="newStoneImageFile" type="file" accept="image/png,image/jpeg,image/webp,image/gif" class="w-full text-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-cyan-500/20 file:text-cyan-300 hover:file:bg-cyan-500/30" />
            </div>
            <div class="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button type="button" id="btnCancelAddStone" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold">ยกเลิก</button>
              <button type="submit" class="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-slate-950 font-bold inline-flex items-center gap-1.5"><i data-lucide="save" class="w-4 h-4 shrink-0"></i><span>บันทึกลงคลัง</span></button>
            </div>
          </form>
        </div>
      </div>
    `;

    const mainAnchor = document.getElementById('viewInbox') || document.getElementById('viewDashboard');
    if (mainAnchor && mainAnchor.parentElement) {
      mainAnchor.parentElement.insertBefore(section, mainAnchor.nextSibling);
    } else {
      document.body.appendChild(section);
    }
    if (window.lucide) window.lucide.createIcons();

    bindCatalogEvents();
  }
}

function bindCatalogEvents() {
  document.getElementById('catSearchInput')?.addEventListener('input', (e) => {
    searchQuery = e.target.value.trim().toLowerCase();
    renderCatalogTable();
  });

  document.getElementById('catCategoryFilter')?.addEventListener('change', (e) => {
    selectedCategory = e.target.value;
    renderCatalogTable();
  });

  const modal = document.getElementById('addStoneLocalModal');
  document.getElementById('btnOpenAddStoneModal')?.addEventListener('click', () => {
    modal?.classList.remove('hidden');
    modal?.classList.add('flex');
  });
  const closeModal = () => {
    modal?.classList.add('hidden');
    modal?.classList.remove('flex');
  };
  document.getElementById('btnCloseAddStoneModal')?.addEventListener('click', closeModal);
  document.getElementById('btnCancelAddStone')?.addEventListener('click', closeModal);

  document.getElementById('formAddStoneLocal')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = e.target;
    const fd = new FormData(form);
    const payload = {
      category: fd.get('category'),
      name: fd.get('name'),
      size: fd.get('size'),
      unit: fd.get('unit'),
      blockCode: fd.get('blockCode'),
      slabPrice: fd.get('slabPrice'),
      cutPrice: fd.get('cutPrice'),
      note: fd.get('note')
    };

    const fileInput = document.getElementById('newStoneImageFile');
    if (fileInput?.files?.[0]) {
      const imgErr = validateSafeImageFile(fileInput.files[0]);
      if (imgErr) {
        notifyCatalog(` ${imgErr}`, true);
        fileInput.value = '';
        return;
      }
      payload.imageBase64 = await readFileAsDataUrl(fileInput.files[0]);
      payload.imageFilename = fileInput.files[0].name;
    }

    try {
      const data = await apiJson('/api/local-db/catalog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      form.reset();
      closeModal();
      notifyCatalog(` เพิ่ม "${data.item.name}" ลงฐานข้อมูลเรียบร้อยแล้ว`);
      await loadCatalogData();
    } catch (err) {
      notifyCatalog(` ${err.message}`, true);
    }
  });

  document.getElementById('inputImportCatalogCsv')?.addEventListener('change', async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const confirmed = window.confirm(` คำเตือนความปลอดภัย:\nการนำเข้าไฟล์ CSV "${file.name}" จะทำการแทนที่ (Replace) ฐานข้อมูลสินค้าเดิมทั้งหมด\n\nคุณแน่ใจหรือไม่ว่าต้องการดำเนินการต่อ?`);
    if (!confirmed) {
      e.target.value = '';
      return;
    }

    try {
      const csvText = await file.text();
      const data = await apiJson('/api/local-db/catalog-import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csvText, mode: 'replace' })
      });
      notifyCatalog(` นำเข้าข้อมูลสำเร็จ ${data.importedCount} รายการ`);
      await loadCatalogData();
    } catch (err) {
      notifyCatalog(` ${err.message}`, true);
    } finally {
      e.target.value = '';
    }
  });
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export async function loadCatalogData() {
  try {
    const data = await apiJson('/api/local-db/catalog');
    catalogItems = data.items || [];
    populateCategoryFilter();
    renderCatalogTable();
    if (typeof window.ensureCatalogLoaded === 'function') {
      window.ensureCatalogLoaded(true);
    }
  } catch (err) {
    notifyCatalog(` ${err.message}`, true);
  }
}

function populateCategoryFilter() {
  const select = document.getElementById('catCategoryFilter');
  if (!select) return;
  const cats = Array.from(new Set(catalogItems.map((i) => i.category).filter(Boolean)));
  select.innerHTML =
    `<option value="ALL">ทั้งหมดทุกหมวดหมู่ (${catalogItems.length})</option>` +
    cats.map((c) => `<option value="${escapeHtml(c)}" ${selectedCategory === c ? 'selected' : ''}>${escapeHtml(c)}</option>`).join('');
}

function renderCatalogTable() {
  const tbody = document.getElementById('catTableBody');
  const badge = document.getElementById('catTotalBadge');
  if (!tbody) return;

  const filtered = catalogItems.filter((item) => {
    if (selectedCategory !== 'ALL' && item.category !== selectedCategory) return false;
    if (searchQuery) {
      const hay = `${item.category} ${item.name} ${item.size} ${item.note} ${item.blockCode}`.toLowerCase();
      if (!hay.includes(searchQuery)) return false;
    }
    return true;
  });

  if (badge) badge.textContent = `${filtered.length} / ${catalogItems.length} รายการ`;

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="py-10 text-center text-slate-500">ไม่พบรายการสินค้าที่ตรงกับคำค้นหา</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered
    .map((item) => {
      const safeImg = isSafeUrl(item.imageUrl) ? String(item.imageUrl).trim() : '';
      const thumb = safeImg
        ? `<img src="${escapeHtml(safeImg)}" alt="${escapeHtml(item.name)}" class="w-11 h-11 rounded-lg object-cover border border-slate-700" />`
        : `<div class="w-11 h-11 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-[10px] text-slate-600">ไม่มีรูป</div>`;

      return `
        <tr data-row-id="${escapeHtml(item.id)}" class="hover:bg-slate-900/50 transition">
          <td class="py-2 px-3">${thumb}</td>
          <td class="py-2 px-3 text-slate-300 font-medium">${escapeHtml(item.category)}</td>
          <td class="py-2 px-3">
            <input type="text" data-field="name" value="${escapeHtml(item.name)}" class="w-full bg-transparent border border-transparent hover:border-slate-700 focus:border-cyan-400 focus:bg-slate-950 rounded px-2 py-1 text-white font-semibold focus:outline-none" />
          </td>
          <td class="py-2 px-3 text-slate-400 font-mono text-[11px]">${escapeHtml(item.size || '-')} / ${escapeHtml(item.unit)}</td>
          <td class="py-2 px-3">
            <input type="number" data-field="slabPrice" value="${escapeHtml(item.slabPrice ?? '')}" placeholder="-" class="w-24 bg-slate-950/70 border border-slate-800 focus:border-emerald-400 rounded px-2 py-1 text-emerald-300 font-mono text-right focus:outline-none" />
          </td>
          <td class="py-2 px-3">
            <input type="number" data-field="cutPrice" value="${escapeHtml(item.cutPrice ?? '')}" placeholder="-" class="w-24 bg-slate-950/70 border border-slate-800 focus:border-cyan-400 rounded px-2 py-1 text-cyan-300 font-mono text-right focus:outline-none" />
          </td>
          <td class="py-2 px-3 text-slate-400 text-[11px]">
            <div>${escapeHtml(item.note || '-')}</div>
            ${item.blockCode ? `<span class="font-mono text-[10px] text-slate-500">SKU: ${escapeHtml(item.blockCode)}</span>` : ''}
          </td>
          <td class="py-2 px-3 text-right space-x-1">
            <button type="button" data-save-row="${escapeHtml(item.id)}" class="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/35 text-emerald-300 border border-emerald-500/40 font-semibold transition inline-flex items-center gap-1">
              <i data-lucide="save" class="w-3.5 h-3.5 shrink-0"></i><span>บันทึก</span>
            </button>
            <button type="button" data-del-row="${escapeHtml(item.id)}" class="px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/35 transition inline-flex items-center" title="ลบรายการ">
              <i data-lucide="trash-2" class="w-3.5 h-3.5 shrink-0"></i>
            </button>
          </td>
        </tr>
      `;
    })
    .join('');
  if (window.lucide) window.lucide.createIcons();

  tbody.querySelectorAll('[data-save-row]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-save-row');
      const tr = btn.closest('tr');
      if (!tr || !id) return;
      const name = tr.querySelector('[data-field="name"]')?.value?.trim();
      const slabPrice = tr.querySelector('[data-field="slabPrice"]')?.value;
      const cutPrice = tr.querySelector('[data-field="cutPrice"]')?.value;

      btn.disabled = true;
      try {
        const data = await apiJson(`/api/local-db/catalog/${encodeURIComponent(id)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name, slabPrice, cutPrice })
        });
        notifyCatalog(` อัปเดตราคา "${data.item.name}" สำเร็จ`);
        await loadCatalogData();
      } catch (err) {
        notifyCatalog(` ${err.message}`, true);
      } finally {
        btn.disabled = false;
      }
    });
  });

  tbody.querySelectorAll('[data-del-row]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-del-row');
      if (!id || !confirm('ยืนยันการลบรายการสินค้านี้ออกจากคลัง?')) return;
      try {
        await apiJson(`/api/local-db/catalog/${encodeURIComponent(id)}`, { method: 'DELETE' });
        notifyCatalog(' ลบรายการเรียบร้อยแล้ว');
        await loadCatalogData();
      } catch (err) {
        notifyCatalog(` ${err.message}`, true);
      }
    });
  });
}

export function activateCatalogView() {
  injectCatalogNavAndView();
  ['viewDashboard', 'viewInbox', 'viewOrdersManager'].forEach((id) => {
    document.getElementById(id)?.classList.add('hidden');
  });
  document.getElementById(VIEW_ID)?.classList.remove('hidden');

  const activeCls =
    'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition bg-gradient-to-r from-cyan-500/25 to-indigo-500/25 text-cyan-200 border border-cyan-400/40 glow-cyan';
  const idleCls =
    'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition text-slate-400 hover:text-white border border-transparent';

  ['tabBtnDashboard', 'tabBtnInbox', 'tabBtnOrders'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.className = idleCls;
  });
  const catBtn = document.getElementById(TAB_BTN_ID);
  if (catBtn) catBtn.className = activeCls;

  loadCatalogData();
}

window.activateCatalogView = activateCatalogView;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectCatalogNavAndView);
} else {
  injectCatalogNavAndView();
}
