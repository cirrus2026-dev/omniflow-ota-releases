// Phase 8.4 Modular UI Plugin: Hover Image Preview for Inspector (Both Left & Right sides)
(function initHoverPreviewPlugin() {
  const previewCache = new Map(); // stoneName -> { ok, imageUrl, source, label }
  let activeLookupToken = 0;

  const popover = document.createElement('div');
  popover.id = 'stoneHoverPopover';
  popover.className =
    'fixed hidden z-[9999] pointer-events-none rounded-xl border border-cyan-500/45 bg-slate-950/95 backdrop-blur-md shadow-2xl p-2.5 transition-all duration-150 w-56';
  popover.innerHTML = `
    <div class="flex items-center gap-1.5 mb-1.5 pb-1 border-b border-slate-800">
      <i data-lucide="search" class="w-3.5 h-3.5 text-cyan-400 shrink-0"></i>
      <span id="hoverPopoverTitle" class="text-[11px] font-bold text-cyan-200 truncate"></span>
    </div>
    <div class="relative w-full h-44 rounded-lg overflow-hidden border border-slate-800 bg-black flex items-center justify-center">
      <img id="hoverPopoverImg" class="w-full h-full object-cover" alt="รูปตัวอย่างหิน" />
    </div>
    <div id="hoverPopoverSub" class="mt-1.5 text-[10px] font-mono text-emerald-300 truncate"></div>
  `;
  document.body.appendChild(popover);
  if (window.lucide) window.lucide.createIcons();

  const titleEl = document.getElementById('hoverPopoverTitle');
  const imgEl = document.getElementById('hoverPopoverImg');
  const subEl = document.getElementById('hoverPopoverSub');

  function getInspectionData() {
    return window.lastInspectionData || (typeof state !== 'undefined' ? state.lastInspection : null);
  }

  function showPopover(title, imgUrl, subtitle, e) {
    if (!imgUrl) return;
    titleEl.textContent = title || 'รูปตัวอย่างหิน';
    if (imgEl.src !== imgUrl) {
      imgEl.src = imgUrl;
    }
    subEl.textContent = subtitle || '';
    subEl.style.display = subtitle ? 'block' : 'none';
    popover.classList.remove('hidden');
    updatePosition(e);
  }

  function hidePopover() {
    activeLookupToken++;
    popover.classList.add('hidden');
  }

  function updatePosition(e) {
    const gap = 16;
    const w = 232;
    const h = 248;
    let x = e.clientX + gap;
    let y = e.clientY - 110;
    if (x + w > window.innerWidth - 8) x = e.clientX - w - gap;
    if (x < 8) x = 8;
    if (y < 8) y = 8;
    if (y + h > window.innerHeight - 8) y = window.innerHeight - h - 8;
    popover.style.left = `${x}px`;
    popover.style.top = `${y}px`;
  }

  async function fetchStonePreview(stoneName) {
    const key = String(stoneName || '').trim();
    if (!key) return null;
    if (previewCache.has(key)) return previewCache.get(key);
    try {
      const res = await fetch(`/api/catalog/stone-preview?name=${encodeURIComponent(key)}`);
      if (!res.ok) return null;
      const json = await res.json();
      if (json && json.ok && json.imageUrl) {
        previewCache.set(key, json);
        return json;
      }
      previewCache.set(key, null);
    } catch (err) {
      console.warn('[HoverPreview] fallback to customer image:', err);
    }
    return null;
  }

  async function showStonePreviewWithAsyncLookup(stoneName, fallbackUrl, fallbackSub, e) {
    const token = ++activeLookupToken;
    const cached = previewCache.get(String(stoneName || '').trim());
    if (cached && cached.imageUrl) {
      const srcLabel = cached.source === 'catalog' ? ' รูปจริงจากคลัง Price_List' : ' ภาพอ้างอิงตัวอย่างลายหิน';
      showPopover(stoneName, cached.imageUrl, srcLabel, e);
      return;
    }

    if (fallbackUrl) {
      showPopover(stoneName, fallbackUrl, fallbackSub || '⏳ กำลังดึงภาพตัวอย่างลายหิน...', e);
    }

    const resolved = await fetchStonePreview(stoneName);
    if (token !== activeLookupToken || popover.classList.contains('hidden')) return;
    if (resolved && resolved.imageUrl) {
      const srcLabel = resolved.source === 'catalog' ? ' รูปจริงจากคลัง Price_List' : ' ภาพอ้างอิงตัวอย่างลายหิน';
      imgEl.src = resolved.imageUrl;
      subEl.textContent = srcLabel;
      subEl.style.display = 'block';
    } else if (fallbackUrl) {
      subEl.textContent = ' ภาพที่ลูกค้าส่งมา (ต้นทาง)';
      subEl.style.display = 'block';
    }
  }

  const triggerSelector = '#inspectAltStockText, #inspectPriceRangeText, #inspectStoneNameInput, #inspectCandidateChips button';

  document.addEventListener('mouseover', (e) => {
    const data = getInspectionData();
    if (!data) return;

    // 1a. Right side: Alternative stone in catalog (#inspectAltStockText)
    const altTarget = e.target.closest('#inspectAltStockText');
    if (altTarget) {
      const altName = data.alternativeStone || 'รุ่นใกล้เคียงในคลัง';
      if (data.alternativeImageUrl) {
        showPopover(altName, data.alternativeImageUrl, ` สต็อกร้าน • ${data.alternativePriceRange || ''}`, e);
      } else {
        showStonePreviewWithAsyncLookup(altName, data.imageUrl, data.alternativePriceRange || 'คลังร้าน Price_List', e);
      }
      return;
    }

    // 1b. Right side: Matched catalog stone price (#inspectPriceRangeText)
    const priceTarget = e.target.closest('#inspectPriceRangeText');
    if (priceTarget && data.inCatalog) {
      const matchedName = data.stoneName || 'รุ่นในคลังร้าน';
      if (data.matchedImageUrl) {
        showPopover(matchedName, data.matchedImageUrl, ` มีในคลัง • ${data.priceRange || ''}`, e);
      } else {
        showStonePreviewWithAsyncLookup(matchedName, data.imageUrl, data.priceRange || '', e);
      }
      return;
    }

    // 2. Left side: Identified stone input (#inspectStoneNameInput)
    const nameInput = e.target.closest('#inspectStoneNameInput');
    if (nameInput) {
      const targetName = (nameInput.value || data.stoneName || '').trim();
      showStonePreviewWithAsyncLookup(
        targetName || 'รูปที่ลูกค้าส่งมา',
        data.imageUrl,
        ' ภาพต้นทางที่สแกน (กำลังค้นหาตัวอย่างลาย...)',
        e
      );
      return;
    }

    // 3. Left side: Candidate chips (#inspectCandidateChips button)
    const chip = e.target.closest('#inspectCandidateChips button');
    if (chip) {
      const candName = chip.textContent.replace(/^#\d+\s*/, '').trim();
      showStonePreviewWithAsyncLookup(
        candName,
        data.imageUrl,
        ' กำลังค้นหาภาพตัวอย่างลายหิน...',
        e
      );
      return;
    }
  });

  document.addEventListener('mousemove', (e) => {
    if (!popover.classList.contains('hidden')) {
      updatePosition(e);
    }
  });

  document.addEventListener('mouseout', (e) => {
    const leftTrigger = e.target.closest(triggerSelector);
    if (!leftTrigger) return;
    const entering = e.relatedTarget && e.relatedTarget.closest(triggerSelector);
    if (entering !== leftTrigger) {
      hidePopover();
    }
  });

  function applyHoverCues(data) {
    const altEl = document.getElementById('inspectAltStockText');
    if (altEl && data?.alternativeStone) {
      altEl.classList.add('cursor-pointer', 'underline', 'decoration-dotted', 'decoration-cyan-400/60', 'hover:text-cyan-200');
      altEl.title = 'เอาเมาส์ชี้เพื่อดูรูปตัวอย่างจากคลัง Price_List';
    }
    const priceEl = document.getElementById('inspectPriceRangeText');
    if (priceEl && data?.inCatalog) {
      priceEl.classList.add('cursor-pointer', 'underline', 'decoration-dotted', 'decoration-emerald-400/60');
      priceEl.title = 'เอาเมาส์ชี้เพื่อดูรูปจริงในสต็อก';
    }
    const nameInput = document.getElementById('inspectStoneNameInput');
    if (nameInput) {
      nameInput.title = 'เอาเมาส์ชี้เพื่อดูรูปตัวอย่างลายหิน';
    }
  }

  const origRender = window.renderInspectResultCard;
  window.renderInspectResultCard = function (data) {
    window.lastInspectionData = data;
    if (typeof origRender === 'function') {
      origRender(data);
    }
    applyHoverCues(data);
  };
})();
