// gateway/public/modules/v2/flow-canvas/flow-simulator-drawer.mjs
// OmniFlow Enterprise v2 — Phase 2 Interactive Dry-Run Chat Simulator Drawer (3 Modes + Live Node Trace Highlight)

import { esc } from '../v2-api.mjs';
import { renderLucideIcon } from './flow-icons.mjs';

const QUICK_TEST_CASES = Object.freeze([
  { label: 'คำนวณพื้นที่หิน 2.5x4 = 10 ตร.ม.', text: 'สอบถามราคาหิน 2.5x4 = 10 ตร.ม. โทร 081-234-5678' },
  { label: 'ทดสอบบล็อกปูนกาว ถุง + ตร.ม.', text: 'สั่งปูนกาว 5 ถุง พื้นที่ 20 ตร.ม. ราคาเท่าไหร่' },
  { label: 'ขายส่งหินยกแผ่น 60 ตร.ม.', text: 'ขอใบเสนอราคาหิน 60 ตร.ม.' },
  { label: 'คำสั่งปลุกบอท (#บอท)', text: '#บอท ช่วยคิดราคาหิน 3x4 ม.' },
]);

export function renderSimulatorDrawer(containerEl, state, handlers = {}) {
  if (!containerEl) return;
  const lastSim = state.lastSimulation || null;
  const traceHtml = (lastSim?.traceSteps || [])
    .map((s) => {
      const badgeCls =
        s.outcome === 'ok'
          ? 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300'
          : s.outcome === 'guard_blocked'
            ? 'border-rose-500/40 bg-rose-950/40 text-rose-300'
            : 'border-amber-500/40 bg-amber-950/40 text-amber-300';
      return `<div class="p-2 rounded-lg border border-zinc-800 bg-zinc-900/70 space-y-1 text-[11px]">
        <div class="flex items-center justify-between gap-2">
          <span class="font-semibold text-zinc-100">#${esc(s.stepIndex)} ${esc(s.label)} (${esc(s.nodeType)})</span>
          <span class="px-1.5 py-0.5 rounded border text-[10px] font-mono ${badgeCls}">${esc(s.outcome)} • ${esc(s.latencyMs)}ms</span>
        </div>
        <div class="font-mono text-[10px] text-zinc-400">พอร์ตขาออก: <strong class="text-cyan-300">${esc(s.port)}</strong> ${s.guardCode ? `• Guard: <strong class="text-rose-300">${esc(s.guardCode)}</strong>` : ''}</div>
      </div>`;
    })
    .join('');

  const repliesHtml = (lastSim?.replies || [])
    .map(
      (r) =>
        `<div class="p-2.5 rounded-lg border border-cyan-500/40 bg-cyan-950/25 text-cyan-100 text-xs">${esc(r)}</div>`
    )
    .join('');

  const quickBtns = QUICK_TEST_CASES.map(
    (c) =>
      `<button type="button" data-sim-preset="${esc(c.text)}" class="px-2 py-1 rounded-lg border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 text-[11px] text-zinc-200 text-left">${esc(c.label)}</button>`
  ).join('');

  containerEl.innerHTML = `
    <div class="space-y-3 text-xs">
      <div class="flex items-center justify-between gap-2 border-b border-zinc-800 pb-2">
        <div class="flex items-center gap-2 font-semibold text-zinc-100">
          <span class="text-emerald-400">${renderLucideIcon('play', 'w-4 h-4')}</span>
          <span>จำลองการสนทนา (Sandbox Dry-Run)</span>
        </div>
        <span class="text-[10px] font-mono text-zinc-400">ไม่กวนแชตลูกค้าจริง</span>
      </div>
      <div class="space-y-1.5">
        <div class="text-[11px] text-zinc-400">ข้อความทดสอบด่วน (คลิกเพื่อกรอก):</div>
        <div class="flex flex-wrap gap-1.5">${quickBtns}</div>
      </div>
      <form id="v2FlowSimForm" class="space-y-2.5">
        <div>
          <label class="block text-zinc-300 font-medium mb-1">ข้อความจำลองจากลูกค้า</label>
          <input id="v2SimTextInput" name="mockText" required value="${esc(state.simDraftText || 'สอบถามราคาหิน 2.5x4 = 10 ตร.ม. โทร 081-234-5678')}" class="w-full px-2.5 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100" />
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="block text-zinc-400 text-[11px] mb-1">ผลจำลอง Vision Cosine</label>
            <input name="mockImageCosine" type="number" step="0.01" min="0" max="1" value="${esc(state.simCosine ?? 0.86)}" class="w-full px-2 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" />
          </div>
          <div class="flex items-end pb-1">
            <label class="flex items-center gap-1.5 text-zinc-300 cursor-pointer">
              <input type="checkbox" name="adminTakeover" ${state.simAdminTakeover ? 'checked' : ''} />
              <span>จำลองแอดมินแทรกอยู่</span>
            </label>
          </div>
        </div>
        <button type="submit" class="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-emerald-400 text-zinc-950 hover:bg-emerald-300 font-semibold">
          ${renderLucideIcon('play', 'w-3.5 h-3.5')}<span>รันทดสอบกราฟ (Dry-Run)</span>
        </button>
      </form>
      ${
        lastSim
          ? `<div class="space-y-2 pt-2 border-t border-zinc-800">
              <div class="text-[11px] font-mono text-zinc-400">PDPA Masked Input: <span class="text-zinc-200">${esc(lastSim.maskedInputPreview || '-')}</span></div>
              ${lastSim.haltedByTakeover ? '<div class="p-2 rounded-lg border border-amber-500/40 bg-amber-950/30 text-amber-200">บอทหยุดทำงานชั่วคราวเนื่องจากแอดมินดูแลอยู่ (พิมพ์ #บอท เพื่อปลุก)</div>' : ''}
              ${repliesHtml}
              <div class="space-y-1.5">${traceHtml}</div>
            </div>`
          : ''
      }
    </div>`;

  const inputEl = containerEl.querySelector('#v2SimTextInput');
  containerEl.querySelectorAll('[data-sim-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (inputEl) inputEl.value = btn.dataset.simPreset || '';
    });
  });

  containerEl.querySelector('#v2FlowSimForm')?.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    handlers.onRunSimulate?.({
      text: String(fd.get('mockText') || ''),
      mockImageCosine: Number(fd.get('mockImageCosine') || 0.86),
      adminTakeover: Boolean(fd.get('adminTakeover')),
    });
  });
}
