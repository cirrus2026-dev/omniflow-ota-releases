// gateway/public/modules/v2/flow-canvas/flow-icons.mjs
// OmniFlow Enterprise v2 — Pure Lucide Inline SVG Icon & Node Catalog Helper (Zero Emoji Policy)

import { lucideIcon, refreshLucideIcons } from '../v2-icons.mjs';

const INLINE_SVG_PATHS = Object.freeze({
  workflow: '<rect width="8" height="8" x="3" y="3" rx="2"/><path d="M7 11v4a2 2 0 0 0 2 2h4"/><rect width="8" height="8" x="13" y="13" rx="2"/>',
  'message-square': '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  'git-branch': '<line x1="6" x2="6" y1="3" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/>',
  'scan-text': '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><path d="M7 8h8"/><path d="M7 12h10"/><path d="M7 16h6"/>',
  'scan-eye': '<path d="M3 7V5a2 2 0 0 1 2-2h2"/><path d="M17 3h2a2 2 0 0 1 2 2v2"/><path d="M21 17v2a2 2 0 0 1-2 2h-2"/><path d="M7 21H5a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="12" r="1"/><path d="M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0"/>',
  calculator: '<rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/>',
  send: '<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
  cpu: '<rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2"/><path d="M15 20v2"/><path d="M2 15h2"/><path d="M2 9h2"/><path d="M20 15h2"/><path d="M20 9h2"/><path d="M9 2v2"/><path d="M9 20v2"/>',
  webhook: '<path d="M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2"/><path d="m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06"/><path d="m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8"/>',
  'user-check': '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>',
  'shield-check': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  play: '<polygon points="6 3 20 12 6 21 6 3"/>',
  history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  flame: '<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
  'alert-triangle': '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
});

export function renderLucideIcon(name, className = 'w-4 h-4 shrink-0') {
  const key = String(name || 'workflow').trim();
  const paths = INLINE_SVG_PATHS[key];
  if (paths) {
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-${key} ${className}" aria-hidden="true">${paths}</svg>`;
  }
  return lucideIcon(key, className);
}

export { refreshLucideIcons };

export const NODE_CATALOG = Object.freeze([
  { type: 'trigger_inbound', icon: 'message-square', label: 'Trigger Inbound', ports: ['out'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
  { type: 'condition_router', icon: 'git-branch', label: 'Condition Router (Thai Regex)', ports: ['quote', 'image', 'default'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
  { type: 'slot_extractor_ai', icon: 'scan-text', label: 'AI Slot Extractor', ports: ['out', 'missing_slot_prompt'], modes: ['smart_agent', 'hybrid_rules'] },
  { type: 'vision_match', icon: 'scan-eye', label: 'Dual-Engine Vision (>=0.82)', ports: ['matched', 'uncertain'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
  { type: 'hardguard_math_quote', icon: 'calculator', label: 'HardGuard Math Quote', ports: ['out', 'guard_blocked', 'missing_slot_prompt'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
  { type: 'template_reply', icon: 'send', label: 'Template Reply', ports: ['out'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
  { type: 'agent_brain', icon: 'cpu', label: 'Smart Agent Brain (<=4 hops)', ports: ['out', 'guard_blocked'], modes: ['smart_agent'] },
  { type: 'http_webhook', icon: 'webhook', label: 'Safe HTTP Webhook (fetchSafe)', ports: ['out', 'error'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
  { type: 'human_handoff', icon: 'user-check', label: 'Human Admin Handoff', ports: ['out'], modes: ['smart_agent', 'hybrid_rules', 'strict_guard'] },
]);

export function getNodeCatalogMeta(type) {
  return NODE_CATALOG.find((n) => n.type === type) || NODE_CATALOG[0];
}
