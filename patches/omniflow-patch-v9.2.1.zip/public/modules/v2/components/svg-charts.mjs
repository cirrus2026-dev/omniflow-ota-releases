// gateway/public/modules/v2/components/svg-charts.mjs
// Pure SVG Chart Components (Zero External Chart Libraries)

import { esc } from '../v2-api.mjs';

export function renderBarChart12M(series = []) {
  const maxVal = Math.max(1, ...series.map((s) => Math.max(s.revenueBaht || 0, s.chats || 0)));
  const width = 620;
  const height = 180;
  const barW = Math.floor((width - 40) / Math.max(1, series.length));

  const bars = series
    .map((item, idx) => {
      const val = item.revenueBaht || item.chats || 0;
      const barH = Math.max(4, Math.round((val / maxVal) * 130));
      const x = 24 + idx * barW;
      const y = 148 - barH;
      const label = String(item.month || '').slice(5);
      return `
        <g>
          <rect x="${x}" y="${y}" width="${Math.max(8, barW - 10)}" height="${barH}" rx="4"
            fill="url(#v2BarGrad)" opacity="0.9">
            <title>${esc(item.month)}: ฿${esc(item.revenueBaht)} (${esc(item.chats)} แชท)</title>
          </rect>
          <text x="${x + Math.max(4, (barW - 10) / 2)}" y="166" text-anchor="middle" fill="#94a3b8" font-size="10">${esc(label)}</text>
        </g>`;
    })
    .join('');

  return `
    <svg viewBox="0 0 ${width} ${height}" class="w-full h-48 overflow-visible">
      <defs>
        <linearGradient id="v2BarGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#00f0ff" />
          <stop offset="100%" stop-color="#0284c7" />
        </linearGradient>
      </defs>
      <line x1="20" y1="148" x2="${width - 10}" y2="148" stroke="rgba(148,163,184,0.25)" />
      ${bars}
    </svg>`;
}

export function renderTrendChart7D(dailyRows = []) {
  if (!dailyRows.length) {
    return '<div class="h-44 flex items-center justify-center text-xs text-slate-400">ยังไม่มีข้อมูลแชทย้อนหลัง 7 วัน</div>';
  }
  const byDay = new Map();
  for (const r of dailyRows) {
    byDay.set(r.day, (byDay.get(r.day) || 0) + Number(r.chats || 0));
  }
  const points = Array.from(byDay.entries()).slice(-7);
  const maxY = Math.max(1, ...points.map((p) => p[1]));
  const width = 420;
  const stepX = points.length > 1 ? Math.floor((width - 50) / (points.length - 1)) : 0;

  const coords = points.map(([, val], idx) => {
    const x = 25 + idx * stepX;
    const y = 140 - Math.round((val / maxY) * 110);
    return { x, y, val };
  });
  const polyline = coords.map((c) => `${c.x},${c.y}`).join(' ');

  return `
    <svg viewBox="0 0 ${width} 170" class="w-full h-48 overflow-visible">
      <polyline fill="none" stroke="#38bdf8" stroke-width="3" points="${polyline}" />
      ${coords
        .map((c, i) => `
          <circle cx="${c.x}" cy="${c.y}" r="4.5" fill="#00f0ff">
            <title>${esc(points[i][0])}: ${esc(c.val)} แชท</title>
          </circle>
          <text x="${c.x}" y="160" text-anchor="middle" fill="#94a3b8" font-size="9">${esc(points[i][0].slice(5))}</text>
        `)
        .join('')}
    </svg>`;
}
