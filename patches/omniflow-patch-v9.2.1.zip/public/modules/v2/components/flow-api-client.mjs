// gateway/public/modules/v2/flow-canvas/flow-api-client.mjs
// OmniFlow Enterprise v2 — Phase 2 Flow Builder API Client Wrapper

import { v2FetchJson } from '../v2-api.mjs';

export function createFlowApiClient(fetchJson = v2FetchJson) {
  return {
    listFlows(workspaceId = '') {
      const q = workspaceId ? `?workspaceId=${encodeURIComponent(workspaceId)}` : '';
      return fetchJson(`/api/v2/flows${q}`);
    },
    getFlowDetail(flowId = '') {
      const q = flowId ? `?id=${encodeURIComponent(flowId)}` : '';
      return fetchJson(`/api/v2/flows/detail${q}`);
    },
    createFlow(payload) {
      return fetchJson('/api/v2/flows', { method: 'POST', body: payload });
    },
    saveDraft(payload) {
      return fetchJson('/api/v2/flows/draft', { method: 'PUT', body: payload });
    },
    publishFlow(payload) {
      return fetchJson('/api/v2/flows/publish', { method: 'POST', body: payload });
    },
    rollbackFlow(payload) {
      return fetchJson('/api/v2/flows/rollback', { method: 'POST', body: payload });
    },
    simulateFlow(payload) {
      return fetchJson('/api/v2/flows/simulate', { method: 'POST', body: payload });
    },
    getTelemetry({ flowId, versionId = '', windowHours = 24 } = {}) {
      const params = new URLSearchParams({ flowId: String(flowId || ''), windowHours: String(windowHours) });
      if (versionId) params.set('versionId', String(versionId));
      return fetchJson(`/api/v2/flows/telemetry?${params.toString()}`);
    },
    listFeedback({ flowId = '', status = '' } = {}) {
      const params = new URLSearchParams();
      if (flowId) params.set('flowId', String(flowId));
      if (status) params.set('status', String(status));
      const qs = params.toString();
      return fetchJson(`/api/v2/flows/feedback${qs ? `?${qs}` : ''}`);
    },
    resolveFeedback(payload) {
      return fetchJson('/api/v2/flows/feedback/resolve', { method: 'POST', body: payload });
    },
  };
}
