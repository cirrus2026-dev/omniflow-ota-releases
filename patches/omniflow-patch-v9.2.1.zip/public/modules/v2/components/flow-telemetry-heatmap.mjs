// gateway/public/modules/v2/flow-canvas/flow-telemetry-heatmap.mjs
// OmniFlow Enterprise v2 — Phase 2 Node Telemetry Heatmap Badges & Feedback Loop Panel

import { esc } from '../v2-api.mjs';
import { renderLucideIcon } from './flow-icons.mjs';

export function renderNodeHeatmapBadge(nodeStat) {
  if (!nodeStat || !nodeStat.totalHits) {
    return `<div class="mt-1.5 inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-zinc-900 text-[10px] font-mono text-zinc-500">${renderLucideIcon('flame', 'w-3 h-3')}<span>0 hits</span></div>`;
  }
  const hasGuards = Number(nodeStat.guardBlockedCount || 0) > 0;
  const cls = hasGuards
    ? 'border-rose-500/40 bg-rose-950/50 text-rose-200'
    : 'border-cyan-500/40 bg-cyan-950/40 text-cyan-200';
  const guardPct = Math.round(Number(nodeStat.guardRate || 0) * 100);
  return `
    <div class="mt-1.5 flex items-center justify-between gap-1 px-1.5 py-0.5 rounded border text-[10px] font-mono ${cls}">
      <span class="inline-flex items-center gap-1">${renderLucideIcon('flame', 'w-3 h-3')}<span>${esc(nodeStat.totalHits)} hits • ${esc(nodeStat.avgLatencyMs)}ms</span></span>
      ${hasGuards ? `<span>Guard ${esc(guardPct)}%</span>` : ''}
    </div>`;
}

export function renderTelemetryAndFeedbackPanel(containerEl, state, handlers = {}) {
  if (!containerEl) return;
  const hm = state.heatmap || { totalSteps: 0, avgLatencyMs: 0, guardTrips: 0, handoffRate: 0, nodeStats: [] };
  const items = state.feedbackItems || [];

  const rowsHtml = items
    .map((item) => {
      const isOpen = item.resolution_status === 'open';
      return `<div class="p-2.5 rounded-lg border border-zinc-800 bg-zinc-900/60 space-y-1.5 text-[11px]">
        <div class="flex items-center justify-between gap-2">
          <span class="font-semibold text-zinc-100">โหนด: ${esc(item.drop_node_id)} • ${esc(item.trigger_reason)}</span>
          <span class="px-1.5 py-0.5 rounded text-[10px] font-mono ${isOpen ? 'bg-amber-950/60 text-amber-300 border border-amber-500/40' : 'bg-emerald-950/50 text-emerald-300 border border-emerald-500/40'}">${esc(item.resolution_status)}</span>
        </div>
        ${item.admin_note ? `<div class="text-zinc-400 font-mono text-[10px]">หมายเหตุ: ${esc(item.admin_note)}</div>` : ''}
        ${
          isOpen
            ? `<button type="button" data-resolve-fb="${esc(item.id)}" class="inline-flex items-center gap-1 px-2 py-1 rounded bg-zinc-100 text-zinc-950 hover:bg-white font-semibold text-[10px]">
                ${renderLucideIcon('shield-check', 'w-3 h-3')}<span>ทำเครื่องหมายว่าแก้ไขแล้ว</span>
              </button>`
            : ''
        }
      </div>`;
    })
    .join('');

  containerEl.innerHTML = `
    <div class="space-y-3 text-xs">
      <div class="flex items-center justify-between gap-2 border-b border-zinc-800 pb-2">
        <div class="flex items-center gap-2 font-semibold text-zinc-100">
          <span class="text-amber-400">${renderLucideIcon('flame', 'w-4 h-4')}</span>
          <span>สถิติ Heatmap &amp; Feedback Loop (24 ชม.)</span>
        </div>
        <button type="button" data-act="refresh-telemetry" class="px-2 py-1 rounded border border-zinc-700 text-zinc-200 hover:bg-zinc-800 text-[11px]">รีเฟรช</button>
      </div>
      <div class="grid grid-cols-3 gap-2 text-center font-mono">
        <div class="p-2 rounded-lg border border-zinc-800 bg-zinc-900/50">
          <div class="text-[10px] text-zinc-400">Steps รวม</div>
          <div class="text-sm font-bold text-cyan-300">${esc(hm.totalSteps ?? 0)}</div>
        </div>
        <div class="p-2 rounded-lg border border-zinc-800 bg-zinc-900/50">
          <div class="text-[10px] text-zinc-400">ความหน่วงเฉลี่ย</div>
          <div class="text-sm font-bold text-emerald-300">${esc(hm.avgLatencyMs ?? 0)}ms</div>
        </div>
        <div class="p-2 rounded-lg border border-zinc-800 bg-zinc-900/50">
          <div class="text-[10px] text-zinc-400">ติด Guardrail</div>
          <div class="text-sm font-bold text-rose-300">${esc(hm.guardTrips ?? 0)}</div>
        </div>
      </div>
      <div class="space-y-1.5">
        <div class="font-semibold text-zinc-200">รายการ Feedback Loop (${items.length})</div>
        ${rowsHtml || '<div class="text-zinc-500 text-[11px]">ยังไม่มีรายการติด Guardrail หรือ Admin Takeover ที่รอแก้ไข</div>'}
      </div>
    </div>`;

  containerEl.querySelector('[data-act="refresh-telemetry"]')?.addEventListener('click', () => {
    handlers.onRefreshTelemetry?.();
  });
  containerEl.querySelectorAll('[data-resolve-fb]').forEach((btn) => {
    btn.addEventListener('click', () => handlers.onResolveFeedback?.(btn.dataset.resolveFb));
  });
}
