// gateway/public/modules/v2/components/shift-handover-modal.mjs
// Category 2: Shift Handover Modal (mounted on document.body to avoid stacking traps)

import { esc, v2FetchJson } from '../v2-api.mjs';

export async function openShiftHandoverModal(_options = {}, _api = null) {
  document.getElementById('v2ShiftHandoverBackdrop')?.remove();

  const backdrop = document.createElement('div');
  backdrop.id = 'v2ShiftHandoverBackdrop';
  backdrop.className = 'v2-modal-backdrop';
  backdrop.innerHTML = `
    <div class="v2-modal">
      <div class="flex items-center justify-between mb-4">
        <div>
          <span class="v2-badge v2-badge--ready">Shift Handover</span>
          <h3 class="text-base font-bold text-white mt-1.5">บันทึกส่งมอบกะงานอัตโนมัติ</h3>
        </div>
        <button id="v2ShiftCloseBtn" type="button" class="v2-btn text-xs">ปิด</button>
      </div>
      <form id="v2ShiftForm" class="space-y-3 text-xs">
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="block text-slate-300 mb-1">จากกะ (From)</label>
            <select name="fromShift" class="w-full px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white">
              <option value="morning">กะเช้า (08:00-20:00)</option>
              <option value="night">กะดึก (20:00-08:00)</option>
            </select>
          </div>
          <div>
            <label class="block text-slate-300 mb-1">ส่งต่อให้กะ (To)</label>
            <select name="toShift" class="w-full px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white">
              <option value="night">กะดึก (20:00-08:00)</option>
              <option value="morning">กะเช้า (08:00-20:00)</option>
            </select>
          </div>
        </div>
        <div>
          <label class="block text-slate-300 mb-1">โน้ตฝากกะถัดไป (Pinned Notes)</label>
          <textarea name="pinnedNotes" rows="3" placeholder="เช่น ลูกค้าห้องคุณสมชายรอเช็กสลิปมัดจำตอน 21:00 น."
            class="w-full px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white"></textarea>
        </div>
        <div id="v2ShiftStatus" class="hidden v2-subcard text-xs"></div>
        <div class="flex justify-end gap-2 pt-2">
          <button type="button" id="v2ShiftCancelBtn" class="v2-btn">ยกเลิก</button>
          <button type="submit" class="v2-btn v2-btn--primary"><i data-lucide="check-circle-2" class="w-4 h-4 shrink-0"></i><span>ยืนยันส่งมอบกะ</span></button>
        </div>
      </form>
    </div>
  `;

  document.body.appendChild(backdrop);
  if (window.lucide) window.lucide.createIcons();
  const close = () => backdrop.remove();
  backdrop.querySelector('#v2ShiftCloseBtn')?.addEventListener('click', close);
  backdrop.querySelector('#v2ShiftCancelBtn')?.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) close();
  });

  const form = backdrop.querySelector('#v2ShiftForm');
  const statusEl = backdrop.querySelector('#v2ShiftStatus');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    const fromShift = String(fd.get('fromShift') || 'morning');
    const toShift = String(fd.get('toShift') || 'night');
    const pinnedNotes = String(fd.get('pinnedNotes') || '').trim();
    try {
      const res = await v2FetchJson('/api/v2/shifts/handover', {
        method: 'POST',
        body: { fromShift, toShift, pinnedNotes },
      });
      statusEl.className = 'v2-subcard text-emerald-300';
      statusEl.textContent = `ส่งมอบกะสำเร็จ! แชทค้าง ${esc(res.handover?.open_chats_count ?? 0)} ห้อง`;
      statusEl.classList.remove('hidden');
      window.dispatchEvent(new CustomEvent('omniflow:v2:shift-handover-saved', { detail: res.handover }));
      setTimeout(close, 900);
    } catch (err) {
      statusEl.className = 'v2-subcard text-rose-300';
      statusEl.textContent = err.message;
      statusEl.classList.remove('hidden');
    }
  });
}

export default openShiftHandoverModal;
