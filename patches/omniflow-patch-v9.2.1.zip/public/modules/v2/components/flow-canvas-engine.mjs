// gateway/public/modules/v2/flow-canvas/flow-canvas-engine.mjs
// OmniFlow Enterprise v2 — Hybrid DOM + SVG Cubic Bezier Flow Canvas & 60fps Zoom Slider (AP-22 Guarded)

import { esc } from '../v2-api.mjs';
import { getNodeCatalogMeta, renderLucideIcon } from './flow-icons.mjs';
import { renderNodeHeatmapBadge } from './flow-telemetry-heatmap.mjs';

export const CANVAS_VP_STORAGE_KEY = 'omniflow_v2_canvas_vp';
const NODE_WIDTH = 220;
const NODE_HEIGHT = 86;

export function applyCanvasViewportTransform(stageEl, viewport = { x: 0, y: 0, zoom: 1 }) {
  if (!stageEl) return;
  const x = Number(viewport.x || 0);
  const y = Number(viewport.y || 0);
  const z = Math.max(0.5, Math.min(1.5, Number(viewport.zoom || 1)));
  stageEl.style.transform = `translate(${x}px, ${y}px) scale(${z})`;
  stageEl.style.transformOrigin = '0 0';
}

/**
 * Bind zoom slider events following Anti-Pattern AP-22:
 * - 'input': updates ONLY CSS transform at 60fps (ZERO localStorage writes)
 * - 'change': saves viewport state to localStorage once on release
 */
export function bindCanvasZoomSlider(sliderEl, stageEl, viewportState, storage = globalThis.localStorage) {
  if (!sliderEl) return;
  sliderEl.addEventListener('input', (ev) => {
    const pct = Number(ev.target.value || 100);
    viewportState.zoom = Number((pct / 100).toFixed(2));
    applyCanvasViewportTransform(stageEl, viewportState);
  });
  sliderEl.addEventListener('change', (ev) => {
    const pct = Number(ev.target.value || 100);
    viewportState.zoom = Number((pct / 100).toFixed(2));
    applyCanvasViewportTransform(stageEl, viewportState);
    try {
      storage?.setItem(CANVAS_VP_STORAGE_KEY, JSON.stringify(viewportState));
    } catch {
      // Ignore storage quota or restricted context
    }
  });
}

export function computeCubicBezierPath(sx, sy, tx, ty) {
  const dx = Math.max(50, Math.abs(tx - sx) * 0.5);
  return `M ${sx} ${sy} C ${sx + dx} ${sy}, ${tx - dx} ${ty}, ${tx} ${ty}`;
}

function buildEdgesSvgHtml(graph, nodeMap, activeTraceNodeIds = new Set()) {
  const paths = (graph.edges || [])
    .map((ed) => {
      const src = nodeMap.get(ed.source);
      const tgt = nodeMap.get(ed.target);
      if (!src || !tgt) return '';
      const sx = Number(src.position?.x || 0) + NODE_WIDTH;
      const sy = Number(src.position?.y || 0) + NODE_HEIGHT / 2;
      const tx = Number(tgt.position?.x || 0);
      const ty = Number(tgt.position?.y || 0) + NODE_HEIGHT / 2;
      const d = computeCubicBezierPath(sx, sy, tx, ty);
      const active = activeTraceNodeIds.has(ed.source) && activeTraceNodeIds.has(ed.target);
      const stroke = active ? '#22d3ee' : '#52525b';
      const width = active ? '2.5' : '1.75';
      const labelX = Math.round((sx + tx) / 2);
      const labelY = Math.round((sy + ty) / 2) - 6;
      const portLabel = ed.sourcePort && ed.sourcePort !== 'out' ? `<text x="${labelX}" y="${labelY}" fill="#a1a1aa" font-size="10" text-anchor="middle">${esc(ed.sourcePort)}</text>` : '';
      return `<g data-edge-id="${esc(ed.id)}"><path d="${d}" fill="none" stroke="${stroke}" stroke-width="${width}" marker-end="url(#v2FlowArrow)" />${portLabel}</g>`;
    })
    .join('');

  return `<svg class="v2-flow-edges-layer absolute inset-0 w-full h-full pointer-events-none" width="1600" height="900" viewBox="0 0 1600 900">
    <defs>
      <marker id="v2FlowArrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
        <path d="M 0 1 L 8 5 L 0 9 z" fill="#22d3ee" />
      </marker>
    </defs>
    ${paths}
  </svg>`;
}

export function renderFlowCanvasStage(containerEl, state, handlers = {}) {
  if (!containerEl) return;
  const graph = state.draftGraph || { nodes: [], edges: [], viewport: { x: 20, y: 20, zoom: 1 } };
  const nodeMap = new Map((graph.nodes || []).map((n) => [n.id, n]));
  const activeSet = new Set(state.highlightedNodeIds || []);
  const statMap = new Map(((state.heatmap?.nodeStats) || []).map((s) => [s.nodeId, s]));

  const nodesHtml = (graph.nodes || [])
    .map((node) => {
      const meta = getNodeCatalogMeta(node.type);
      const isSelected = state.selectedNodeId === node.id;
      const isTraced = activeSet.has(node.id);
      const x = Number(node.position?.x || 40);
      const y = Number(node.position?.y || 40);
      const borderCls = isTraced
        ? 'border-cyan-400 ring-2 ring-cyan-400/40 bg-zinc-900'
        : isSelected
          ? 'border-emerald-400 bg-zinc-900'
          : 'border-zinc-700 bg-zinc-950/95 hover:border-zinc-500';
      const ports = (meta.ports || ['out'])
        .map(
          (p) =>
            `<button type="button" data-connect-from="${esc(node.id)}" data-connect-port="${esc(p)}" title="ลากเชื่อมจากพอร์ต ${esc(p)}" class="px-1.5 py-0.5 rounded bg-zinc-800 hover:bg-cyan-950 text-[10px] font-mono text-cyan-300 border border-zinc-700">${esc(p)}</button>`
        )
        .join('');
      const heatBadge = state.showHeatmap ? renderNodeHeatmapBadge(statMap.get(node.id)) : '';

      return `<article data-flow-node="${esc(node.id)}" style="left:${x}px;top:${y}px;width:${NODE_WIDTH}px"
        class="v2-flow-node absolute rounded-xl border ${borderCls} p-2.5 shadow-xl cursor-pointer select-none transition">
        <div class="flex items-center justify-between gap-1.5">
          <span class="inline-flex items-center gap-1.5 text-xs font-semibold text-zinc-100 truncate">
            <span class="text-cyan-400">${renderLucideIcon(node.icon || meta.icon, 'w-3.5 h-3.5')}</span>
            <span class="truncate">${esc(node.label || meta.label)}</span>
          </span>
          <span class="text-[10px] font-mono text-zinc-500">${esc(node.id)}</span>
        </div>
        <div class="text-[10px] font-mono text-zinc-400 mt-1 truncate">${esc(node.type)}</div>
        ${heatBadge}
        <div class="flex flex-wrap items-center justify-between gap-1 mt-2 pt-1.5 border-t border-zinc-800/80">
          <button type="button" data-connect-to="${esc(node.id)}" class="px-1.5 py-0.5 rounded bg-zinc-900 hover:bg-emerald-950 text-[10px] font-mono text-emerald-300 border border-zinc-800">in</button>
          <div class="flex flex-wrap gap-1">${ports}</div>
        </div>
      </article>`;
    })
    .join('');

  containerEl.innerHTML = `
    <div id="v2FlowCanvasStage" class="relative w-[1600px] h-[900px]">
      ${buildEdgesSvgHtml(graph, nodeMap, activeSet)}
      <div class="v2-flow-nodes-layer relative w-full h-full">${nodesHtml}</div>
    </div>`;

  const stageEl = containerEl.querySelector('#v2FlowCanvasStage');
  applyCanvasViewportTransform(stageEl, graph.viewport || { x: 20, y: 20, zoom: 1 });

  let dragNodeId = null;
  let startX = 0;
  let startY = 0;
  let origX = 0;
  let origY = 0;

  containerEl.querySelectorAll('[data-flow-node]').forEach((card) => {
    card.addEventListener('mousedown', (ev) => {
      if (ev.target.closest('button')) return;
      dragNodeId = card.dataset.flowNode;
      const node = nodeMap.get(dragNodeId);
      if (!node) return;
      startX = ev.clientX;
      startY = ev.clientY;
      origX = Number(node.position?.x || 0);
      origY = Number(node.position?.y || 0);
      handlers.onSelectNode?.(dragNodeId);
    });
  });

  const onMove = (ev) => {
    if (!dragNodeId) return;
    const node = nodeMap.get(dragNodeId);
    if (!node) return;
    const z = Number(graph.viewport?.zoom || 1) || 1;
    node.position = {
      x: Math.max(10, Math.round(origX + (ev.clientX - startX) / z)),
      y: Math.max(10, Math.round(origY + (ev.clientY - startY) / z)),
    };
    const card = containerEl.querySelector(`[data-flow-node="${dragNodeId}"]`);
    if (card) {
      card.style.left = `${node.position.x}px`;
      card.style.top = `${node.position.y}px`;
    }
  };

  const onUp = () => {
    if (!dragNodeId) return;
    dragNodeId = null;
    window.removeEventListener('mousemove', onMove);
    window.removeEventListener('mouseup', onUp);
    handlers.onGraphMoved?.();
  };

  containerEl.addEventListener('mousedown', (ev) => {
    if (ev.target.closest('[data-flow-node]') && !ev.target.closest('button')) {
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    }
  });
}
