// gateway/public/modules/v2/flow-canvas/flow-node-inspector.mjs
// OmniFlow Enterprise v2 — Right-Hand Node Inspector (Thai Regex \b Guard, HardGuard Config & AP-23 Safe Data Image)

import { esc } from '../v2-api.mjs';
import { getNodeCatalogMeta, renderLucideIcon } from './flow-icons.mjs';

export const SAFE_DATA_IMG_RE = /^data:image\/(?:png|jpeg|jpg|webp|gif);base64,[A-Za-z0-9+/=]+$/i;
export const THAI_WORD_BOUNDARY_HAZARD_RE = /\\b[^\n]*[\u0E00-\u0E7F]|[\u0E00-\u0E7F][^\n]*\\b/;

export function isSafeCanvasImageUrl(rawUrl) {
  const val = String(rawUrl ?? '').trim();
  if (!val) return true;
  if (val.length > 2_000_000) return false;
  if (SAFE_DATA_IMG_RE.test(val)) return true;
  if (val.startsWith('/') && !val.startsWith('//')) return true;
  try {
    const u = new URL(val);
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

export function validateThaiRegexPattern(pattern = '') {
  const raw = String(pattern ?? '');
  if (!raw) return { ok: true, error: '' };
  if (THAI_WORD_BOUNDARY_HAZARD_RE.test(raw)) {
    return { ok: false, error: 'ห้ามใช้ \\b คู่กับอักษรไทย (AP-16) เพราะภาษาไทยไม่มีเว้นวรรคคำ' };
  }
  try {
    new RegExp(raw, 'u');
    return { ok: true, error: '' };
  } catch (err) {
    return { ok: false, error: `รูปแบบ Regex ไม่ถูกต้อง: ${err.message}` };
  }
}

function buildTypeSpecificFields(node) {
  const cfg = node.config || {};
  if (node.type === 'condition_router') {
    const firstRule = (cfg.rules && cfg.rules[0]) || { port: 'quote', matchType: 'regex_th', pattern: '(?:ราคา|ตร\\.?ม)' };
    const check = validateThaiRegexPattern(firstRule.pattern);
    return `
      <div class="space-y-2">
        <label class="block text-zinc-300 font-medium">พอร์ตขาออกเมื่อตรงเงื่อนไข</label>
        <input name="rulePort" value="${esc(firstRule.port || 'quote')}" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" />
        <label class="block text-zinc-300 font-medium">Thai-Safe Regex Pattern (ห้ามใช้ \\b กับภาษาไทย)</label>
        <input name="rulePattern" value="${esc(firstRule.pattern || '')}" class="w-full px-2.5 py-1.5 rounded-lg border ${check.ok ? 'border-zinc-800' : 'border-rose-500'} bg-zinc-950 text-zinc-100 font-mono" />
        ${check.ok ? '<div class="text-[11px] text-emerald-400">ผ่านการตรวจ Thai Regex Guard (AP-16)</div>' : `<div class="text-[11px] text-rose-300">${esc(check.error)}</div>`}
      </div>`;
  }

  if (node.type === 'hardguard_math_quote') {
    return `
      <div class="grid grid-cols-2 gap-2">
        <div><label class="block text-zinc-400 mb-1">ราคาแผ่นใหญ่ (Slab)</label><input name="slabPrice" type="number" value="${esc(cfg.slabPrice ?? 1200)}" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
        <div><label class="block text-zinc-400 mb-1">ราคาตัด (Cut)</label><input name="cutPrice" type="number" value="${esc(cfg.cutPrice ?? 1350)}" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
        <div><label class="block text-zinc-400 mb-1">เกณฑ์ขายส่ง (ตร.ม.)</label><input name="wholesaleMinSqm" type="number" value="${esc(cfg.wholesaleMinSqm ?? 50)}" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
      </div>
      <label class="flex items-center gap-2 text-zinc-200 mt-1"><input type="checkbox" name="requireUnitCheck" ${cfg.requireUnitCheck !== false ? 'checked' : ''} /><span>บล็อกการคูณหน่วย ถุง ข้ามกับ ตร.ม. (AP-20)</span></label>
      <label class="flex items-center gap-2 text-zinc-200"><input type="checkbox" name="enforceCutBelowSlab" ${cfg.enforceCutBelowSlab !== false ? 'checked' : ''} /><span>ป้องกันราคาตัดสูงกว่าราคายกแผ่นเมื่อ >=50 ตร.ม. (AP-19)</span></label>`;
  }

  if (node.type === 'vision_match') {
    return `
      <div>
        <label class="block text-zinc-300 font-medium mb-1">เกณฑ์ความเหมือนขั้นต่ำ (Cosine >= 0.82)</label>
        <input name="minCosine" type="number" step="0.01" min="0.5" max="0.99" value="${esc(cfg.minCosine ?? 0.82)}" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" />
      </div>`;
  }

  if (node.type === 'template_reply') {
    const imgUrl = String(cfg.previewImageUrl || '');
    const safeImg = isSafeCanvasImageUrl(imgUrl);
    return `
      <div class="space-y-2">
        <label class="block text-zinc-300 font-medium">ข้อความตอบกลับ (รองรับ {{net_area_sqm}}, {{total_price_formatted}})</label>
        <textarea name="template" rows="3" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100">${esc(cfg.template || '')}</textarea>
        <label class="block text-zinc-300 font-medium">รูปภาพประกอบ (HTTPS หรือ data:image/...;base64,...)</label>
        <input name="previewImageUrl" value="${esc(imgUrl)}" placeholder="data:image/png;base64,..." class="w-full px-2.5 py-1.5 rounded-lg border ${safeImg ? 'border-zinc-800' : 'border-rose-500'} bg-zinc-950 text-zinc-100 font-mono text-[11px]" />
        ${imgUrl && safeImg ? `<img src="${esc(imgUrl)}" alt="Preview" class="h-12 w-auto rounded border border-zinc-700 bg-white/95 p-1 object-contain" />` : ''}
        ${!safeImg ? '<div class="text-[11px] text-rose-300">บล็อก URL รูปภาพที่ไม่ปลอดภัย (AP-23)</div>' : ''}
      </div>`;
  }

  if (node.type === 'http_webhook') {
    return `
      <div>
        <label class="block text-zinc-300 font-medium mb-1">Webhook URL (ผ่าน fetchSafe SSRF Guard)</label>
        <input name="url" value="${esc(cfg.url || '')}" placeholder="https://api.example.com/hook" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" />
      </div>`;
  }

  return `<div class="text-zinc-400">โหนดนี้ทำงานตามกฎความปลอดภัยมาตรฐานของโหมดที่เลือก</div>`;
}

export function renderNodeInspector(containerEl, state, handlers = {}) {
  if (!containerEl) return;
  const graph = state.draftGraph || { nodes: [], edges: [] };
  const node = (graph.nodes || []).find((n) => n.id === state.selectedNodeId) || graph.nodes?.[0];
  if (!node) {
    containerEl.innerHTML = `<div class="p-4 text-xs text-zinc-400">คลิกเลือกโหนดบนผืนผ้าใบเพื่อตั้งค่าพารามิเตอร์</div>`;
    return;
  }
  const meta = getNodeCatalogMeta(node.type);
  const outgoingEdges = (graph.edges || []).filter((e) => e.source === node.id);
  const edgeRows = outgoingEdges
    .map(
      (e) =>
        `<div class="flex items-center justify-between gap-2 px-2 py-1 rounded bg-zinc-900 border border-zinc-800 text-[11px] font-mono">
          <span>${esc(e.sourcePort || 'out')} -> ${esc(e.target)}</span>
          <button type="button" data-del-edge="${esc(e.id)}" class="text-rose-400 hover:text-rose-200">ลบเส้น</button>
        </div>`
    )
    .join('');

  containerEl.innerHTML = `
    <form id="v2FlowInspectorForm" class="space-y-3 text-xs">
      <div class="flex items-center justify-between gap-2 border-b border-zinc-800 pb-2.5">
        <div class="flex items-center gap-2 font-semibold text-zinc-100">
          <span class="text-cyan-400">${renderLucideIcon(node.icon || meta.icon, 'w-4 h-4')}</span>
          <span>ตั้งค่าโหนด: ${esc(node.id)}</span>
        </div>
        ${node.type !== 'trigger_inbound' ? `<button type="button" data-del-node="${esc(node.id)}" class="px-2 py-1 rounded border border-rose-500/40 bg-rose-950/30 text-rose-300 hover:bg-rose-950/60 text-[11px]">ลบโหนด</button>` : ''}
      </div>
      <div>
        <label class="block text-zinc-300 font-medium mb-1">ชื่อป้ายกำกับโหนด (Label)</label>
        <input name="label" required value="${esc(node.label || meta.label)}" class="w-full px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100" />
      </div>
      ${buildTypeSpecificFields(node)}
      <div class="space-y-1.5 pt-2 border-t border-zinc-800">
        <div class="text-[11px] font-semibold text-zinc-400">เส้นทางขาออก (${outgoingEdges.length})</div>
        ${edgeRows || '<div class="text-[11px] text-zinc-500">ยังไม่มีเส้นเชื่อมขาออก (คลิกพอร์ตบนการ์ดโหนดเพื่อเชื่อม)</div>'}
      </div>
      <button type="submit" class="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">
        ${renderLucideIcon('shield-check', 'w-3.5 h-3.5')}<span>อัปเดตพารามิเตอร์โหนด</span>
      </button>
    </form>`;

  containerEl.querySelector('#v2FlowInspectorForm')?.addEventListener('submit', (ev) => {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    node.label = String(fd.get('label') || node.label).trim();
    node.config = node.config || {};
    if (node.type === 'condition_router') {
      const pattern = String(fd.get('rulePattern') || '');
      const check = validateThaiRegexPattern(pattern);
      if (!check.ok) {
        handlers.onInspectorError?.(check.error);
        return;
      }
      node.config.rules = [{ port: String(fd.get('rulePort') || 'quote'), matchType: 'regex_th', pattern }, ...(node.config.rules || []).slice(1)];
    } else if (node.type === 'hardguard_math_quote') {
      node.config.slabPrice = Number(fd.get('slabPrice') || 1200);
      node.config.cutPrice = Number(fd.get('cutPrice') || 1350);
      node.config.wholesaleMinSqm = Number(fd.get('wholesaleMinSqm') || 50);
      node.config.requireUnitCheck = Boolean(fd.get('requireUnitCheck'));
      node.config.enforceCutBelowSlab = Boolean(fd.get('enforceCutBelowSlab'));
    } else if (node.type === 'vision_match') {
      node.config.minCosine = Number(fd.get('minCosine') || 0.82);
    } else if (node.type === 'template_reply') {
      const imgUrl = String(fd.get('previewImageUrl') || '').trim();
      if (!isSafeCanvasImageUrl(imgUrl)) {
        handlers.onInspectorError?.('URL รูปภาพไม่ผ่านเกณฑ์ความปลอดภัย AP-23');
        return;
      }
      node.config.template = String(fd.get('template') || '');
      node.config.previewImageUrl = imgUrl;
    } else if (node.type === 'http_webhook') {
      node.config.url = String(fd.get('url') || '').trim();
    }
    handlers.onNodeUpdated?.(node);
  });

  containerEl.querySelectorAll('[data-del-edge]').forEach((btn) => {
    btn.addEventListener('click', () => handlers.onDeleteEdge?.(btn.dataset.delEdge));
  });
  containerEl.querySelector('[data-del-node]')?.addEventListener('click', (ev) => {
    handlers.onDeleteNode?.(ev.currentTarget.dataset.delNode);
  });
}
