// gateway/public/modules/v2/v2-api.mjs
// OmniFlow Enterprise v2 — Safe HTML Escaping & JSON Fetch Client

export function esc(val) {
  return String(val ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export async function v2FetchJson(url, options = {}) {
  const headers = new Headers(options.headers || {});
  const isJsonBody = options.body && typeof options.body === 'object' && !(options.body instanceof FormData);
  if (isJsonBody && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  if (!headers.has('Accept')) headers.set('Accept', 'application/json');

  const res = await fetch(url, {
    credentials: 'same-origin',
    ...options,
    headers,
    body: isJsonBody ? JSON.stringify(options.body) : options.body,
  });

  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { ok: false, error: text || `HTTP ${res.status}` };
  }

  if (res.status === 401 && data?.requirePin) {
    window.dispatchEvent(new CustomEvent('omniflow:v2:pin-required', { detail: data }));
  }

  if (!res.ok) {
    const err = new Error(data?.error || `คำขอล้มเหลว (HTTP ${res.status})`);
    err.status = res.status;
    err.data = data;
    err.payload = data;
    err.code = data?.code;
    throw err;
  }
  return data;
}
