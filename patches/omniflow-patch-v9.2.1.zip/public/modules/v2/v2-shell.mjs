// gateway/public/modules/v2/v2-shell.mjs
// OmniFlow Enterprise v2 — Single-Hook Frontend Shell, Lazy View Router & Public SDK

import { injectV2Styles } from './v2-styles.mjs';
import { esc, v2FetchJson } from './v2-api.mjs';
import { lucideIcon, refreshLucideIcons } from './v2-icons.mjs';
import {
  V2_VIEW_MAP,
  V2_NAV_SPECS,
  LEGACY_VIEW_IDS,
  registerV2View,
  getV2ViewMeta,
} from './v2-nav-registry.mjs';

export { V2_VIEW_MAP, v2FetchJson, registerV2View };

const shellState = {
  initialized: false,
  activeView: null,
  role: 'owner',
  platformRole: 'subscriber',
  renderSeq: 0,
};

function ensureV2Viewport() {
  let viewport = document.getElementById('v2-viewport');
  if (viewport) return viewport;

  viewport = document.createElement('section');
  viewport.id = 'v2-viewport';
  viewport.className = 'hidden flex-1 p-4 sm:p-6 w-full mx-auto';

  const anchor =
    document.getElementById('viewAddonPreview') ||
    document.getElementById('viewSettingsEnterprise') ||
    document.getElementById('viewDashboard');

  if (anchor?.parentElement) {
    anchor.parentElement.appendChild(viewport);
  } else {
    document.body.appendChild(viewport);
  }
  return viewport;
}

function upgradeExistingAddonBadges(root) {
  if (!root) return;
  ['analytics_addon', 'users_addon', 'broadcast_addon'].forEach((viewKey) => {
    root.querySelectorAll(`[data-view="${viewKey}"]`).forEach((btn) => {
      if (btn.dataset.v2Upgraded === '1') return;
      btn.dataset.v2Upgraded = '1';
      btn.querySelectorAll('span').forEach((sp) => {
        const txt = sp.textContent.trim();
        if (/add-?on|เร็วๆ\s*นี้|soon|preview|v2\s*ready/i.test(txt)) {
          sp.classList.add('hidden');
          sp.hidden = true;
          sp.style.display = 'none';
        }
      });
    });
  });
}

function buildSuiteNavButton(viewKey, iconName, label, badgeText, extraClass = '') {
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.dataset.view = viewKey;
  btn.dataset.v2Injected = '1';
  btn.className = `sh-nav-item w-full flex items-center justify-between gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-slate-200 hover:bg-slate-800/60 transition ${extraClass}`.trim();
  btn.innerHTML = `<span class="flex items-center gap-2.5 truncate">${lucideIcon(iconName)}<span class="sidebar-label truncate">${esc(label)}</span></span><span class="sidebar-badge v2-badge v2-badge--ready">${esc(badgeText)}</span>`;
  btn.addEventListener('click', () => window.switchView?.(viewKey));
  return btn;
}

function injectSuiteNavSpec({ key, icon, label, badge }) {
  const sidebar = document.getElementById('enterpriseSidebar');
  const dropdown = document.getElementById('topbarSuiteDropdownMenu');
  const sidebarSuiteNav =
    sidebar?.querySelector('[data-view="broadcast_addon"]')?.parentElement ||
    sidebar?.querySelector('nav:last-of-type');

  if (sidebarSuiteNav && !sidebarSuiteNav.querySelector(`[data-view="${key}"]`)) {
    sidebarSuiteNav.appendChild(buildSuiteNavButton(key, icon, label, badge));
  }
  if (dropdown && !dropdown.querySelector(`[data-view="${key}"]`)) {
    dropdown.appendChild(buildSuiteNavButton(key, icon, label, badge));
  }
}

function injectSuiteNavigation() {
  const sidebar = document.getElementById('enterpriseSidebar');
  const dropdown = document.getElementById('topbarSuiteDropdownMenu');
  upgradeExistingAddonBadges(sidebar);
  upgradeExistingAddonBadges(dropdown);

  V2_NAV_SPECS.forEach(injectSuiteNavSpec);
  refreshLucideIcons(sidebar);
  refreshLucideIcons(dropdown);
  syncRoleNavVisibility();
}

function syncRoleNavVisibility() {
  const isSuperadmin = shellState.platformRole === 'platform_superadmin';
  document.querySelectorAll('[data-view="saas_growth_v2"]').forEach((el) => {
    el.classList.toggle('hidden', !isSuperadmin);
  });
}

function renderV2FallbackCard(viewport, viewKey, meta, reason = '') {
  viewport.innerHTML = `<div class="v2-grid"><div class="v2-card sh-card v2-col-12">
    <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
      <div><span class="v2-badge v2-badge--ready">${esc(meta.categoryLabel)}</span><h2 class="text-lg font-bold text-white mt-2">${esc(meta.title)}</h2></div>
      <span class="v2-badge v2-badge--warn">Module Standby</span>
    </div>
    <p class="text-xs text-slate-300 leading-relaxed mb-4">โครงสร้าง V2 Shell และ SQLite Core เชื่อมต่อพร้อมใช้งานแล้ว กำลังรอติดตั้งโมดูลหน้าจอ <code class="px-1.5 py-0.5 rounded bg-slate-900 text-cyan-300 font-mono">${esc(meta.modulePath)}</code> สำหรับมุมมอง <strong>${esc(viewKey)}</strong></p>
    ${reason ? `<div class="v2-subcard text-xs font-mono text-amber-300 mb-4">สถานะโหลดโมดูล: ${esc(reason)}</div>` : ''}
    <div class="v2-grid"><div class="v2-skeleton v2-col-3 h-24"></div><div class="v2-skeleton v2-col-3 h-24"></div><div class="v2-skeleton v2-col-3 h-24"></div><div class="v2-skeleton v2-col-3 h-24"></div></div>
  </div></div>`;
}

async function activateV2View(viewKey) {
  const meta = getV2ViewMeta(viewKey);
  if (!meta) return false;
  if (meta.superadminOnly && shellState.platformRole !== 'platform_superadmin') {
    shellState.activeView = null;
    return false;
  }

  const seq = ++shellState.renderSeq;
  shellState.activeView = viewKey;
  const viewport = ensureV2Viewport();

  LEGACY_VIEW_IDS.forEach((id) => document.getElementById(id)?.classList.add('hidden'));
  viewport.classList.remove('hidden');

  document.querySelectorAll('[data-view]').forEach((btn) => {
    const active = btn.getAttribute('data-view') === viewKey;
    btn.classList.toggle('active', active);
    btn.setAttribute('aria-current', active ? 'page' : 'false');
  });

  const suiteBtn = document.getElementById('topbarSuiteDropdownBtn');
  if (suiteBtn) suiteBtn.classList.add('active');
  const suiteLabel = document.getElementById('topbarSuiteActiveLabel');
  if (suiteLabel) {
    suiteLabel.textContent = meta.shortLabel || meta.title;
    suiteLabel.classList.remove('hidden');
  }
  document.getElementById('topbarSuiteDropdownMenu')?.classList.add('hidden');
  document.getElementById('layoutToolbarGroup')?.classList.add('hidden');
  if (typeof window.toggleMobileSidebar === 'function') {
    window.toggleMobileSidebar(false);
  }

  viewport.innerHTML = `
    <div class="v2-card sh-card">
      <div class="text-xs text-slate-300 mb-3">กำลังโหลดโมดูล ${esc(meta.title)}...</div>
      <div class="v2-skeleton h-32 w-full"></div>
    </div>
  `;

  try {
    const mod = await import(meta.modulePath);
    if (seq !== shellState.renderSeq) return true;
    const renderFn = mod.render || mod.mount || mod.default;
    if (typeof renderFn === 'function') {
      await renderFn(viewport, window.OmniflowV2);
      refreshLucideIcons(viewport);
    } else {
      renderV2FallbackCard(viewport, viewKey, meta, 'ไม่พบฟังก์ชัน export render(viewport, api)');
    }
  } catch (err) {
    if (seq === shellState.renderSeq) {
      renderV2FallbackCard(viewport, viewKey, meta, err?.message || 'View module not installed yet');
    }
  }
  return true;
}

function hookGlobalSwitchView() {
  const legacySwitchView = typeof window.switchView === 'function' ? window.switchView : null;
  if (legacySwitchView?._isOmniflowV2Wrapped) return;

  const wrappedSwitchView = function switchViewWithV2(viewName, ...rest) {
    const key = String(viewName || '').trim();
    if (getV2ViewMeta(key)) {
      if (window.state && typeof window.state === 'object') window.state.currentView = key;
      activateV2View(key);
      return;
    }
    shellState.activeView = null;
    shellState.renderSeq += 1;
    document.getElementById('v2-viewport')?.classList.add('hidden');
    if (legacySwitchView) {
      return legacySwitchView.call(this, key, ...rest);
    }
  };

  wrappedSwitchView._isOmniflowV2Wrapped = true;
  window.switchView = wrappedSwitchView;
}

async function openShiftHandoverModal(options = {}) {
  try {
    const mod = await import('./components/shift-handover-modal.mjs');
    const openFn = mod.openShiftHandoverModal || mod.default;
    if (typeof openFn === 'function') return await openFn(options, window.OmniflowV2);
  } catch {
    window.dispatchEvent(new CustomEvent('omniflow:v2:shift-handover', { detail: options }));
  }
  return null;
}

async function triggerFirstRunGate() {
  if (typeof document === 'undefined' || typeof document.getElementById !== 'function') return null;
  try {
    const mod = await import('./views/first-run-gate.view.mjs');
    if (typeof mod.mountFirstRunOverlayIfNeeded !== 'function') return null;
    return await mod.mountFirstRunOverlayIfNeeded({
      fetchJson: v2FetchJson,
      onAuthenticated: (detail) => {
        const pRole = detail?.account?.platform_role;
        if (pRole) {
          shellState.platformRole = String(pRole);
          syncRoleNavVisibility();
        }
        window.dispatchEvent(new CustomEvent('omniflow:v2:authenticated'));
        if (shellState.activeView) activateV2View(shellState.activeView);
      },
    });
  } catch {
    return null;
  }
}

export function initV2Shell() {
  if (shellState.initialized) return window.OmniflowV2;
  shellState.initialized = true;

  try {
    const roleHint = localStorage.getItem('omniflow_v2_platform_role');
    if (roleHint === 'platform_superadmin') shellState.platformRole = 'platform_superadmin';
  } catch { /* ignore storage restriction */ }

  injectV2Styles();
  ensureV2Viewport();
  injectSuiteNavigation();
  hookGlobalSwitchView();
  window.addEventListener?.('omniflow:v2:logged-out', () => {
    shellState.platformRole = 'subscriber';
    try {
      localStorage.removeItem('omniflow_v2_platform_role');
    } catch { /* ignore storage restriction */ }
    syncRoleNavVisibility();
    triggerFirstRunGate();
  });
  import('./v2-auto-lock.mjs').then((m) => m.startV2AutoLock({ fetchJson: v2FetchJson })).catch(() => {});

  window.OmniflowV2 = {
    switchV2View: (viewName) => window.switchView(viewName),
    registerV2View: (key, meta) => {
      registerV2View(key, meta);
      injectSuiteNavSpec({
        key,
        icon: meta.icon || 'layers',
        label: meta.navLabel || meta.title,
        badge: meta.shortLabel || 'New',
      });
      refreshLucideIcons();
    },
    getActiveRole: () => shellState.role,
    getPlatformRole: () => shellState.platformRole,
    setRoleContext: ({ role, platformRole } = {}) => {
      if (role) shellState.role = String(role);
      if (platformRole) shellState.platformRole = String(platformRole);
      syncRoleNavVisibility();
    },
    openShiftHandoverModal,
    openFirstRunGate: triggerFirstRunGate,
    v2FetchJson,
  };

  triggerFirstRunGate();
  return window.OmniflowV2;
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initV2Shell, { once: true });
  } else {
    initV2Shell();
  }
}
