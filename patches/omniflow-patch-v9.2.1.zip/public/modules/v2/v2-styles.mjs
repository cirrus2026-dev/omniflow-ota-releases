// gateway/public/modules/v2/v2-styles.mjs
// OmniFlow Enterprise v2 — Scoped Glassmorphism & 2K 12-Column Grid Stylesheet Injector
// Integrates cleanly with theme-engine-ui.js CSS variables (--omni-primary, --omni-border, --bg-void)

const V2_STYLE_TAG_ID = 'omniflow-v2-styles';

const V2_CSS_TEXT = `
  :root {
    --v2-accent: var(--omni-primary, #00f0ff);
    --v2-accent-secondary: var(--omni-secondary, #38bdf8);
    --v2-glass-bg: rgba(10, 16, 36, 0.68);
    --v2-glass-sub-bg: rgba(6, 11, 28, 0.56);
    --v2-glass-blur: 16px;
    --v2-glass-border: var(--omni-border, rgba(56, 189, 248, 0.28));
    --v2-glass-glow: var(--omni-glow, rgba(0, 240, 255, 0.2));
    --v2-surface-shadow: 0 10px 32px rgba(2, 6, 23, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.1);
  }

  #v2-viewport {
    position: relative;
    max-width: 2400px;
    width: 100%;
    box-sizing: border-box;
  }

  #v2-viewport svg.lucide, .v2-modal svg.lucide {
    display: inline-block;
    vertical-align: -0.125em;
  }

  .v2-grid {
    display: grid;
    grid-template-columns: repeat(12, minmax(0, 1fr));
    gap: 1rem;
    width: 100%;
  }

  .v2-col-3 { grid-column: span 3 / span 3; }
  .v2-col-4 { grid-column: span 4 / span 4; }
  .v2-col-5 { grid-column: span 5 / span 5; }
  .v2-col-6 { grid-column: span 6 / span 6; }
  .v2-col-7 { grid-column: span 7 / span 7; }
  .v2-col-8 { grid-column: span 8 / span 8; }
  .v2-col-12 { grid-column: span 12 / span 12; }

  @media (max-width: 1279px) {
    .v2-col-3 { grid-column: span 6 / span 6; }
    .v2-col-4, .v2-col-5, .v2-col-7, .v2-col-8 { grid-column: span 12 / span 12; }
  }

  @media (max-width: 767px) {
    .v2-grid { gap: 0.75rem; }
    .v2-col-3, .v2-col-4, .v2-col-5, .v2-col-6, .v2-col-7, .v2-col-8 {
      grid-column: span 12 / span 12;
    }
  }

  .v2-card {
    position: relative;
    border-radius: 1rem;
    padding: 1.25rem;
    background: var(--v2-glass-bg);
    backdrop-filter: blur(var(--v2-glass-blur)) saturate(175%);
    -webkit-backdrop-filter: blur(var(--v2-glass-blur)) saturate(175%);
    border: 1px solid var(--v2-glass-border);
    box-shadow: var(--v2-surface-shadow);
    transition: border-color 0.2s ease, transform 0.2s ease, box-shadow 0.2s ease;
  }

  .v2-card:hover {
    border-color: var(--v2-accent);
    box-shadow: 0 12px 36px rgba(2, 6, 23, 0.5), 0 0 18px var(--v2-glass-glow);
  }

  .v2-subcard {
    border-radius: 0.75rem;
    padding: 0.875rem 1rem;
    background: var(--v2-glass-sub-bg);
    border: 1px solid rgba(148, 163, 184, 0.2);
  }

  .v2-badge {
    display: inline-flex;
    align-items: center;
    gap: 0.35rem;
    padding: 0.2rem 0.6rem;
    border-radius: 9999px;
    font-size: 0.7rem;
    font-weight: 700;
    letter-spacing: 0.03em;
    border: 1px solid rgba(148, 163, 184, 0.32);
    background: rgba(15, 23, 42, 0.65);
    color: #e2e8f0;
    white-space: nowrap;
  }

  .v2-badge--ok {
    background: rgba(16, 185, 129, 0.16);
    border-color: rgba(16, 185, 129, 0.45);
    color: #6ee7b7;
  }

  .v2-badge--warn {
    background: rgba(245, 158, 11, 0.16);
    border-color: rgba(245, 158, 11, 0.45);
    color: #fcd34d;
  }

  .v2-badge--danger {
    background: rgba(244, 63, 94, 0.16);
    border-color: rgba(244, 63, 94, 0.45);
    color: #fda4af;
  }

  .v2-badge--ready {
    background: rgba(0, 240, 255, 0.14);
    border-color: var(--v2-glass-border);
    color: var(--v2-accent);
  }

  .v2-table-wrap {
    width: 100%;
    overflow-x: auto;
    border-radius: 0.75rem;
    border: 1px solid rgba(148, 163, 184, 0.2);
  }

  .v2-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.8125rem;
    text-align: left;
  }

  .v2-table th {
    padding: 0.75rem 1rem;
    font-size: 0.72rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: #94a3b8;
    background: rgba(2, 6, 23, 0.55);
    border-bottom: 1px solid rgba(148, 163, 184, 0.22);
  }

  .v2-table td {
    padding: 0.75rem 1rem;
    border-bottom: 1px solid rgba(148, 163, 184, 0.12);
    color: #f1f5f9;
    vertical-align: middle;
  }

  .v2-table tbody tr:hover td {
    background: rgba(56, 189, 248, 0.06);
  }

  .v2-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.45rem;
    padding: 0.5rem 1rem;
    border-radius: 0.75rem;
    font-size: 0.8rem;
    font-weight: 700;
    cursor: pointer;
    border: 1px solid rgba(148, 163, 184, 0.3);
    background: rgba(15, 23, 42, 0.78);
    color: #f8fafc;
    transition: all 0.18s ease;
  }

  .v2-btn:hover:not(:disabled) {
    border-color: var(--v2-accent);
    box-shadow: 0 0 14px var(--v2-glass-glow);
  }

  .v2-btn:disabled {
    cursor: not-allowed;
  }

  .v2-btn--primary {
    background: linear-gradient(135deg, var(--v2-accent), var(--v2-accent-secondary));
    color: #020617;
    border-color: transparent;
  }

  .v2-auth-overlay {
    position: fixed;
    inset: 0;
    z-index: 9985;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1.25rem;
    background: rgba(2, 6, 23, 0.82);
    backdrop-filter: blur(18px);
    -webkit-backdrop-filter: blur(18px);
    overflow-y: auto;
  }

  .v2-modal-backdrop {
    position: fixed;
    inset: 0;
    z-index: 9992;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 1rem;
    background: rgba(2, 6, 23, 0.72);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
  }

  .v2-modal {
    width: 100%;
    max-width: 42rem;
    max-height: 90vh;
    overflow-y: auto;
    border-radius: 1.25rem;
    padding: 1.5rem;
    background: rgba(10, 16, 36, 0.95);
    border: 1px solid var(--v2-glass-border);
    box-shadow: 0 24px 60px rgba(0, 0, 0, 0.65), 0 0 24px var(--v2-glass-glow);
  }

  .v2-skeleton {
    border-radius: 0.65rem;
    background: linear-gradient(90deg, rgba(30, 41, 59, 0.45) 25%, rgba(56, 189, 248, 0.16) 50%, rgba(30, 41, 59, 0.45) 75%);
    background-size: 200% 100%;
    animation: v2Shimmer 1.6s infinite linear;
  }

  @keyframes v2Shimmer {
    0% { background-position: 200% 0; }
    100% { background-position: -200% 0; }
  }
`;

export function injectV2Styles() {
  if (typeof document === 'undefined') return null;
  let styleTag = document.getElementById(V2_STYLE_TAG_ID);
  if (styleTag) return styleTag;
  styleTag = document.createElement('style');
  styleTag.id = V2_STYLE_TAG_ID;
  styleTag.textContent = V2_CSS_TEXT;
  document.head.appendChild(styleTag);
  return styleTag;
}
