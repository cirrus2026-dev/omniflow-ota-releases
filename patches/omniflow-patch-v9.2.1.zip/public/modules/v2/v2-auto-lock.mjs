// gateway/public/modules/v2/v2-auto-lock.mjs
// OmniFlow Enterprise v2 — Client-Side Idle Auto-Lock Watcher

const ACTIVITY_EVENTS = ['mousemove', 'keydown', 'click', 'touchstart', 'scroll'];
let started = false;

export function startV2AutoLock({ fetchJson } = {}) {
  if (started || typeof window === 'undefined' || typeof fetchJson !== 'function') return;
  started = true;

  let minutes = 0;
  let timerId = null;

  const clearTimer = () => {
    if (timerId) {
      window.clearTimeout(timerId);
      timerId = null;
    }
  };

  const armTimer = () => {
    clearTimer();
    if (!Number.isFinite(minutes) || minutes <= 0) return;
    timerId = window.setTimeout(async () => {
      timerId = null;
      try {
        await fetchJson('/api/v2/auth/logout', { method: 'POST' });
      } catch {
        // Ignore network/session errors during idle lock
      }
      window.dispatchEvent(new CustomEvent('omniflow:v2:logged-out'));
    }, minutes * 60_000);
  };

  const applyMinutes = (raw) => {
    const parsed = Number.parseInt(raw, 10);
    minutes = Number.isInteger(parsed) && parsed > 0 ? Math.min(1440, parsed) : 0;
    armTimer();
  };

  const loadSettings = async () => {
    try {
      const res = await fetchJson('/api/v2/settings-suite');
      applyMinutes(res?.settings?.autoLockMinutes);
    } catch {
      // Ignore 401 or unauthenticated startup state
    }
  };

  ACTIVITY_EVENTS.forEach((evt) => {
    window.addEventListener(evt, () => {
      if (minutes > 0) armTimer();
    }, { passive: true });
  });

  window.addEventListener('omniflow:v2:settings-updated', (ev) => {
    applyMinutes(ev?.detail?.autoLockMinutes);
  });
  window.addEventListener('omniflow:v2:authenticated', () => {
    loadSettings();
  });
  window.addEventListener('omniflow:v2:logged-out', () => {
    clearTimer();
  });

  loadSettings();
}
