// gateway/public/modules/v2/views/cat2-rbac.view.mjs
// Category 2: Multi-User RBAC, Agent KPI & Shift Handover View

import { esc, v2FetchJson } from '../v2-api.mjs';

const ROLE_LABELS = {
  owner: 'Owner (เห็นทั้งหมด)',
  sales_morning: 'ฝ่ายขาย (กะเช้า)',
  sales_night: 'ฝ่ายขาย (กะดึก)',
  accounting: 'ฝ่ายบัญชี',
};

let activeHandoverHandler = null;

export async function render(viewport, api) {
  const [usersRes, kpisRes, shiftsRes] = await Promise.all([
    v2FetchJson('/api/v2/rbac/users'),
    v2FetchJson('/api/v2/rbac/kpis'),
    v2FetchJson('/api/v2/shifts/handovers'),
  ]);

  const users = usersRes.users || [];
  const kpis = kpisRes.kpis || [];
  const handovers = shiftsRes.handovers || [];

  viewport.innerHTML = `
    <div class="v2-grid">
      <div class="v2-card sh-card v2-col-12 flex flex-wrap items-center justify-between gap-3">
        <div>
          <span class="v2-badge v2-badge--ready">หมวดที่ 2 • Multi-User RBAC</span>
          <h2 class="text-lg font-bold text-white mt-1.5">จัดการทีมแอดมิน สิทธิ์การใช้งาน & ส่งมอบกะ</h2>
        </div>
        <div class="flex flex-wrap gap-2">
          <button id="v2OpenShiftBtn" type="button" class="v2-btn"><i data-lucide="moon" class="w-4 h-4 shrink-0"></i><span>บันทึกส่งมอบกะ</span></button>
          <button id="v2ToggleAddUserBtn" type="button" class="v2-btn v2-btn--primary"><i data-lucide="user-plus" class="w-4 h-4 shrink-0"></i><span>เพิ่มบัญชีแอดมิน</span></button>
        </div>
      </div>

      <div id="v2AddUserPanel" class="hidden v2-card sh-card v2-col-12">
        <h3 class="text-sm font-bold text-white mb-3">สร้างบัญชีทีมงานใหม่ (ซ่อน API Keys อัตโนมัติสำหรับ Sales/Accounting)</h3>
        <form id="v2CreateUserForm" class="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs">
          <input name="username" required placeholder="Username (เช่น may_sales)" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
          <input name="displayName" required placeholder="ชื่อแสดงผล (เช่น แอดมินเมย์)" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
          <input name="password" type="password" required minlength="6" placeholder="รหัสผ่าน (>= 6 ตัว)" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
          <select name="role" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white">
            <option value="sales_morning">ฝ่ายขาย (กะเช้า)</option>
            <option value="sales_night">ฝ่ายขาย (กะดึก)</option>
            <option value="accounting">ฝ่ายบัญชี</option>
            <option value="owner">Owner</option>
          </select>
          <button type="submit" class="v2-btn v2-btn--primary">บันทึกบัญชี</button>
        </form>
        <div id="v2UserFormMsg" class="hidden mt-2 text-xs"></div>
      </div>

      <div class="v2-card sh-card v2-col-7">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="users" class="w-4 h-4 shrink-0 text-cyan-400"></i><span>รายชื่อทีมงาน & สิทธิ์การเข้าถึง (${users.length})</span></h3>
        <div class="v2-table-wrap">
          <table class="v2-table">
            <thead><tr><th>ชื่อ</th><th>Username</th><th>บทบาท</th><th>API Key</th><th>สถานะ</th></tr></thead>
            <tbody>
              ${users.length ? users.map((u) => `
                <tr>
                  <td class="font-semibold">${esc(u.display_name)}</td>
                  <td class="font-mono text-xs text-slate-300">${esc(u.username)}</td>
                  <td>${esc(ROLE_LABELS[u.role] || u.role)}</td>
                  <td><span class="v2-badge ${u.canViewApiKeys ? 'v2-badge--ok' : 'v2-badge--warn'}">${u.canViewApiKeys ? 'เห็นทั้งหมด' : '<i data-lucide="lock" class="w-3.5 h-3.5 shrink-0"></i><span>ซ่อนมิดชิด</span>'}</span></td>
                  <td><span class="v2-badge ${u.is_active ? 'v2-badge--ok' : 'v2-badge--danger'}">${u.is_active ? 'ใช้งาน' : 'ปิด'}</span></td>
                </tr>
              `).join('') : '<tr><td colspan="5" class="text-center text-slate-400">ยังไม่มีบัญชีทีมงาน — กดปุ่ม + เพิ่มบัญชีแอดมิน ด้านบน</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>

      <div class="v2-card sh-card v2-col-5">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="trophy" class="w-4 h-4 shrink-0 text-amber-400"></i><span>KPI แอดมินรายบุคคล</span></h3>
        <div class="v2-table-wrap">
          <table class="v2-table">
            <thead><tr><th>แอดมิน</th><th>แชท</th><th>ปิดสำเร็จ</th><th>FRT เฉลี่ย</th></tr></thead>
            <tbody>
              ${kpis.length ? kpis.map((k) => `
                <tr>
                  <td>${esc(k.display_name)}</td>
                  <td>${esc(k.total_chats ?? 0)}</td>
                  <td>${esc(k.resolved_chats ?? 0)}</td>
                  <td>${k.avg_frt_ms ? `${Math.round(k.avg_frt_ms / 1000)}s` : '--'}</td>
                </tr>
              `).join('') : '<tr><td colspan="4" class="text-center text-slate-400">ยังไม่มีข้อมูลการรับแชท</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>

      <div class="v2-card sh-card v2-col-12">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="clipboard-list" class="w-4 h-4 shrink-0 text-emerald-400"></i><span>ประวัติการส่งมอบกะล่าสุด (${handovers.length})</span></h3>
        <div class="v2-table-wrap">
          <table class="v2-table">
            <thead><tr><th>เวลา</th><th>จากกะ</th><th>ถึงกะ</th><th>แชทค้าง</th><th>รอมัดจำ</th><th>โน้ตสำคัญ</th></tr></thead>
            <tbody>
              ${handovers.length ? handovers.map((h) => `
                <tr>
                  <td class="font-mono text-xs">${esc(h.created_at)}</td>
                  <td>${esc(h.from_shift)}</td>
                  <td>${esc(h.to_shift)}</td>
                  <td>${esc(h.open_chats_count)}</td>
                  <td>${esc(h.pending_quotes_count)}</td>
                  <td>${esc(h.pinned_notes || '-')}</td>
                </tr>
              `).join('') : '<tr><td colspan="6" class="text-center text-slate-400">ยังไม่มีประวัติการส่งมอบกะ</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
  if (window.lucide) window.lucide.createIcons();

  viewport.querySelector('#v2OpenShiftBtn')?.addEventListener('click', () => api?.openShiftHandoverModal?.());
  viewport.querySelector('#v2ToggleAddUserBtn')?.addEventListener('click', () => {
    viewport.querySelector('#v2AddUserPanel')?.classList.toggle('hidden');
  });

  const form = viewport.querySelector('#v2CreateUserForm');
  const msgEl = viewport.querySelector('#v2UserFormMsg');
  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    try {
      await v2FetchJson('/api/v2/rbac/users', {
        method: 'POST',
        body: {
          username: fd.get('username'),
          displayName: fd.get('displayName'),
          password: fd.get('password'),
          role: fd.get('role'),
        },
      });
      await render(viewport, api);
    } catch (err) {
      msgEl.className = 'mt-2 text-xs text-rose-300';
      msgEl.textContent = err.message;
      msgEl.classList.remove('hidden');
    }
  });

  if (activeHandoverHandler) {
    window.removeEventListener('omniflow:v2:shift-handover-saved', activeHandoverHandler);
  }
  activeHandoverHandler = () => {
    if (!viewport.classList.contains('hidden')) render(viewport, api);
  };
  window.addEventListener('omniflow:v2:shift-handover-saved', activeHandoverHandler);
}
