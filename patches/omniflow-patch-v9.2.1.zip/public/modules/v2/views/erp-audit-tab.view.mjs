// gateway/public/modules/v2/views/erp-audit-tab.view.mjs
// OmniFlow Enterprise v2 — Immutable Audit Log, External ERP API Keys & Human-Gated Sync UI

import { esc, v2FetchJson } from '../v2-api.mjs';
import { lucideIcon, refreshLucideIcons } from '../v2-icons.mjs';
import { openAuditDiffModal, openCreateErpKeyModal } from './erp-key-modal.mjs';

function fmtThb(row) {
  const num = Number.isFinite(Number(row?.amount_thb)) ? Number(row.amount_thb) : Number(row?.amount_satang || 0) / 100;
  return `${num.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} บาท`;
}

function renderStatusPill(status) {
  const map = {
    active: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300',
    approved_sent: 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300',
    pending_approval: 'border-amber-500/40 bg-amber-950/40 text-amber-300',
    sending: 'border-sky-500/40 bg-sky-950/40 text-sky-300',
    revoked: 'border-zinc-700 bg-zinc-900 text-zinc-400',
    rejected: 'border-zinc-700 bg-zinc-900 text-zinc-400',
    send_failed: 'border-rose-500/40 bg-rose-950/40 text-rose-300',
  };
  const cls = map[status] || 'border-zinc-700 bg-zinc-900 text-zinc-300';
  return `<span class="inline-flex px-2 py-0.5 rounded-full text-[10px] font-medium border ${cls}">${esc(status || '-')}</span>`;
}

function buildSyncCard(s) {
  const enabled = Number(s?.outbound_enabled || 0) === 1;
  const mode = s?.sync_mode || 'manual_approval';
  const secretPh = s?.has_webhook_secret ? 'บันทึก Secret ไว้แล้ว (กรอกเมื่อต้องการเปลี่ยนใหม่)' : 'กรอก Webhook Secret สำหรับ HMAC-SHA256';
  return `
    <section class="rounded-xl border border-zinc-800 bg-zinc-950/80 p-4 space-y-4">
      <div class="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-800 pb-3">
        <div class="flex items-center gap-2">${lucideIcon('shield-check', 'w-4 h-4 text-zinc-200')}<h3 class="text-sm font-semibold text-zinc-100">Outbound ERP / Webhook Sync (Human-Gated)</h3></div>
        <span class="text-[11px] text-zinc-400">${enabled ? 'สถานะ: เปิดใช้งาน' : 'สถานะ: ปิด (Default Safe)'}</span>
      </div>
      <form id="erpSyncForm" class="space-y-3.5 text-xs">
        <div class="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border border-zinc-800 bg-zinc-900/50">
          <div>
            <div class="font-medium text-zinc-100">Master Switch ส่งข้อมูลออกไปยัง ERP ภายนอก</div>
            <div class="text-[11px] text-zinc-400">ค่าเริ่มต้นคือปิด (OFF) ระบบจะบล็อกการยิง Webhook ออกทั้งหมดจนกว่าจะเปิดสวิตช์นี้</div>
          </div>
          <label class="inline-flex items-center gap-2 cursor-pointer font-medium text-zinc-200">
            <input id="erpOutboundEnabled" type="checkbox" ${enabled ? 'checked' : ''} class="rounded border-zinc-600 bg-zinc-950 text-emerald-500" />
            <span>เปิดใช้งาน Outbound Sync</span>
          </label>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          <label class="flex items-start gap-2.5 p-3 rounded-lg border ${mode === 'manual_approval' ? 'border-zinc-500 bg-zinc-900' : 'border-zinc-800 bg-zinc-900/40'} cursor-pointer">
            <input type="radio" name="erpSyncMode" value="manual_approval" ${mode === 'manual_approval' ? 'checked' : ''} class="mt-0.5" />
            <span><strong class="block text-zinc-100">ตรวจสอบและอนุมัติโดยคนก่อนส่ง (Human Approval — แนะนำ)</strong><span class="text-[11px] text-zinc-400">ทุกออเดอร์จะพักไว้ในคิวรออนุมัติจนกว่าผู้ดูแลจะกดยืนยัน</span></span>
          </label>
          <label class="flex items-start gap-2.5 p-3 rounded-lg border ${mode === 'auto_verified' ? 'border-amber-500/60 bg-amber-950/20' : 'border-zinc-800 bg-zinc-900/40'} cursor-pointer">
            <input type="radio" name="erpSyncMode" value="auto_verified" ${mode === 'auto_verified' ? 'checked' : ''} class="mt-0.5" />
            <span><strong class="block text-zinc-100">ส่งอัตโนมัติเมื่อผ่านเกณฑ์ HardGuard (Auto-Verified Only)</strong><span class="text-[11px] text-zinc-400">ใช้เฉพาะเมื่อตั้งค่าตรวจสอบสลิปและ Webhook ปลายทางพร้อมแล้ว</span></span>
          </label>
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div><label class="block text-zinc-300 font-medium mb-1">Outbound Webhook URL (HTTPS)</label><input id="erpWebhookUrl" type="url" value="${esc(s?.webhook_url || '')}" placeholder="https://erp.example.com/webhooks/omniflow" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100 font-mono text-xs" /></div>
          <div><label class="block text-zinc-300 font-medium mb-1">Webhook HMAC Secret</label><input id="erpWebhookSecret" type="password" autocomplete="new-password" placeholder="${esc(secretPh)}" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100 font-mono text-xs" /></div>
        </div>
        <div class="flex flex-wrap items-center justify-end gap-2 pt-1">
          <button type="button" data-act="ping-webhook" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-zinc-700 text-zinc-200 hover:bg-zinc-800 font-medium">${lucideIcon('send', 'w-3.5 h-3.5')}<span>ทดสอบยิง Webhook (Dry-Run Ping)</span></button>
          <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>บันทึกการตั้งค่า</span></button>
        </div>
      </form>
    </section>`;
}

function buildQueueSection(items) {
  const rows = items.length
    ? items.map((q) => {
        const canAct = q.status === 'pending_approval' || q.status === 'send_failed';
        return `<tr class="border-t border-zinc-800/80 hover:bg-zinc-900/40">
          <td class="px-3 py-2.5 font-mono text-zinc-200">${esc(q.order_id)}</td>
          <td class="px-3 py-2.5 font-mono text-zinc-100">${esc(fmtThb(q))}</td>
          <td class="px-3 py-2.5 text-zinc-400 max-w-xs truncate" title="${esc(q.ai_confidence_note || '')}">${esc(q.ai_confidence_note || '-')}</td>
          <td class="px-3 py-2.5">${renderStatusPill(q.status)}${q.last_error ? `<div class="text-[10px] text-rose-300 mt-0.5 truncate max-w-[180px]">${esc(q.last_error)}</div>` : ''}</td>
          <td class="px-3 py-2.5 text-right whitespace-nowrap">${canAct ? `
            <button type="button" data-act="approve-queue" data-id="${esc(q.id)}" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25 mr-1">${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>อนุมัติส่ง ERP</span></button>
            <button type="button" data-act="reject-queue" data-id="${esc(q.id)}" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-zinc-700 text-zinc-300 hover:bg-zinc-800">${lucideIcon('x-circle', 'w-3.5 h-3.5')}<span>ยกเลิก</span></button>` : `<span class="text-zinc-500">${esc(q.approved_by || '-')}</span>`}
          </td></tr>`;
      }).join('')
    : `<tr><td colspan="5" class="px-3 py-6 text-center text-zinc-500">ไม่มีรายการรออนุมัติส่งเข้า ERP</td></tr>`;

  return `
    <section class="rounded-xl border border-zinc-800 bg-zinc-950/80 p-4 space-y-3">
      <div class="flex items-center justify-between">
        <div class="flex items-center gap-2">${lucideIcon('activity', 'w-4 h-4 text-zinc-200')}<h3 class="text-sm font-semibold text-zinc-100">คิวรออนุมัติส่งข้อมูลเข้า ERP (Human-Approval Queue)</h3></div>
        <span class="text-[11px] text-zinc-400">${items.length} รายการ</span>
      </div>
      <div class="overflow-x-auto rounded-lg border border-zinc-800">
        <table class="w-full text-left text-xs"><thead class="bg-zinc-900/80 text-[11px] text-zinc-400">
          <tr><th class="px-3 py-2">Order ID</th><th class="px-3 py-2">ยอดสุทธิ</th><th class="px-3 py-2">หมายเหตุ AI</th><th class="px-3 py-2">สถานะ</th><th class="px-3 py-2 text-right">การดำเนินการ</th></tr>
        </thead><tbody>${rows}</tbody></table>
      </div>
    </section>`;
}

function buildKeysSection(keys) {
  const rows = keys.length
    ? keys.map((k) => `<tr class="border-t border-zinc-800/80 hover:bg-zinc-900/40">
        <td class="px-3 py-2.5 font-medium text-zinc-100">${esc(k.key_name)}</td>
        <td class="px-3 py-2.5 font-mono text-zinc-300">${esc(k.masked_key)}</td>
        <td class="px-3 py-2.5 font-mono text-[11px] text-zinc-400">${esc((k.scopes || []).join(', '))}</td>
        <td class="px-3 py-2.5 text-zinc-400">${esc(k.last_used_at || 'ยังไม่เคยใช้')}</td>
        <td class="px-3 py-2.5">${renderStatusPill(k.status)}</td>
        <td class="px-3 py-2.5 text-right">${k.status === 'active' ? `<button type="button" data-act="revoke-key" data-id="${esc(k.id)}" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-rose-500/40 bg-rose-950/30 text-rose-300 hover:bg-rose-950/60">${lucideIcon('trash-2', 'w-3.5 h-3.5')}<span>เพิกถอน</span></button>` : '<span class="text-zinc-500">-</span>'}</td>
      </tr>`).join('')
    : `<tr><td colspan="6" class="px-3 py-6 text-center text-zinc-500">ยังไม่มี External ERP API Key</td></tr>`;

  return `
    <section class="rounded-xl border border-zinc-800 bg-zinc-950/80 p-4 space-y-3">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">${lucideIcon('key-round', 'w-4 h-4 text-zinc-200')}<h3 class="text-sm font-semibold text-zinc-100">External ERP API Keys (Bearer Token)</h3></div>
        <button type="button" data-act="create-key" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white text-xs font-semibold">${lucideIcon('key-round', 'w-3.5 h-3.5')}<span>สร้าง API Key ใหม่</span></button>
      </div>
      <div class="overflow-x-auto rounded-lg border border-zinc-800">
        <table class="w-full text-left text-xs"><thead class="bg-zinc-900/80 text-[11px] text-zinc-400">
          <tr><th class="px-3 py-2">ชื่อคีย์</th><th class="px-3 py-2">Masked Key</th><th class="px-3 py-2">Scopes</th><th class="px-3 py-2">ใช้งานล่าสุด</th><th class="px-3 py-2">สถานะ</th><th class="px-3 py-2 text-right">จัดการ</th></tr>
        </thead><tbody>${rows}</tbody></table>
      </div>
    </section>`;
}

function buildAuditSection(logs, filterAction) {
  const rows = logs.length
    ? logs.map((row, idx) => `<tr class="border-t border-zinc-800/80 hover:bg-zinc-900/40">
        <td class="px-3 py-2 font-mono text-[11px] text-zinc-400 whitespace-nowrap">${esc(row.created_at)}</td>
        <td class="px-3 py-2 text-zinc-200">${esc(row.actor_id)} <span class="text-zinc-500">(${esc(row.actor_role)})</span></td>
        <td class="px-3 py-2 font-mono text-[11px] text-zinc-100">${esc(row.action)}</td>
        <td class="px-3 py-2 font-mono text-[11px] text-zinc-400">${esc(row.target_type)}:${esc(row.target_id)}</td>
        <td class="px-3 py-2 text-right"><button type="button" data-act="view-diff" data-idx="${idx}" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-md border border-zinc-700 text-zinc-200 hover:bg-zinc-800">${lucideIcon('eye', 'w-3.5 h-3.5')}<span>ดู Diff</span></button></td>
      </tr>`).join('')
    : `<tr><td colspan="5" class="px-3 py-6 text-center text-zinc-500">ไม่พบประวัติ Audit Log ตามเงื่อนไขที่เลือก</td></tr>`;

  return `
    <section class="rounded-xl border border-zinc-800 bg-zinc-950/80 p-4 space-y-3">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2">${lucideIcon('activity', 'w-4 h-4 text-zinc-200')}<h3 class="text-sm font-semibold text-zinc-100">Immutable Audit Log (Append-Only)</h3></div>
        <form id="erpAuditFilterForm" class="flex flex-wrap items-center gap-2 text-xs">
          <input id="erpAuditActionInput" type="text" value="${esc(filterAction)}" placeholder="กรองตาม action เช่น erp_key.created" class="px-2.5 py-1.5 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100 w-56" />
          <button type="submit" class="px-3 py-1.5 rounded-lg border border-zinc-700 text-zinc-200 hover:bg-zinc-800">กรอง</button>
          <button type="button" data-act="export-csv" class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-700 text-zinc-100 hover:bg-zinc-800">${lucideIcon('download', 'w-3.5 h-3.5')}<span>Export CSV</span></button>
        </form>
      </div>
      <div class="overflow-x-auto rounded-lg border border-zinc-800">
        <table class="w-full text-left text-xs"><thead class="bg-zinc-900/80 text-[11px] text-zinc-400">
          <tr><th class="px-3 py-2">เวลา</th><th class="px-3 py-2">ผู้ทำรายการ</th><th class="px-3 py-2">เหตุการณ์ (Action)</th><th class="px-3 py-2">เป้าหมาย</th><th class="px-3 py-2 text-right">รายละเอียด</th></tr>
        </thead><tbody>${rows}</tbody></table>
      </div>
    </section>`;
}

export async function render(viewport, api = {}) {
  const fetchJson = api?.v2FetchJson || v2FetchJson;
  const state = { settings: null, queue: [], keys: [], logs: [], actionFilter: '', notice: '', isError: false };
  const root = document.createElement('div');
  root.className = 'space-y-4 text-zinc-100';
  viewport.replaceChildren(root);

  const paint = () => {
    const noticeHtml = state.notice
      ? `<div class="flex items-center gap-2 px-3.5 py-2.5 rounded-lg border text-xs ${state.isError ? 'border-rose-500/40 bg-rose-950/40 text-rose-200' : 'border-emerald-500/40 bg-emerald-950/30 text-emerald-200'}">${lucideIcon(state.isError ? 'alert-triangle' : 'check-circle-2', 'w-4 h-4')}<span>${esc(state.notice)}</span></div>`
      : '';
    root.innerHTML = `
      <div class="flex items-start gap-3 p-4 rounded-xl border border-amber-500/40 bg-amber-950/25 text-amber-100 text-xs">
        ${lucideIcon('alert-triangle', 'w-5 h-5 text-amber-400 shrink-0 mt-0.5')}
        <div>
          <div class="font-semibold text-amber-200">คำเตือนด้านความปลอดภัยระบบบัญชี (Financial Integrity Warning)</div>
          <p class="text-amber-100/85 mt-1 leading-relaxed">ระบบประมวลผลด้วย AI หรือการตรวจจับรูปภาพมีโอกาสเกิดความผิดพลาด (Error Margin / False Positive) การส่งข้อมูลเข้าสู่ระบบบัญชี/ERP ภายนอกอัตโนมัติอาจทำให้ข้อมูลภาษีและสต็อกสินค้าคลาดเคลื่อน แนะนำให้ใช้โหมด "ตรวจสอบและอนุมัติโดยมนุษย์ (Human Approval)" ก่อนส่งข้อมูลเข้าสู่ระบบจริงเสมอ</p>
        </div>
      </div>
      ${noticeHtml}${buildSyncCard(state.settings)}${buildQueueSection(state.queue)}${buildKeysSection(state.keys)}${buildAuditSection(state.logs, state.actionFilter)}`;
    refreshLucideIcons(root);
  };

  const loadAll = async () => {
    try {
      const qs = state.actionFilter ? `?action=${encodeURIComponent(state.actionFilter)}&limit=50` : '?limit=50';
      const [sRes, qRes, kRes, aRes] = await Promise.all([
        fetchJson('/api/v2/erp/sync-settings'),
        fetchJson('/api/v2/erp/outbound-queue?limit=50'),
        fetchJson('/api/v2/erp/keys'),
        fetchJson(`/api/v2/audit-logs${qs}`),
      ]);
      state.settings = sRes.settings || {};
      state.queue = qRes.items || [];
      state.keys = kRes.items || [];
      state.logs = aRes.items || [];
      paint();
    } catch (err) {
      state.notice = err?.message || 'โหลดข้อมูล ERP & Audit Log ไม่สำเร็จ';
      state.isError = true;
      paint();
    }
  };

  root.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    if (ev.target.id === 'erpSyncForm') {
      const modeEl = root.querySelector('input[name="erpSyncMode"]:checked');
      const secretVal = root.querySelector('#erpWebhookSecret')?.value?.trim() || '';
      const body = {
        outbound_enabled: root.querySelector('#erpOutboundEnabled')?.checked ? 1 : 0,
        sync_mode: modeEl ? modeEl.value : 'manual_approval',
        webhook_url: root.querySelector('#erpWebhookUrl')?.value?.trim() || '',
        ...(secretVal ? { webhook_secret: secretVal } : {}),
      };
      try {
        await fetchJson('/api/v2/erp/sync-settings', { method: 'PUT', body });
        state.notice = 'บันทึกการตั้งค่า Outbound ERP Sync เรียบร้อยแล้ว';
        state.isError = false;
        await loadAll();
      } catch (err) {
        state.notice = err?.message || 'บันทึกการตั้งค่าไม่สำเร็จ';
        state.isError = true;
        paint();
      }
    } else if (ev.target.id === 'erpAuditFilterForm') {
      state.actionFilter = root.querySelector('#erpAuditActionInput')?.value?.trim() || '';
      await loadAll();
    }
  });

  root.addEventListener('click', async (ev) => {
    const btn = ev.target.closest('[data-act]');
    if (!btn) return;
    const act = btn.dataset.act;
    const id = btn.dataset.id || '';
    try {
      if (act === 'create-key') return openCreateErpKeyModal({ onCreated: () => loadAll(), fetchJson });
      if (act === 'view-diff') return openAuditDiffModal(state.logs[Number(btn.dataset.idx)] || {});
      if (act === 'ping-webhook') {
        const res = await fetchJson('/api/v2/erp/sync-settings/ping', {
          method: 'POST',
          body: { webhookUrl: root.querySelector('#erpWebhookUrl')?.value?.trim() || '', webhookSecret: root.querySelector('#erpWebhookSecret')?.value?.trim() || undefined },
        });
        state.notice = `Dry-Run Ping สำเร็จ (HTTP ${res.status}, ${res.latencyMs}ms)`;
        state.isError = false;
        return paint();
      }
      if (act === 'approve-queue') {
        await fetchJson('/api/v2/erp/outbound-queue/approve', { method: 'POST', body: { id } });
        state.notice = 'อนุมัติและส่งข้อมูลเข้า ERP เรียบร้อยแล้ว';
      } else if (act === 'reject-queue') {
        const reason = window.prompt('ระบุเหตุผลการยกเลิกรายการส่งเข้า ERP:', 'ข้อมูลไม่ตรงสลิป');
        if (reason === null) return;
        await fetchJson('/api/v2/erp/outbound-queue/reject', { method: 'POST', body: { id, reason } });
        state.notice = 'ปฏิเสธรายการส่งเข้า ERP เรียบร้อยแล้ว';
      } else if (act === 'revoke-key') {
        if (!window.confirm('ยืนยันเพิกถอน API Key นี้ทันที? ระบบภายนอกที่ใช้คีย์นี้จะถูกปฏิเสธ 401 ทันที')) return;
        await fetchJson('/api/v2/erp/keys/revoke', { method: 'POST', body: { id } });
        state.notice = 'เพิกถอน ERP API Key เรียบร้อยแล้ว';
      } else if (act === 'export-csv') {
        const q = state.actionFilter ? `?action=${encodeURIComponent(state.actionFilter)}` : '';
        const res = await fetch(`/api/v2/audit-logs/export-csv${q}`, { credentials: 'same-origin' });
        if (!res.ok) throw new Error(`Export CSV ล้มเหลว (HTTP ${res.status})`);
        const blobUrl = URL.createObjectURL(await res.blob());
        Object.assign(document.createElement('a'), { href: blobUrl, download: `omniflow-audit-logs-${new Date().toISOString().slice(0, 10)}.csv` }).click();
        URL.revokeObjectURL(blobUrl);
        return;
      }
      state.isError = false;
      await loadAll();
    } catch (err) {
      state.notice = err?.payload?.error || err?.message || 'ดำเนินการไม่สำเร็จ';
      state.isError = true;
      paint();
    }
  });

  await loadAll();
}
