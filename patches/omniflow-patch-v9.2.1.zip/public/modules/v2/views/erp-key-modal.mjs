// gateway/public/modules/v2/views/erp-key-modal.mjs
// OmniFlow Enterprise v2 — Create External ERP API Key Modal (One-Time Reveal) & Audit Diff Modal

import { esc, v2FetchJson } from '../v2-api.mjs';
import { lucideIcon, refreshLucideIcons } from '../v2-icons.mjs';

const SCOPE_OPTIONS = [
  { id: 'orders:read', label: 'orders:read — อ่านรายการออเดอร์' },
  { id: 'quotes:read', label: 'quotes:read — อ่านใบเสนอราคา' },
  { id: 'catalog:read', label: 'catalog:read — อ่านแคตตาล็อกและราคา' },
];

function prettyJson(raw) {
  if (raw === null || raw === undefined || raw === '') return '(ไม่มีข้อมูล)';
  if (typeof raw === 'object') return JSON.stringify(raw, null, 2);
  try {
    return JSON.stringify(JSON.parse(String(raw)), null, 2);
  } catch {
    return String(raw);
  }
}

function mountModal(id, iconName, title, subtitle, bodyHtml) {
  document.getElementById(id)?.remove();
  const overlay = document.createElement('div');
  overlay.id = id;
  overlay.className = 'fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm';
  overlay.innerHTML = `
    <div class="w-full max-w-2xl rounded-xl border border-zinc-800 bg-zinc-950 text-zinc-100 shadow-2xl overflow-hidden">
      <div class="flex items-center justify-between gap-3 px-5 py-3.5 border-b border-zinc-800 bg-zinc-900/60">
        <div class="flex items-center gap-2.5 min-w-0">
          <span class="p-2 rounded-lg bg-zinc-800 text-zinc-200">${lucideIcon(iconName, 'w-4 h-4')}</span>
          <div class="min-w-0">
            <h3 class="text-sm font-semibold text-zinc-100 truncate">${esc(title)}</h3>
            <p class="text-[11px] text-zinc-400 truncate">${esc(subtitle)}</p>
          </div>
        </div>
        <button type="button" data-close-modal class="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800">
          ${lucideIcon('x-circle', 'w-4 h-4')}
        </button>
      </div>
      <div data-modal-body class="p-5 max-h-[78vh] overflow-y-auto">${bodyHtml}</div>
    </div>`;

  const close = () => {
    document.removeEventListener('keydown', onKeyDown);
    overlay.remove();
  };
  const onKeyDown = (ev) => {
    if (ev.key === 'Escape') close();
  };
  overlay.addEventListener('click', (ev) => {
    if (ev.target === overlay || ev.target.closest('[data-close-modal]')) close();
  });
  document.addEventListener('keydown', onKeyDown);
  document.body.appendChild(overlay);
  refreshLucideIcons(overlay);
  return { overlay, body: overlay.querySelector('[data-modal-body]'), close };
}

export function openCreateErpKeyModal({ onCreated, fetchJson = v2FetchJson } = {}) {
  const scopesHtml = SCOPE_OPTIONS.map(
    (opt, idx) => `
      <label class="flex items-center gap-2.5 p-2.5 rounded-lg border border-zinc-800 bg-zinc-900/50 cursor-pointer hover:border-zinc-700 text-xs">
        <input type="checkbox" name="erpScope" value="${esc(opt.id)}" ${idx === 0 ? 'checked' : ''} class="rounded border-zinc-600 bg-zinc-950 text-emerald-500" />
        <span class="text-zinc-200">${esc(opt.label)}</span>
      </label>`
  ).join('');

  const formHtml = `
    <form id="erpCreateKeyForm" class="space-y-4 text-xs">
      <div>
        <label class="block font-medium text-zinc-300 mb-1.5">ชื่อ API Key *</label>
        <input id="erpKeyNameInput" type="text" required maxlength="100" placeholder="เช่น PEAK_Accounting_Sync" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100 focus:outline-none focus:border-zinc-500" />
      </div>
      <div>
        <label class="block font-medium text-zinc-300 mb-1.5">สิทธิ์การเข้าถึง (Scopes) *</label>
        <div class="space-y-2">${scopesHtml}</div>
      </div>
      <div>
        <label class="block font-medium text-zinc-300 mb-1.5">วันหมดอายุ (ไม่บังคับ)</label>
        <input id="erpKeyExpiresInput" type="datetime-local" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100 focus:outline-none focus:border-zinc-500" />
      </div>
      <div id="erpCreateKeyErr" class="hidden p-2.5 rounded-lg border border-rose-500/40 bg-rose-950/40 text-rose-200"></div>
      <div class="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
        <button type="button" data-close-modal class="px-3.5 py-2 rounded-lg border border-zinc-700 text-zinc-300 hover:bg-zinc-800">ยกเลิก</button>
        <button id="erpCreateKeySubmit" type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 font-semibold hover:bg-white">
          ${lucideIcon('key-round', 'w-3.5 h-3.5')}<span>สร้าง API Key</span>
        </button>
      </div>
    </form>`;

  const modal = mountModal('erpCreateKeyModal', 'key-round', 'สร้าง External ERP API Key', 'เก็บเฉพาะ SHA-256 Hash ในฐานข้อมูล', formHtml);
  const form = modal.body.querySelector('#erpCreateKeyForm');
  const errEl = modal.body.querySelector('#erpCreateKeyErr');
  const submitBtn = modal.body.querySelector('#erpCreateKeySubmit');

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const keyName = modal.body.querySelector('#erpKeyNameInput').value.trim();
    const scopes = [...modal.body.querySelectorAll('input[name="erpScope"]:checked')].map((el) => el.value);
    const rawExp = modal.body.querySelector('#erpKeyExpiresInput').value.trim();
    if (!keyName || scopes.length === 0) {
      errEl.textContent = 'กรุณากรอกชื่อ Key และเลือกอย่างน้อย 1 สิทธิ์ (Scope)';
      errEl.classList.remove('hidden');
      return;
    }
    errEl.classList.add('hidden');
    submitBtn.disabled = true;
    try {
      const payload = { keyName, scopes };
      if (rawExp) payload.expiresAt = new Date(rawExp).toISOString();
      const res = await fetchJson('/api/v2/erp/keys', { method: 'POST', body: payload });
      const rawKey = res?.key?.rawKey || '';
      if (typeof onCreated === 'function') onCreated(res.key);
      modal.body.innerHTML = `
        <div class="space-y-4 text-xs">
          <div class="flex items-start gap-2.5 p-3 rounded-lg border border-amber-500/40 bg-amber-950/30 text-amber-200">
            ${lucideIcon('alert-triangle', 'w-4 h-4 shrink-0 mt-0.5')}
            <div>
              <div class="font-semibold">คีย์ฉบับเต็มจะแสดงเพียงครั้งเดียวนี้เท่านั้น</div>
              <p class="text-amber-200/80 mt-0.5">กรุณาคัดลอกและนำไปเก็บในระบบ ERP/บัญชีของคุณทันที หลังจากปิดหน้าต่างนี้จะไม่สามารถดูคีย์เต็มได้อีก</p>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <input id="erpRevealRawKey" type="text" readonly value="${esc(rawKey)}" class="flex-1 px-3 py-2.5 rounded-lg border border-zinc-700 bg-zinc-900 font-mono text-emerald-300 text-xs" />
            <button id="erpCopyRawKeyBtn" type="button" class="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-lg bg-zinc-100 text-zinc-950 font-semibold hover:bg-white">
              ${lucideIcon('copy', 'w-3.5 h-3.5')}<span>คัดลอก</span>
            </button>
          </div>
          <div class="flex justify-end pt-2 border-t border-zinc-800">
            <button type="button" data-close-modal class="px-4 py-2 rounded-lg border border-zinc-700 text-zinc-200 hover:bg-zinc-800 font-medium">ปิดหน้าต่าง</button>
          </div>
        </div>`;
      refreshLucideIcons(modal.overlay);
      const copyBtn = modal.body.querySelector('#erpCopyRawKeyBtn');
      const keyInput = modal.body.querySelector('#erpRevealRawKey');
      copyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(rawKey);
        } catch {
          keyInput.select();
        }
        copyBtn.innerHTML = `${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>คัดลอกแล้ว</span>`;
        refreshLucideIcons(copyBtn);
      });
    } catch (err) {
      errEl.textContent = err?.message || 'สร้าง API Key ไม่สำเร็จ';
      errEl.classList.remove('hidden');
      submitBtn.disabled = false;
    }
  });
}

export function openAuditDiffModal(logRow = {}) {
  const subtitle = `${logRow.actor_id || '-'} (${logRow.actor_role || '-'}) • ${logRow.created_at || '-'}`;
  const bodyHtml = `
    <div class="space-y-4 text-xs">
      <div class="flex flex-wrap items-center gap-2 text-[11px]">
        <span class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 font-mono text-zinc-200">${esc(logRow.action || '-')}</span>
        <span class="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 font-mono text-zinc-400">${esc(logRow.target_type || '-')}:${esc(logRow.target_id || '-')}</span>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div class="rounded-lg border border-rose-500/30 bg-zinc-900/70 p-3">
          <div class="text-[11px] font-semibold text-rose-300 mb-2">ก่อนแก้ไข (Before)</div>
          <pre class="text-[11px] font-mono text-zinc-300 whitespace-pre-wrap break-all overflow-x-auto max-h-72">${esc(prettyJson(logRow.before_json))}</pre>
        </div>
        <div class="rounded-lg border border-emerald-500/30 bg-zinc-900/70 p-3">
          <div class="text-[11px] font-semibold text-emerald-300 mb-2">หลังแก้ไข (After)</div>
          <pre class="text-[11px] font-mono text-zinc-300 whitespace-pre-wrap break-all overflow-x-auto max-h-72">${esc(prettyJson(logRow.after_json))}</pre>
        </div>
      </div>
      <div class="flex justify-end pt-2 border-t border-zinc-800">
        <button type="button" data-close-modal class="px-4 py-2 rounded-lg border border-zinc-700 text-zinc-200 hover:bg-zinc-800">ปิด</button>
      </div>
    </div>`;
  mountModal('erpAuditDiffModal', 'eye', 'เปรียบเทียบข้อมูล Audit Log (Before / After)', subtitle, bodyHtml);
}
