// gateway/public/modules/v2/views/settings-suite.view.mjs
// OmniFlow Enterprise v2 — Phase 1A Settings Suite (5 Categories: Account, System, Notifications, Billing, About)

import { esc, v2FetchJson } from '../v2-api.mjs';
import { lucideIcon, refreshLucideIcons } from '../v2-icons.mjs';

const CATEGORIES = [
  { id: 'account', icon: 'shield-check', label: 'บัญชีและความปลอดภัย' },
  { id: 'system', icon: 'server', label: 'ระบบและการเริ่มต้น' },
  { id: 'notifications', icon: 'bell', label: 'การแจ้งเตือนและเสียง' },
  { id: 'billing', icon: 'receipt', label: 'หัวบิลและใบเสร็จ PDF' },
  { id: 'about', icon: 'activity', label: 'เกี่ยวกับและแจ้งซ่อม' },
];

function buildAccountPanel(state) {
  const acc = state.bootstrap?.account || {};
  const s = state.settings;
  return `
    <div class="space-y-4 text-xs">
      <div class="flex flex-wrap items-center justify-between gap-3 p-4 rounded-xl border border-zinc-800 bg-zinc-900/50">
        <div>
          <div class="font-semibold text-zinc-100">${esc(acc.full_name || 'ผู้ดูแลระบบ (Owner)')}</div>
          <div class="text-[11px] text-zinc-400 mt-0.5">${esc(acc.company_name || 'OmniFlow Workspace')} • สถานะเซสชัน: ${state.bootstrap?.authenticated ? 'ล็อกอินถาวรอยู่' : 'โหมดแอดมินท้องถิ่น'}</div>
        </div>
        <button type="button" data-ss-act="logout" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-rose-500/40 bg-rose-950/30 text-rose-300 hover:bg-rose-950/60 font-semibold">${lucideIcon('log-out', 'w-3.5 h-3.5')}<span>ออกจากระบบ (Logout)</span></button>
      </div>
      <form id="ssSettingsForm" class="p-4 rounded-xl border border-zinc-800 bg-zinc-900/40 space-y-3">
        <div class="font-semibold text-zinc-100 flex items-center gap-2">${lucideIcon('lock', 'w-4 h-4 text-cyan-400')}<span>ตั้งเวลาล็อกหน้าจออัตโนมัติ (Auto-Lock)</span></div>
        <div class="max-w-xs">
          <label class="block text-zinc-400 mb-1">ล็อกหน้าจอเมื่อไม่มีการใช้งาน (นาที, 0 = ปิด)</label>
          <input name="autoLockMinutes" type="number" min="0" max="1440" value="${esc(s.autoLockMinutes ?? 0)}" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100" />
        </div>
        <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>บันทึกเวลา Auto-Lock</span></button>
      </form>
      <form id="ssPasswordForm" class="p-4 rounded-xl border border-zinc-800 bg-zinc-900/40 space-y-3">
        <div class="font-semibold text-zinc-100 flex items-center gap-2">${lucideIcon('key-round', 'w-4 h-4 text-amber-400')}<span>เปลี่ยนรหัสผ่านบัญชีหลัก</span></div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-2.5">
          <input name="currentPassword" type="password" required placeholder="รหัสผ่านปัจจุบัน *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100" />
          <input name="newPassword" type="password" required minlength="6" placeholder="รหัสผ่านใหม่ (>= 6 ตัวอักษร) *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100" />
          <input name="confirmPassword" type="password" required minlength="6" placeholder="ยืนยันรหัสผ่านใหม่ *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100" />
        </div>
        <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-zinc-700 text-zinc-100 hover:bg-zinc-800 font-semibold">${lucideIcon('key-round', 'w-3.5 h-3.5')}<span>อัปเดตรหัสผ่าน</span></button>
      </form>
    </div>`;
}

function buildSystemPanel(s) {
  const tm = String(s.tunnelMode || 'off');
  return `
    <form id="ssSettingsForm" class="space-y-4 text-xs">
      <div class="p-4 rounded-xl border border-zinc-800 bg-zinc-900/40 space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div class="font-semibold text-zinc-100">เปิดโปรแกรมอัตโนมัติตอนเปิดคอมพิวเตอร์ (Windows Boot)</div>
            <div class="text-[11px] text-zinc-400 mt-0.5">ดาวน์โหลดไฟล์ .bat แล้วนำไปวางในโฟลเดอร์ Startup (กด Win+R พิมพ์ shell:startup)</div>
          </div>
          <label class="inline-flex items-center gap-2 cursor-pointer text-zinc-200"><input name="autoStartEnabled" type="checkbox" ${s.autoStartEnabled ? 'checked' : ''} class="rounded border-zinc-600 bg-zinc-950" /><span>เปิดใช้ Auto-Start</span></label>
        </div>
        <button type="button" data-ss-act="download-bat" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-cyan-500/40 bg-cyan-950/30 text-cyan-200 hover:bg-cyan-950/60 font-medium">${lucideIcon('download', 'w-3.5 h-3.5')}<span>ดาวน์โหลด omniflow-autostart.bat</span></button>
      </div>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 rounded-xl border border-zinc-800 bg-zinc-900/40">
        <div><label class="block text-zinc-300 font-medium mb-1">พอร์ต Gateway (1024 - 65535)</label><input name="gatewayPort" type="number" min="1024" max="65535" value="${esc(s.gatewayPort ?? 4001)}" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
        <div>
          <label class="block text-zinc-300 font-medium mb-1">โหมด Cloudflare Tunnel</label>
          <select name="tunnelMode" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100">
            <option value="off" ${tm === 'off' ? 'selected' : ''}>ปิดใช้งาน (Local Only)</option>
            <option value="quick" ${tm === 'quick' ? 'selected' : ''}>Quick Tunnel (ชั่วคราว)</option>
            <option value="named" ${tm === 'named' ? 'selected' : ''}>Named Tunnel (โดเมนถาวร)</option>
          </select>
        </div>
      </div>
      <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>บันทึกการตั้งค่าระบบ</span></button>
    </form>`;
}

function buildNotificationsPanel(s) {
  return `
    <form id="ssSettingsForm" class="space-y-4 text-xs">
      <div class="flex items-center justify-between gap-3 p-4 rounded-xl border border-zinc-800 bg-zinc-900/40">
        <div>
          <div class="font-semibold text-zinc-100">เสียงแจ้งเตือนแชทและออเดอร์เข้า</div>
          <div class="text-[11px] text-zinc-400">เล่นเสียงแจ้งเตือนบนเบราว์เซอร์เมื่อมีลูกค้าทักหรือส่งสลิปใหม่</div>
        </div>
        <label class="inline-flex items-center gap-2 cursor-pointer text-zinc-200"><input name="soundEnabled" type="checkbox" ${s.soundEnabled !== false ? 'checked' : ''} class="rounded border-zinc-600 bg-zinc-950" /><span>เปิดเสียงแจ้งเตือน</span></label>
      </div>
      <div class="p-4 rounded-xl border border-zinc-800 bg-zinc-900/40 space-y-3">
        <div class="font-semibold text-zinc-100 flex items-center gap-2">${lucideIcon('moon', 'w-4 h-4 text-indigo-400')}<span>ช่วงเวลางดส่งเสียงแจ้งเตือน (Quiet Hours)</span></div>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
          <div><label class="block text-zinc-400 mb-1">เริ่มงดเสียง (HH:MM)</label><input name="quietHoursStart" type="time" value="${esc(s.quietHoursStart || '21:00')}" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
          <div><label class="block text-zinc-400 mb-1">สิ้นสุด (HH:MM)</label><input name="quietHoursEnd" type="time" value="${esc(s.quietHoursEnd || '08:30')}" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
        </div>
      </div>
      <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>บันทึกการแจ้งเตือน</span></button>
    </form>`;
}

function buildBillingPanel(s) {
  const logoPreview = s.receiptLogoUrl
    ? `<img src="${esc(s.receiptLogoUrl)}" alt="Receipt Logo" class="h-12 w-auto rounded border border-zinc-700 bg-white/95 p-1 object-contain" />`
    : '<span class="text-[11px] text-zinc-500">ยังไม่ได้กำหนดโลโก้หัวบิล</span>';
  return `
    <form id="ssSettingsForm" class="space-y-4 text-xs">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-3 p-4 rounded-xl border border-zinc-800 bg-zinc-900/40">
        <div><label class="block text-zinc-300 font-medium mb-1">เลขประจำตัวผู้เสียภาษี (Tax ID)</label><input name="taxId" type="text" maxlength="32" value="${esc(s.taxId || '')}" placeholder="เช่น 0105566778899" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
        <div><label class="block text-zinc-300 font-medium mb-1">คำนำหน้าเลขที่บิล (Invoice Prefix)</label><input name="invoicePrefix" type="text" maxlength="32" required value="${esc(s.invoicePrefix || 'INV-2026-')}" placeholder="INV-2026-" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono" /></div>
        <div class="md:col-span-2"><label class="block text-zinc-300 font-medium mb-1">ที่อยู่ร้านค้าบนหัวใบเสร็จ / ใบเสนอราคา PDF</label><textarea name="storeAddress" rows="3" maxlength="500" placeholder="เลขที่ ถนน แขวง/ตำบล เขต/อำเภอ จังหวัด รหัสไปรษณีย์" class="w-full px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100">${esc(s.storeAddress || '')}</textarea></div>
        <div class="md:col-span-2 space-y-2">
          <label class="block text-zinc-300 font-medium">โลโก้หัวบิล (URL หรืออัปโหลดไฟล์ PNG/JPG/WebP)</label>
          <div class="flex flex-wrap items-center gap-2">
            <input id="ssLogoUrlInput" name="receiptLogoUrl" type="text" value="${esc(s.receiptLogoUrl || '')}" placeholder="https://... หรือ data:image/png;base64,..." class="flex-1 min-w-[220px] px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-950 text-zinc-100 font-mono text-[11px]" />
            <label class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-zinc-700 text-zinc-200 hover:bg-zinc-800 cursor-pointer">${lucideIcon('upload', 'w-3.5 h-3.5')}<span>เลือกไฟล์รูป</span><input id="ssLogoFileInput" type="file" accept="image/png,image/jpeg,image/webp" class="hidden" /></label>
          </div>
          <div class="pt-1">${logoPreview}</div>
        </div>
      </div>
      <button type="submit" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('check-circle-2', 'w-3.5 h-3.5')}<span>บันทึกข้อมูลหัวบิล PDF</span></button>
    </form>`;
}

function buildAboutPanel(diag) {
  const c = diag?.counts || {};
  return `
    <div class="space-y-4 text-xs">
      <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div class="p-3 rounded-xl border border-zinc-800 bg-zinc-900/50"><div class="text-[11px] text-zinc-400">เวอร์ชันโปรแกรม</div><div class="font-mono font-bold text-cyan-300 mt-1">${esc(diag?.appVersion || '2.2.1-v2')}</div></div>
        <div class="p-3 rounded-xl border border-zinc-800 bg-zinc-900/50"><div class="text-[11px] text-zinc-400">Node Runtime</div><div class="font-mono font-semibold text-zinc-100 mt-1">${esc(diag?.nodeVersion || '-')}</div></div>
        <div class="p-3 rounded-xl border border-zinc-800 bg-zinc-900/50"><div class="text-[11px] text-zinc-400">ฐานข้อมูล SQLite</div><div class="font-mono font-semibold ${diag?.dbOk ? 'text-emerald-300' : 'text-rose-300'} mt-1">${diag?.dbOk ? `OK (${esc(diag.journalMode)})` : 'ERROR'}</div></div>
        <div class="p-3 rounded-xl border border-zinc-800 bg-zinc-900/50"><div class="text-[11px] text-zinc-400">Uptime</div><div class="font-mono font-semibold text-zinc-100 mt-1">${esc(diag?.uptimeSec ?? 0)} วินาที</div></div>
      </div>
      <div class="p-4 rounded-xl border border-zinc-800 bg-zinc-900/40 space-y-2">
        <div class="font-semibold text-zinc-100">สรุปสถิติระบบ (Sanitized — ไม่มี API Key หรือข้อมูลลับ)</div>
        <div class="grid grid-cols-2 sm:grid-cols-5 gap-2 font-mono text-[11px] text-zinc-300">
          <div class="p-2 rounded bg-zinc-950 border border-zinc-800">Accounts: ${esc(c.accounts ?? 0)}</div>
          <div class="p-2 rounded bg-zinc-950 border border-zinc-800">Workspaces: ${esc(c.workspaces ?? 0)}</div>
          <div class="p-2 rounded bg-zinc-950 border border-zinc-800">Sessions: ${esc(c.activeSessions ?? 0)}</div>
          <div class="p-2 rounded bg-zinc-950 border border-zinc-800">Audit Logs: ${esc(c.auditLogs ?? 0)}</div>
          <div class="p-2 rounded bg-zinc-950 border border-zinc-800">ERP Keys: ${esc(c.erpApiKeys ?? 0)}</div>
        </div>
      </div>
      <div class="flex flex-wrap items-center gap-2">
        <button type="button" data-ss-act="refresh-diag" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-zinc-700 text-zinc-200 hover:bg-zinc-800 font-medium">${lucideIcon('refresh-cw', 'w-3.5 h-3.5')}<span>รีเฟรชสถานะ</span></button>
        <button type="button" data-ss-act="export-diag" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('download', 'w-3.5 h-3.5')}<span>Export Log แจ้งซ่อม (.json)</span></button>
      </div>
    </div>`;
}

export async function render(viewport, api = {}) {
  const fetchJson = api?.v2FetchJson || v2FetchJson;
  const state = { tab: 'account', settings: {}, diagnostics: null, bootstrap: null, notice: '', isError: false };
  const root = document.createElement('div');
  root.className = 'grid grid-cols-1 lg:grid-cols-12 gap-4 text-zinc-100';
  viewport.replaceChildren(root);

  const paint = () => {
    const navHtml = CATEGORIES.map((c) => {
      const active = state.tab === c.id;
      return `<button type="button" data-ss-tab="${esc(c.id)}" class="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs text-left transition ${active ? 'bg-zinc-800 text-zinc-100 font-semibold border border-zinc-700' : 'text-zinc-400 hover:text-zinc-100 hover:bg-zinc-900'}">${lucideIcon(c.icon, 'w-4 h-4')}<span>${esc(c.label)}</span></button>`;
    }).join('');
    const noticeHtml = state.notice
      ? `<div class="flex items-center gap-2 px-3.5 py-2.5 rounded-lg border text-xs mb-4 ${state.isError ? 'border-rose-500/40 bg-rose-950/40 text-rose-200' : 'border-emerald-500/40 bg-emerald-950/30 text-emerald-200'}">${lucideIcon(state.isError ? 'alert-triangle' : 'check-circle-2', 'w-4 h-4 shrink-0')}<span>${esc(state.notice)}</span></div>`
      : '';
    const panelHtml = state.tab === 'account' ? buildAccountPanel(state)
      : state.tab === 'system' ? buildSystemPanel(state.settings)
      : state.tab === 'notifications' ? buildNotificationsPanel(state.settings)
      : state.tab === 'billing' ? buildBillingPanel(state.settings)
      : buildAboutPanel(state.diagnostics);
    root.innerHTML = `<aside class="lg:col-span-3 rounded-xl border border-zinc-800 bg-zinc-950/85 p-3 space-y-1 h-fit"><div class="px-2 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-zinc-400">ตั้งค่าระบบ (5 หมวด)</div>${navHtml}</aside><main class="lg:col-span-9 rounded-xl border border-zinc-800 bg-zinc-950/85 p-5">${noticeHtml}${panelHtml}</main>`;
    refreshLucideIcons(root);
  };

  const loadAll = async () => {
    try {
      const [sRes, dRes, bRes] = await Promise.all([fetchJson('/api/v2/settings-suite'), fetchJson('/api/v2/settings-suite/diagnostics'), fetchJson('/api/v2/auth/bootstrap-status')]);
      state.settings = sRes.settings || {}; state.diagnostics = dRes.diagnostics || null; state.bootstrap = bRes || null;
      paint();
    } catch (err) {
      state.notice = err?.message || 'โหลดข้อมูลการตั้งค่าไม่สำเร็จ'; state.isError = true; paint();
    }
  };

  root.addEventListener('change', (ev) => {
    if (ev.target.id !== 'ssLogoFileInput') return;
    const file = ev.target.files?.[0];
    if (!file) return;
    const form = root.querySelector('#ssSettingsForm');
    if (form) {
      const fd = new FormData(form);
      ['taxId', 'invoicePrefix', 'storeAddress'].forEach((k) => {
        if (fd.has(k)) state.settings[k] = String(fd.get(k) || '');
      });
    }
    const reader = new FileReader();
    reader.onload = () => { state.settings.receiptLogoUrl = String(reader.result || ''); paint(); };
    reader.readAsDataURL(file);
  });

  root.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    try {
      if (ev.target.id === 'ssPasswordForm') {
        const currentPassword = String(fd.get('currentPassword') || '');
        const newPassword = String(fd.get('newPassword') || '');
        if (newPassword !== String(fd.get('confirmPassword') || '')) throw new Error('รหัสผ่านใหม่และการยืนยันรหัสผ่านไม่ตรงกัน');
        await fetchJson('/api/v2/auth/change-password', { method: 'POST', body: { currentPassword, newPassword } });
        ev.target.reset();
        state.notice = 'เปลี่ยนรหัสผ่านเรียบร้อยแล้ว ระบบออกจากระบบทุกอุปกรณ์เพื่อความปลอดภัย';
        state.isError = false;
        paint();
        window.dispatchEvent(new CustomEvent('omniflow:v2:logged-out'));
        return;
      }
      if (ev.target.id === 'ssSettingsForm') {
        const patch = {};
        if (state.tab === 'account') patch.autoLockMinutes = Number(fd.get('autoLockMinutes') || 0);
        if (state.tab === 'system') Object.assign(patch, { autoStartEnabled: Boolean(fd.get('autoStartEnabled')), gatewayPort: Number(fd.get('gatewayPort') || 4001), tunnelMode: String(fd.get('tunnelMode') || 'off') });
        if (state.tab === 'notifications') Object.assign(patch, { soundEnabled: Boolean(fd.get('soundEnabled')), quietHoursStart: String(fd.get('quietHoursStart') || '21:00'), quietHoursEnd: String(fd.get('quietHoursEnd') || '08:30') });
        if (state.tab === 'billing') Object.assign(patch, { taxId: String(fd.get('taxId') || ''), invoicePrefix: String(fd.get('invoicePrefix') || 'INV-2026-'), storeAddress: String(fd.get('storeAddress') || ''), receiptLogoUrl: String(fd.get('receiptLogoUrl') || '') });
        const res = await fetchJson('/api/v2/settings-suite', { method: 'PUT', body: patch });
        state.settings = res.settings || { ...state.settings, ...patch };
        window.dispatchEvent(new CustomEvent('omniflow:v2:settings-updated', { detail: state.settings }));
        state.notice = 'บันทึกการตั้งค่าเรียบร้อยแล้ว'; state.isError = false; paint();
      }
    } catch (err) {
      state.notice = err?.message || 'บันทึกไม่สำเร็จ'; state.isError = true; paint();
    }
  });

  root.addEventListener('click', async (ev) => {
    const tabBtn = ev.target.closest('[data-ss-tab]');
    if (tabBtn) { state.tab = tabBtn.dataset.ssTab; state.notice = ''; paint(); return; }
    const actBtn = ev.target.closest('[data-ss-act]');
    if (!actBtn) return;
    const act = actBtn.dataset.ssAct;
    try {
      if (act === 'logout') {
        if (!window.confirm('ยืนยันออกจากระบบ (Logout) และยกเลิก Persistent Session ปัจจุบัน?')) return;
        await fetchJson('/api/v2/auth/logout', { method: 'POST' });
        window.dispatchEvent(new CustomEvent('omniflow:v2:logged-out'));
        state.notice = 'ออกจากระบบเรียบร้อยแล้ว'; state.isError = false; await loadAll();
      } else if (act === 'download-bat') {
        const port = window.location.port || state.settings.gatewayPort || 4001;
        const res = await fetch(`/api/v2/settings-suite/startup-script?port=${encodeURIComponent(port)}`, { credentials: 'same-origin' });
        if (!res.ok) throw new Error(`ดาวน์โหลดสคริปต์ไม่สำเร็จ (HTTP ${res.status})`);
        const url = URL.createObjectURL(await res.blob());
        Object.assign(document.createElement('a'), { href: url, download: 'omniflow-autostart.bat' }).click();
        URL.revokeObjectURL(url);
      } else if (act === 'refresh-diag') {
        state.diagnostics = (await fetchJson('/api/v2/settings-suite/diagnostics')).diagnostics;
        state.notice = 'อัปเดตสถานะระบบล่าสุดแล้ว'; state.isError = false; paint();
      } else if (act === 'export-diag') {
        const dRes = await fetchJson('/api/v2/settings-suite/diagnostics');
        const url = URL.createObjectURL(new Blob([JSON.stringify(dRes.diagnostics || {}, null, 2)], { type: 'application/json' }));
        Object.assign(document.createElement('a'), { href: url, download: `omniflow-diagnostics-${new Date().toISOString().slice(0, 10)}.json` }).click();
        URL.revokeObjectURL(url);
      }
    } catch (err) {
      state.notice = err?.message || 'ดำเนินการไม่สำเร็จ'; state.isError = true; paint();
    }
  });

  await loadAll();
}
