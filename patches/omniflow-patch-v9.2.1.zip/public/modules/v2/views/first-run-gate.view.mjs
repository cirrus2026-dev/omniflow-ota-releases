// gateway/public/modules/v2/views/first-run-gate.view.mjs
// OmniFlow Enterprise v2 — Phase 1A First-Run Onboarding Gate (Signup + OTP Free 6M, Login & 3-Tier License Keys)

import { esc, v2FetchJson } from '../v2-api.mjs';
import { lucideIcon, refreshLucideIcons } from '../v2-icons.mjs';

const DEMO_LICENSE_KEYS = Object.freeze([
  ['Starter', 'OMNI-STARTER-2026-TRIAL'],
  ['Pro', 'OMNI-PRO-2026-TRIAL'],
  ['Enterprise', 'OMNI-ENTERPRISE-2026-VIP'],
]);

function buildAuthenticatedCard(status) {
  const ws = status.workspace || {};
  const sub = status.subscription || {};
  const acc = status.account || {};
  const planCode = String(sub.plan_code || 'free_6m').toLowerCase();
  const planLabel = planCode === 'free_6m' ? 'FREE 6M (ทดลองฟรี 6 เดือน)' : planCode.toUpperCase();
  const days = status.daysRemaining ?? sub.daysRemaining;
  const daysBadge = Number.isFinite(Number(days))
    ? `<span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-medium border border-emerald-500/40 bg-emerald-950/40 text-emerald-300">${lucideIcon('clock', 'w-3.5 h-3.5')}<span>คงเหลือ ${esc(days)} วัน</span></span>`
    : '';
  return `
    <div class="w-full max-w-lg mx-auto rounded-2xl border border-zinc-800 bg-zinc-950/95 p-6 space-y-5 shadow-2xl text-xs">
      <div class="flex items-start justify-between gap-3 border-b border-zinc-800 pb-4">
        <div class="flex items-center gap-3">
          <div class="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300">${lucideIcon('shield-check', 'w-5 h-5')}</div>
          <div>
            <h2 class="text-base font-bold text-zinc-100">เข้าสู่ระบบแบบถาวรเรียบร้อยแล้ว</h2>
            <p class="text-zinc-400 mt-0.5">${esc(ws.name || acc.company_name || 'OmniFlow Workspace')} • ${esc(acc.full_name || 'ผู้ดูแลระบบ')}</p>
          </div>
        </div>
      </div>
      <div class="flex flex-wrap items-center gap-2">
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold border border-cyan-500/40 bg-cyan-950/40 text-cyan-300">${lucideIcon('gift', 'w-3.5 h-3.5')}<span>${esc(planLabel)}</span></span>
        ${daysBadge}
      </div>
      <div class="rounded-lg border border-zinc-800 bg-zinc-900/60 p-3 text-zinc-400">เซสชัน HttpOnly Persistent Login กำลังทำงานอยู่ (ใช้งานต่อเนื่องจนกว่าจะกด Logout)</div>
      <div class="flex items-center justify-between gap-2 pt-2">
        <button type="button" data-gate-act="logout" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-rose-500/40 bg-rose-950/30 text-rose-300 hover:bg-rose-950/60 font-medium">${lucideIcon('log-out', 'w-3.5 h-3.5')}<span>ออกจากระบบ</span></button>
        <button type="button" data-gate-act="enter-app" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-zinc-100 text-zinc-950 hover:bg-white font-semibold"><span>เข้าสู่หน้าหลัก OmniFlow</span>${lucideIcon('arrow-right', 'w-3.5 h-3.5')}</button>
      </div>
    </div>`;
}

function buildSignupForm(state) {
  const plan = state.planCode || 'free_6m';
  const otpBlock = state.pendingAccountId
    ? `<div class="rounded-xl border border-cyan-500/40 bg-cyan-950/20 p-4 space-y-3 mt-4">
        <div class="flex items-center gap-2 text-cyan-300 font-semibold">${lucideIcon('key-round', 'w-4 h-4')}<span>ขั้นตอนที่ 2: ยืนยันรหัส OTP (Sandbox: 123456)</span></div>
        <div class="flex gap-2">
          <input id="frgOtpInput" type="text" maxlength="10" value="${esc(state.devOtpHint || '')}" placeholder="กรอกรหัส OTP 6 หลัก" class="flex-1 px-3 py-2 rounded-lg border border-zinc-700 bg-zinc-900 text-zinc-100 font-mono" />
          <button type="button" data-gate-act="verify-otp" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-cyan-400 text-zinc-950 font-semibold hover:bg-cyan-300">${lucideIcon('check-circle-2', 'w-4 h-4')}<span>ยืนยัน OTP &amp; เปิดใช้งาน</span></button>
        </div>
      </div>`
    : '';
  return `
    <form id="frgSignupForm" class="space-y-3.5 text-xs">
      <div>
        <label class="block text-zinc-300 font-medium mb-1.5">เลือกแพ็กเกจเริ่มต้น</label>
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <label class="flex items-start gap-2.5 p-3 rounded-xl border ${plan === 'free_6m' ? 'border-emerald-500/60 bg-emerald-950/25' : 'border-zinc-800 bg-zinc-900/50'} cursor-pointer">
            <input type="radio" name="planCode" value="free_6m" ${plan === 'free_6m' ? 'checked' : ''} class="mt-0.5" />
            <span><strong class="block text-zinc-100">ทดลองใช้ฟรี 6 เดือน (180 วัน)</strong><span class="text-[11px] text-emerald-300">แพ็กเกจ free_6m • 0 บาท (แนะนำ)</span></span>
          </label>
          <label class="flex items-start gap-2.5 p-3 rounded-xl border ${plan === 'free_trial' ? 'border-zinc-500 bg-zinc-900' : 'border-zinc-800 bg-zinc-900/50'} cursor-pointer">
            <input type="radio" name="planCode" value="free_trial" ${plan === 'free_trial' ? 'checked' : ''} class="mt-0.5" />
            <span><strong class="block text-zinc-100">ทดลองใช้มาตรฐาน (14 วัน)</strong><span class="text-[11px] text-zinc-400">แพ็กเกจ free_trial • 0 บาท</span></span>
          </label>
        </div>
      </div>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <input name="companyName" required placeholder="ชื่อบริษัท / ร้านค้า *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" />
        <input name="fullName" required placeholder="ชื่อ-นามสกุลผู้ดูแล *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" />
        <input name="email" type="email" required placeholder="อีเมลสำหรับเข้าสู่ระบบ *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" />
        <input name="phone" placeholder="เบอร์โทรศัพท์ (ไม่บังคับ)" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" />
        <input name="password" type="password" required minlength="6" placeholder="ตั้งรหัสผ่าน (>= 6 ตัวอักษร) *" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" />
        <select name="teamSizeBucket" class="px-3 py-2 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100">
          <option value="1-2">ทีมงาน 1-2 คน</option><option value="3-10">ทีมงาน 3-10 คน</option><option value="11-50">ทีมงาน 11-50 คน</option>
        </select>
      </div>
      <div class="rounded-lg border border-zinc-800 bg-zinc-900/50 p-3 space-y-1.5 text-[11px] text-zinc-300">
        <label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" name="acceptTosDpa" required /><span>ยอมรับเงื่อนไขการใช้บริการและสัญญา B2B DPA *</span></label>
        <label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" name="acceptOnboardingComms" checked /><span>รับคำแนะนำการตั้งค่าระบบและแจ้งเตือนสำคัญ</span></label>
      </div>
      <button type="submit" class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('user-plus', 'w-4 h-4')}<span>สมัครสมาชิกและรับรหัส OTP</span></button>
    </form>${otpBlock}`;
}

function buildLoginForm() {
  return `
    <form id="frgLoginForm" class="space-y-3.5 text-xs">
      <div><label class="block text-zinc-300 font-medium mb-1">อีเมลบัญชี OmniFlow</label><input name="email" type="email" required autocomplete="username" placeholder="owner@company.com" class="w-full px-3 py-2.5 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" /></div>
      <div><label class="block text-zinc-300 font-medium mb-1">รหัสผ่าน</label><input name="password" type="password" required autocomplete="current-password" placeholder="กรอกรหัสผ่านของคุณ" class="w-full px-3 py-2.5 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" /></div>
      <div class="rounded-lg border border-zinc-800 bg-zinc-900/50 p-2.5 text-[11px] text-zinc-400 flex items-center gap-2">${lucideIcon('shield-check', 'w-4 h-4 text-emerald-400 shrink-0')}<span>ระบบจะบันทึก HttpOnly Persistent Session ให้ล็อกอินครั้งเดียวใช้งานต่อเนื่องจนกว่าจะกด Logout</span></div>
      <button type="submit" class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-100 text-zinc-950 hover:bg-white font-semibold">${lucideIcon('log-in', 'w-4 h-4')}<span>เข้าสู่ระบบ OmniFlow</span></button>
    </form>`;
}

function buildLicenseForm() {
  const demoBtns = DEMO_LICENSE_KEYS.map(
    ([tier, key]) =>
      `<button type="button" data-fill-license="${esc(key)}" class="px-2.5 py-1.5 rounded-lg border border-cyan-500/40 bg-cyan-950/30 hover:bg-cyan-950/60 text-[11px] font-mono text-cyan-200 transition">${esc(tier)}: ${esc(key)}</button>`
  ).join('');
  return `
    <form id="frgLicenseForm" class="space-y-3.5 text-xs">
      <div><label class="block text-zinc-300 font-medium mb-1">รหัสคีย์แพ็กเกจ / คีย์โปรโมชัน (Product License Key) *</label><input id="frgLicenseKeyInput" name="licenseKey" required placeholder="เช่น OMNI-PRO-2026-TRIAL หรือคีย์ส่วนลดลูกค้า" class="w-full px-3 py-2.5 rounded-lg border border-zinc-700 bg-zinc-900 text-zinc-100 font-mono uppercase" /></div>
      <div><label class="block text-zinc-300 font-medium mb-1">ชื่อบริษัท / ร้านค้า (สำหรับสร้าง Workspace)</label><input name="companyName" placeholder="เช่น ร้านหินอ่อนราชา" class="w-full px-3 py-2.5 rounded-lg border border-zinc-800 bg-zinc-900 text-zinc-100" /></div>
      <div class="rounded-xl border border-zinc-800 bg-zinc-900/60 p-3 space-y-2"><div class="text-[11px] text-zinc-400">คีย์ทดสอบ 3 แพ็กเกจสำหรับสาธิตการขาย (คลิกเพื่อกรอก):</div><div class="flex flex-wrap gap-1.5">${demoBtns}</div></div>
      <button type="submit" class="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-400 text-zinc-950 hover:bg-cyan-300 font-semibold">${lucideIcon('key-round', 'w-4 h-4')}<span>ยืนยันคีย์แพ็กเกจ &amp; เปิดใช้งานทันที</span></button>
    </form>`;
}

export async function render(viewport, api = {}) {
  const fetchJson = api?.v2FetchJson || v2FetchJson;
  const onAuthenticated = typeof api?.onAuthenticated === 'function' ? api.onAuthenticated : null;
  const state = { loading: true, status: null, mode: 'signup', planCode: 'free_6m', pendingAccountId: null, devOtpHint: '', notice: '', isError: false };
  const root = document.createElement('div');
  root.className = 'w-full py-4 px-2 text-zinc-100';
  viewport.replaceChildren(root);

  const notifyAuth = (detail) => {
    window.dispatchEvent(new CustomEvent('omniflow:v2:authenticated', { detail }));
    if (onAuthenticated) onAuthenticated(detail);
  };

  const paint = () => {
    if (state.loading) {
      root.innerHTML = `<div class="max-w-md mx-auto p-6 rounded-2xl border border-zinc-800 bg-zinc-950 text-center text-xs text-zinc-400">กำลังตรวจสอบสถานะบัญชีและเซสชัน...</div>`;
      return;
    }
    if (state.status?.authenticated) {
      root.innerHTML = buildAuthenticatedCard(state.status);
      refreshLucideIcons(root);
      return;
    }
    const noticeHtml = state.notice
      ? `<div class="flex items-center gap-2 p-3 rounded-lg border text-xs ${state.isError ? 'border-rose-500/40 bg-rose-950/40 text-rose-200' : 'border-emerald-500/40 bg-emerald-950/30 text-emerald-200'}">${lucideIcon(state.isError ? 'alert-triangle' : 'check-circle-2', 'w-4 h-4 shrink-0')}<span>${esc(state.notice)}</span></div>`
      : '';
    const tabCls = (active) => active
      ? 'flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-zinc-800 text-zinc-100 font-semibold text-xs'
      : 'flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-zinc-400 hover:text-zinc-200 text-xs';
    const bodyHtml = state.mode === 'signup' ? buildSignupForm(state) : state.mode === 'license' ? buildLicenseForm() : buildLoginForm();

    root.innerHTML = `
      <div class="w-full max-w-xl mx-auto rounded-2xl border border-zinc-800 bg-zinc-950/95 p-6 space-y-4 shadow-2xl">
        <div class="flex items-center gap-3">
          <div class="p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-cyan-400">${lucideIcon('shield-check', 'w-5 h-5')}</div>
          <div>
            <h2 class="text-base font-bold text-zinc-100">ยินดีต้อนรับสู่ OmniFlow Enterprise v2</h2>
            <p class="text-xs text-zinc-400">${state.status?.hasAccount ? 'กรุณาเข้าสู่ระบบ สมัครบัญชีใหม่ หรือกรอกคีย์แพ็กเกจ' : 'เปิดใช้งานครั้งแรก: สมัครทดลองฟรี 6 เดือน หรือใช้รหัสคีย์แพ็กเกจ'}</p>
          </div>
        </div>
        <div class="flex flex-wrap gap-1.5 p-1 rounded-xl border border-zinc-800 bg-zinc-900/70">
          <button type="button" data-gate-mode="signup" class="${tabCls(state.mode === 'signup')}">${lucideIcon('user-plus', 'w-3.5 h-3.5')}<span>สมัครใช้งานครั้งแรก</span></button>
          <button type="button" data-gate-mode="login" class="${tabCls(state.mode === 'login')}">${lucideIcon('log-in', 'w-3.5 h-3.5')}<span>เข้าสู่ระบบด้วยอีเมล</span></button>
          <button type="button" data-gate-mode="license" class="${tabCls(state.mode === 'license')}">${lucideIcon('key-round', 'w-3.5 h-3.5')}<span>ใช้คีย์แพ็กเกจ (3 รุ่น)</span></button>
        </div>
        ${noticeHtml}${bodyHtml}
      </div>`;
    refreshLucideIcons(root);
  };

  const loadStatus = async () => {
    state.loading = true;
    paint();
    try {
      const res = await fetchJson('/api/v2/auth/bootstrap-status');
      state.status = res;
      state.mode = res.hasAccount ? 'login' : 'signup';
    } catch (err) {
      state.notice = err?.message || 'ตรวจสอบสถานะระบบไม่สำเร็จ';
      state.isError = true;
    } finally {
      state.loading = false;
      paint();
    }
  };

  root.addEventListener('change', (ev) => {
    if (ev.target.name === 'planCode') { state.planCode = ev.target.value; paint(); }
  });

  root.addEventListener('click', async (ev) => {
    const fillBtn = ev.target.closest('[data-fill-license]');
    if (fillBtn) { const inp = root.querySelector('#frgLicenseKeyInput'); if (inp) inp.value = fillBtn.dataset.fillLicense || ''; return; }
    const modeBtn = ev.target.closest('[data-gate-mode]');
    if (modeBtn) { state.mode = modeBtn.dataset.gateMode; state.notice = ''; paint(); return; }
    const actBtn = ev.target.closest('[data-gate-act]');
    if (!actBtn) return;
    const act = actBtn.dataset.gateAct;
    try {
      if (act === 'verify-otp') {
        const otp = root.querySelector('#frgOtpInput')?.value?.trim() || '';
        await fetchJson('/api/v2/saas/verify-otp', { method: 'POST', body: { accountId: state.pendingAccountId, otp, planCode: state.planCode, deviceLabel: 'web-first-run' } });
        state.pendingAccountId = null; state.mode = 'login';
        state.notice = 'ยืนยัน OTP สำเร็จแล้ว! กรุณาเข้าสู่ระบบด้วยอีเมลและรหัสผ่านของคุณ';
        state.isError = false; paint();
      } else if (act === 'logout') {
        await fetchJson('/api/v2/auth/logout', { method: 'POST' });
        state.notice = 'ออกจากระบบเรียบร้อยแล้ว'; state.isError = false; await loadStatus();
      } else if (act === 'enter-app') {
        notifyAuth(state.status);
      }
    } catch (err) {
      state.notice = err?.message || 'ดำเนินการไม่สำเร็จ'; state.isError = true; paint();
    }
  });

  root.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const fd = new FormData(ev.target);
    try {
      if (ev.target.id === 'frgSignupForm') {
        const planCode = String(fd.get('planCode') || state.planCode || 'free_6m');
        state.planCode = planCode;
        const res = await fetchJson('/api/v2/saas/signup', {
          method: 'POST',
          body: { companyName: fd.get('companyName'), fullName: fd.get('fullName'), email: fd.get('email'), phone: fd.get('phone'), password: fd.get('password'), teamSizeBucket: fd.get('teamSizeBucket'), planCode, acceptTosDpa: Boolean(fd.get('acceptTosDpa')), acceptOnboardingComms: Boolean(fd.get('acceptOnboardingComms')) },
        });
        state.pendingAccountId = res.accountId; state.devOtpHint = res.devOtpHint || '';
        state.notice = 'สร้างบัญชีแล้ว กรุณากรอกรหัส OTP ด้านล่างเพื่อเปิดสิทธิ์ใช้งาน';
        state.isError = false; paint();
      } else if (ev.target.id === 'frgLoginForm') {
        const res = await fetchJson('/api/v2/auth/login', { method: 'POST', body: { email: fd.get('email'), password: fd.get('password'), deviceLabel: 'web-login' } });
        state.notice = 'เข้าสู่ระบบสำเร็จ'; state.isError = false; await loadStatus(); notifyAuth(res);
      } else if (ev.target.id === 'frgLicenseForm') {
        const res = await fetchJson('/api/v2/saas/license/activate', { method: 'POST', body: { licenseKey: fd.get('licenseKey'), companyName: fd.get('companyName') || '', deviceLabel: 'web-license-gate' } });
        state.notice = 'เปิดใช้งานคีย์แพ็กเกจสำเร็จ!'; state.isError = false; await loadStatus(); notifyAuth(res);
      }
    } catch (err) {
      if (err?.code === 'OTP_REQUIRED' || err?.payload?.code === 'OTP_REQUIRED') {
        state.mode = 'signup'; state.pendingAccountId = err?.payload?.accountId || err?.data?.accountId || null;
        state.notice = 'บัญชีนี้ยังไม่ได้ยืนยัน OTP กรุณากรอกรหัส OTP ด้านล่าง'; state.isError = false; paint(); return;
      }
      state.notice = err?.message || 'ส่งข้อมูลไม่สำเร็จ'; state.isError = true; paint();
    }
  });

  await loadStatus();
}

export async function mountFirstRunOverlayIfNeeded({ onAuthenticated, fetchJson = v2FetchJson } = {}) {
  const status = await fetchJson('/api/v2/auth/bootstrap-status');
  if (status?.authenticated) return { needed: false, status };
  document.getElementById('v2FirstRunGateOverlay')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'v2FirstRunGateOverlay';
  overlay.className = 'fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-zinc-950/95 backdrop-blur-md overflow-y-auto';
  overlay.style.zIndex = '20000';
  document.body.appendChild(overlay);
  await render(overlay, { v2FetchJson: fetchJson, onAuthenticated: (detail) => { overlay.remove(); if (typeof onAuthenticated === 'function') onAuthenticated(detail); } });
  return { needed: true, status };
}
