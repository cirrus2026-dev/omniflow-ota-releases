// gateway/public/modules/v2/views/cat5-saas-growth.view.mjs
// Category 5: Platform Superadmin SaaS Growth, CAC/MRR, Funnel ROAS & Hot PQL Leads

import { esc, v2FetchJson } from '../v2-api.mjs';

export async function render(viewport, api) {
  const [metricsRes, roasRes, pqlRes] = await Promise.all([
    v2FetchJson('/api/v2/marketing/saas-metrics'),
    v2FetchJson('/api/v2/marketing/funnel-roas'),
    v2FetchJson('/api/v2/marketing/pql-hot'),
  ]);

  const m = metricsRes.metrics || {};
  const campaigns = roasRes.campaigns || [];
  const leads = pqlRes.leads || [];

  viewport.innerHTML = `
    <div class="v2-grid">
      <div class="v2-card sh-card v2-col-12">
        <span class="v2-badge v2-badge--ready">หมวดที่ 5 • Platform Superadmin</span>
        <h2 class="text-lg font-bold text-white mt-1.5 flex items-center gap-2"><i data-lucide="rocket" class="w-5 h-5 shrink-0 text-cyan-400"></i><span>ศูนย์บัญชาการเติบโตธุรกิจ SaaS (MRR, CAC, ROAS & Hot PQL)</span></h2>
      </div>

      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="gem" class="w-4 h-4 shrink-0 text-cyan-400"></i><span>รายได้ประจำ (MRR)</span></div>
        <div class="text-2xl font-bold text-cyan-300 mt-1">฿${esc(Number(m.mrrBaht || 0).toLocaleString('th-TH'))}</div>
        <div class="text-xs text-slate-400 mt-1">ARR: ฿${esc(Number(m.arrBaht || 0).toLocaleString('th-TH'))}</div>
      </div>
      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="target" class="w-4 h-4 shrink-0 text-amber-400"></i><span>ต้นทุนหาลูกค้า (CAC)</span></div>
        <div class="text-2xl font-bold text-amber-300 mt-1">฿${esc(Number(m.cacBaht || 0).toLocaleString('th-TH'))}</div>
        <div class="text-xs text-slate-400 mt-1">งบแอดรวม ฿${esc(Number(m.totalAdSpendBaht || 0).toLocaleString('th-TH'))}</div>
      </div>
      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="flame" class="w-4 h-4 shrink-0 text-emerald-400"></i><span>Trial ➔ Paid Conversion</span></div>
        <div class="text-2xl font-bold text-emerald-300 mt-1">${esc(m.trialToPaidPct ?? 0)}%</div>
        <div class="text-xs text-slate-400 mt-1">จ่ายเงิน ${esc(m.activePaidCount || 0)} / ทดลอง ${esc(m.trialingCount || 0)}</div>
      </div>
      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="trending-down" class="w-4 h-4 shrink-0 text-rose-400"></i><span>อัตรายกเลิก (Churn)</span></div>
        <div class="text-2xl font-bold text-white mt-1">${esc(m.churnPct ?? 0)}%</div>
        <div class="text-xs text-slate-400 mt-1">เป้าหมายองค์กร &lt; 3%</div>
      </div>

      <div class="v2-card sh-card v2-col-7">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="coins" class="w-4 h-4 shrink-0 text-amber-400"></i><span>ROAS & ประสิทธิภาพแคมเปญโฆษณา</span></h3>
        <div class="v2-table-wrap mb-3">
          <table class="v2-table">
            <thead><tr><th>แคมเปญ (UTM)</th><th>แพลตฟอร์ม</th><th>ค่าแอด</th><th>คนสมัคร</th><th>รายได้</th><th>ROAS</th></tr></thead>
            <tbody>
              ${campaigns.length ? campaigns.map((c) => `
                <tr>
                  <td class="font-mono text-xs">${esc(c.utmCampaign)}</td>
                  <td>${esc(c.adPlatform)}</td>
                  <td>฿${esc(c.spendBaht)}</td>
                  <td>${esc(c.signups)}</td>
                  <td class="text-emerald-300">฿${esc(c.revenueBaht)}</td>
                  <td class="font-bold text-cyan-300">${esc(c.roas)}x</td>
                </tr>
              `).join('') : '<tr><td colspan="6" class="text-center text-slate-400">ยังไม่มีข้อมูลค่าแอด</td></tr>'}
            </tbody>
          </table>
        </div>
        <form id="v2AdSpendForm" class="grid grid-cols-2 md:grid-cols-5 gap-2 text-xs">
          <input name="spendDate" type="date" required value="${new Date().toISOString().slice(0, 10)}" class="px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white" />
          <select name="adPlatform" class="px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white">
            <option value="meta">Meta</option><option value="google">Google</option><option value="tiktok">TikTok</option>
          </select>
          <input name="utmCampaign" required placeholder="UTM Campaign" class="px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white" />
          <input name="spendBaht" type="number" required min="0" placeholder="ค่าแอด (บาท)" class="px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white" />
          <button type="submit" class="v2-btn v2-btn--primary">+ บันทึกค่าแอด</button>
        </form>
      </div>

      <div class="v2-card sh-card v2-col-5">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="flame" class="w-4 h-4 shrink-0 text-orange-400"></i><span>Hot PQL (ลูกค้าทดลองใช้พร้อมซื้อ)</span></h3>
        <div class="v2-table-wrap">
          <table class="v2-table">
            <thead><tr><th>บริษัท</th><th>ขนาดทีม</th><th>ช่องทาง</th><th>คะแนน</th></tr></thead>
            <tbody>
              ${leads.length ? leads.map((l) => `
                <tr>
                  <td class="font-semibold">${esc(l.company_name)}</td>
                  <td>${esc(l.team_size_bucket)}</td>
                  <td>${esc(l.connected_channels_count)}</td>
                  <td><span class="v2-badge ${l.pql_score >= 80 ? 'v2-badge--ok' : 'v2-badge--ready'}">${esc(l.pql_score)}/100</span></td>
                </tr>
              `).join('') : '<tr><td colspan="4" class="text-center text-slate-400">ยังไม่มีบัญชี Trial ที่รันอยู่</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
  if (window.lucide) window.lucide.createIcons();

  viewport.querySelector('#v2AdSpendForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await v2FetchJson('/api/v2/marketing/ad-spend', {
        method: 'POST',
        body: {
          spendDate: fd.get('spendDate'),
          adPlatform: fd.get('adPlatform'),
          utmCampaign: fd.get('utmCampaign'),
          spendSatang: Math.round(Number(fd.get('spendBaht') || 0) * 100),
        },
      });
      await render(viewport, api);
    } catch (err) {
      alert(err.message);
    }
  });
}
