// gateway/public/modules/v2/views/cat1-analytics.view.mjs
// Category 1: Deep Analytics, FRT by Channel, 12M/7D SVG Charts, Cohorts & PDF Export

import { esc, v2FetchJson } from '../v2-api.mjs';
import { renderBarChart12M, renderTrendChart7D } from '../components/svg-charts.mjs';

function renderLiveKanbanFunnel(apiCounts = null) {
  const convs = Array.isArray(window.state?.conversations) ? window.state.conversations : [];
  const counts = apiCounts || {
    lead: convs.filter((c) => (c.statusTag || 'lead') === 'lead').length,
    quoted: convs.filter((c) => c.statusTag === 'quoted').length,
    deposit_paid: convs.filter((c) => c.statusTag === 'deposit_paid').length,
    completed: convs.filter((c) => c.statusTag === 'completed').length,
  };
  const total = Math.max(1, (counts.lead || 0) + (counts.quoted || 0) + (counts.deposit_paid || 0) + (counts.completed || 0));
  const stages = [
    ['lead', 'สนใจถามราคา (Lead)', 'bg-amber-400'],
    ['quoted', 'รอตัดสินใจ (Quoted)', 'bg-blue-500'],
    ['deposit_paid', 'โอนมัดจำแล้ว', 'bg-emerald-500'],
    ['completed', 'ปิดจ็อบแล้ว', 'bg-slate-400'],
  ];
  return stages
    .map(([key, label, cls]) => {
      const cnt = Number(counts[key] || 0);
      const w = Math.max(6, Math.round((cnt / total) * 100));
      return `<div class="space-y-1"><div class="flex justify-between text-[11px]"><span>${esc(label)}</span><span class="font-mono text-slate-300">${cnt} ห้อง</span></div><div class="h-2 rounded-full overflow-hidden bg-slate-800"><div class="${cls} h-full rounded-full" style="width:${w}%"></div></div></div>`;
    })
    .join('');
}

function renderLiveTopProducts() {
  const orders = Array.isArray(window.state?.liveOrders) ? window.state.liveOrders : [];
  const counts = new Map();
  orders.forEach((o) => {
    const p = String(o.productName || '').trim();
    if (p) counts.set(p, (counts.get(p) || 0) + 1);
  });
  const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3);
  if (!top.length) return '<div class="text-slate-400 py-2">ยังไม่มีข้อมูลสินค้าในทะเบียนออเดอร์</div>';
  return top
    .map(([name, cnt], idx) => `<div class="v2-subcard flex justify-between items-center py-1.5"><span>${idx + 1}. ${esc(name)}</span><span class="font-mono font-bold text-emerald-300">${cnt} ออเดอร์</span></div>`)
    .join('');
}

export async function render(viewport) {
  const [overview, aiStats, frtRes, cohortRes] = await Promise.all([
    v2FetchJson('/api/v2/analytics/overview'),
    v2FetchJson('/api/v2/analytics/ai-resolution'),
    v2FetchJson('/api/v2/analytics/frt-by-channel'),
    v2FetchJson('/api/v2/analytics/cohorts?months=6'),
  ]);

  const channels = frtRes.channels || [];
  const cohorts = cohortRes.cohorts || [];
  const avgFrt = channels.length
    ? Math.round(channels.reduce((s, c) => s + c.avgSeconds, 0) / channels.length)
    : 0;

  viewport.innerHTML = `
    <div class="v2-grid">
      <div class="v2-card sh-card v2-col-12 flex flex-wrap items-center justify-between gap-3">
        <div>
          <span class="v2-badge v2-badge--ready">หมวดที่ 1 • Deep Analytics</span>
          <h2 class="text-lg font-bold text-white mt-1.5">แดชบอร์ดวิเคราะห์เชิงลึก & Time-Series Funnel</h2>
        </div>
        <button id="v2ExportPdfBtn" type="button" class="v2-btn v2-btn--primary"><i data-lucide="file-text" class="w-4 h-4 shrink-0"></i><span>Export Executive PDF</span></button>
      </div>

      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="bot" class="w-4 h-4 shrink-0 text-cyan-400"></i><span>AI ปิดการขายเอง</span></div>
        <div class="text-2xl font-bold text-cyan-300 mt-1">${esc(aiStats.aiResolutionPct)}%</div>
        <div class="text-xs text-slate-400 mt-1">${esc(aiStats.aiConverted)} / ${esc(aiStats.totalConverted)} ออเดอร์</div>
      </div>
      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="zap" class="w-4 h-4 shrink-0 text-emerald-400"></i><span>ความเร็วตอบแรกเฉลี่ย (FRT)</span></div>
        <div class="text-2xl font-bold text-emerald-300 mt-1">${esc(avgFrt)} วินาที</div>
        <div class="text-xs text-slate-400 mt-1 truncate">${channels.slice(0, 3).map((c) => `${esc(c.channel)} ${esc(c.avgSeconds)}s`).join(' | ') || 'ยังไม่มีสถิติ'}</div>
      </div>
      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="coins" class="w-4 h-4 shrink-0 text-amber-400"></i><span>ยอดขายสะสมรวม</span></div>
        <div class="text-2xl font-bold text-amber-300 mt-1">฿${esc(Number(aiStats.totalRevenueBaht || 0).toLocaleString('th-TH'))}</div>
        <div class="text-xs text-slate-400 mt-1">จาก ${esc(aiStats.totalSessions)} เซสชันแชท</div>
      </div>
      <div class="v2-card sh-card v2-col-3">
        <div class="text-xs text-slate-400 flex items-center gap-1.5"><i data-lucide="messages-square" class="w-4 h-4 shrink-0 text-sky-400"></i><span>ห้องแชทในระบบปัจจุบัน</span></div>
        <div class="text-2xl font-bold text-white mt-1">${esc(overview.liveConversationCount ?? 0)}</div>
        <div class="text-xs text-slate-400 mt-1">ซิงก์ตรงจาก Gateway State</div>
      </div>

      <div class="v2-card sh-card v2-col-7">
        <h3 class="text-sm font-bold text-white mb-2 flex items-center gap-2"><i data-lucide="bar-chart-3" class="w-4 h-4 shrink-0 text-cyan-400"></i><span>ยอดขาย & ปริมาณแชทรายเดือน (12 เดือนย้อนหลัง)</span></h3>
        ${renderBarChart12M(overview.monthlySeries || [])}
      </div>

      <div class="v2-card sh-card v2-col-5">
        <h3 class="text-sm font-bold text-white mb-2 flex items-center gap-2"><i data-lucide="trending-up" class="w-4 h-4 shrink-0 text-emerald-400"></i><span>แนวโน้มแชทย้อนหลัง 7 วัน</span></h3>
        ${renderTrendChart7D(overview.daily7d || [])}
      </div>

      <div class="v2-card sh-card v2-col-5">
        <div class="flex items-center justify-between gap-2 mb-3">
          <h3 class="text-sm font-bold text-white flex items-center gap-2"><i data-lucide="filter" class="w-4 h-4 shrink-0 text-amber-400"></i><span>Kanban Funnel &amp; Top สินค้า (Live)</span></h3>
          <span class="v2-badge v2-badge--ok">Live Sync</span>
        </div>
        <div class="space-y-2.5 text-xs">
          ${renderLiveKanbanFunnel(overview.kanbanCounts)}
        </div>
        <div class="mt-4 pt-3 border-t border-slate-800 space-y-1.5 text-xs">
          <div class="text-[11px] font-bold text-slate-400 uppercase">TOP สินค้าที่ถูกสั่งซื้อ</div>
          ${renderLiveTopProducts()}
        </div>
      </div>

      <div class="v2-card sh-card v2-col-7">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="calendar" class="w-4 h-4 shrink-0 text-purple-400"></i><span>ตารางวิเคราะห์ Cohort รายเดือน</span></h3>
        <div class="v2-table-wrap">
          <table class="v2-table">
            <thead><tr><th>เดือนที่ทักครั้งแรก</th><th>ลูกค้าใหม่</th><th>ออเดอร์ปิดสำเร็จ</th><th>ยอดซื้อสะสม (บาท)</th></tr></thead>
            <tbody>
              ${cohorts.length ? cohorts.map((c) => `
                <tr>
                  <td class="font-mono">${esc(c.cohort_month)}</td>
                  <td>${esc(c.new_customers)} คน</td>
                  <td>${esc(c.converted_orders)}</td>
                  <td class="text-cyan-300 font-semibold">฿${esc(Number(c.total_revenue_baht || 0).toLocaleString('th-TH'))}</td>
                </tr>
              `).join('') : '<tr><td colspan="4" class="text-center text-slate-400">ยังไม่มีข้อมูล Cohort สะสม</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
  if (window.lucide) window.lucide.createIcons();

  viewport.querySelector('#v2ExportPdfBtn')?.addEventListener('click', async () => {
    try {
      const res = await fetch('/api/v2/analytics/export-pdf', { method: 'POST', credentials: 'same-origin' });
      if (!res.ok) throw new Error(`Export PDF ล้มเหลว (HTTP ${res.status})`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'omniflow-executive-report.pdf';
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert(err.message);
    }
  });
}
