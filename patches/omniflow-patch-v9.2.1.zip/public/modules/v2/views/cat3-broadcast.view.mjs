// gateway/public/modules/v2/views/cat3-broadcast.view.mjs
// Category 3: Kanban Segment Broadcast, Smart Follow-up Drip & Safe Queue Monitor

import { esc, v2FetchJson } from '../v2-api.mjs';

export async function render(viewport, api) {
  const [campRes, stepsRes, queueRes] = await Promise.all([
    v2FetchJson('/api/v2/campaigns'),
    v2FetchJson('/api/v2/drip-steps'),
    v2FetchJson('/api/v2/queue/status'),
  ]);

  const campaigns = campRes.campaigns || [];
  const steps = stepsRes.steps || [];
  const counts = queueRes.counts || {};
  const channels = queueRes.availableChannels || [];

  viewport.innerHTML = `
    <div class="v2-grid">
      <div class="v2-card sh-card v2-col-12">
        <span class="v2-badge v2-badge--ready">หมวดที่ 3 • Smart Drip & Safe Queue</span>
        <h2 class="text-lg font-bold text-white mt-1.5">ระบบ Broadcast แยกกลุ่ม Kanban & ติดตามใบเสนอราคาอัตโนมัติ</h2>
      </div>

      <div class="v2-card sh-card v2-col-7">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="target" class="w-4 h-4 shrink-0 text-cyan-400"></i><span>สร้างแคมเปญ Kanban Broadcast</span></h3>
        <form id="v2BroadcastForm" class="space-y-3 text-xs">
          <input name="name" required placeholder="ชื่อแคมเปญ (เช่น โปรโมชันหินแกรนิตปลายเดือน)"
            class="w-full px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
          <div class="flex flex-wrap gap-3 v2-subcard">
            <span class="text-slate-400 font-semibold">กลุ่ม Kanban:</span>
            <label><input type="checkbox" name="stage" value="LEAD" checked /> LEAD</label>
            <label><input type="checkbox" name="stage" value="QUOTED" checked /> QUOTED</label>
            <label><input type="checkbox" name="stage" value="WON" /> WON</label>
          </div>
          <div class="flex flex-wrap gap-3 v2-subcard max-h-24 overflow-y-auto">
            <span class="text-slate-400 font-semibold">ช่องทาง (${channels.length}):</span>
            ${channels.map((c) => `<label><input type="checkbox" name="channel" value="${esc(c.id)}" ${c.id === 'line' ? 'checked' : ''} /> ${esc(c.name)}</label>`).join('')}
          </div>
          <textarea name="messageText" rows="3" required placeholder="ข้อความบรอดแคสต์... (ระบบแนบสิทธิ์ยกเลิกรับข่าวสาร PDPA อัตโนมัติ)"
            class="w-full px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white"></textarea>
          <div class="flex flex-wrap gap-2">
            <button type="button" id="v2PreviewAudienceBtn" class="v2-btn"><i data-lucide="search" class="w-4 h-4 shrink-0"></i><span>เช็คจำนวนผู้รับปลอดภัย</span></button>
            <button type="submit" class="v2-btn v2-btn--primary"><i data-lucide="save" class="w-4 h-4 shrink-0"></i><span>สร้างแคมเปญ</span></button>
          </div>
          <div id="v2AudiencePreviewBox" class="hidden v2-subcard text-cyan-300"></div>
        </form>
      </div>

      <div class="v2-card sh-card v2-col-5">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="timer" class="w-4 h-4 shrink-0 text-amber-400"></i><span>กฎ Smart Follow-up Drip (ค้างใบเสนอราคา)</span></h3>
        <div class="space-y-2 mb-3 text-xs">
          ${steps.length ? steps.map((s) => `
            <div class="v2-subcard flex justify-between items-center">
              <div><strong>Step ${esc(s.step_order)}</strong> (${esc(s.delay_minutes)} นาที): ${esc(s.message_template)}</div>
              <span class="v2-badge v2-badge--ok">${s.is_active ? 'เปิด' : 'ปิด'}</span>
            </div>
          `).join('') : '<div class="v2-subcard text-slate-400">ยังไม่มี Step ทักซ้ำ — เพิ่มด้านล่างได้ทันที</div>'}
        </div>
        <form id="v2DripStepForm" class="space-y-2 text-xs">
          <div class="grid grid-cols-2 gap-2">
            <input name="stepOrder" type="number" value="${steps.length + 1}" min="1" class="px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white" placeholder="ลำดับ" />
            <input name="delayMinutes" type="number" value="240" min="1" class="px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white" placeholder="หน่วง (นาที)" />
          </div>
          <input name="messageTemplate" required placeholder="ข้อความทักซ้ำ เช่น สอบถามเพิ่มเติมใบเสนอราคาครับ" class="w-full px-2 py-1.5 rounded bg-slate-900 border border-slate-700 text-white" />
          <button type="submit" class="v2-btn w-full">+ เพิ่ม/อัปเดต Drip Step</button>
        </form>
      </div>

      <div class="v2-card sh-card v2-col-12">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2"><i data-lucide="shield-check" class="w-4 h-4 shrink-0 text-emerald-400"></i><span>คิวส่งข้อความปลอดภัย (Rate-Limit Safe Queue) & แคมเปญ (${campaigns.length})</span></h3>
        <div class="flex flex-wrap gap-2 mb-3 text-xs">
          <span class="v2-badge">รอส่ง: ${esc(counts.queued || 0)}</span>
          <span class="v2-badge v2-badge--ok">ส่งสำเร็จ: ${esc(counts.sent || 0)}</span>
          <span class="v2-badge v2-badge--warn">ข้ามตามกฎ PDPA/24h: ${esc(counts.skipped_policy || 0)}</span>
          <span class="v2-badge v2-badge--ready">ยกเลิกเพราะโอนแล้ว: ${esc(counts.cancelled_paid || 0)}</span>
        </div>
        <div class="v2-table-wrap">
          <table class="v2-table">
            <thead><tr><th>ชื่อแคมเปญ</th><th>สถานะ</th><th>กลุ่มเป้าหมาย</th><th>จัดการ</th></tr></thead>
            <tbody>
              ${campaigns.length ? campaigns.map((c) => {
                const isSent = c.status === 'running' || c.status === 'completed';
                return `
                <tr>
                  <td class="font-semibold">${esc(c.name)}</td>
                  <td><span class="v2-badge ${isSent ? 'v2-badge--ok' : ''}">${esc(c.status)}</span></td>
                  <td class="font-mono text-xs">${esc(c.target_stages_json)}</td>
                  <td>${isSent
                    ? '<button type="button" disabled class="v2-btn text-xs opacity-70 cursor-not-allowed"><i data-lucide="check-circle-2" class="w-3.5 h-3.5 shrink-0"></i><span>ส่งเข้าคิวแล้ว</span></button>'
                    : `<button type="button" data-send-camp="${esc(c.id)}" class="v2-send-camp-btn v2-btn text-xs"><i data-lucide="send" class="w-3.5 h-3.5 shrink-0"></i><span>ส่งเข้าคิว</span></button>`
                  }</td>
                </tr>`;
              }).join('') : '<tr><td colspan="4" class="text-center text-slate-400">ยังไม่มีแคมเปญ</td></tr>'}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `;
  if (window.lucide) window.lucide.createIcons();

  const form = viewport.querySelector('#v2BroadcastForm');
  const getSelections = () => ({
    targetStages: Array.from(form.querySelectorAll('input[name="stage"]:checked')).map((el) => el.value),
    channels: Array.from(form.querySelectorAll('input[name="channel"]:checked')).map((el) => el.value),
  });

  const box = viewport.querySelector('#v2AudiencePreviewBox');
  const showMsg = (msg, isErr = false) => {
    if (!box) return;
    box.className = `v2-subcard ${isErr ? 'text-rose-300' : 'text-cyan-300'}`;
    box.textContent = msg;
    box.classList.remove('hidden');
  };

  viewport.querySelector('#v2PreviewAudienceBtn')?.addEventListener('click', async () => {
    try {
      const res = await v2FetchJson('/api/v2/campaigns/preview', { method: 'POST', body: getSelections() });
      showMsg(`เป้าหมายทั้งหมด ${res.totalMatched} | หัก Opt-out ${res.skippedOptOut} | หักเกิน 24h ${res.skipped24hWindow} => ส่งได้จริง ${res.eligibleCount} คน`);
    } catch (err) {
      showMsg(err.message, true);
    }
  });

  form?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    try {
      await v2FetchJson('/api/v2/campaigns', {
        method: 'POST',
        body: { name: fd.get('name'), messageText: fd.get('messageText'), ...getSelections() },
      });
      await render(viewport, api);
    } catch (err) {
      showMsg(err.message, true);
    }
  });

  viewport.querySelector('#v2DripStepForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      await v2FetchJson('/api/v2/drip-steps', {
        method: 'POST',
        body: { stepOrder: fd.get('stepOrder'), delayMinutes: fd.get('delayMinutes'), messageTemplate: fd.get('messageTemplate') },
      });
      await render(viewport, api);
    } catch (err) {
      showMsg(err.message, true);
    }
  });

  viewport.querySelectorAll('.v2-send-camp-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await v2FetchJson('/api/v2/campaigns/send', { method: 'POST', body: { campaignId: btn.dataset.sendCamp } });
        await render(viewport, api);
      } catch (err) {
        showMsg(err.message, true);
      }
    });
  });
}
