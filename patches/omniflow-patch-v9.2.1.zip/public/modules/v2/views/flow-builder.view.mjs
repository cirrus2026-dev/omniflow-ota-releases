// gateway/public/modules/v2/views/flow-builder.view.mjs
// OmniFlow Enterprise v2 — Phase 2 Visual AI Flow Builder & Telemetry Loop Main View

import { esc, v2FetchJson } from '../v2-api.mjs';
import { createFlowApiClient } from '../components/flow-api-client.mjs';
import { NODE_CATALOG, refreshLucideIcons, renderLucideIcon } from '../components/flow-icons.mjs';
import { bindCanvasZoomSlider, renderFlowCanvasStage } from '../components/flow-canvas-engine.mjs';
import { renderNodeInspector } from '../components/flow-node-inspector.mjs';
import { renderSimulatorDrawer } from '../components/flow-simulator-drawer.mjs';
import { renderTelemetryAndFeedbackPanel } from '../components/flow-telemetry-heatmap.mjs';

const MODE_LABELS = Object.freeze({
  smart_agent: 'Mode 1: Smart Agent (Autonomous <=4 hops)',
  hybrid_rules: 'Mode 2: Hybrid Rules (Deterministic + AI Slots)',
  strict_guard: 'Mode 3: Strict Guard (Zero Free-Form LLM)',
});

export async function render(viewport, api = {}) {
  const client = createFlowApiClient(api?.v2FetchJson || v2FetchJson);
  const state = {
    flows: [],
    flow: null,
    draftGraph: null,
    versions: [],
    selectedNodeId: null,
    pendingConnectFrom: null,
    sideTab: 'inspector',
    showHeatmap: true,
    heatmap: null,
    feedbackItems: [],
    lastSimulation: null,
    highlightedNodeIds: [],
    notice: '',
    isError: false,
  };

  const root = document.createElement('div');
  root.className = 'space-y-3 text-zinc-100 text-xs';
  viewport.replaceChildren(root);

  const setNotice = (msg, isError = false) => {
    state.notice = msg;
    state.isError = isError;
    paint();
  };

  const refreshTelemetryData = async () => {
    const [hm, fb] = await Promise.all([
      client.getTelemetry({ flowId: state.flow.id }),
      client.listFeedback({ flowId: state.flow.id }),
    ]);
    state.heatmap = hm;
    state.feedbackItems = fb.items || [];
  };

  const loadFlowData = async (targetFlowId = '') => {
    const listRes = await client.listFlows();
    state.flows = listRes.flows || [];
    const detail = await client.getFlowDetail(targetFlowId || state.flow?.id || '');
    state.flow = detail.flow;
    state.draftGraph = detail.draftGraph;
    state.versions = detail.versions || [];
    if (!state.selectedNodeId && state.draftGraph?.nodes?.[0]) {
      state.selectedNodeId = state.draftGraph.nodes[0].id;
    }
    await refreshTelemetryData();
  };

  const paintSidePanel = () => {
    const sideEl = root.querySelector('#v2FlowSideBody');
    if (!sideEl) return;
    if (state.sideTab === 'inspector') {
      renderNodeInspector(sideEl, state, {
        onInspectorError: (err) => setNotice(err, true),
        onNodeUpdated: () => setNotice('อัปเดตพารามิเตอร์โหนดแล้ว (กดบันทึก Draft เพื่อเขียนลง SQLite)'),
        onDeleteEdge: (edgeId) => {
          state.draftGraph.edges = (state.draftGraph.edges || []).filter((e) => e.id !== edgeId);
          paint();
        },
        onDeleteNode: (nodeId) => {
          state.draftGraph.nodes = (state.draftGraph.nodes || []).filter((n) => n.id !== nodeId);
          state.draftGraph.edges = (state.draftGraph.edges || []).filter((e) => e.source !== nodeId && e.target !== nodeId);
          state.selectedNodeId = state.draftGraph.nodes[0]?.id || null;
          paint();
        },
      });
    } else if (state.sideTab === 'simulator') {
      renderSimulatorDrawer(sideEl, state, {
        onRunSimulate: async ({ text, mockImageCosine, adminTakeover }) => {
          try {
            Object.assign(state, { simDraftText: text, simCosine: mockImageCosine, simAdminTakeover: adminTakeover });
            const res = await client.simulateFlow({
              flowId: state.flow.id,
              useDraft: true,
              executionMode: state.flow.executionMode,
              mockMessage: { text },
              mockImageCosine,
              sessionState: { adminTakeover },
            });
            state.lastSimulation = res;
            state.highlightedNodeIds = (res.traceSteps || []).map((s) => s.nodeId);
            await refreshTelemetryData();
            paint();
          } catch (err) {
            setNotice(err.message || 'จำลองกราฟไม่สำเร็จ', true);
          }
        },
      });
    } else {
      renderTelemetryAndFeedbackPanel(sideEl, state, {
        onRefreshTelemetry: async () => {
          await refreshTelemetryData();
          paint();
        },
        onResolveFeedback: async (feedbackId) => {
          await client.resolveFeedback({ feedbackId, resolutionStatus: 'resolved_in_version', adminNote: 'แก้ไขผ่าน Canvas แล้ว' });
          await refreshTelemetryData();
          setNotice('ปิดงาน Feedback Loop เรียบร้อยแล้ว');
        },
      });
    }
  };

  const paint = () => {
    if (!state.flow || !state.draftGraph) {
      root.innerHTML = `<div class="p-6 rounded-xl border border-zinc-800 bg-zinc-950 text-zinc-400">กำลังโหลด Visual AI Flow Builder...</div>`;
      return;
    }
    const mode = state.flow.executionMode || 'hybrid_rules';
    const zoomPct = Math.round(Number(state.draftGraph.viewport?.zoom || 1) * 100);
    const modeOpts = Object.entries(MODE_LABELS).map(([k, lbl]) => `<option value="${esc(k)}" ${mode === k ? 'selected' : ''}>${esc(lbl)}</option>`).join('');
    const nodeOpts = NODE_CATALOG.filter((n) => n.type !== 'trigger_inbound' && n.modes.includes(mode)).map((n) => `<option value="${esc(n.type)}">+ ${esc(n.label)}</option>`).join('');
    const verOpts = state.versions.map((v) => `<option value="${esc(v.id)}">v${esc(v.version_num)} (${esc(String(v.checksum_sha256).slice(0, 8))})</option>`).join('');
    const noticeHtml = state.notice
      ? `<div class="flex items-center gap-2 px-3 py-2 rounded-lg border ${state.isError ? 'border-rose-500/40 bg-rose-950/40 text-rose-200' : 'border-emerald-500/40 bg-emerald-950/30 text-emerald-200'}">${renderLucideIcon(state.isError ? 'alert-triangle' : 'shield-check', 'w-4 h-4')}<span>${esc(state.notice)}</span></div>`
      : '';

    root.innerHTML = `
      <div class="flex flex-wrap items-center justify-between gap-2 p-3 rounded-xl border border-zinc-800 bg-zinc-950/90">
        <div class="flex flex-wrap items-center gap-2">
          <span class="inline-flex items-center gap-1.5 font-bold text-sm text-zinc-100">${renderLucideIcon('workflow', 'w-4 h-4 text-cyan-400')}<span>${esc(state.flow.name)}</span></span>
          <select id="v2FlowModeSelect" class="px-2.5 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 text-zinc-100">${modeOpts}</select>
          <select id="v2FlowAddNodeSelect" class="px-2.5 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 text-cyan-300"><option value="">+ เพิ่มโหนดเข้ากราฟ...</option>${nodeOpts}</select>
        </div>
        <div class="flex flex-wrap items-center gap-2">
          <label class="inline-flex items-center gap-1.5 text-zinc-400"><span>Zoom</span><input id="v2FlowZoomSlider" type="range" min="50" max="150" value="${esc(zoomPct)}" class="w-24" /></label>
          <button type="button" data-fb-act="toggle-heatmap" class="px-2.5 py-1.5 rounded-lg border ${state.showHeatmap ? 'border-amber-500/50 bg-amber-950/30 text-amber-200' : 'border-zinc-700 text-zinc-400'}">${renderLucideIcon('flame', 'w-3.5 h-3.5 inline')} Heatmap</button>
          <button type="button" data-fb-act="save-draft" class="px-3 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 hover:bg-zinc-800 font-semibold text-zinc-100">บันทึก Draft</button>
          <button type="button" data-fb-act="publish" class="px-3 py-1.5 rounded-lg bg-cyan-400 text-zinc-950 hover:bg-cyan-300 font-semibold">Publish เวอร์ชันใหม่</button>
          ${verOpts ? `<select id="v2FlowRollbackSelect" class="px-2 py-1.5 rounded-lg border border-zinc-700 bg-zinc-900 text-zinc-300"><option value="">Rollback...</option>${verOpts}</select>` : ''}
        </div>
      </div>
      ${noticeHtml}
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-3">
        <div id="v2FlowCanvasViewport" class="lg:col-span-8 relative h-[560px] rounded-xl border border-zinc-800 bg-zinc-950 overflow-auto"></div>
        <aside class="lg:col-span-4 rounded-xl border border-zinc-800 bg-zinc-950/90 p-3 space-y-3">
          <div class="grid grid-cols-3 gap-1 p-1 rounded-lg bg-zinc-900 border border-zinc-800">
            <button type="button" data-fb-tab="inspector" class="py-1.5 rounded font-semibold ${state.sideTab === 'inspector' ? 'bg-zinc-800 text-white' : 'text-zinc-400'}">ตั้งค่าโหนด</button>
            <button type="button" data-fb-tab="simulator" class="py-1.5 rounded font-semibold ${state.sideTab === 'simulator' ? 'bg-zinc-800 text-emerald-300' : 'text-zinc-400'}">Simulator</button>
            <button type="button" data-fb-tab="telemetry" class="py-1.5 rounded font-semibold ${state.sideTab === 'telemetry' ? 'bg-zinc-800 text-amber-300' : 'text-zinc-400'}">Telemetry</button>
          </div>
          <div id="v2FlowSideBody"></div>
        </aside>
      </div>`;

    const canvasVp = root.querySelector('#v2FlowCanvasViewport');
    renderFlowCanvasStage(canvasVp, state, {
      onSelectNode: (nodeId) => {
        state.selectedNodeId = nodeId;
        state.sideTab = 'inspector';
        paint();
      },
    });
    state.draftGraph.viewport = state.draftGraph.viewport || { x: 20, y: 20, zoom: 1 };
    bindCanvasZoomSlider(root.querySelector('#v2FlowZoomSlider'), canvasVp?.querySelector('#v2FlowCanvasStage'), state.draftGraph.viewport);
    paintSidePanel();
    refreshLucideIcons(root);
  };

  root.addEventListener('change', async (ev) => {
    if (ev.target.id === 'v2FlowModeSelect') {
      state.flow.executionMode = ev.target.value;
      paint();
    } else if (ev.target.id === 'v2FlowAddNodeSelect' && ev.target.value) {
      const type = ev.target.value;
      const meta = NODE_CATALOG.find((n) => n.type === type);
      const id = `nd_${type.slice(0, 6)}_${Date.now().toString(36).slice(-3)}`;
      state.draftGraph.nodes.push({ id, type, label: meta?.label || type, icon: meta?.icon || 'workflow', position: { x: 240, y: 220 }, config: {} });
      state.selectedNodeId = id;
      paint();
    } else if (ev.target.id === 'v2FlowRollbackSelect' && ev.target.value) {
      try {
        await client.rollbackFlow({ flowId: state.flow.id, versionId: ev.target.value });
        await loadFlowData(state.flow.id);
        setNotice('Rollback เวอร์ชันพร้อมตรวจสอบ SHA-256 สำเร็จ');
      } catch (err) {
        setNotice(err.message || 'Rollback ไม่สำเร็จ', true);
      }
    }
  });

  root.addEventListener('click', async (ev) => {
    const tabBtn = ev.target.closest('[data-fb-tab]');
    if (tabBtn) {
      state.sideTab = tabBtn.dataset.fbTab;
      paint();
      return;
    }
    const fromBtn = ev.target.closest('[data-connect-from]');
    if (fromBtn) {
      state.pendingConnectFrom = { source: fromBtn.dataset.connectFrom, sourcePort: fromBtn.dataset.connectPort || 'out' };
      setNotice(`เลือกพอร์ตขาออก ${state.pendingConnectFrom.sourcePort} แล้ว คลิกปุ่ม "in" บนโหนดปลายทางเพื่อเชื่อมเส้น`);
      return;
    }
    const toBtn = ev.target.closest('[data-connect-to]');
    if (toBtn && state.pendingConnectFrom) {
      const target = toBtn.dataset.connectTo;
      if (target !== state.pendingConnectFrom.source) {
        state.draftGraph.edges.push({ id: `ed_${Date.now().toString(36)}`, source: state.pendingConnectFrom.source, sourcePort: state.pendingConnectFrom.sourcePort, target });
      }
      state.pendingConnectFrom = null;
      setNotice('เชื่อมเส้นทางโหนดเรียบร้อยแล้ว');
      return;
    }
    const actBtn = ev.target.closest('[data-fb-act]');
    if (!actBtn) return;
    const act = actBtn.dataset.fbAct;
    try {
      if (act === 'toggle-heatmap') {
        state.showHeatmap = !state.showHeatmap;
        paint();
      } else if (act === 'save-draft') {
        await client.saveDraft({ flowId: state.flow.id, executionMode: state.flow.executionMode, draftGraph: state.draftGraph });
        setNotice('บันทึก Draft Graph ลงฐานข้อมูล SQLite เรียบร้อยแล้ว');
      } else if (act === 'publish') {
        await client.saveDraft({ flowId: state.flow.id, executionMode: state.flow.executionMode, draftGraph: state.draftGraph });
        const pub = await client.publishFlow({ flowId: state.flow.id, changelog: 'Published from Visual Canvas' });
        await loadFlowData(state.flow.id);
        setNotice(`Publish เวอร์ชัน v${pub.versionNum} สำเร็จ (SHA-256: ${String(pub.checksumSha256).slice(0, 12)}...)`);
      }
    } catch (err) {
      setNotice(err.message || 'ดำเนินการไม่สำเร็จ', true);
    }
  });

  await loadFlowData();
  paint();
}
