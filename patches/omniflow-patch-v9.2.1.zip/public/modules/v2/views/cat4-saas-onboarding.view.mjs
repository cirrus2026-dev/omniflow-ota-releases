// gateway/public/modules/v2/views/cat4-saas-onboarding.view.mjs
// Category 4: B2B SaaS Signup, Free 6M (180 Days) Countdown, License Key Activation, Milestones & Plan Upgrade

import { esc, v2FetchJson } from '../v2-api.mjs';
import { lucideIcon, refreshLucideIcons } from '../v2-icons.mjs';

const DEMO_KEYS = [
  ['Starter', 'OMNI-STARTER-2026-TRIAL'],
  ['Pro', 'OMNI-PRO-2026-TRIAL'],
  ['Enterprise', 'OMNI-ENTERPRISE-2026-VIP'],
];

function renderLicenseKeyBox(workspaceId = null) {
  const quickBtns = DEMO_KEYS.map(
    ([label, key]) =>
      `<button type="button" data-fill-key="${key}" class="v2-demo-key-btn px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[11px] font-mono text-cyan-300 transition">${esc(label)}: ${esc(key)}</button>`
  ).join('');
  return `
    <div class="v2-card sh-card v2-col-12 space-y-3">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">${lucideIcon('key-round', 'w-4 h-4 shrink-0 text-cyan-400')}<span>เปิดใช้งานด้วยรหัสคีย์แพ็กเกจ (Product License Key Activation)</span></h3>
        <span class="v2-badge v2-badge--ready">รองรับคีย์ทดสอบ &amp; คีย์ลูกค้าจริง</span>
      </div>
      <form id="v2LicenseForm" class="flex flex-col sm:flex-row gap-2 text-xs">
        <input id="v2LicenseKeyInput" name="licenseKey" required placeholder="กรอกรหัสคีย์ เช่น OMNI-PRO-2026-TRIAL"
          class="flex-1 px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 font-mono text-white uppercase" />
        ${workspaceId ? '' : '<input name="companyName" placeholder="ชื่อร้านค้า (ไม่บังคับ)" class="sm:w-56 px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />'}
        <button type="submit" class="v2-btn v2-btn--primary shrink-0">${lucideIcon('check-circle-2', 'w-4 h-4 shrink-0')}<span>ยืนยันเปิดใช้คีย์</span></button>
      </form>
      <div class="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
        <span>คีย์ทดสอบด่วน (คลิกเพื่อกรอก):</span>${quickBtns}
      </div>
      <div id="v2LicenseMsg" class="hidden text-xs"></div>
    </div>`;
}

function bindLicenseEvents(viewport, api, workspaceId = null) {
  const input = viewport.querySelector('#v2LicenseKeyInput');
  const msgEl = viewport.querySelector('#v2LicenseMsg');
  viewport.querySelectorAll('.v2-demo-key-btn').forEach((btn) => {
    btn.addEventListener('click', () => { if (input) input.value = btn.dataset.fillKey || ''; });
  });
  viewport.querySelector('#v2LicenseForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    try {
      const res = await v2FetchJson('/api/v2/saas/license/activate', {
        method: 'POST',
        body: { licenseKey: fd.get('licenseKey'), workspaceId, companyName: fd.get('companyName') || '' },
      });
      window.dispatchEvent?.(new CustomEvent('omniflow:v2:authenticated', { detail: res }));
      await render(viewport, api);
    } catch (err) {
      if (msgEl) {
        msgEl.className = 'text-xs text-rose-300';
        msgEl.textContent = err.message;
        msgEl.classList.remove('hidden');
      }
    }
  });
}

function renderTrialCountdownBanner(activePlan, subscription, daysRemaining) {
  const isFree6m = activePlan === 'free_6m';
  const isTrial = isFree6m || activePlan === 'free_trial';
  if (!isTrial) return '';
  const totalDays = isFree6m ? 180 : 14;
  const remain = Number.isFinite(Number(daysRemaining)) ? Number(daysRemaining) : totalDays;
  const pct = Math.max(0, Math.min(100, Math.round((remain / totalDays) * 100)));
  const expText = subscription?.trial_ends_at ? String(subscription.trial_ends_at).slice(0, 10) : '-';
  const title = isFree6m ? 'แพ็กเกจทดลองใช้ฟรี 6 เดือน (FREE_6M • 180 วัน)' : 'แพ็กเกจทดลองใช้งาน (FREE_TRIAL • 14 วัน)';

  return `
    <div class="v2-card sh-card v2-col-12 border-emerald-500/40 bg-emerald-950/20 space-y-2.5">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div class="flex items-center gap-2 text-xs font-bold text-emerald-300">
          ${lucideIcon('gift', 'w-4 h-4 shrink-0')}<span>${esc(title)}</span>
        </div>
        <div class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-emerald-500/40 bg-emerald-950/60 text-emerald-200 text-xs font-mono font-semibold">
          ${lucideIcon('clock', 'w-3.5 h-3.5 shrink-0')}<span>คงเหลือ ${esc(remain)} / ${esc(totalDays)} วัน</span>
        </div>
      </div>
      <div class="w-full h-2 rounded-full bg-slate-800 overflow-hidden"><div class="h-full bg-emerald-400 transition-all" style="width:${pct}%"></div></div>
      <div class="flex flex-wrap items-center justify-between text-[11px] text-slate-300">
        <span>ค่าบริการรายเดือนปัจจุบัน: ฿0 (MRR 0 สตางค์)</span>
        <span>วันหมดอายุสิทธิ์ทดลอง: <strong class="font-mono text-white">${esc(expText)}</strong></span>
      </div>
    </div>`;
}

export async function render(viewport, api) {
  const res = await v2FetchJson('/api/v2/saas/workspace/current');
  const { workspace, subscription, milestones, account } = res;
  const daysRemaining = res.daysRemaining ?? subscription?.daysRemaining ?? null;

  if (!workspace) {
    renderSignupFlow(viewport, api);
    return;
  }

  const mrrBaht = ((subscription?.mrr_satang || 0) / 100).toLocaleString('th-TH');
  const score = milestones?.onboarding_score || 0;
  const activePlan = String(subscription?.plan_code || 'free_trial').toLowerCase();
  const planBadgeText = activePlan === 'free_6m' ? 'FREE 6M (180 วัน)' : activePlan.toUpperCase();
  const aiQuota = Number(workspace.ai_quota_monthly || 1000).toLocaleString('th-TH');
  const planSpecs = [
    { code: 'starter', title: 'Starter', price: '฿1,490/ด.', btnLabel: 'เลือก Starter' },
    { code: 'pro', title: 'Pro (ยอดนิยม)', price: '฿2,990/ด.', btnLabel: 'อัปเกรด Pro' },
    { code: 'enterprise', title: 'Enterprise', price: '฿7,990/ด.', btnLabel: 'อัปเกรด Enterprise' },
  ];
  const plansHtml = planSpecs.map((p) => {
    const isCurrent = activePlan === p.code;
    const cardCls = isCurrent ? 'v2-subcard space-y-2 border-cyan-400/60 shadow-[0_0_16px_rgba(0,240,255,0.14)]' : 'v2-subcard space-y-2';
    const btnHtml = isCurrent
      ? `<button type="button" data-plan="${p.code}" disabled class="v2-btn v2-btn--primary w-full opacity-90 cursor-not-allowed">${lucideIcon('check-circle-2', 'w-3.5 h-3.5 shrink-0')}<span>ใช้งานอยู่</span></button>`
      : `<button type="button" data-plan="${p.code}" class="v2-upgrade-btn v2-btn w-full">${esc(p.btnLabel)}</button>`;
    return `<div class="${cardCls}"><div class="font-bold text-white">${esc(p.title)}</div><div class="text-cyan-300 font-bold">${esc(p.price)}</div>${btnHtml}</div>`;
  }).join('');

  viewport.innerHTML = `
    <div class="v2-grid">
      <div class="v2-card sh-card v2-col-12 flex flex-wrap items-center justify-between gap-3">
        <div>
          <span class="v2-badge v2-badge--ready">หมวดที่ 4 • B2B SaaS Workspace</span>
          <h2 class="text-lg font-bold text-white mt-1.5 flex items-center gap-2">${lucideIcon('building-2', 'w-5 h-5 shrink-0 text-cyan-400')}<span>${esc(workspace.name)} (${esc(workspace.slug)})</span></h2>
          <p class="text-xs text-slate-300 mt-1">ผู้ดูแล: ${esc(account?.full_name || '-')} • อุตสาหกรรม: ${esc(account?.business_industry || '-')}</p>
        </div>
        <div class="text-right space-y-1">
          <div class="flex items-center justify-end gap-1.5">
            <span class="v2-badge v2-badge--ok">${esc(planBadgeText)}</span>
            ${Number.isFinite(Number(daysRemaining)) ? `<span class="v2-badge v2-badge--ready">เหลือ ${esc(daysRemaining)} วัน</span>` : ''}
          </div>
          <div class="text-sm font-bold text-cyan-300">฿${esc(mrrBaht)} / เดือน</div>
        </div>
      </div>
      ${renderTrialCountdownBanner(activePlan, subscription, daysRemaining)}
      <div class="v2-card sh-card v2-col-6">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2">${lucideIcon('rocket', 'w-4 h-4 shrink-0 text-cyan-400')}<span>Onboarding &amp; โควตาปัจจุบัน (${score}%)</span></h3>
        <div class="w-full h-2.5 rounded-full bg-slate-800 overflow-hidden mb-4"><div class="h-full bg-cyan-400" style="width:${Math.min(100, score)}%"></div></div>
        <div class="space-y-2 text-xs">
          <div class="v2-subcard flex justify-between items-center"><span>1. ยืนยันบัญชีและโปรไฟล์ธุรกิจ</span><span class="text-emerald-300 inline-flex items-center gap-1">${lucideIcon('check-circle-2', 'w-3.5 h-3.5 shrink-0')}<span>เสร็จแล้ว</span></span></div>
          <div class="v2-subcard flex justify-between items-center">
            <span>2. เชื่อมต่อช่องทางแชทแรก (จาก 23 ช่องทาง)</span>
            <span>${milestones?.step_first_channel_connectedAt ? `<span class="text-emerald-300 inline-flex items-center gap-1">${lucideIcon('check-circle-2', 'w-3.5 h-3.5 shrink-0')}<span>${esc(milestones.first_connected_channel)}</span></span>` : '<button id="v2SyncChannelBtn" class="v2-btn text-xs">ซิงก์การเชื่อมต่อ</button>'}</span>
          </div>
          <div class="v2-subcard flex justify-between items-center"><span>3. จำนวนสิทธิ์แอดมิน (Seats)</span><span class="font-semibold text-white">${esc(workspace.seat_limit)} ที่นั่ง</span></div>
          <div class="v2-subcard flex justify-between items-center"><span>4. โควตา AI ตอบแชทรายเดือน</span><span class="font-mono font-semibold text-cyan-300">${esc(aiQuota)} ข้อความ/ด.</span></div>
        </div>
      </div>
      <div class="v2-card sh-card v2-col-6">
        <h3 class="text-sm font-bold text-white mb-3 flex items-center gap-2">${lucideIcon('gem', 'w-4 h-4 shrink-0 text-amber-400')}<span>อัปเกรดแพ็กเกจซอฟต์แวร์ OmniFlow</span></h3>
        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">${plansHtml}</div>
        <div id="v2UpgradeMsg" class="hidden mt-3 text-xs"></div>
      </div>
      ${renderLicenseKeyBox(workspace.id)}
    </div>`;
  refreshLucideIcons(viewport);
  bindLicenseEvents(viewport, api, workspace.id);

  const showErr = (message) => {
    const msg = viewport.querySelector('#v2UpgradeMsg');
    if (!msg) return;
    msg.className = 'mt-3 text-xs text-rose-300';
    msg.textContent = message;
    msg.classList.remove('hidden');
  };

  viewport.querySelector('#v2SyncChannelBtn')?.addEventListener('click', async () => {
    try {
      await v2FetchJson('/api/v2/saas/milestones/sync', { method: 'POST', body: { workspaceId: workspace.id, connectedChannelsCount: 1, firstChannel: 'line' } });
      await render(viewport, api);
    } catch (err) {
      showErr(err.message);
    }
  });

  viewport.querySelectorAll('.v2-upgrade-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      try {
        await v2FetchJson('/api/v2/saas/subscriptions/upgrade', { method: 'POST', body: { workspaceId: workspace.id, planCode: btn.dataset.plan, billingCycle: 'monthly' } });
        await render(viewport, api);
      } catch (err) {
        showErr(err.message);
      }
    });
  });
}

function renderSignupFlow(viewport, api) {
  viewport.innerHTML = `
    <div class="v2-grid">
      ${renderLicenseKeyBox(null)}
      <div class="v2-card sh-card v2-col-12 max-w-3xl mx-auto">
        <span class="v2-badge v2-badge--ready">หมวดที่ 4 • ทดลองใช้งานฟรี 6 เดือน (180 วัน)</span>
        <h2 class="text-lg font-bold text-white mt-2 mb-4">สมัครไอดีโปรแกรม OmniFlow Enterprise (SaaS Signup)</h2>
        <form id="v2SaasSignupForm" class="space-y-3 text-xs">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <input name="companyName" required placeholder="ชื่อบริษัท / ร้านค้า" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
            <input name="fullName" required placeholder="ชื่อผู้สมัคร (เจ้าของกิจการ)" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
            <input name="email" type="email" required placeholder="อีเมลทำงาน" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
            <input name="phone" placeholder="เบอร์มือถือ (สำหรับ OTP)" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
            <input name="password" type="password" required minlength="6" placeholder="ตั้งรหัสผ่าน (>= 6 ตัวอักษร)" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-slate-700 text-white" />
            <select name="planCode" class="px-3 py-2 rounded-lg bg-slate-900/90 border border-emerald-500/50 text-emerald-200 font-semibold">
              <option value="free_6m" selected>แพ็กเกจฟรี 6 เดือน (free_6m • 180 วัน)</option>
              <option value="free_trial">ทดลองใช้มาตรฐาน (free_trial • 14 วัน)</option>
            </select>
          </div>
          <div class="v2-subcard space-y-2">
            <label class="flex items-center gap-2"><input type="checkbox" name="acceptTosDpa" required /> ยอมรับเงื่อนไขการใช้บริการและสัญญา B2B DPA *(จำเป็น)</label>
            <label class="flex items-center gap-2"><input type="checkbox" name="acceptOnboardingComms" /> ยินยอมรับคำแนะนำการตั้งค่าแชท (ไม่บังคับ)</label>
            <label class="flex items-center gap-2"><input type="checkbox" name="acceptMarketingPromo" /> ยินยอมรับข่าวสารโปรโมชันซอฟต์แวร์ (ไม่บังคับ)</label>
          </div>
          <button type="submit" class="v2-btn v2-btn--primary">${lucideIcon('rocket', 'w-4 h-4 shrink-0')}<span>สมัครเปิดใช้งานฟรี 6 เดือน</span></button>
        </form>
        <div id="v2OtpBox" class="hidden mt-4 v2-subcard space-y-2 text-xs">
          <div class="text-cyan-300 font-bold">กรอกรหัส OTP ยืนยันตัวตน (Sandbox ใช้รหัส: 123456)</div>
          <div class="flex gap-2">
            <input id="v2OtpInput" placeholder="กรอกรหัส OTP 6 หลัก" class="px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-white" />
            <button id="v2OtpConfirmBtn" type="button" class="v2-btn v2-btn--primary">ยืนยัน OTP</button>
          </div>
        </div>
        <div id="v2SignupMsg" class="hidden mt-3 text-xs"></div>
      </div>
    </div>`;
  refreshLucideIcons(viewport);
  bindLicenseEvents(viewport, api, null);

  let pendingAccountId = null;
  let pendingPlanCode = 'free_6m';
  const msgEl = viewport.querySelector('#v2SignupMsg');
  viewport.querySelector('#v2SaasSignupForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    pendingPlanCode = String(fd.get('planCode') || 'free_6m');
    try {
      const res = await v2FetchJson('/api/v2/saas/signup', {
        method: 'POST',
        body: {
          companyName: fd.get('companyName'), fullName: fd.get('fullName'), email: fd.get('email'),
          phone: fd.get('phone'), password: fd.get('password'), planCode: pendingPlanCode,
          acceptTosDpa: Boolean(fd.get('acceptTosDpa')),
          acceptOnboardingComms: Boolean(fd.get('acceptOnboardingComms')),
          acceptMarketingPromo: Boolean(fd.get('acceptMarketingPromo')),
        },
      });
      pendingAccountId = res.accountId;
      const otpInput = viewport.querySelector('#v2OtpInput');
      if (otpInput && res.devOtpHint) otpInput.value = res.devOtpHint;
      viewport.querySelector('#v2OtpBox')?.classList.remove('hidden');
      msgEl.className = 'mt-3 text-xs text-emerald-300';
      msgEl.textContent = 'สร้างบัญชีแล้ว กรุณายืนยัน OTP ด้านล่าง';
      msgEl.classList.remove('hidden');
    } catch (err) {
      msgEl.className = 'mt-3 text-xs text-rose-300';
      msgEl.textContent = err.message;
      msgEl.classList.remove('hidden');
    }
  });

  viewport.querySelector('#v2OtpConfirmBtn')?.addEventListener('click', async () => {
    const otp = viewport.querySelector('#v2OtpInput')?.value || '';
    try {
      const res = await v2FetchJson('/api/v2/saas/verify-otp', { method: 'POST', body: { accountId: pendingAccountId, otp, planCode: pendingPlanCode } });
      window.dispatchEvent?.(new CustomEvent('omniflow:v2:authenticated', { detail: res }));
      await render(viewport, api);
    } catch (err) {
      msgEl.className = 'mt-3 text-xs text-rose-300';
      msgEl.textContent = err.message;
      msgEl.classList.remove('hidden');
    }
  });
}
