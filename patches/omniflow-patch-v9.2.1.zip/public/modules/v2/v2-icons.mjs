// gateway/public/modules/v2/v2-icons.mjs
// Shared Lucide SVG icon helpers for OmniFlow Enterprise v2 (shadcn-admin 2.2.1 style)

import { esc } from './v2-api.mjs';

/**
 * Render a Lucide icon placeholder element cleanly without emojis.
 */
export function lucideIcon(name, className = 'w-4 h-4 shrink-0') {
  return `<i data-lucide="${esc(name)}" class="${esc(className)}"></i>`;
}

/**
 * Hydrate `<i data-lucide="...">` placeholders into crisp inline SVG icons.
 */
export function refreshLucideIcons(root = null) {
  if (typeof window === 'undefined' || !window.lucide || typeof window.lucide.createIcons !== 'function') {
    return;
  }
  try {
    if (root && typeof root.querySelectorAll === 'function') {
      window.lucide.createIcons({ root });
    } else {
      window.lucide.createIcons();
    }
  } catch {
    try {
      window.lucide.createIcons();
    } catch { /* ignore icon hydration error */ }
  }
}
