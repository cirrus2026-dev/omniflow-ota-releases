// gateway/public/modules/v2/v2-nav-registry.mjs
// Centralized Navigation & Lazy View Registry for OmniFlow Enterprise v2

export const V2_VIEW_MAP = Object.freeze({
  analytics_addon: {
    modulePath: './views/cat1-analytics.view.mjs',
    title: 'Analytics เชิงลึก & Funnel',
    shortLabel: 'Analytics',
    categoryLabel: 'หมวดที่ 1 • Deep Analytics',
  },
  users_addon: {
    modulePath: './views/cat2-rbac.view.mjs',
    title: 'จัดการทีมแอดมิน & กะงาน (RBAC)',
    shortLabel: 'RBAC',
    categoryLabel: 'หมวดที่ 2 • Multi-User RBAC',
  },
  broadcast_addon: {
    modulePath: './views/cat3-broadcast.view.mjs',
    title: 'Broadcast & ติดตามใบเสนอราคา',
    shortLabel: 'Broadcast',
    categoryLabel: 'หมวดที่ 3 • Smart Drip & Queue',
  },
  saas_onboarding_v2: {
    modulePath: './views/cat4-saas-onboarding.view.mjs',
    title: 'แพ็กเกจ & ตั้งค่า Workspace',
    shortLabel: 'SaaS',
    categoryLabel: 'หมวดที่ 4 • B2B SaaS Workspace',
  },
  saas_growth_v2: {
    modulePath: './views/cat5-saas-growth.view.mjs',
    title: 'SaaS Growth & Attribution',
    shortLabel: 'Growth',
    categoryLabel: 'หมวดที่ 5 • Platform Superadmin',
    superadminOnly: true,
  },
});

// Extensible registry for Phase 1 (ERP/Audit, Settings 5 หมวด, First-Run Gate) & Phase 2 (Flow Builder) plug-ins
const V2_PLUGIN_VIEWS = new Map();

export function registerV2View(viewKey, meta) {
  const key = String(viewKey || '').trim();
  if (!key || !meta || !meta.modulePath) {
    throw new Error('registerV2View requires viewKey and meta.modulePath');
  }
  V2_PLUGIN_VIEWS.set(key, Object.freeze({ ...meta }));
}

export function getV2ViewMeta(viewKey) {
  const key = String(viewKey || '').trim();
  if (Object.hasOwn(V2_VIEW_MAP, key)) return V2_VIEW_MAP[key];
  return V2_PLUGIN_VIEWS.get(key) || null;
}

export const V2_NAV_SPECS = Object.freeze([
  { key: 'flow_builder_v2', icon: 'workflow', label: 'AI Flow Builder & Telemetry', badge: 'FLOW' },
  { key: 'saas_onboarding_v2', icon: 'building-2', label: 'แพ็กเกจ & Workspace', badge: 'SaaS' },
  { key: 'saas_growth_v2', icon: 'trending-up', label: 'SaaS Growth & ROAS', badge: 'HQ' },
  { key: 'erp_audit_v2', icon: 'shield-check', label: 'Audit Log & ERP Keys', badge: 'ERP' },
  { key: 'settings_suite_v2', icon: 'sliders-horizontal', label: 'ตั้งค่าระบบ (5 หมวด)', badge: 'SET' },
]);

export const LEGACY_VIEW_IDS = Object.freeze([
  'viewDashboard',
  'viewInbox',
  'viewOrdersEnterprise',
  'viewCatalogEnterprise',
  'viewSettingsEnterprise',
  'viewAddonPreview',
  'viewCatalogManager',
  'viewOrdersManager',
]);

// Phase 1B: Register ERP Audit Log & External API Keys via plugin registry (keeps V2_VIEW_MAP 5 base keys intact)
registerV2View('erp_audit_v2', {
  modulePath: './views/erp-audit-tab.view.mjs',
  title: 'Audit Log & External ERP API Keys',
  shortLabel: 'ERP & Audit',
  categoryLabel: 'Enterprise Suite • Audit & ERP Sync',
});

// Phase 1A: Register Settings Suite (5 Categories) & First-Run Gate via plugin registry
registerV2View('settings_suite_v2', {
  modulePath: './views/settings-suite.view.mjs',
  title: 'ตั้งค่าระบบครบวงจร (5 หมวด)',
  shortLabel: 'Settings Suite',
  categoryLabel: 'Phase 1A • Account, System, Notify, Billing & About',
});

registerV2View('first_run_gate_v2', {
  modulePath: './views/first-run-gate.view.mjs',
  title: 'เข้าสู่ระบบ / สมัครใช้งานครั้งแรก',
  shortLabel: 'Onboarding Gate',
  categoryLabel: 'Phase 1A • First-Run Gate & Persistent Auth',
});

registerV2View('flow_builder_v2', {
  modulePath: './views/flow-builder.view.mjs',
  title: 'Visual AI Flow Builder & Telemetry Loop',
  shortLabel: 'Flow Builder',
  categoryLabel: 'Phase 2 • Smart Agent, Hybrid Rules & Strict Guard',
});

export const V2_EXTRA_NAV_SPECS = Object.freeze([
  { key: 'flow_builder_v2', icon: 'workflow', label: 'AI Flow Builder & Telemetry', badge: 'FLOW' },
  { key: 'erp_audit_v2', icon: 'shield-check', label: 'Audit Log & ERP Keys', badge: 'ERP' },
  { key: 'settings_suite_v2', icon: 'sliders-horizontal', label: 'ตั้งค่าระบบ (5 หมวด)', badge: 'SET' },
]);
