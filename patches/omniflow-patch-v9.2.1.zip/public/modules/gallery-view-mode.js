/**
 * OmniFlow AI Suite - Gallery View Mode Module
 * Fixes card stacking stripes by preserving internal card DOM hierarchy,
 * unlocking fixed image wrapper heights (h-32, h-36, max-h-*, aspect-video),
 * and applying clean responsive CSS Grid columns + 4:3 proportional image framing.
 */

const STORAGE_KEY = 'omniflow_gallery_view_mode';

const VIEW_MODES = {
  medium: {
    id: 'medium',
    label: 'Medium',
    minWidth: '230px',
    imgHeight: '180px',
    titleSize: '0.82rem',
    priceSize: '0.75rem',
    metaSize: '0.68rem',
    gridGap: '0.75rem',
  },
  large: {
    id: 'large',
    label: 'Large',
    minWidth: '330px',
    imgHeight: '250px',
    titleSize: '0.88rem',
    priceSize: '0.80rem',
    metaSize: '0.72rem',
    gridGap: '1rem',
  },
  xlarge: {
    id: 'xlarge',
    label: 'Extra Large',
    minWidth: '460px',
    imgHeight: '350px',
    titleSize: '0.94rem',
    priceSize: '0.84rem',
    metaSize: '0.75rem',
    gridGap: '1.25rem',
  },
};

const MODE_ORDER = ['medium', 'large', 'xlarge'];

class GalleryViewModeController {
  constructor() {
    this.currentMode = this._loadSavedMode();
    this.wheelLockUntil = 0;
    this.observer = null;
  }

  _loadSavedMode() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && VIEW_MODES[saved]) return saved;
    } catch (err) {
      console.warn('[GalleryView] storage access error:', err);
    }
    return 'medium';
  }

  _escapeHtml(str) {
    if (typeof window.escapeHtml === 'function') return window.escapeHtml(str);
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  _saveMode(modeId) {
    try {
      localStorage.setItem(STORAGE_KEY, modeId);
    } catch (err) {
      console.warn('[GalleryView] storage access error:', err);
    }
  }

  injectStyles() {
    if (document.getElementById('gallery-view-mode-styles')) return;

    const style = document.createElement('style');
    style.id = 'gallery-view-mode-styles';
    style.textContent = `
      /* 1. Responsive Grid Columns without CSS transform:scale distortion */
      #stoneGalleryGrid {
        --gvm-min-width: 230px;
        --gvm-img-height: 180px;
        --gvm-title-size: 0.82rem;
        --gvm-price-size: 0.75rem;
        --gvm-meta-size: 0.68rem;
        --gvm-grid-gap: 0.75rem;

        display: grid !important;
        grid-template-columns: repeat(auto-fill, minmax(min(100%, var(--gvm-min-width)), 1fr)) !important;
        grid-auto-rows: max-content !important;
        align-content: start !important;
        gap: var(--gvm-grid-gap) !important;
        align-items: stretch !important;
      }

      /* 2. Preserve each card's internal layout without clipping or overlapping */
      #stoneGalleryGrid > * {
        width: 100% !important;
        max-width: 100% !important;
        height: max-content !important;
        min-height: max-content !important;
        align-self: start !important;
        position: relative !important;
        overflow: hidden !important;
        display: flex !important;
        flex-direction: column !important;
      }

      /* 3. Explicit responsive image height so implicit grid rows never collapse */
      #stoneGalleryGrid > * .gvm-img-frame {
        position: relative !important;
        width: 100% !important;
        height: var(--gvm-img-height, 180px) !important;
        min-height: var(--gvm-img-height, 180px) !important;
        max-height: none !important;
        aspect-ratio: 4 / 3 !important;
        overflow: hidden !important;
        flex-shrink: 0 !important;
      }

      /* 4. Image fills its 4:3 wrapper cleanly without overflowing onto next rows */
      #stoneGalleryGrid > * .gvm-img-frame > img,
      #stoneGalleryGrid > * img.gvm-target-img {
        position: relative !important;
        width: 100% !important;
        height: 100% !important;
        max-height: none !important;
        aspect-ratio: 4 / 3 !important;
        object-fit: cover !important;
        display: block !important;
      }

      /* 5. Keep category badges & multi-select checkboxes pinned cleanly in corners */
      #stoneGalleryGrid .gallery-item-chk {
        width: 1.15rem !important;
        height: 1.15rem !important;
        z-index: 25 !important;
        cursor: pointer;
        accent-color: #00f0ff;
      }

      /* 6. Crisp, legible typography that never bloats over the stone photo */
      #stoneGalleryGrid h3,
      #stoneGalleryGrid h4,
      #stoneGalleryGrid .stone-title,
      #stoneGalleryGrid [data-stone-name] {
        font-size: var(--gvm-title-size) !important;
        line-height: 1.35 !important;
      }

      #stoneGalleryGrid .stone-price,
      #stoneGalleryGrid [data-stone-price] {
        font-size: var(--gvm-price-size) !important;
        line-height: 1.3 !important;
      }

      #stoneGalleryGrid .stone-meta,
      #stoneGalleryGrid [data-stone-meta] {
        font-size: var(--gvm-meta-size) !important;
      }

      /* Explorer View Switcher Toolbar */
      .gvm-toolbar {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        padding: 0.25rem;
        border-radius: 0.65rem;
        background: rgba(6, 11, 28, 0.92);
        border: 1px solid rgba(56, 189, 248, 0.28);
      }

      .gvm-btn {
        display: inline-flex;
        align-items: center;
        gap: 0.35rem;
        padding: 0.3rem 0.65rem;
        border-radius: 0.45rem;
        font-size: 0.72rem;
        font-family: 'JetBrains Mono', 'Noto Sans Thai', monospace;
        font-weight: 600;
        color: #94a3b8;
        background: transparent;
        border: 1px solid transparent;
        cursor: pointer;
        transition: all 0.15s ease;
        white-space: nowrap;
      }

      .gvm-btn:hover {
        color: #e2e8f0;
        background: rgba(30, 41, 59, 0.75);
      }

      .gvm-btn.active {
        color: #cffafe;
        background: linear-gradient(135deg, rgba(0, 240, 255, 0.22), rgba(99, 102, 241, 0.24));
        border-color: rgba(0, 240, 255, 0.5);
        box-shadow: 0 0 12px rgba(0, 240, 255, 0.18);
      }

      .gvm-hint {
        font-size: 0.68rem;
        color: #64748b;
        margin-left: 0.35rem;
        padding-right: 0.35rem;
      }

      @media (max-width: 640px) {
        .gvm-hint {
          display: none;
        }
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Inspects each rendered card inside #stoneGalleryGrid and tags its image wrapper
   * with `.gvm-img-frame` so fixed Tailwind heights (h-32, h-36, aspect-video)
   * unlock cleanly without causing vertical overlap/striping.
   */
  normalizeCardFrames() {
    const grid = document.getElementById('stoneGalleryGrid');
    if (!grid) return;

    const cards = Array.from(grid.children);
    for (const card of cards) {
      const img = card.querySelector('img');
      if (!img) continue;

      img.classList.add('gvm-target-img');
      const wrapper = img.parentElement;
      if (wrapper && wrapper !== card && wrapper !== grid) {
        wrapper.classList.add('gvm-img-frame');
      }
    }
  }

  applyMode(modeId) {
    const spec = VIEW_MODES[modeId] || VIEW_MODES.medium;
    this.currentMode = spec.id;
    this._saveMode(spec.id);

    const grid = document.getElementById('stoneGalleryGrid');
    if (grid) {
      this.normalizeCardFrames();
      grid.dataset.viewMode = spec.id;
      grid.style.setProperty('--gvm-min-width', spec.minWidth);
      grid.style.setProperty('--gvm-img-height', spec.imgHeight);
      grid.style.setProperty('--gvm-title-size', spec.titleSize);
      grid.style.setProperty('--gvm-price-size', spec.priceSize);
      grid.style.setProperty('--gvm-meta-size', spec.metaSize);
      grid.style.setProperty('--gvm-grid-gap', spec.gridGap);
    }

    document.querySelectorAll('.gvm-btn[data-gvm-mode]').forEach((btn) => {
      const isMatch = btn.getAttribute('data-gvm-mode') === spec.id;
      btn.classList.toggle('active', isMatch);
      btn.setAttribute('aria-pressed', isMatch ? 'true' : 'false');
    });
  }

  stepMode(direction) {
    const idx = MODE_ORDER.indexOf(this.currentMode);
    const nextIdx = Math.min(MODE_ORDER.length - 1, Math.max(0, idx + direction));
    if (nextIdx !== idx) {
      this.applyMode(MODE_ORDER[nextIdx]);
    }
  }

  mountToolbar() {
    const modal = document.getElementById('stoneGalleryModal');
    const grid = document.getElementById('stoneGalleryGrid');
    if (!modal || !grid) return;

    if (document.getElementById('galleryViewModeToolbar')) {
      this.applyMode(this.currentMode);
      return;
    }

    const toolbar = document.createElement('div');
    toolbar.id = 'galleryViewModeToolbar';
    toolbar.className = 'gvm-toolbar';
    toolbar.setAttribute('role', 'group');
    toolbar.setAttribute('aria-label', 'ขนาดการแสดงผลคลังรูปหิน');

    const modes = [
      { id: 'medium', label: '⊞ Medium', title: 'มุมมองปานกลาง (4-5 รูป/แถว)' },
      { id: 'large', label: '⊟ Large', title: 'มุมมองใหญ่ (3 รูป/แถว)' },
      { id: 'xlarge', label: '⊡ Extra Large', title: 'มุมมองใหญ่พิเศษ (2 รูป/แถว ส่องลายแร่)' }
    ];
    toolbar.innerHTML =
      modes
        .map(
          (m) =>
            `<button type="button" class="gvm-btn" data-gvm-mode="${this._escapeHtml(m.id)}" title="${this._escapeHtml(m.title)}"><span>${this._escapeHtml(m.label)}</span></button>`
        )
        .join('') + `<span class="gvm-hint">${this._escapeHtml('Ctrl + Scroll ซูม')}</span>`;

    toolbar.querySelectorAll('.gvm-btn[data-gvm-mode]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.applyMode(btn.getAttribute('data-gvm-mode'));
      });
    });

    const filterBar =
      modal.querySelector('[data-gallery-toolbar]') ||
      modal.querySelector('#galleryAttributeFilters');

    if (filterBar) {
      filterBar.appendChild(toolbar);
    } else if (grid.parentElement) {
      const wrapper = document.createElement('div');
      wrapper.className = 'flex flex-wrap items-center justify-between gap-2 mb-3';
      wrapper.innerHTML = `
        <span class="text-[11px] font-mono text-slate-400">
          มุมมองแกลเลอรี (คลิกติ๊กมุมขวาบนได้หลายรูป แล้วกด <kbd class="px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">Enter</kbd> เพื่อส่ง)
        </span>
      `;
      wrapper.appendChild(toolbar);
      grid.parentElement.insertBefore(wrapper, grid);
    }

    this.applyMode(this.currentMode);
  }

  bindEvents() {
    // 1. Ctrl + Mouse Wheel zoom on #stoneGalleryGrid
    document.addEventListener(
      'wheel',
      (e) => {
        if (!e.ctrlKey) return;
        const grid = document.getElementById('stoneGalleryGrid');
        const modal = document.getElementById('stoneGalleryModal');
        if (!grid || !modal || modal.classList.contains('hidden')) return;
        if (!grid.contains(e.target) && !modal.contains(e.target)) return;

        e.preventDefault();
        const now = Date.now();
        if (now < this.wheelLockUntil) return;
        this.wheelLockUntil = now + 180;

        if (e.deltaY < 0) {
          this.stepMode(1);
        } else if (e.deltaY > 0) {
          this.stepMode(-1);
        }
      },
      { passive: false }
    );

    // 2. Preserve Multi-Select Enter-to-Send compatibility
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      const modal = document.getElementById('stoneGalleryModal');
      if (!modal || modal.classList.contains('hidden')) return;

      const activeTag = document.activeElement?.tagName?.toLowerCase();
      if (activeTag === 'input' && document.activeElement?.type !== 'checkbox') return;
      if (activeTag === 'textarea' || activeTag === 'select') return;

      const checked = modal.querySelectorAll('.gallery-item-chk:checked');
      if (checked.length === 0) return;

      const sendSelectedBtn =
        modal.querySelector('#galleryBatchSendBtn') ||
        modal.querySelector('#sendSelectedGalleryImagesBtn') ||
        modal.querySelector('[data-send-selected-gallery]');
      if (sendSelectedBtn && !sendSelectedBtn.disabled) {
        e.preventDefault();
        sendSelectedBtn.click();
      }
    });

    // 3. Wrap filterStoneGallery so normalization and current view mode always run right after rendering
    const origFilter = window.filterStoneGallery;
    if (typeof origFilter === 'function') {
      window.filterStoneGallery = (...args) => {
        const result = origFilter.apply(window, args);
        this.mountToolbar();
        this.normalizeCardFrames();
        this.applyMode(this.currentMode);
        return result;
      };
    }

    // 4. Re-normalize card image wrappers only on grid child list changes (prevent infinite loop)
    let isNormalizing = false;
    const grid = document.getElementById('stoneGalleryGrid');
    if (grid) {
      this.observer = new MutationObserver(() => {
        if (isNormalizing) return;
        isNormalizing = true;
        try {
          this.mountToolbar();
          this.normalizeCardFrames();
          if (grid.dataset.viewMode !== this.currentMode) {
            this.applyMode(this.currentMode);
          }
        } finally {
          setTimeout(() => { isNormalizing = false; }, 50);
        }
      });

      this.observer.observe(grid, {
        childList: true,
      });
    }
  }

  init() {
    this.injectStyles();
    this.mountToolbar();
    this.bindEvents();
    this.applyMode(this.currentMode);
  }
}

const galleryViewMode = new GalleryViewModeController();

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => galleryViewMode.init());
} else {
  galleryViewMode.init();
}

export { GalleryViewModeController, galleryViewMode };
