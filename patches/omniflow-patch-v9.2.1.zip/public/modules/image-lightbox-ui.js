// Phase 8.6 Modular UI Plugin: Interactive Image Lightbox with Mouse Wheel Zoom & Pan
(function initImageZoomLightbox() {
  let currentZoom = 1;
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let translateX = 0;
  let translateY = 0;

  // Create Lightbox DOM Container
  const lightbox = document.createElement('div');
  lightbox.id = 'stoneImageLightbox';
  lightbox.className = 'hidden fixed inset-0 z-[10000] bg-black/95 backdrop-blur-md flex flex-col justify-between p-4 select-none';
  lightbox.innerHTML = `
    <!-- Top Bar -->
    <div class="flex items-center justify-between px-4 py-2 border-b border-slate-800/80 bg-slate-950/70 rounded-xl">
      <div class="flex items-center gap-3">
        <i data-lucide="search" class="w-4 h-4 text-cyan-400 shrink-0"></i>
        <div>
          <h4 id="lightboxTitle" class="text-sm font-bold text-white leading-tight">ชื่อหิน</h4>
          <p id="lightboxSubtitle" class="text-xs font-mono text-emerald-300">ราคา</p>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <div class="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-slate-300 font-mono">
          <button id="zoomOutBtn" type="button" class="px-2 py-0.5 hover:text-cyan-400 font-bold" title="ย่อ">-</button>
          <span id="zoomPercentBadge" class="px-2 text-cyan-300">100%</span>
          <button id="zoomInBtn" type="button" class="px-2 py-0.5 hover:text-cyan-400 font-bold" title="ขยาย">+</button>
          <button id="zoomResetBtn" type="button" class="px-2 py-0.5 ml-1 text-[11px] text-slate-400 hover:text-white border-l border-slate-700 pl-2">รีเซ็ต</button>
        </div>
        <button id="lightboxCloseBtn" type="button" class="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition inline-flex items-center gap-1">
          <i data-lucide="x" class="w-3.5 h-3.5 shrink-0"></i><span>ปิด (Esc)</span>
        </button>
      </div>
    </div>

    <!-- Viewer Canvas -->
    <div id="lightboxViewport" class="flex-1 relative overflow-hidden flex items-center justify-center my-2 cursor-grab">
      <img id="lightboxImg" src="" alt="ซูมลายหิน" class="max-w-none transition-transform duration-75 will-change-transform" style="transform: scale(1) translate(0px, 0px);" draggable="false" />
    </div>

    <!-- Bottom Help Bar -->
    <div class="flex flex-wrap items-center justify-between px-4 py-2 text-xs text-slate-400 bg-slate-950/70 rounded-xl border-t border-slate-800/80">
      <span class="flex items-center gap-2">
        <span class="inline-flex items-center gap-1.5"><i data-lucide="lightbulb" class="w-3.5 h-3.5 text-amber-400 shrink-0"></i><b>ใช้ลูกกลิ้งเมาส์ (Scroll Wheel):</b> เลื่อนขึ้นเพื่อซูมขยาย / เลื่อนลงเพื่อย่อ</span>
        <span class="hidden sm:inline">• <b>คลิกลาก (Drag):</b> เลื่อนดูรายละเอียดลายหิน</span>
        <span class="hidden sm:inline">• <b>ดับเบิลคลิก:</b> ซูมเข้า 2x ทันที</span>
      </span>
      <span class="font-mono text-slate-500">กดปุ่ม Esc หรือคลิกพื้นหลังเพื่อปิด</span>
    </div>
  `;
  document.body.appendChild(lightbox);
  if (window.lucide) window.lucide.createIcons();

  const imgEl = document.getElementById('lightboxImg');
  const titleEl = document.getElementById('lightboxTitle');
  const subEl = document.getElementById('lightboxSubtitle');
  const badgeEl = document.getElementById('zoomPercentBadge');
  const viewport = document.getElementById('lightboxViewport');

  function updateTransform() {
    imgEl.style.transform = `translate(${translateX}px, ${translateY}px) scale(${currentZoom})`;
    badgeEl.textContent = `${Math.round(currentZoom * 100)}%`;
  }

  function resetZoom() {
    currentZoom = 1;
    translateX = 0;
    translateY = 0;
    updateTransform();
    viewport.style.cursor = 'grab';
  }

  function setZoom(newZoom, originX = 0, originY = 0) {
    const clamped = Math.min(Math.max(newZoom, 0.5), 6.0); // 50% to 600%
    currentZoom = clamped;
    updateTransform();
    viewport.style.cursor = currentZoom > 1 ? 'grab' : 'default';
  }

  // Global Function to Open Lightbox
  window.openImageLightbox = function (imageUrl, title = 'หินธรรมชาติ', subtitle = '') {
    if (!imageUrl) return;
    imgEl.src = imageUrl;
    titleEl.textContent = title;
    subEl.textContent = subtitle;
    resetZoom();
    lightbox.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
  };

  // Close Lightbox
  function closeLightbox() {
    lightbox.classList.add('hidden');
    imgEl.src = '';
    document.body.style.overflow = '';
  }

  document.getElementById('lightboxCloseBtn').addEventListener('click', closeLightbox);
  document.getElementById('zoomInBtn').addEventListener('click', () => setZoom(currentZoom + 0.3));
  document.getElementById('zoomOutBtn').addEventListener('click', () => setZoom(currentZoom - 0.3));
  document.getElementById('zoomResetBtn').addEventListener('click', resetZoom);

  // Close on Esc key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && !lightbox.classList.contains('hidden')) {
      closeLightbox();
    }
  });

  // Mouse Wheel Zoom
  viewport.addEventListener('wheel', (e) => {
    e.preventDefault();
    const zoomDelta = e.deltaY < 0 ? 0.2 : -0.2;
    setZoom(currentZoom + zoomDelta);
  }, { passive: false });

  // Double Click Zoom Toggle
  viewport.addEventListener('dblclick', (e) => {
    if (currentZoom > 1) {
      resetZoom();
    } else {
      setZoom(2.5);
    }
  });

  // Mouse Drag to Pan when zoomed
  viewport.addEventListener('mousedown', (e) => {
    if (e.target === lightbox || e.button !== 0) return;
    isDragging = true;
    startX = e.clientX - translateX;
    startY = e.clientY - translateY;
    viewport.style.cursor = 'grabbing';
  });

  window.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    translateX = e.clientX - startX;
    translateY = e.clientY - startY;
    updateTransform();
  });

  window.addEventListener('mouseup', () => {
    if (isDragging) {
      isDragging = false;
      viewport.style.cursor = currentZoom > 1 ? 'grab' : 'default';
    }
  });
})();
