// gateway/public/modules/theme-engine-ui.js
// Phase 11 v1.2: OmniFlow Dynamic Multi-Theme Engine (Bright, Glassmorphism & High Contrast Upgrade)
// Pure Vanilla JS + HTML5 Canvas API • Zero Third-Party Dependencies • Zero-Breakage CSS Injection

const STORAGE_KEY = 'omniflow_theme_config_v1';
const STYLE_TAG_ID = 'omniflow-dynamic-theme';
const BG_LAYER_ID = 'omniflow-wallpaper-layer';
const NAV_BTN_ID = 'omniOpenThemeBtn';
const MODAL_ID = 'omniThemeModal';

const PRESET_THEMES = {
  cyber_cyan: {
    id: 'cyber_cyan',
    name: 'Cyber Cyan',
    subtitle: 'ดำออบซิเดียน + ฟ้าเรืองแสง (Default)',
    primary: '#00f0ff',
    secondary: '#38bdf8',
    backdrop: '#050814',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  luxury_gold: {
    id: 'luxury_gold',
    name: 'Luxury Gold',
    subtitle: 'ดำพรีเมียม + ทองคำเรืองแสง',
    primary: '#eab308',
    secondary: '#f59e0b',
    backdrop: '#090704',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  emerald_tech: {
    id: 'emerald_tech',
    name: 'Emerald Tech',
    subtitle: 'เขียวมรกตเมทริกซ์ไซเบอร์',
    primary: '#10b981',
    secondary: '#059669',
    backdrop: '#030d0a',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  purple_synthwave: {
    id: 'purple_synthwave',
    name: 'Purple Synthwave',
    subtitle: 'ม่วงนีออนไซเบอร์พังก์',
    primary: '#a855f7',
    secondary: '#8b5cf6',
    backdrop: '#080512',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  crimson_red: {
    id: 'crimson_red',
    name: 'Crimson Red',
    subtitle: 'แดงทับทิมดุดันทรงพลัง',
    primary: '#f43f5e',
    secondary: '#e11d48',
    backdrop: '#0d0407',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  glass_frosted: {
    id: 'glass_frosted',
    name: 'กระจกคริสตัลฝ้านีออน',
    subtitle: 'High Glassmorphism โปร่งใสละมุนตา',
    primary: '#38bdf8',
    secondary: '#818cf8',
    backdrop: '#0c1527',
    cardOpacity: 0.45,
    glassBlur: 16
  },
  modern_navy: {
    id: 'modern_navy',
    name: 'สีกรมท่าสว่างโมเดิร์น',
    subtitle: 'Clean Slate Business ระดับสากล',
    primary: '#0284c7',
    secondary: '#38bdf8',
    backdrop: '#0f172a',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  clean_pearl: {
    id: 'clean_pearl',
    name: 'โหมดสว่างนวลตา',
    subtitle: 'Soft Pearl / Clean Light คอนทราสต์สูง',
    primary: '#0284c7',
    secondary: '#6366f1',
    backdrop: '#f1f5f9',
    cardOpacity: 0.78,
    glassBlur: 14
  },
  ruby_flare: {
    id: 'ruby_flare',
    name: 'Ruby Red',
    subtitle: 'แดงสดรูบี้ คมชัดมีพลัง',
    primary: '#ef4444',
    secondary: '#f87171',
    backdrop: '#120506',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  amber_sunset: {
    id: 'amber_sunset',
    name: 'Amber Sunset',
    subtitle: 'ส้มอำพันอบอุ่น สดใสเด่นชัด',
    primary: '#f97316',
    secondary: '#fb923c',
    backdrop: '#120903',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  royal_indigo: {
    id: 'royal_indigo',
    name: 'Royal Indigo',
    subtitle: 'น้ำเงินครามรอยัล สุขุมหรูหรา',
    primary: '#6366f1',
    secondary: '#818cf8',
    backdrop: '#070918',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  sakura_rose: {
    id: 'sakura_rose',
    name: 'Rose Pink',
    subtitle: 'ชมพูโรสซากุระ ละมุนทันสมัย',
    primary: '#ec4899',
    secondary: '#f472b6',
    backdrop: '#12050d',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  teal_ocean: {
    id: 'teal_ocean',
    name: 'Teal Ocean',
    subtitle: 'เขียวอมฟ้าเทอร์ควอยซ์ สบายตา',
    primary: '#14b8a6',
    secondary: '#2dd4bf',
    backdrop: '#041010',
    cardOpacity: 0.65,
    glassBlur: 14
  },
  graphite_mono: {
    id: 'graphite_mono',
    name: 'Graphite Slate',
    subtitle: 'โหมดมืดเทา-ขาวมินิมอล อ่านง่ายทั้งวัน',
    primary: '#e2e8f0',
    secondary: '#94a3b8',
    backdrop: '#0f1115',
    cardOpacity: 0.72,
    glassBlur: 12
  },
  warm_ivory: {
    id: 'warm_ivory',
    name: 'Warm Ivory Light',
    subtitle: 'โหมดสว่างครีม-อำพัน ถนอมสายตา',
    primary: '#d97706',
    secondary: '#ea580c',
    backdrop: '#faf7f2',
    cardOpacity: 0.82,
    glassBlur: 12
  },
  mint_daylight: {
    id: 'mint_daylight',
    name: 'Mint Daylight',
    subtitle: 'โหมดสว่างเขียวมิ้นต์ สดชื่นอ่านง่าย',
    primary: '#059669',
    secondary: '#0d9488',
    backdrop: '#f0fdf9',
    cardOpacity: 0.82,
    glassBlur: 12
  },
  obsidian_charcoal: {
    id: 'obsidian_charcoal',
    name: 'Obsidian Charcoal',
    subtitle: 'ชาร์โคลเข้ม-เทาเงิน สุขุมระดับผู้บริหาร',
    primary: '#d4d4d8',
    secondary: '#71717a',
    backdrop: '#09090b',
    cardOpacity: 0.78,
    glassBlur: 12
  },
  corporate_bw: {
    id: 'corporate_bw',
    name: 'Corporate Black & White',
    subtitle: 'ขาว-ดำคลาสสิก สะอาดตา คมชัดแบบองค์กร',
    primary: '#18181b',
    secondary: '#52525b',
    backdrop: '#f8fafc',
    cardOpacity: 0.88,
    glassBlur: 10
  },
  titanium_silver: {
    id: 'titanium_silver',
    name: 'Titanium Silver',
    subtitle: 'ไทเทเนียมเมทัลลิก เทาเงินหรูหรานุ่มตา',
    primary: '#cbd5e1',
    secondary: '#64748b',
    backdrop: '#11161f',
    cardOpacity: 0.72,
    glassBlur: 14
  },
  deep_navy_corporate: {
    id: 'deep_navy_corporate',
    name: 'Deep Navy Corporate',
    subtitle: 'กรมท่าเข้ม-ฟ้าสตีล มาตรฐานองค์กร',
    primary: '#60a5fa',
    secondary: '#3b82f6',
    backdrop: '#070e1c',
    cardOpacity: 0.75,
    glassBlur: 14
  }
};

const DEFAULT_THEME_STATE = {
  mode: 'preset', // 'preset' | 'custom'
  presetId: 'cyber_cyan',
  primaryHex: '#00f0ff',
  secondaryHex: '#38bdf8',
  backdropHex: '#050814',
  cardOpacity: 0.65,
  glassBlur: 14,
  wallpaperEnabled: false,
  wallpaperDataUrl: '',
  overlayOpacity: 75 // 25 - 90 (%)
};

const SAFE_HEX_RE = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
const SAFE_DATA_IMG_RE = /^data:image\/(?:png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i;
const MAX_THEME_IMAGE_BYTES = 10 * 1024 * 1024; // 10 MB

function escapeHtml(str) {
  if (typeof window.escapeHtml === 'function') return window.escapeHtml(str);
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sanitizeHexColor(val, fallback = '#00f0ff') {
  const s = String(val ?? '').trim();
  return SAFE_HEX_RE.test(s) ? s : fallback;
}

function sanitizeWallpaperDataUrl(val) {
  const s = String(val ?? '').trim();
  if (!s || /["'\\(){}<>]/.test(s)) return '';
  if (typeof window.isSafeUrl === 'function') {
    return window.isSafeUrl(s, { allowDataImage: true }) && SAFE_DATA_IMG_RE.test(s) ? s : '';
  }
  return SAFE_DATA_IMG_RE.test(s) ? s : '';
}

function sanitizeThemeConfig(rawCfg = {}) {
  const merged = { ...DEFAULT_THEME_STATE, ...(rawCfg && typeof rawCfg === 'object' ? rawCfg : {}) };
  const mode = merged.mode === 'custom' ? 'custom' : 'preset';
  const presetId = Object.hasOwn(PRESET_THEMES, merged.presetId) ? merged.presetId : 'cyber_cyan';
  const cardNum = Number(merged.cardOpacity);
  const blurNum = Number(merged.glassBlur);
  const overlayNum = Number(merged.overlayOpacity);
  const safeWallpaper = sanitizeWallpaperDataUrl(merged.wallpaperDataUrl);

  return {
    ...merged,
    mode,
    presetId,
    primaryHex: sanitizeHexColor(merged.primaryHex, DEFAULT_THEME_STATE.primaryHex),
    secondaryHex: sanitizeHexColor(merged.secondaryHex, DEFAULT_THEME_STATE.secondaryHex),
    backdropHex: sanitizeHexColor(merged.backdropHex, DEFAULT_THEME_STATE.backdropHex),
    cardOpacity: Math.max(0.2, Math.min(1.0, Number.isFinite(cardNum) ? cardNum : DEFAULT_THEME_STATE.cardOpacity)),
    glassBlur: Math.max(0, Math.min(32, Number.isFinite(blurNum) ? blurNum : DEFAULT_THEME_STATE.glassBlur)),
    overlayOpacity: Math.max(25, Math.min(90, Number.isFinite(overlayNum) ? overlayNum : DEFAULT_THEME_STATE.overlayOpacity)),
    wallpaperDataUrl: safeWallpaper,
    wallpaperEnabled: Boolean(merged.wallpaperEnabled && safeWallpaper)
  };
}

let applyThemeRafId = 0;
function scheduleApplyOmniTheme(cfg) {
  if (applyThemeRafId) cancelAnimationFrame(applyThemeRafId);
  applyThemeRafId = requestAnimationFrame(() => {
    applyThemeRafId = 0;
    applyOmniTheme(cfg);
  });
}

let currentTheme = loadStoredTheme();
let draftTheme = { ...currentTheme };

function loadStoredTheme() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_THEME_STATE };
    const parsed = JSON.parse(raw);
    return sanitizeThemeConfig(parsed);
  } catch {
    return { ...DEFAULT_THEME_STATE };
  }
}

function saveStoredTheme(cfg) {
  let merged = { ...cfg };
  try {
    const prev = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    const navLayout = merged.navLayout || localStorage.getItem('omniflow_nav_layout_v1') || prev.navLayout;
    const barStyle = merged.barStyle || localStorage.getItem('omniflow_bar_style_v1') || prev.barStyle;
    if (navLayout) merged.navLayout = navLayout;
    if (barStyle) merged.barStyle = barStyle;
  } catch (err) {
    console.warn('[OmniTheme] storage error:', err);
  }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
  } catch (err) {
    console.warn('[OmniTheme] localStorage quota warning:', err.message);
    try {
      const lite = { ...merged, wallpaperDataUrl: '', wallpaperEnabled: false };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lite));
    } catch (err) {
      console.warn('[OmniTheme] storage error:', err);
    }
  }
}

function hexToRgb(hex) {
  const clean = String(hex || '#00f0ff').replace('#', '').trim();
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0').slice(0, 6);
  const num = parseInt(full, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

function rgbToHex(r, g, b) {
  const clamp = (v) => Math.max(0, Math.min(255, Math.round(v)));
  return (
    '#' +
    [clamp(r), clamp(g), clamp(b)]
      .map((x) => x.toString(16).padStart(2, '0'))
      .join('')
  );
}

function rgbToHsl(r, g, b) {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const l = (max + min) / 2;
  let h = 0;
  let s = 0;

  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case rn:
        h = (gn - bn) / d + (gn < bn ? 6 : 0);
        break;
      case gn:
        h = (bn - rn) / d + 2;
        break;
      default:
        h = (rn - gn) / d + 4;
        break;
    }
    h /= 6;
  }

  return { h: h * 360, s: s * 100, l: l * 100 };
}

function hslToHex(h, s, l) {
  const sn = Math.max(0, Math.min(100, s)) / 100;
  const ln = Math.max(0, Math.min(100, l)) / 100;
  const c = (1 - Math.abs(2 * ln - 1)) * sn;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = ln - c / 2;
  let r1 = 0;
  let g1 = 0;
  let b1 = 0;

  if (h >= 0 && h < 60) {
    r1 = c;
    g1 = x;
  } else if (h >= 60 && h < 120) {
    r1 = x;
    g1 = c;
  } else if (h >= 120 && h < 180) {
    g1 = c;
    b1 = x;
  } else if (h >= 180 && h < 240) {
    g1 = x;
    b1 = c;
  } else if (h >= 240 && h < 300) {
    r1 = x;
    b1 = c;
  } else {
    r1 = c;
    b1 = x;
  }

  return rgbToHex((r1 + m) * 255, (g1 + m) * 255, (b1 + m) * 255);
}

/**
 * Smart Image Color Adaptive Engine (Pure HTML5 Canvas API)
 * Extracts dominant vibrant hue (Saturation > 25% and Luminance between 20% and 80%),
 * then generates Neon Primary, Secondary, Glow, Border Accent, and Dark Backdrop.
 */
export function extractDominantColor(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith('image/') || /svg/i.test(file.type) || /\.svg$/i.test(file.name || '')) {
      reject(new Error('กรุณาเลือกไฟล์รูปภาพที่ปลอดภัย (.jpg, .png, .webp) และไม่รองรับ .svg'));
      return;
    }
    if (file.size > MAX_THEME_IMAGE_BYTES) {
      reject(new Error('ขนาดไฟล์รูปภาพต้องไม่เกิน 10 MB'));
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => reject(new Error('ไม่สามารถอ่านไฟล์รูปภาพได้'));
    reader.onload = () => {
      const originalDataUrl = String(reader.result || '');
      const img = new Image();
      img.onerror = () => reject(new Error('ไฟล์รูปภาพเสียหายหรือไม่รองรับ'));
      img.onload = () => {
        const sampleCanvas = document.createElement('canvas');
        const sampleSize = 96;
        sampleCanvas.width = sampleSize;
        sampleCanvas.height = sampleSize;
        const ctx = sampleCanvas.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(img, 0, 0, sampleSize, sampleSize);

        const { data } = ctx.getImageData(0, 0, sampleSize, sampleSize);

        const buckets = Array.from({ length: 36 }, () => ({
          weight: 0,
          sumH: 0,
          sumS: 0,
          sumL: 0,
          count: 0
        }));
        const fallbackBuckets = Array.from({ length: 36 }, () => ({
          weight: 0,
          sumH: 0,
          sumS: 0,
          sumL: 0,
          count: 0
        }));

        for (let i = 0; i < data.length; i += 4) {
          const a = data[i + 3];
          if (a < 140) continue;

          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const { h, s, l } = rgbToHsl(r, g, b);
          const bin = Math.floor(h / 10) % 36;

          if (s > 25 && l >= 20 && l <= 80) {
            const vibrancyWeight = (s / 100) * (1 - Math.abs(l - 50) / 50 + 0.35);
            buckets[bin].weight += vibrancyWeight;
            buckets[bin].sumH += h;
            buckets[bin].sumS += s;
            buckets[bin].sumL += l;
            buckets[bin].count += 1;
          } else if (s > 5 && l >= 8 && l <= 92) {
            const softWeight = (s / 100 + 0.05) * (1 - Math.abs(l - 50) / 60 + 0.25);
            fallbackBuckets[bin].weight += softWeight;
            fallbackBuckets[bin].sumH += h;
            fallbackBuckets[bin].sumS += s;
            fallbackBuckets[bin].sumL += l;
            fallbackBuckets[bin].count += 1;
          }
        }

        let bestBucket = null;
        for (const b of buckets) {
          if (b.count > 0 && (!bestBucket || b.weight > bestBucket.weight)) {
            bestBucket = b;
          }
        }
        if (!bestBucket) {
          for (const b of fallbackBuckets) {
            if (b.count > 0 && (!bestBucket || b.weight > bestBucket.weight)) {
              bestBucket = b;
            }
          }
        }

        let dominantHue = 186;
        let dominantSat = 92;
        let dominantLum = 54;

        if (bestBucket) {
          dominantHue = bestBucket.sumH / bestBucket.count;
          dominantSat = Math.max(72, Math.min(98, bestBucket.sumS / bestBucket.count));
          dominantLum = Math.max(48, Math.min(62, bestBucket.sumL / bestBucket.count));
        }

        const primaryHex = hslToHex(dominantHue, dominantSat, dominantLum);
        const secondaryHex = hslToHex((dominantHue + 16) % 360, Math.max(65, dominantSat - 8), Math.max(42, dominantLum - 6));
        const backdropHex = hslToHex(dominantHue, 38, 8);

        let compressedWallpaper = originalDataUrl;
        try {
          const maxDim = 1600;
          let targetW = img.naturalWidth || img.width;
          let targetH = img.naturalHeight || img.height;
          if (targetW > maxDim || targetH > maxDim) {
            const ratio = Math.min(maxDim / targetW, maxDim / targetH);
            targetW = Math.round(targetW * ratio);
            targetH = Math.round(targetH * ratio);
          }
          const wallCanvas = document.createElement('canvas');
          wallCanvas.width = targetW;
          wallCanvas.height = targetH;
          const wCtx = wallCanvas.getContext('2d');
          wCtx.drawImage(img, 0, 0, targetW, targetH);
          compressedWallpaper = wallCanvas.toDataURL('image/jpeg', 0.82);
        } catch {
          compressedWallpaper = originalDataUrl;
        }

        resolve({
          primaryHex,
          secondaryHex,
          backdropHex,
          hue: Math.round(dominantHue),
          saturation: Math.round(dominantSat),
          luminance: Math.round(dominantLum),
          wallpaperDataUrl: compressedWallpaper
        });
      };
      img.src = originalDataUrl;
    };
    reader.readAsDataURL(file);
  });
}

function ensureWallpaperLayer() {
  let layer = document.getElementById(BG_LAYER_ID);
  if (!layer) {
    layer = document.createElement('div');
    layer.id = BG_LAYER_ID;
    layer.setAttribute('aria-hidden', 'true');
    layer.className = 'fixed inset-0 pointer-events-none z-0 hidden transition-all duration-300';
    layer.style.zIndex = '0';
    layer.innerHTML = `
      <div id="${BG_LAYER_ID}-img" class="absolute inset-0 bg-cover bg-center bg-no-repeat"></div>
      <div id="${BG_LAYER_ID}-scrim" class="absolute inset-0 backdrop-blur-sm bg-[#050814]/75"></div>
    `;
    document.body.prepend(layer);
  }
  return layer;
}

/**
 * Zero-Breakage CSS Injection Engine (v1.2 Bright, Glassmorphism & High Contrast Upgrade)
 */
export function applyOmniTheme(rawCfg) {
  const cfg = sanitizeThemeConfig(rawCfg);
  const primary = cfg.primaryHex;
  const secondary = cfg.secondaryHex;
  const backdrop = cfg.backdropHex;
  const { r, g, b } = hexToRgb(primary);
  const { r: sr, g: sg, b: sb } = hexToRgb(secondary);
  const { r: br, g: bg, b: bb } = hexToRgb(backdrop);

  // Detect Light Mode via Backdrop Luminance (> 60%)
  const { l: backdropLuminance } = rgbToHsl(br, bg, bb);
  const isLightMode = backdropLuminance > 60;
  const safeWallpaperUrl = sanitizeWallpaperDataUrl(cfg.wallpaperDataUrl);
  const hasWallpaper = Boolean(cfg.wallpaperEnabled && safeWallpaperUrl);

  const glowRgba = `rgba(${r}, ${g}, ${b}, ${isLightMode ? '0.18' : '0.25'})`;
  const glowSoftRgba = `rgba(${r}, ${g}, ${b}, ${isLightMode ? '0.06' : '0.08'})`;
  const borderRgba = `rgba(${r}, ${g}, ${b}, ${isLightMode ? '0.35' : '0.35'})`;
  const borderSubtleRgba = `rgba(${r}, ${g}, ${b}, ${isLightMode ? '0.22' : '0.20'})`;
  const textGlowShadow = isLightMode
    ? `0 0 1px rgba(${r}, ${g}, ${b}, 0.35)`
    : `0 0 12px rgba(${r}, ${g}, ${b}, 0.65)`;

  let styleEl = document.getElementById(STYLE_TAG_ID);
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = STYLE_TAG_ID;
    document.head.appendChild(styleEl);
  }

  // Handle Wallpaper Overlay Layer (Scrim range 25% - 90%)
  const wallLayer = ensureWallpaperLayer();
  const wallImgEl = document.getElementById(`${BG_LAYER_ID}-img`);
  const wallScrimEl = document.getElementById(`${BG_LAYER_ID}-scrim`);
  const opacityPct = Math.max(25, Math.min(90, Number(cfg.overlayOpacity ?? 75)));

  if (hasWallpaper) {
    wallLayer.classList.remove('hidden');
    if (wallImgEl) {
      wallImgEl.style.backgroundImage = `url("${safeWallpaperUrl}")`;
    }
    if (wallScrimEl) {
      wallScrimEl.style.backgroundColor = `rgba(${br}, ${bg}, ${bb}, ${(opacityPct / 100).toFixed(2)})`;
    }
  } else {
    wallLayer.classList.add('hidden');
    if (wallImgEl) wallImgEl.style.backgroundImage = '';
  }

  // Calculate Glassmorphism Opacity & Blur (User-adjustable 20% - 100%)
  const presetMeta = cfg.mode === 'preset' ? PRESET_THEMES[cfg.presetId] : null;
  const rawCardAlpha = Number(cfg.cardOpacity ?? presetMeta?.cardOpacity ?? 0.65);
  const baseCardAlpha = Math.max(0.2, Math.min(1.0, Number.isFinite(rawCardAlpha) ? rawCardAlpha : 0.65));
  const rawBlur = Number(cfg.glassBlur ?? presetMeta?.glassBlur ?? 16);
  const glassBlurPx = Math.max(0, Math.min(32, Number.isFinite(rawBlur) ? Math.round(rawBlur) : 14));

  const panelAlphaTop = baseCardAlpha;
  const panelAlphaBottom = Math.max(0.22, Math.min(1.0, baseCardAlpha + 0.06));
  const subcardAlpha = Math.max(0.15, Math.min(0.98, baseCardAlpha * 0.85));
  const barAlpha = Math.max(0.35, Math.min(0.98, baseCardAlpha + 0.08));

  const panelTopRgb = isLightMode
    ? `255, 255, 255`
    : `${Math.min(255, Math.round(br + 12 + r * 0.04))}, ${Math.min(255, Math.round(bg + 12 + g * 0.04))}, ${Math.min(255, Math.round(bb + 12 + b * 0.04))}`;
  const panelBottomRgb = isLightMode
    ? `248, 250, 252`
    : `${Math.min(255, Math.round(br + 5 + r * 0.02))}, ${Math.min(255, Math.round(bg + 5 + g * 0.02))}, ${Math.min(255, Math.round(bb + 5 + b * 0.02))}`;
  const innerDeepRgb = `${Math.min(255, Math.round(br + 2 + r * 0.02))}, ${Math.min(255, Math.round(bg + 2 + g * 0.02))}, ${Math.min(255, Math.round(bb + 2 + b * 0.02))}`;
  const innerSurfaceRgb = `${Math.min(255, Math.round(br + 9 + r * 0.03))}, ${Math.min(255, Math.round(bg + 9 + g * 0.03))}, ${Math.min(255, Math.round(bb + 9 + b * 0.03))}`;
  const modalShellRgb = `${Math.min(255, Math.round(br + 6 + r * 0.03))}, ${Math.min(255, Math.round(bg + 6 + g * 0.03))}, ${Math.min(255, Math.round(bb + 6 + b * 0.03))}`;
  const innerDeepAlpha = hasWallpaper ? '0.58' : '0.68';
  const innerSurfaceAlpha = hasWallpaper ? '0.68' : '0.78';

  const panelShadow = isLightMode
    ? `0 8px 28px rgba(15, 23, 42, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.9) !important;`
    : `0 8px 32px rgba(0, 0, 0, 0.35), inset 0 1px 0 rgba(255, 255, 255, 0.12) !important;`;

  const bodyBackgroundCss = hasWallpaper
    ? `background-color: transparent !important; background-image: none !important;`
    : isLightMode
    ? `
      background-color: ${backdrop} !important;
      background-image:
        radial-gradient(circle at 12% 8%, rgba(${sr}, ${sg}, ${sb}, 0.10) 0%, transparent 45%),
        radial-gradient(circle at 88% 12%, rgba(${r}, ${g}, ${b}, 0.10) 0%, transparent 45%),
        linear-gradient(rgba(15, 23, 42, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(15, 23, 42, 0.03) 1px, transparent 1px) !important;
      background-size: 100% 100%, 100% 100%, 36px 36px, 36px 36px !important;
    `
    : `
      background-color: ${backdrop} !important;
      background-image:
        radial-gradient(circle at 15% 10%, rgba(${sr}, ${sg}, ${sb}, 0.16) 0%, transparent 42%),
        radial-gradient(circle at 85% 15%, rgba(${r}, ${g}, ${b}, 0.16) 0%, transparent 44%),
        linear-gradient(rgba(${r}, ${g}, ${b}, 0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(${r}, ${g}, ${b}, 0.035) 1px, transparent 1px) !important;
      background-size: 100% 100%, 100% 100%, 36px 36px, 36px 36px !important;
    `;

  const lightModeOverrides = isLightMode
    ? `
    body {
      color: #0f172a !important;
    }

    header {
      background-color: rgba(255, 255, 255, 0.85) !important;
      backdrop-filter: blur(16px) !important;
      -webkit-backdrop-filter: blur(16px) !important;
      border-bottom-color: rgba(15, 23, 42, 0.10) !important;
    }

    .text-white {
      color: #0f172a !important;
    }

    .text-slate-100,
    .text-slate-200 {
      color: #1e293b !important;
    }

    .text-slate-300 {
      color: #334155 !important;
    }

    .text-slate-400 {
      color: #475569 !important;
    }

    .text-slate-500 {
      color: #64748b !important;
    }

    .bg-slate-950\\/90,
    .bg-slate-950\\/80,
    .bg-slate-950\\/70,
    .bg-slate-950\\/60,
    .bg-slate-950\\/50,
    .bg-slate-900\\/90,
    .bg-slate-900\\/80,
    .bg-\\[\\#060b1c\\],
    .bg-\\[\\#060b1c\\]\\/80,
    .bg-\\[\\#070d22\\],
    .bg-\\[\\#060a18\\],
    .bg-\\[\\#050814\\]\\/60,
    .bg-black\\/60,
    .bg-black\\/40 {
      background-color: rgba(241, 245, 249, 0.88) !important;
      border-color: rgba(148, 163, 184, 0.45) !important;
    }

    .border-slate-800,
    .border-slate-800\\/90,
    .border-slate-800\\/80,
    .border-slate-800\\/70,
    .border-slate-700,
    .border-slate-700\\/90,
    .border-slate-700\\/80 {
      border-color: rgba(148, 163, 184, 0.45) !important;
    }

    .text-emerald-300,
    .text-emerald-400 {
      color: #047857 !important;
    }

    .text-purple-300 {
      color: #6d28d9 !important;
    }

    .text-indigo-300,
    .text-indigo-200 {
      color: #3730a3 !important;
    }

    .text-amber-300,
    .text-amber-200 {
      color: #b45309 !important;
    }
    `
    : `
    header {
      background-color: rgba(${br}, ${bg}, ${bb}, ${hasWallpaper ? '0.68' : '0.78'}) !important;
      backdrop-filter: blur(16px) !important;
      -webkit-backdrop-filter: blur(16px) !important;
      border-bottom-color: ${borderSubtleRgba} !important;
    }

    .bg-slate-950,
    .bg-slate-950\\/90,
    .bg-slate-950\\/80,
    .bg-slate-950\\/75,
    .bg-slate-950\\/70,
    .bg-slate-950\\/60,
    .bg-slate-950\\/50,
    .bg-\\[\\#060b1c\\],
    .bg-\\[\\#060b1c\\]\\/80,
    .bg-\\[\\#060a18\\],
    .bg-\\[\\#050814\\]\\/60,
    .bg-black\\/70,
    .bg-black\\/60,
    .bg-black\\/45,
    .bg-black\\/40 {
      background-color: rgba(${innerDeepRgb}, ${innerDeepAlpha}) !important;
    }

    .bg-slate-900,
    .bg-slate-900\\/90,
    .bg-slate-900\\/80,
    .bg-slate-900\\/75,
    .bg-slate-900\\/70,
    .bg-slate-900\\/60,
    .bg-slate-900\\/40,
    .bg-\\[\\#070d22\\],
    .bg-\\[\\#070c1e\\] {
      background-color: rgba(${innerSurfaceRgb}, ${innerSurfaceAlpha}) !important;
    }

    .bg-\\[\\#0a1024\\],
    .bg-\\[\\#0a1024\\]\\/95 {
      background-color: rgba(${modalShellRgb}, 0.94) !important;
    }

    .border-slate-800,
    .border-slate-800\\/90,
    .border-slate-800\\/80,
    .border-slate-800\\/70,
    .border-slate-800\\/60,
    .border-slate-700,
    .border-slate-700\\/90,
    .border-slate-700\\/80,
    .border-slate-700\\/70,
    .border-slate-700\\/60 {
      border-color: ${borderSubtleRgba} !important;
    }
    `;

  styleEl.textContent = `
    :root {
      --neon-cyan: ${primary};
      --omni-primary: ${primary};
      --omni-secondary: ${secondary};
      --omni-glow: ${glowRgba};
      --omni-border: ${borderRgba};
      --omni-text-glow: ${textGlowShadow};
      --bg-void: ${backdrop};
    }

    html,
    body {
      ${bodyBackgroundCss}
    }

    ${hasWallpaper ? `
    body > div.flex-1 {
      position: relative;
      z-index: 1;
    }
    #rwAdminSettingsModal,
    #omniThemeModal {
      background-color: rgba(2, 6, 23, 0.38) !important;
      backdrop-filter: none !important;
      -webkit-backdrop-filter: none !important;
    }
    ` : ''}

    ${lightModeOverrides}

    .aether-panel,
    .sh-card,
    .grid-stack > .grid-stack-item > .grid-stack-item-content {
      background: linear-gradient(160deg, rgba(${panelTopRgb}, ${panelAlphaTop.toFixed(2)}) 0%, rgba(${panelBottomRgb}, ${panelAlphaBottom.toFixed(2)}) 100%) !important;
      backdrop-filter: blur(${glassBlurPx}px) saturate(180%) !important;
      -webkit-backdrop-filter: blur(${glassBlurPx}px) saturate(180%) !important;
      border-color: ${borderSubtleRgba} !important;
      box-shadow: ${panelShadow}
    }

    .aether-panel:hover,
    .sh-card:hover,
    .grid-stack > .grid-stack-item > .grid-stack-item-content:hover {
      border-color: var(--omni-border) !important;
    }

    .sh-subcard {
      background-color: rgba(${isLightMode ? '241, 245, 249' : innerSurfaceRgb}, ${subcardAlpha.toFixed(2)}) !important;
      backdrop-filter: blur(${Math.max(6, Math.round(glassBlurPx * 0.6))}px) !important;
      -webkit-backdrop-filter: blur(${Math.max(6, Math.round(glassBlurPx * 0.6))}px) !important;
      border-color: ${borderSubtleRgba} !important;
    }

    .sh-sidebar,
    .sh-header {
      background-color: rgba(${isLightMode ? '255, 255, 255' : `${br}, ${bg}, ${bb}`}, ${barAlpha.toFixed(2)}) !important;
      backdrop-filter: blur(${glassBlurPx}px) saturate(160%) !important;
      -webkit-backdrop-filter: blur(${glassBlurPx}px) saturate(160%) !important;
      border-color: ${borderSubtleRgba} !important;
    }

    .glow-cyan {
      box-shadow: 0 0 18px var(--omni-glow), inset 0 0 12px ${glowSoftRgba} !important;
      border-color: var(--omni-border) !important;
    }

    .text-glow-cyan {
      color: var(--omni-primary) !important;
      text-shadow: var(--omni-text-glow) !important;
    }

    .text-cyan-400,
    .text-cyan-300,
    .text-cyan-200 {
      color: var(--omni-primary) !important;
    }

    .border-cyan-500\\/20,
    .border-cyan-500\\/25,
    .border-cyan-500\\/30,
    .border-cyan-400\\/40,
    .border-cyan-400\\/50 {
      border-color: var(--omni-border) !important;
    }

    ::-webkit-scrollbar-thumb:hover {
      background: var(--omni-primary) !important;
    }
  `;
}

function showThemeToast(msg, isError = false) {
  const existing = document.getElementById('omniThemeToast');
  if (existing) existing.remove();
  const el = document.createElement('div');
  el.id = 'omniThemeToast';
  el.className = `fixed bottom-5 right-5 z-[10010] px-4 py-3 rounded-xl border text-xs font-semibold shadow-2xl transition ${
    isError
      ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
      : 'bg-slate-950/95 border-cyan-400/50 text-slate-100'
  }`;
  el.style.borderColor = isError ? '' : currentTheme.primaryHex;
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2800);
}

/**
 * Inject  Theme Switcher Button right next to  ตั้งค่าระบบ on Header
 */
export function injectThemeNavButton() {
  // Theme settings are now integrated as Tab 3 inside  ตั้งค่าระบบ modal
  return;
}

function buildThemeModal() {
  if (document.getElementById(MODAL_ID)) return;

  const overlay = document.createElement('div');
  overlay.id = MODAL_ID;
  overlay.className =
    'fixed inset-0 z-[9995] hidden items-center justify-center bg-slate-950/75 backdrop-blur-md p-4';

  overlay.innerHTML = `
    <div class="w-full max-w-4xl max-h-[90vh] flex flex-col rounded-2xl bg-[#0a1024]/95 border border-slate-700/90 shadow-2xl text-slate-100 overflow-hidden">
      <!-- Header -->
      <div class="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-xl bg-slate-900 border border-slate-700 flex items-center justify-center text-cyan-400"><i data-lucide="palette" class="w-4 h-4 shrink-0"></i></div>
          <div>
            <h2 class="text-base font-bold !text-white">สกินปรับแต่งแดชบอร์ดอัจฉริยะ (OmniFlow Theme Engine v1.2)</h2>
            <p class="text-xs !text-slate-400">เลือกธีมสำเร็จรูป ${Object.keys(PRESET_THEMES).length} สไตล์ (ครบทุกแม่สี รวมโหมดมืด/สว่างและกระจกใส Glassmorphism) หรือสกัดสีจากรูปภาพอัตโนมัติ</p>
          </div>
        </div>
        <button type="button" id="omniCloseThemeBtn" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-500/20 !text-slate-300 hover:!text-rose-300 border border-slate-700 text-xs font-semibold transition inline-flex items-center gap-1">
          <i data-lucide="x" class="w-3.5 h-3.5 shrink-0"></i><span>ปิด</span>
        </button>
      </div>

      <!-- Body -->
      <div id="omniThemeModalBody" class="flex-1 overflow-y-auto p-6 space-y-6"></div>

      <!-- Footer -->
      <div class="flex flex-wrap items-center justify-between gap-2 px-6 py-3.5 border-t border-slate-800 bg-slate-950/80">
        <button type="button" id="omniResetThemeBtn" class="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-rose-950/50 !text-slate-300 hover:!text-rose-200 border border-slate-700 text-xs font-semibold transition inline-flex items-center gap-1.5">
          <i data-lucide="rotate-ccw" class="w-3.5 h-3.5 shrink-0"></i><span>รีเซ็ตเป็นค่าเริ่มต้น (Reset to Default)</span>
        </button>
        <div class="flex items-center gap-2">
          <button type="button" id="omniCancelThemeBtn" class="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 !text-slate-200 text-xs font-semibold transition">
            ยกเลิก
          </button>
          <button type="button" id="omniSaveThemeBtn" class="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 !text-slate-950 font-bold text-xs shadow-lg transition inline-flex items-center gap-1.5">
            <i data-lucide="save" class="w-3.5 h-3.5 shrink-0"></i><span>บันทึกธีมนี้</span>
          </button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  if (window.lucide) window.lucide.createIcons();

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeThemeModal();
  });
  document.getElementById('omniCloseThemeBtn').addEventListener('click', closeThemeModal);
  document.getElementById('omniCancelThemeBtn').addEventListener('click', closeThemeModal);

  document.getElementById('omniResetThemeBtn').addEventListener('click', () => {
    draftTheme = { ...DEFAULT_THEME_STATE };
    currentTheme = { ...DEFAULT_THEME_STATE };
    saveStoredTheme(currentTheme);
    applyOmniTheme(currentTheme);
    renderThemeModalContent();
    showThemeToast(' รีเซ็ตธีมกลับเป็น Cyber Cyan ค่าเริ่มต้นเรียบร้อยแล้ว');
  });

  document.getElementById('omniSaveThemeBtn').addEventListener('click', () => {
    currentTheme = { ...draftTheme };
    saveStoredTheme(currentTheme);
    applyOmniTheme(currentTheme);
    closeThemeModal(true);
    showThemeToast(' บันทึกการตั้งค่าธีมและภาพพื้นหลังลงเบราว์เซอร์เรียบร้อยแล้ว');
  });
}

function openThemeModal() {
  draftTheme = { ...currentTheme };
  buildThemeModal();
  renderThemeModalContent();
  const overlay = document.getElementById(MODAL_ID);
  overlay.classList.remove('hidden');
  overlay.classList.add('flex');
}

function closeThemeModal(saved = false) {
  if (!saved) {
    applyOmniTheme(currentTheme);
  }
  const overlay = document.getElementById(MODAL_ID);
  if (!overlay) return;
  overlay.classList.add('hidden');
  overlay.classList.remove('flex');
}

function renderThemeModalContent(targetEl) {
  queueMicrotask(() => { if (window.lucide) window.lucide.createIcons(); });
  const outerBody = targetEl || document.getElementById('omniThemeModalBody');
  if (!outerBody) return;
  let body = outerBody.querySelector('#omniThemeInnerRoot');
  if (!body) {
    outerBody.innerHTML = '<div id="omniThemeInnerRoot" class="space-y-4"></div>';
    body = outerBody.querySelector('#omniThemeInnerRoot');
  }

  const presetList = Object.values(PRESET_THEMES);
  const presetsHtml = presetList
    .map((p) => {
      const isSelected = draftTheme.mode === 'preset' && draftTheme.presetId === p.id;
      const { r: pr, g: pg, b: pb } = hexToRgb(p.backdrop);
      const isLightSwatch = rgbToHsl(pr, pg, pb).l > 60;
      const safePrimary = sanitizeHexColor(p.primary, '#00f0ff');
      const safeBackdrop = sanitizeHexColor(p.backdrop, '#050814');
      return `
        <button type="button" data-preset-id="${escapeHtml(p.id)}"
          class="omni-preset-card text-left p-3.5 rounded-xl border transition flex flex-col justify-between gap-2.5 ${
            isSelected
              ? 'bg-slate-900 border-white/80 ring-2 ring-white/30'
              : 'bg-slate-950/80 border-slate-800 hover:border-slate-600'
          }">
          <div class="flex items-center justify-between w-full">
            <div class="flex items-center gap-1.5">
              <span class="w-5 h-5 rounded-full border border-white/30 shadow-md" style="background:${safePrimary}; box-shadow: 0 0 12px ${safePrimary};"></span>
              <span class="w-3.5 h-3.5 rounded-full border border-slate-500/50" style="background:${safeBackdrop};" title="Backdrop: ${escapeHtml(safeBackdrop)}"></span>
            </div>
            ${isSelected ? '<span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/15 !text-white">ACTIVE</span>' : ''}
          </div>
          <div>
            <div class="text-xs font-bold !text-white flex items-center gap-1">
              <span>${escapeHtml(p.name)}</span>
              ${isLightSwatch ? '<span class="text-[9px] px-1 py-0.2 rounded bg-sky-500/20 !text-sky-300 font-mono">LIGHT</span>' : ''}
            </div>
            <div class="text-[10px] !text-slate-400 mt-0.5 leading-snug">${escapeHtml(p.subtitle)}</div>
          </div>
        </button>
      `;
    })
    .join('');

  const safeWallUrl = sanitizeWallpaperDataUrl(draftTheme.wallpaperDataUrl);
  const hasWallpaper = Boolean(safeWallUrl);
  const { r: pr, g: pg, b: pb } = hexToRgb(draftTheme.primaryHex);
  const { r: sr, g: sg, b: sb } = hexToRgb(draftTheme.secondaryHex);
  const { r: br, g: bg, b: bb } = hexToRgb(draftTheme.backdropHex);
  const isLightPrimary = rgbToHsl(pr, pg, pb).l > 55;
  const isLightSecondary = rgbToHsl(sr, sg, sb).l > 55;
  const isLightBackdrop = rgbToHsl(br, bg, bb).l > 60;
  const cardOpacityPct = Math.round(Math.max(0.2, Math.min(1.0, Number(draftTheme.cardOpacity ?? 0.65))) * 100);
  const scrimAlpha = (Math.max(25, Math.min(90, Number(draftTheme.overlayOpacity ?? 75))) / 100).toFixed(2);

  setTimeout(() => { if (window.lucide) window.lucide.createIcons(); }, 0);
  body.innerHTML = `
    <!-- Section 1: Built-in Preset Skins -->
    <div class="space-y-2.5">
      <div class="flex items-center justify-between">
        <h3 class="text-xs font-bold uppercase tracking-wider !text-slate-300">1. คลังธีมสำเร็จรูป (${presetList.length} Built-in Preset Skins • Dark / Corporate / Glass / Light)</h3>
        <span class="text-[11px] font-mono !text-slate-400">คลิกเพื่อพรีวิวทันที</span>
      </div>
      <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        ${presetsHtml}
      </div>
    </div>

    <!-- Section 2: Smart Image Color Adaptive Engine -->
    <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-4">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider !text-white">2. สกัดสีอัจฉริยะจากรูปภาพ / โลโก้ร้านค้า (Smart Image Palette Engine)</h3>
          <p class="text-[11px] !text-slate-400 mt-0.5">วิเคราะห์ RGB ผ่าน HTML5 Canvas คัดกรองค่าสีสด (Vibrancy &gt; 25%) และสร้างคู่สีเรืองแสงอัตโนมัติ</p>
        </div>
        <div class="flex items-center gap-2">
          <label class="text-[11px] !text-slate-400">ปรับสีหลักเอง:</label>
          <input id="omniCustomHexPicker" type="color" value="${draftTheme.primaryHex}" class="w-8 h-8 rounded cursor-pointer bg-transparent border-0" />
          <span id="omniCurrentHexLabel" class="text-xs font-mono font-bold px-2 py-1 rounded bg-slate-950 border border-slate-700 !text-white">${draftTheme.primaryHex.toUpperCase()}</span>
        </div>
      </div>

      <!-- Drag & Drop Upload Box -->
      <div id="omniDropZone" class="border-2 border-dashed border-slate-700 hover:border-slate-500 rounded-xl p-5 text-center transition cursor-pointer bg-slate-950/60">
        <input id="omniThemeImageInput" type="file" accept="image/jpeg,image/png,image/webp" class="hidden" />
        <div class="flex justify-center mb-1.5 text-cyan-400"><i data-lucide="image" class="w-6 h-6 shrink-0"></i></div>
        <div class="text-xs font-semibold !text-slate-200">ลากวางรูปโลโก้ หรือ ภาพพื้นหลังที่นี่ (รองรับ .jpg, .png, .webp)</div>
        <div class="text-[11px] !text-slate-400 mt-1">ระบบจะสกัดโทนสีเด่นและแสดงผลบนแดชบอร์ดทันทีโดยไม่ส่งไฟล์ออกนอกเครื่อง</div>
      </div>

      <!-- Extracted Palette & Wallpaper Overlay Controls -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
        <div class="p-3 rounded-xl bg-slate-950/90 border border-slate-800 space-y-2.5">
          <div class="text-[11px] font-bold !text-slate-300">การแสดงผลภาพพื้นหลัง (Wallpaper Overlay)</div>
          ${hasWallpaper ? `
          <div class="relative h-20 w-full rounded-lg overflow-hidden border border-slate-700/80">
            <div id="omniWallpaperPreviewThumb" class="absolute inset-0 bg-cover bg-center" style="background-image: url(&quot;${safeWallUrl}&quot;);"></div>
            <div id="omniWallpaperPreviewScrim" class="absolute inset-0 flex items-center justify-between px-3 transition-colors" style="background-color: rgba(${br}, ${bg}, ${bb}, ${draftTheme.wallpaperEnabled ? scrimAlpha : '0.15'});">
              <span class="text-[10px] font-semibold px-2 py-0.5 rounded bg-black/55 !text-white backdrop-blur-xs">${draftTheme.wallpaperEnabled ? 'พรีวิวพื้นหลัง + ฟิลเตอร์' : 'ปิดพื้นหลังชั่วคราว'}</span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-black/55 !text-cyan-300">Scrim ${draftTheme.overlayOpacity}%</span>
            </div>
          </div>
          ` : ''}
          <label class="flex items-center gap-2 text-xs !text-slate-200 cursor-pointer ${!hasWallpaper ? 'opacity-50' : ''}">
            <input id="omniWallpaperToggle" type="checkbox" ${draftTheme.wallpaperEnabled && hasWallpaper ? 'checked' : ''} ${!hasWallpaper ? 'disabled' : ''} class="rounded bg-slate-900 border-slate-600" />
            <span>ตั้งรูปที่อัปโหลดเป็น Wallpaper พื้นหลังแดชบอร์ด</span>
          </label>
          <div class="space-y-1">
            <div class="flex justify-between text-[11px] !text-slate-400">
              <span>ความเข้มฟิลเตอร์ครอบพื้นหลัง (Readability Scrim):</span>
              <span id="omniOpacityVal" class="font-mono !text-white">${draftTheme.overlayOpacity}%</span>
            </div>
            <input id="omniOpacitySlider" type="range" min="25" max="90" value="${draftTheme.overlayOpacity}" class="w-full accent-cyan-400 cursor-pointer" />
            <div class="flex justify-between text-[9px] font-mono !text-slate-500">
              <span>25% (ภาพสว่างสดใส)</span>
              <span>90% (เน้นอ่านตัวหนังสือ)</span>
            </div>
          </div>

          <div class="pt-2 border-t border-slate-800/80 space-y-1.5">
            <div class="flex justify-between text-[11px] !text-slate-400">
              <span>ความหนาสี / ความโปร่งใสของกล่อง (Card Opacity):</span>
              <span id="omniCardOpacityVal" class="font-mono font-bold !text-cyan-300">${cardOpacityPct}%</span>
            </div>
            <input id="omniCardOpacitySlider" type="range" min="20" max="100" step="1" value="${cardOpacityPct}" class="w-full accent-cyan-400 cursor-pointer" />
            <div class="flex flex-wrap items-center justify-between gap-1 pt-0.5">
              <button type="button" data-card-opacity-preset="40" class="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-mono !text-slate-200 cursor-pointer">ใส 40%</button>
              <button type="button" data-card-opacity-preset="65" class="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-mono !text-slate-200 cursor-pointer">กระจก 65%</button>
              <button type="button" data-card-opacity-preset="85" class="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-mono !text-slate-200 cursor-pointer">กึ่งทึบ 85%</button>
              <button type="button" data-card-opacity-preset="100" class="px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-mono !text-slate-200 cursor-pointer">ทึบ 100%</button>
            </div>
          </div>
        </div>

        <div class="p-3 rounded-xl bg-slate-950/90 border border-slate-800 flex flex-col justify-between">
          <div class="text-[11px] font-bold !text-slate-300 mb-2">พรีวิวคู่สีปัจจุบัน (Live Swatches)</div>
          <div class="grid grid-cols-3 gap-2 text-center font-mono text-[10px]">
            <div class="p-2 rounded-lg border border-white/15" style="background:${draftTheme.primaryHex}; color:${isLightPrimary ? '#050814' : '#f8fafc'}; font-weight:700;">
              PRIMARY<br/>${draftTheme.primaryHex.toUpperCase()}
            </div>
            <div class="p-2 rounded-lg border border-white/15" style="background:${draftTheme.secondaryHex}; color:${isLightSecondary ? '#050814' : '#f8fafc'}; font-weight:700;">
              ACCENT<br/>${draftTheme.secondaryHex.toUpperCase()}
            </div>
            <div class="p-2 rounded-lg border border-white/15" style="background:${draftTheme.backdropHex}; color:${isLightBackdrop ? '#0f172a' : '#e2e8f0'}; font-weight:700;">
              BACKDROP<br/>${draftTheme.backdropHex.toUpperCase()}
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  // Bind Preset Cards
  body.querySelectorAll('.omni-preset-card').forEach((card) => {
    card.addEventListener('click', () => {
      const pid = card.getAttribute('data-preset-id');
      const preset = PRESET_THEMES[pid];
      if (!preset) return;
      draftTheme = {
        ...draftTheme,
        mode: 'preset',
        presetId: preset.id,
        primaryHex: preset.primary,
        secondaryHex: preset.secondary,
        backdropHex: preset.backdrop,
        cardOpacity: preset.cardOpacity ?? 0.65,
        glassBlur: preset.glassBlur ?? 14
      };
      currentTheme = { ...draftTheme };
      saveStoredTheme(currentTheme);
      applyOmniTheme(currentTheme);
      renderThemeModalContent(outerBody);
    });
  });

  // Bind Manual Color Picker (rAF throttled)
  const hexPicker = document.getElementById('omniCustomHexPicker');
  hexPicker?.addEventListener('input', (e) => {
    const val = sanitizeHexColor(e.target.value, DEFAULT_THEME_STATE.primaryHex);
    const { h, s, l } = rgbToHsl(...Object.values(hexToRgb(val)));
    draftTheme = {
      ...draftTheme,
      mode: 'custom',
      presetId: 'custom',
      primaryHex: val,
      secondaryHex: hslToHex((h + 15) % 360, s, Math.max(35, l - 6)),
      backdropHex: hslToHex(h, 38, 8),
      cardOpacity: 0.65,
      glassBlur: 14
    };
    currentTheme = { ...draftTheme };
    scheduleApplyOmniTheme(currentTheme);
    const lbl = document.getElementById('omniCurrentHexLabel');
    if (lbl) lbl.textContent = val.toUpperCase();
  });
  hexPicker?.addEventListener('change', () => {
    saveStoredTheme(currentTheme);
  });

  // Bind Dropzone & File Input
  const dropZone = document.getElementById('omniDropZone');
  const fileInput = document.getElementById('omniThemeImageInput');

  const processImageFile = async (file) => {
    try {
      const extracted = await extractDominantColor(file);
      draftTheme = {
        ...draftTheme,
        mode: 'custom',
        presetId: 'custom_image',
        primaryHex: extracted.primaryHex,
        secondaryHex: extracted.secondaryHex,
        backdropHex: extracted.backdropHex,
        cardOpacity: 0.62,
        glassBlur: 14,
        wallpaperDataUrl: extracted.wallpaperDataUrl,
        wallpaperEnabled: true
      };
      currentTheme = { ...draftTheme };
      saveStoredTheme(currentTheme);
      applyOmniTheme(currentTheme);
      renderThemeModalContent(outerBody);
      showThemeToast(` สกัดโทนสีเด่น (${extracted.primaryHex.toUpperCase()}) และตั้งภาพพื้นหลังสำเร็จ!`);
    } catch (err) {
      showThemeToast(` ${err.message}`, true);
    }
  };

  dropZone?.addEventListener('click', () => fileInput?.click());
  dropZone?.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('border-cyan-400', 'bg-slate-900');
  });
  dropZone?.addEventListener('dragleave', () => {
    dropZone.classList.remove('border-cyan-400', 'bg-slate-900');
  });
  dropZone?.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('border-cyan-400', 'bg-slate-900');
    const file = e.dataTransfer?.files?.[0];
    if (file) processImageFile(file);
  });

  fileInput?.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) processImageFile(file);
  });

  // Bind Wallpaper Toggle & Scrim Opacity Slider (25% - 90%)
  const wallToggle = document.getElementById('omniWallpaperToggle');
  wallToggle?.addEventListener('change', (e) => {
    draftTheme.wallpaperEnabled = Boolean(e.target.checked);
    currentTheme = { ...draftTheme };
    saveStoredTheme(currentTheme);
    applyOmniTheme(currentTheme);
    renderThemeModalContent(outerBody);
  });

  const opacitySlider = document.getElementById('omniOpacitySlider');
  opacitySlider?.addEventListener('input', (e) => {
    const val = Math.max(25, Math.min(90, Number(e.target.value) || 75));
    draftTheme.overlayOpacity = val;
    currentTheme = { ...draftTheme };
    const valLbl = document.getElementById('omniOpacityVal');
    if (valLbl) valLbl.textContent = `${val}%`;
    const previewScrim = document.getElementById('omniWallpaperPreviewScrim');
    if (previewScrim && draftTheme.wallpaperEnabled) {
      const { r: sbr, g: sbg, b: sbb } = hexToRgb(draftTheme.backdropHex);
      previewScrim.style.backgroundColor = `rgba(${sbr}, ${sbg}, ${sbb}, ${(val / 100).toFixed(2)})`;
    }
    scheduleApplyOmniTheme(currentTheme);
  });
  opacitySlider?.addEventListener('change', () => {
    saveStoredTheme(currentTheme);
  });

  const syncCardOpacityUi = (pctVal) => {
    const rounded = Math.max(20, Math.min(100, Math.round(Number(pctVal) || 65)));
    const lbl = document.getElementById('omniCardOpacityVal');
    if (lbl) lbl.textContent = `${rounded}%`;
    const slider = document.getElementById('omniCardOpacitySlider');
    if (slider && Number(slider.value) !== rounded) slider.value = String(rounded);
    const entLbl = document.getElementById('entCardOpacityVal');
    if (entLbl) entLbl.textContent = `${rounded}%`;
    const entSlider = document.getElementById('entCardOpacitySlider');
    if (entSlider && Number(entSlider.value) !== rounded) entSlider.value = String(rounded);
  };

  const cardOpacitySlider = document.getElementById('omniCardOpacitySlider');
  cardOpacitySlider?.addEventListener('input', (e) => {
    const pct = Math.max(20, Math.min(100, Number(e.target.value) || 65));
    draftTheme.cardOpacity = Number((pct / 100).toFixed(2));
    currentTheme = { ...draftTheme };
    syncCardOpacityUi(pct);
    scheduleApplyOmniTheme(currentTheme);
  });
  cardOpacitySlider?.addEventListener('change', () => {
    saveStoredTheme(currentTheme);
  });

  body.querySelectorAll('[data-card-opacity-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const pct = Math.max(20, Math.min(100, Number(btn.getAttribute('data-card-opacity-preset')) || 65));
      draftTheme.cardOpacity = Number((pct / 100).toFixed(2));
      currentTheme = { ...draftTheme };
      saveStoredTheme(currentTheme);
      syncCardOpacityUi(pct);
      applyOmniTheme(currentTheme);
    });
  });
}

function initOmniThemeEngine() {
  applyOmniTheme(currentTheme);
}

window.getOmniCardOpacityPct = () => {
  const raw = Number(currentTheme?.cardOpacity ?? 0.65);
  return Math.round(Math.max(0.2, Math.min(1.0, Number.isFinite(raw) ? raw : 0.65)) * 100);
};

window.setOmniCardOpacity = (pct, saveImmediate = true) => {
  const rounded = Math.max(20, Math.min(100, Math.round(Number(pct) || 65)));
  const alpha = Number((rounded / 100).toFixed(2));
  draftTheme.cardOpacity = alpha;
  if (saveImmediate) {
    currentTheme.cardOpacity = alpha;
    saveStoredTheme(currentTheme);
  }
  applyOmniTheme(saveImmediate ? currentTheme : draftTheme);
  const entLbl = document.getElementById('entCardOpacityVal');
  if (entLbl) entLbl.textContent = `${rounded}%`;
  const entSlider = document.getElementById('entCardOpacitySlider');
  if (entSlider && Number(entSlider.value) !== rounded) entSlider.value = String(rounded);
  const modalLbl = document.getElementById('omniCardOpacityVal');
  if (modalLbl) modalLbl.textContent = `${rounded}%`;
  const modalSlider = document.getElementById('omniCardOpacitySlider');
  if (modalSlider && Number(modalSlider.value) !== rounded) modalSlider.value = String(rounded);
  return rounded;
};

window.renderOmniThemeTab = (container) => {
  draftTheme = { ...currentTheme };
  renderThemeModalContent(container);
};

window.saveOmniTheme = () => {
  currentTheme = { ...draftTheme };
  saveStoredTheme(currentTheme);
  applyOmniTheme(currentTheme);
  showThemeToast(' บันทึกการตั้งค่าธีมและภาพพื้นหลังลงเบราว์เซอร์เรียบร้อยแล้ว');
};

window.resetOmniTheme = (container) => {
  draftTheme = { ...DEFAULT_THEME_STATE };
  currentTheme = { ...DEFAULT_THEME_STATE };
  saveStoredTheme(currentTheme);
  applyOmniTheme(currentTheme);
  const target =
    container ||
    document.getElementById('rwSettingsBody') ||
    document.getElementById('omniThemeModalBody');
  if (target) renderThemeModalContent(target);
  showThemeToast(' รีเซ็ตธีมกลับเป็น Cyber Cyan ค่าเริ่มต้นเรียบร้อยแล้ว');
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initOmniThemeEngine);
} else {
  initOmniThemeEngine();
}
