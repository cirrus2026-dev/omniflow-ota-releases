// gateway/public/modules/admin-settings-ui.js
// Phase 10.5: White-Label Business Profile, Channel Keys Vault & Universal Dynamic AI Provider List

const MODAL_ID = 'rwAdminSettingsModal';
const BTN_ID = 'rwOpenSettingsBtn';

const PROVIDER_TYPE_META = {
  openai_compat: {
    label: 'OpenAI-Compatible (Groq / OpenAI / DeepSeek / OpenRouter / Typhoon)',
    defaultBaseUrl: 'https://api.groq.com/openai/v1',
    defaultModel: 'llama-3.3-70b-versatile',
    needsKey: true
  },
  gemini: {
    label: 'Google Gemini API',
    defaultBaseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    defaultModel: 'gemini-2.5-flash',
    needsKey: true
  },
  local: {
    label: 'Local AI (Ollama / LM Studio - ไม่ต้องใช้ API Key)',
    defaultBaseUrl: 'http://host.docker.internal:11434/v1',
    defaultModel: 'qwen2.5:14b',
    needsKey: false
  }
};

const CHANNEL_SCHEMAS = [
  {
    id: 'line',
    title: 'LINE Official Account',
    badge: 'LINE',
    badgeColor: 'text-emerald-400 border-emerald-500/40 bg-emerald-950/50',
    fields: [
      { key: 'channelId', label: 'Channel ID', type: 'text', placeholder: 'กรอก LINE Channel ID' },
      { key: 'channelSecret', label: 'Channel Secret', type: 'password', placeholder: 'กรอก Channel Secret' },
      { key: 'channelAccessToken', label: 'Channel Access Token', type: 'password', placeholder: 'กรอก Long-lived Access Token' }
    ]
  },
  {
    id: 'facebook',
    title: 'Facebook Messenger & Instagram DM',
    badge: 'META',
    badgeColor: 'text-blue-400 border-blue-500/40 bg-blue-950/50',
    fields: [
      { key: 'pageAccessToken', label: 'Page Access Token', type: 'password', placeholder: 'กรอก Page Access Token' },
      { key: 'appSecret', label: 'App Secret', type: 'password', placeholder: 'กรอก Meta App Secret' },
      { key: 'verifyToken', label: 'Verify Token', type: 'text', placeholder: 'เช่น aether_verify_2026' }
    ]
  },
  {
    id: 'tiktok',
    title: 'TikTok Shop Open Platform',
    badge: 'TIKTOK',
    badgeColor: 'text-pink-400 border-pink-500/40 bg-pink-950/50',
    fields: [
      { key: 'appKey', label: 'App Key', type: 'text', placeholder: 'กรอก TikTok App Key' },
      { key: 'appSecret', label: 'App Secret', type: 'password', placeholder: 'กรอก TikTok App Secret' },
      { key: 'shopId', label: 'Shop ID', type: 'text', placeholder: 'กรอก TikTok Shop ID' }
    ]
  },
  {
    id: 'shopee',
    title: 'Shopee Open Platform',
    badge: 'SHOPEE',
    badgeColor: 'text-orange-400 border-orange-500/40 bg-orange-950/50',
    fields: [
      { key: 'partnerId', label: 'Partner ID', type: 'text', placeholder: 'กรอก Shopee Partner ID' },
      { key: 'partnerKey', label: 'Partner Key', type: 'password', placeholder: 'กรอก Shopee Partner Key' },
      { key: 'shopId', label: 'Shop ID', type: 'text', placeholder: 'กรอก Shopee Shop ID' }
    ]
  },
  {
    id: 'lazada',
    title: 'Lazada Open Platform',
    badge: 'LAZADA',
    badgeColor: 'text-indigo-400 border-indigo-500/40 bg-indigo-950/50',
    fields: [
      { key: 'appKey', label: 'App Key', type: 'text', placeholder: 'กรอก Lazada App Key' },
      { key: 'appSecret', label: 'App Secret', type: 'password', placeholder: 'กรอก Lazada App Secret' },
      { key: 'accessToken', label: 'Access Token', type: 'password', placeholder: 'กรอก Lazada Access Token' }
    ]
  },
  {
    id: 'whatsapp',
    title: 'WhatsApp Business Cloud API',
    badge: 'WHATSAPP',
    badgeColor: 'text-green-400 border-green-500/40 bg-green-950/50',
    fields: [
      { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', placeholder: 'เช่น 109876543210123' },
      { key: 'accessToken', label: 'Permanent Access Token', type: 'password', placeholder: 'กรอก System User Access Token' },
      { key: 'appSecret', label: 'Meta App Secret', type: 'password', placeholder: 'กรอก App Secret (X-Hub-Signature-256)' },
      { key: 'verifyToken', label: 'Verify Token', type: 'text', placeholder: 'เช่น omniflow_wa_verify_2026' }
    ]
  }
];

let cachedChannels = {};
let cachedChannelRegistry = null;
let cachedBusiness = { businessName: 'Aether AI Commerce', businessTagline: '' };
let cachedBrain = { greetingMessage: '', systemPrompt: '', providers: [] };
let activeTab = 'channels';
const tabLoadState = { channels: false, brain: false };

const MAX_JSON_UPLOAD_BYTES = 2 * 1024 * 1024; // 2 MB
const MAX_ZIP_UPLOAD_BYTES = 10 * 1024 * 1024; // 10 MB

function escapeHtml(str) {
  if (typeof window.escapeHtml === 'function') return window.escapeHtml(str);
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isSafeUrl(rawUrl, opts) {
  if (typeof window.isSafeUrl === 'function') return window.isSafeUrl(rawUrl, opts);
  const s = String(rawUrl ?? '').trim();
  if (!s || /^(?:javascript|vbscript|data):/i.test(s)) return false;
  if (/^\/(?!\/)/.test(s)) return true;
  try {
    const u = new URL(s, window.location.origin);
    return u.protocol === 'https:' || u.protocol === 'http:';
  } catch {
    return false;
  }
}

function sanitizeCssColor(val, fallback = '#38bdf8') {
  const s = String(val ?? '').trim();
  if (/^#[0-9a-fA-F]{3,8}$/.test(s)) return s;
  if (/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}(?:\s*,\s*(?:0|1|0?\.\d+))?\s*\)$/.test(s)) return s;
  if (/^linear-gradient\(\s*[0-9a-zA-Z,\s#%().-]{1,160}\)$/.test(s) && !/[;{}<>'"\\]|url\(|expression\(/i.test(s)) {
    return s;
  }
  return fallback;
}

function getBaseOrigin() {
  return window.location.origin;
}

// ===== Unified API Fetch Bridge (ผ่าน ui-security-bridge.js + รองรับ 401/403/429 PIN Modal) =====
async function adminApiFetch(path, { timeoutMs = 12000, ...options } = {}) {
  const bridgeFetch =
    typeof window.omniApiFetch === 'function'
      ? window.omniApiFetch
      : typeof window.apiFetch === 'function'
      ? window.apiFetch
      : null;

  if (bridgeFetch) {
    try {
      return await bridgeFetch(path, { timeoutMs, ...options });
    } catch (err) {
      if ((err?.status === 401 || err?.status === 403 || err?.status === 429) && typeof window.openOmniPinModal === 'function') {
        if (err.status === 401 || err?.data?.requirePin || err?.data?.locked) {
          window.openOmniPinModal({
            message: err?.data?.error || err.message || '',
            locked: Boolean(err?.data?.locked),
            retryAfterSec: Number(err?.data?.retryAfterSec || 0)
          });
        }
      }
      throw err;
    }
  }

  const res = await window.fetch(path, {
    credentials: 'same-origin',
    ...options,
    signal: options.signal || AbortSignal.timeout(timeoutMs)
  });
  const data = await res.json().catch(() => null);
  if ((res.status === 401 || res.status === 403 || res.status === 429) && typeof window.openOmniPinModal === 'function') {
    if (res.status === 401 || data?.requirePin || data?.locked) {
      window.openOmniPinModal({
        message: data?.error || '',
        locked: Boolean(data?.locked),
        retryAfterSec: Number(data?.retryAfterSec || 0)
      });
    }
  }
  if (!res.ok || !data || data.ok === false) {
    throw Object.assign(new Error(data?.error || `HTTP ${res.status}`), { status: res.status, data });
  }
  return data;
}

// ===== Secret Mask Helpers (กติกาเดียวกับ server.mjs / settings-vault.mjs) =====
const SECRET_MASK_PATTERNS = ['••••', '***'];

function isMaskedSecret(value) {
  const s = String(value ?? '').trim();
  return Boolean(s) && SECRET_MASK_PATTERNS.some((p) => s.includes(p));
}

function isMaskedOrEmptySecret(value) {
  const s = String(value ?? '').trim();
  return !s || SECRET_MASK_PATTERNS.some((p) => s.includes(p));
}

// ===== Upload Guard (บล็อก .svg และจำกัดขนาดป้องกัน OOM) =====
function validateUploadFile(file) {
  if (!file) return { ok: false, error: 'ไม่ได้เลือกไฟล์' };
  const name = String(file.name || '');
  const mime = String(file.type || '');
  if (/\.svg$/i.test(name) || /svg/i.test(mime)) {
    return { ok: false, error: 'ไม่อนุญาตให้อัปโหลดไฟล์ SVG เพื่อป้องกันช่องโหว่ XSS' };
  }
  if (!/\.(?:zip|json)$/i.test(name)) {
    return { ok: false, error: 'รองรับเฉพาะไฟล์ .zip หรือ .json เท่านั้น' };
  }
  const isZip = /\.zip$/i.test(name);
  const maxBytes = isZip ? MAX_ZIP_UPLOAD_BYTES : MAX_JSON_UPLOAD_BYTES;
  if (file.size > maxBytes) {
    const maxMb = (maxBytes / (1024 * 1024)).toFixed(0);
    return { ok: false, error: `ไฟล์มีขนาดใหญ่เกินกำหนด (${(file.size / (1024 * 1024)).toFixed(1)} MB) — สูงสุด ${maxMb} MB` };
  }
  return { ok: true };
}

function showToast(message, isError = false) {
  const existing = document.getElementById('rwSettingsToast');
  if (existing) existing.remove();
  const el = document.createElement('div');
  el.id = 'rwSettingsToast';
  el.className = `fixed bottom-5 right-5 z-[10000] px-4 py-3 rounded-xl border text-sm font-medium shadow-2xl transition-all duration-200 ${
    isError
      ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
      : 'bg-cyan-950/95 border-cyan-400/50 text-cyan-100'
  }`;
  el.textContent = message;
  document.body.appendChild(el);
  setTimeout(() => {
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 250);
  }, 3000);
}

async function copyToClipboard(text, btnEl) {
  try {
    await navigator.clipboard.writeText(text);
    const orig = btnEl.innerHTML;
    btnEl.innerHTML = '<i data-lucide="check" class="w-3.5 h-3.5 inline-block mr-1"></i>คัดลอกแล้ว'; if (window.lucide) window.lucide.createIcons();
    btnEl.classList.add('border-emerald-400', 'text-emerald-300');
    setTimeout(() => {
      btnEl.innerHTML = orig;
      btnEl.classList.remove('border-emerald-400', 'text-emerald-300');
    }, 1600);
  } catch {
    showToast('ไม่สามารถคัดลอกอัตโนมัติได้ กรุณาคัดลอกด้วยตนเอง', true);
  }
}

function injectHeaderButton() {
  if (document.getElementById(BTN_ID)) return;
  const nav =
    document.querySelector('header nav') ||
    document.querySelector('nav.flex.items-center') ||
    document.querySelector('nav');
  if (!nav) return;

  const btn = document.createElement('button');
  btn.id = BTN_ID;
  btn.type = 'button';
  btn.className =
    'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900/90 text-slate-300 hover:text-cyan-300 border border-slate-700/60 hover:border-cyan-500/40 transition glow-hover';
  btn.innerHTML = '<i data-lucide="settings" class="w-4 h-4 shrink-0"></i><span>ตั้งค่าระบบ</span>'; if (window.lucide) window.lucide.createIcons();
  btn.addEventListener('click', openSettingsModal);
  nav.appendChild(btn);
}

function buildModalShell() {
  if (document.getElementById(MODAL_ID)) return;

  const overlay = document.createElement('div');
  overlay.id = MODAL_ID;
  overlay.className =
    'fixed inset-0 z-[9990] hidden items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4';

  overlay.innerHTML = `
    <div class="w-full max-w-5xl max-h-[90vh] flex flex-col rounded-2xl bg-[#0a1024] border border-cyan-500/30 shadow-[0_0_50px_rgba(6,182,212,0.18)] text-slate-100 overflow-hidden">
      <!-- Header -->
      <div class="flex items-center justify-between px-6 py-4 border-b border-slate-800/90 bg-slate-950/60">
        <div class="flex items-center gap-3">
          <div class="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-300"><i data-lucide="settings" class="w-5 h-5 shrink-0"></i></div>
          <div>
            <h2 class="text-base font-bold text-cyan-300 tracking-wide">ศูนย์ควบคุมและตั้งค่าระบบ (All-in-One Admin Settings)</h2>
            <p class="text-xs text-slate-400">ตั้งค่าโปรไฟล์ร้านค้า, ช่องทางแชต Omnichannel และเชื่อมต่อ AI Providers จากทุกค่าย</p>
          </div>
        </div>
        <button type="button" id="rwCloseSettingsBtn" class="px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-rose-500/20 text-slate-300 hover:text-rose-300 border border-slate-700 text-xs font-semibold transition">
          <i data-lucide="x" class="w-3.5 h-3.5 inline-block mr-1"></i>ปิดหน้าต่าง
        </button>
      </div>

      <!-- 2-Column Body: Fixed Left Sidebar (220-240px) + Independent Scrollable Content -->
      <div class="flex-1 flex flex-col md:flex-row min-h-0 overflow-hidden">
        <aside class="w-full md:w-60 shrink-0 border-b md:border-b-0 md:border-r border-slate-800/80 bg-slate-950/50 p-3.5 space-y-4 overflow-y-auto">
          <div class="space-y-1">
            <div class="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">ตั้งค่าหลัก (CORE)</div>
            <button type="button" data-rw-tab="channels" class="rw-tab-btn w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold border border-cyan-500/40 bg-cyan-500/15 text-cyan-300 text-left transition">
              <i data-lucide="store" class="w-4 h-4 shrink-0"></i>
              <span class="truncate">โปรไฟล์ &amp; ช่องทางแชท</span>
            </button>
            <button type="button" data-rw-tab="brain" class="rw-tab-btn w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/70 text-left transition">
              <i data-lucide="brain-circuit" class="w-4 h-4 shrink-0"></i>
              <span class="truncate">สมอง AI &amp; โมเดล</span>
            </button>
            <button type="button" data-rw-tab="presets" class="rw-tab-btn w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/70 text-left transition">
              <i data-lucide="blocks" class="w-4 h-4 shrink-0"></i>
              <span class="truncate">ชุดธุรกิจ &amp; เครื่องมือ</span>
            </button>
          </div>

          <div class="space-y-1">
            <div class="px-3 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold">ระบบ &amp; การแสดงผล (SYSTEM)</div>
            <button type="button" data-rw-tab="theme" class="rw-tab-btn w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/70 text-left transition">
              <i data-lucide="palette" class="w-4 h-4 shrink-0"></i>
              <span class="truncate">ธีมสี &amp; พื้นหลัง</span>
            </button>
            <button type="button" data-rw-tab="ota" class="rw-tab-btn w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-xs font-bold border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/70 text-left transition">
              <span class="flex items-center gap-2.5 truncate">
                <i data-lucide="database-backup" class="w-4 h-4 shrink-0"></i>
                <span class="truncate">อัปเดต &amp; สำรองข้อมูล</span>
              </span>
              <span id="rwSidebarOtaBadge" class="hidden w-2.5 h-2.5 rounded-full bg-rose-500 shrink-0 animate-pulse"></span>
            </button>
          </div>
        </aside>

        <div id="rwSettingsBody" class="flex-1 overflow-y-auto p-6 space-y-6">
          <div class="text-center py-12 text-slate-400 text-sm">กำลังโหลดข้อมูลการตั้งค่า...</div>
        </div>
      </div>

      <!-- Footer -->
      <div class="flex flex-wrap items-center justify-between gap-2 px-6 py-3.5 border-t border-slate-800/90 bg-slate-950/70">
        <span id="rwSettingsStatusText" class="text-xs text-slate-400">พร้อมใช้งาน • ข้อมูลความลับถูกเข้ารหัสการแสดงผล (Masked)</span>
        <div class="flex flex-wrap items-center gap-2.5">
          <button type="button" id="rwResetThemeBtn" class="hidden px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-rose-950/60 text-rose-300 hover:text-rose-200 border border-rose-500/40 text-xs font-semibold transition">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5 inline-block mr-1"></i>รีเซ็ตธีมเป็นค่าเริ่มต้น (Reset Theme to Default)
          </button>
          <button type="button" id="rwReloadSettingsBtn" class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold transition">
            <i data-lucide="refresh-cw" class="w-3.5 h-3.5 inline-block mr-1"></i>โหลดค่าใหม่
          </button>
          <button type="button" id="rwSaveSettingsBtn" class="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition">
            <i data-lucide="save" class="w-3.5 h-3.5 inline-block mr-1"></i>บันทึกการตั้งค่า
          </button>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  if (window.lucide) window.lucide.createIcons();

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeSettingsModal();
  });

  document.getElementById('rwCloseSettingsBtn').addEventListener('click', closeSettingsModal);
  document.getElementById('rwResetThemeBtn').addEventListener('click', () => {
    if (typeof window.resetOmniTheme === 'function') {
      window.resetOmniTheme(document.getElementById('rwSettingsBody'));
    }
  });
  document.getElementById('rwReloadSettingsBtn').addEventListener('click', () => loadTabContent(activeTab));
  document.getElementById('rwSaveSettingsBtn').addEventListener('click', handleSaveCurrentTab);

  overlay.querySelectorAll('.rw-tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      switchTab(btn.getAttribute('data-rw-tab'));
    });
  });
}

function switchTab(tab) {
  queueMicrotask(() => { if (window.lucide) window.lucide.createIcons(); });
  const normalizedTab = tab === 'tools' ? 'presets' : tab;
  activeTab = normalizedTab;
  const overlay = document.getElementById(MODAL_ID);
  if (!overlay) return;

  overlay.querySelectorAll('.rw-tab-btn').forEach((btn) => {
    const tabKey = btn.getAttribute('data-rw-tab');
    const isCurrent = tabKey === normalizedTab;
    const base = tabKey === 'ota'
      ? 'rw-tab-btn w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl text-xs font-bold border text-left transition'
      : 'rw-tab-btn w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-bold border text-left transition';
    btn.className = isCurrent
      ? `${base} border-cyan-500/40 bg-cyan-500/15 text-cyan-300 shadow-sm`
      : `${base} border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/70`;
  });

  loadTabContent(normalizedTab);
}

async function openSettingsModal() {
  buildModalShell();
  const overlay = document.getElementById(MODAL_ID);
  overlay.classList.remove('hidden');
  overlay.classList.add('flex');
  const mainDot = document.getElementById('otaUpdateDot');
  const sideBadge = document.getElementById('rwSidebarOtaBadge');
  if (sideBadge) {
    if (mainDot && !mainDot.classList.contains('hidden')) sideBadge.classList.remove('hidden');
    else sideBadge.classList.add('hidden');
  }
  await loadTabContent(activeTab);
}

function closeSettingsModal() {
  const overlay = document.getElementById(MODAL_ID);
  if (!overlay) return;
  overlay.classList.add('hidden');
  overlay.classList.remove('flex');
}

window.openAdminSettingsModal = openSettingsModal;
window.closeAdminSettingsModal = closeSettingsModal;

async function loadTabContent(tab) {
  const effectiveTab = tab === 'tools' ? 'presets' : tab;
  const body = document.getElementById('rwSettingsBody');
  const statusEl = document.getElementById('rwSettingsStatusText');
  if (!body) return;

  const resetThemeBtn = document.getElementById('rwResetThemeBtn');
  if (resetThemeBtn) {
    resetThemeBtn.classList.toggle('hidden', effectiveTab !== 'theme');
  }

  const saveBtn = document.getElementById('rwSaveSettingsBtn');
  if (saveBtn) {
    saveBtn.classList.toggle('hidden', effectiveTab === 'presets' || effectiveTab === 'ota');
    saveBtn.disabled = effectiveTab === 'channels' || effectiveTab === 'brain';
  }

  body.innerHTML = `<div class="text-center py-12 text-cyan-300/80 text-sm animate-pulse">กำลังดึงข้อมูลจากเซิร์ฟเวอร์...</div>`;

  if (effectiveTab === 'channels') {
    tabLoadState.channels = false;
    try {
      const [data, regData] = await Promise.all([
        adminApiFetch('/api/settings/channels'),
        adminApiFetch('/api/channels/registry').catch((err) => {
          console.warn('[admin-settings-ui] registry fetch failed:', err);
          return null;
        })
      ]);
      if (regData?.ok && Array.isArray(regData.channels)) {
        cachedChannelRegistry = regData;
        window.__OMNIFLOW_CHANNEL_REGISTRY__ = regData;
      }
      cachedChannels = data.channels || {};
      cachedBusiness = data.business || { businessName: 'Aether AI Commerce', businessTagline: '' };
      const rawBase = String(data.publicBaseUrl || '').trim().replace(/\/+$/, '');
      const publicBase = rawBase && isSafeUrl(rawBase) ? rawBase : getBaseOrigin();
      const securityData = data.security || { adminPin: '••••••••' };
      renderChannelsTab(body, cachedChannels, cachedBusiness, publicBase, securityData, cachedChannelRegistry);
      tabLoadState.channels = true;
      if (saveBtn) saveBtn.disabled = false;
      if (statusEl) statusEl.textContent = `อัปเดตล่าสุด: ${data.updatedAt || 'พร้อมใช้งาน'} • รองรับ ${(cachedChannelRegistry?.channels || CHANNEL_SCHEMAS).length} ช่องทาง`;
    } catch (err) {
      tabLoadState.channels = false;
      if (saveBtn) saveBtn.disabled = true;
      body.innerHTML = `<div class="p-4 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-sm space-y-1"><div>เกิดข้อผิดพลาด: ${escapeHtml(err.message)}</div><div class="text-xs text-rose-300/80">ล็อกปุ่มบันทึกไว้ชั่วคราวเพื่อป้องกันข้อมูลทับกัน กรุณายืนยัน Admin PIN หรือกดปุ่ม "โหลดค่าใหม่"</div></div>`;
    }
  } else if (effectiveTab === 'brain') {
    tabLoadState.brain = false;
    try {
      const data = await adminApiFetch('/api/settings/brain');
      cachedBrain = data.brain || { greetingMessage: '', systemPrompt: '', providers: [] };
      if (!Array.isArray(cachedBrain.providers)) cachedBrain.providers = [];
      cachedBrain.providers = cachedBrain.providers.map((p) => {
        const rawKey = String(p?.apiKey || '').trim();
        const hasSavedKey = Boolean(rawKey);
        return {
          ...p,
          _hasSavedKey: hasSavedKey,
          _savedMask: isMaskedSecret(rawKey) ? rawKey : '',
          apiKey: isMaskedSecret(rawKey) ? '' : rawKey
        };
      });
      renderBrainTab(body);
      tabLoadState.brain = true;
      if (saveBtn) saveBtn.disabled = false;
      if (statusEl) {
        const activeCount = cachedBrain.providers.filter((p) => p.enabled !== false).length;
        statusEl.textContent = `เชื่อมต่อ AI Providers ที่เปิดใช้งาน ${activeCount} รายการ (Primary + Auto-Failover)`;
      }
    } catch (err) {
      tabLoadState.brain = false;
      if (saveBtn) saveBtn.disabled = true;
      body.innerHTML = `<div class="p-4 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-sm space-y-1"><div>เกิดข้อผิดพลาด: ${escapeHtml(err.message)}</div><div class="text-xs text-rose-300/80">ล็อกปุ่มบันทึกไว้ชั่วคราวเพื่อป้องกันข้อมูล AI Providers สูญหาย กรุณายืนยัน Admin PIN หรือกดปุ่ม "โหลดค่าใหม่"</div></div>`;
    }
  } else if (effectiveTab === 'theme') {
    if (saveBtn) saveBtn.disabled = false;
    if (typeof window.renderOmniThemeTab === 'function') {
      window.renderOmniThemeTab(body);
      if (statusEl) {
        statusEl.textContent = 'ปรับแต่งธีมสีและภาพพื้นหลัง • กดบันทึกการตั้งค่าเพื่อเก็บลงเบราว์เซอร์ถาวร';
      }
    } else {
      body.innerHTML = `<div class="p-4 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-sm">ไม่พบโมดูล Theme Engine</div>`;
    }
  } else if (effectiveTab === 'presets') {
    await renderPresetsTab(body, statusEl);
    return;
  } else if (effectiveTab === 'ota') {
    renderOtaTab(body, statusEl);
  }
}

function buildDynamicWebhookList(publicBase, registry) {
  const list = [];
  const seenPath = new Set();
  const regChannels = Array.isArray(registry?.channels) ? registry.channels : [];
  if (regChannels.length === 0) {
    return [
      { name: 'LINE OA / Facebook Messenger', url: `${publicBase}/webhook` },
      { name: 'WhatsApp Business Cloud API', url: `${publicBase}/api/webhook/whatsapp` },
      { name: 'Email Chat (Inbound Webhook)', url: `${publicBase}/webhook/email` },
      { name: 'Shopee Open Platform', url: `${publicBase}/webhook/shopee` },
      { name: 'TikTok Shop Open Platform', url: `${publicBase}/webhook/tiktok` },
      { name: 'Lazada Open Platform', url: `${publicBase}/webhook/lazada` }
    ];
  }
  for (const ch of regChannels) {
    const wp = ch.webhookPath || `/webhook/${ch.id}`;
    if (wp === '/webhook') {
      if (!seenPath.has(wp)) {
        seenPath.add(wp);
        list.push({ name: 'LINE OA / Facebook Messenger', url: `${publicBase}/webhook` });
      }
      continue;
    }
    if (seenPath.has(wp)) continue;
    seenPath.add(wp);
    list.push({ name: ch.label || ch.id, url: `${publicBase}${wp}` });
  }
  return list;
}

function renderWebhookPillsMarkup(webhookList) {
  return webhookList
    .map(
      (w) => `
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-xl bg-slate-900/90 border border-slate-800">
        <div>
          <div class="text-[11px] font-semibold text-slate-400">${escapeHtml(w.name)}</div>
          <div class="text-xs font-mono text-cyan-300 break-all mt-0.5">${escapeHtml(w.url)}</div>
        </div>
        <button type="button" data-copy-url="${escapeHtml(w.url)}" class="rw-copy-webhook-btn shrink-0 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-cyan-500/20 text-slate-200 hover:text-cyan-300 border border-slate-700 text-xs font-medium transition">
          <i data-lucide="clipboard" class="w-3.5 h-3.5 inline-block mr-1"></i>คัดลอก URL
        </button>
      </div>
    `
    )
    .join('');
}

function renderChannelsTab(container, channelsData, businessData, publicBase, securityData = {}, registry = null) {
  const webhookPillsHtml = renderWebhookPillsMarkup(buildDynamicWebhookList(publicBase, registry));
  const groups = Array.isArray(registry?.groups) && registry.groups.length
    ? registry.groups
    : [{ id: 'core', label: 'ช่องทางการติดต่อ (Channels)' }];
  const regChannels = Array.isArray(registry?.channels) && registry.channels.length
    ? registry.channels
    : CHANNEL_SCHEMAS.map((c) => ({
        id: c.id, wave: 'core', label: c.title, shortLabel: c.badge,
        badgeColor: '#38bdf8', badgeBg: 'rgba(56,189,248,0.14)',
        webhookPath: c.webhookPath || `/webhook/${c.id}`, fields: c.fields
      }));

  const groupedSectionsHtml = groups
    .map((grp) => {
      const grpChannels = regChannels.filter((ch) => (ch.wave || 'core') === grp.id);
      if (grpChannels.length === 0) return '';
      const cardsHtml = grpChannels
        .map((ch) => {
          const saved = channelsData[ch.id] || {};
          const enabled = saved.enabled !== undefined ? Boolean(saved.enabled) : Boolean(ch.enabled);
          const color = sanitizeCssColor(ch.badgeColor, '#38bdf8');
          const bg = sanitizeCssColor(ch.badgeBg, 'rgba(56, 189, 248, 0.14)');
          const borderColor = /^#[0-9a-fA-F]{6}$/.test(color) ? `${color}55` : color;
          const whUrl = `${publicBase}${ch.webhookPath || `/webhook/${ch.id}`}`;
          const statusBadge = ch.configured
            ? '<span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">พร้อมใช้</span>'
            : '<span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 text-slate-400 border border-slate-700">รอตั้งค่าคีย์</span>';

          const fieldsHtml = (ch.fields || [])
            .map((f) => {
              const safeType = ['text', 'password', 'url', 'email', 'number', 'textarea'].includes(f.type) ? f.type : 'text';
              const rawVal = String(saved[f.key] ?? '');
              const isMasked = isMaskedSecret(rawVal);
              const isSecretField = safeType === 'password' || isMasked;
              const displayVal = isSecretField && isMasked ? '' : rawVal;
              const displayPlaceholder =
                isSecretField && isMasked
                  ? `บันทึกค่าไว้แล้ว (${rawVal}) — เว้นว่างหากไม่เปลี่ยน`
                  : (f.placeholder || '');

              if (safeType === 'textarea') {
                return `
                  <div class="md:col-span-3">
                    <label class="block text-xs font-medium text-slate-300 mb-1">${escapeHtml(f.label)}</label>
                    <textarea rows="3" data-ch="${escapeHtml(ch.id)}" data-key="${escapeHtml(f.key)}" data-secret="${isSecretField ? '1' : '0'}" placeholder="${escapeHtml(displayPlaceholder)}"
                      class="rw-ch-input w-full px-3 py-2 rounded-lg bg-slate-950/90 border border-slate-700/90 focus:border-cyan-400 focus:outline-none text-xs font-mono text-slate-100 placeholder-slate-600">${escapeHtml(displayVal)}</textarea>
                  </div>`;
              }
              return `
                <div>
                  <label class="block text-xs font-medium text-slate-300 mb-1">${escapeHtml(f.label)}</label>
                  <div class="relative flex items-center">
                    <input
                      type="${escapeHtml(safeType)}"
                      data-ch="${escapeHtml(ch.id)}"
                      data-key="${escapeHtml(f.key)}"
                      data-secret="${isSecretField ? '1' : '0'}"
                      data-has-saved="${rawVal ? '1' : '0'}"
                      value="${escapeHtml(displayVal)}"
                      placeholder="${escapeHtml(displayPlaceholder)}"
                      autocomplete="off"
                      class="rw-ch-input w-full px-3 py-2 ${safeType === 'password' ? 'pr-8' : ''} rounded-lg bg-slate-950/90 border border-slate-700/90 focus:border-cyan-400 focus:outline-none text-xs font-mono text-slate-100 placeholder-slate-600"
                    />
                    ${
                      safeType === 'password'
                        ? `<button type="button" class="rw-toggle-vis absolute right-2.5 text-slate-400 hover:text-cyan-300 text-xs" title="แสดง/ซ่อน"><i data-lucide="eye" class="w-3.5 h-3.5 pointer-events-none"></i></button>`
                        : ''
                    }
                  </div>
                </div>`;
            })
            .join('');

          return `
            <div class="rw-channel-card p-4 rounded-xl bg-slate-900/60 border border-slate-800/90 space-y-3" data-ch-search="${escapeHtml(`${ch.id} ${ch.label} ${ch.shortLabel} ${grp.label}`.toLowerCase())}">
              <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                <div class="flex flex-wrap items-center gap-2">
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold border" style="color:${escapeHtml(color)};background:${escapeHtml(bg)};border-color:${escapeHtml(borderColor)};">${escapeHtml(ch.shortLabel || ch.id.toUpperCase())}</span>
                  <h3 class="text-sm font-bold text-slate-100">${escapeHtml(ch.label || ch.id)}</h3>
                  ${statusBadge}
                </div>
                <div class="flex items-center gap-3">
                  <button type="button" data-copy-url="${escapeHtml(whUrl)}" class="rw-copy-webhook-btn px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-cyan-500/20 text-[11px] font-mono text-cyan-300 border border-slate-700 transition">
                    <i data-lucide="clipboard" class="w-3 h-3 inline-block mr-1"></i>${escapeHtml(ch.webhookPath || `/webhook/${ch.id}`)}
                  </button>
                  <label class="inline-flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                    <input type="checkbox" data-ch-enabled="${escapeHtml(ch.id)}" ${enabled ? 'checked' : ''} class="rounded border-slate-600 bg-slate-900 text-cyan-500 focus:ring-cyan-500" />
                    <span>เปิดใช้งาน</span>
                  </label>
                </div>
              </div>
              <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
                ${fieldsHtml}
              </div>
            </div>`;
        })
        .join('');

      return `
        <div class="rw-channel-group space-y-3">
          <div class="flex items-center justify-between px-1">
            <h4 class="text-xs font-bold uppercase tracking-wider text-cyan-300/90">${escapeHtml(grp.label)}</h4>
            <span class="text-[11px] font-mono text-slate-500">${grpChannels.length} ช่องทาง</span>
          </div>
          <div class="space-y-3">${cardsHtml}</div>
        </div>`;
    })
    .join('');

  const hasAdminPin = Boolean(securityData.hasAdminPin || securityData.adminPin);
  const rawNotifyWebhook = String(businessData.adminNotifyWebhookUrl || '').trim();
  const hasSavedNotifyWebhook = Boolean(rawNotifyWebhook);
  const notifyWebhookDisplayVal = isMaskedSecret(rawNotifyWebhook) ? '' : rawNotifyWebhook;
  const notifyWebhookPlaceholder =
    hasSavedNotifyWebhook && isMaskedSecret(rawNotifyWebhook)
      ? `บันทึก Webhook URL ไว้แล้ว (${rawNotifyWebhook}) — เว้นว่างหากไม่เปลี่ยน หรือวาง URL ใหม่`
      : 'วาง URL เช่น https://discord.com/api/webhooks/... หรือ https://api.telegram.org/bot.../sendMessage?chat_id=...';

  container.innerHTML = `
    <!-- Business Profile (White-Label Identity) -->
    <div class="p-4 rounded-xl bg-indigo-950/20 border border-indigo-500/30 space-y-3">
      <h3 class="text-sm font-bold text-indigo-300"><i data-lucide="store" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>ข้อมูลโปรไฟล์ธุรกิจ / ร้านค้า (Business Profile &amp; Security)</h3>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label class="block text-xs font-medium text-slate-300 mb-1">ชื่อร้านค้า / ธุรกิจ (Business Name)</label>
          <input id="rwBusinessNameInput" type="text" value="${escapeHtml(businessData.businessName || '')}" placeholder="เช่น ร้านค้าของคุณ" class="w-full px-3 py-2 rounded-lg bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs text-slate-100" />
        </div>
        <div>
          <label class="block text-xs font-medium text-slate-300 mb-1">คำอธิบายสั้นๆ (Business Tagline)</label>
          <input id="rwBusinessTaglineInput" type="text" value="${escapeHtml(businessData.businessTagline || '')}" placeholder="เช่น ศูนย์บริการลูกค้าและปิดการขายอัตโนมัติ" class="w-full px-3 py-2 rounded-lg bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs text-slate-100" />
        </div>
        <div>
          <label class="block text-xs font-medium text-slate-300 mb-1"><i data-lucide="lock" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>รหัสผ่านแอดมินระยะไกล (Remote Admin PIN)</label>
          <div class="relative flex items-center">
            <input id="rwAdminPinInput" type="password" autocomplete="new-password" value="" placeholder="${hasAdminPin ? 'ตั้ง PIN ไว้แล้ว เว้นว่างไว้หากไม่ต้องการเปลี่ยน' : 'ตั้งรหัสผ่านสำหรับเข้าจากนอกร้าน (เช่น 123456)'}" class="w-full px-3 py-2 pr-8 rounded-lg bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs font-mono text-slate-100" />
            <button type="button" class="rw-toggle-vis absolute right-2.5 text-slate-400 hover:text-cyan-300 text-xs" title="แสดง/ซ่อน"><i data-lucide="eye" class="w-3.5 h-3.5 pointer-events-none"></i></button>
          </div>
        </div>
      </div>

      <!-- Feature 3.1: Admin Lead Notification Webhook -->
      <div class="pt-3 border-t border-indigo-500/20">
        <label class="block text-xs font-medium text-emerald-300 mb-1">
          <i data-lucide="bell" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>Webhook แจ้งเตือนแอดมินเมื่อมีลูกค้าสนใจสั่งซื้อ (รองรับ Discord, Telegram, LINE Notify, Make, n8n, Slack)
        </label>
        <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          <div class="relative flex items-center flex-1">
            <input
              id="rwAdminNotifyWebhookInput"
              type="password"
              autocomplete="off"
              data-has-saved-webhook="${hasSavedNotifyWebhook ? '1' : '0'}"
              value="${escapeHtml(notifyWebhookDisplayVal)}"
              placeholder="${escapeHtml(notifyWebhookPlaceholder)}"
              class="w-full px-3 py-2 pr-8 rounded-lg bg-slate-950/90 border border-slate-700 focus:border-emerald-400 focus:outline-none text-xs font-mono text-slate-100 placeholder-slate-600"
            />
            <button type="button" class="rw-toggle-vis absolute right-2.5 text-slate-400 hover:text-cyan-300 text-xs" title="แสดง/ซ่อน"><i data-lucide="eye" class="w-3.5 h-3.5 pointer-events-none"></i></button>
          </div>
          <button
            type="button"
            id="rwTestAdminWebhookBtn"
            class="shrink-0 px-3.5 py-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition flex items-center justify-center gap-1.5"
          >
            <span><i data-lucide="send" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>ทดสอบยิงแจ้งเตือน</span>
          </button>
        </div>
        <p class="text-[11px] text-slate-400 mt-1">
           ทันทีที่ลูกค้าทิ้งเบอร์โทรสั่งซื้อ ระบบจะส่งข้อความสรุปออเดอร์เด้งเข้ามือถือแอดมินทันที ปิดการขายได้ใน 1 นาที (ฟรี 100%)
        </p>
      </div>
    </div>

    <!-- Webhook URL Generator -->
    <div class="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/30 space-y-3">
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h3 class="text-sm font-bold text-cyan-300 flex items-center gap-1.5"><i data-lucide="link" class="w-4 h-4 shrink-0"></i><span>Webhook URL Generator &amp; Copy Pill</span></h3>
          <p class="text-xs text-slate-400">นำ URL ด้านล่างไปวางในหน้า Developer Portal ของแต่ละแพลตฟอร์ม</p>
        </div>
        <div class="flex items-center gap-2">
          <label class="text-xs text-slate-400">Public Host:</label>
          <input id="rwPublicBaseInput" type="text" value="${escapeHtml(publicBase)}" class="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 text-xs font-mono text-cyan-200 w-64" />
        </div>
      </div>
      <div id="rwWebhookPillsGrid" class="grid grid-cols-1 md:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
        ${webhookPillsHtml}
      </div>
    </div>

    <!-- Dynamic Channel Search -->
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
      <div class="text-xs font-bold text-slate-200 flex items-center gap-1.5"><i data-lucide="plug" class="w-4 h-4 text-cyan-400 shrink-0"></i><span>ช่องทางการติดต่อทั้งหมด (${regChannels.length} Channels)</span></div>
      <input id="rwChannelSearchInput" type="text" placeholder=" ค้นหาช่องทาง เช่น Email, Instagram, Shopify, WeChat..."
        class="w-full sm:w-72 px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs text-slate-100" />
    </div>

    <div class="space-y-5">
      ${groupedSectionsHtml}
    </div>
  `;

  container.querySelectorAll('.rw-copy-webhook-btn').forEach((btn) => {
    btn.addEventListener('click', () => copyToClipboard(btn.getAttribute('data-copy-url'), btn));
  });

  container.querySelectorAll('.rw-toggle-vis').forEach((btn) => {
    btn.addEventListener('click', () => {
      const input = btn.parentElement.querySelector('input');
      if (!input) return;
      input.type = input.type === 'password' ? 'text' : 'password';
    });
  });

  const searchInput = document.getElementById('rwChannelSearchInput');
  searchInput?.addEventListener('input', () => {
    const q = searchInput.value.trim().toLowerCase();
    container.querySelectorAll('.rw-channel-card').forEach((card) => {
      const hay = card.getAttribute('data-ch-search') || '';
      card.classList.toggle('hidden', Boolean(q) && !hay.includes(q));
    });
    container.querySelectorAll('.rw-channel-group').forEach((grp) => {
      const visible = grp.querySelectorAll('.rw-channel-card:not(.hidden)').length;
      grp.classList.toggle('hidden', visible === 0);
    });
  });

  const hostInput = document.getElementById('rwPublicBaseInput');
  if (hostInput) {
    hostInput.addEventListener('input', () => {
      const candidateBase = hostInput.value.trim().replace(/\/+$/, '');
      const cleanBase = candidateBase && isSafeUrl(candidateBase) ? candidateBase : getBaseOrigin();
      const grid = document.getElementById('rwWebhookPillsGrid');
      if (!grid) return;
      grid.innerHTML = renderWebhookPillsMarkup(buildDynamicWebhookList(cleanBase, registry));
      grid.querySelectorAll('.rw-copy-webhook-btn').forEach((btn) => {
        btn.addEventListener('click', () => copyToClipboard(btn.getAttribute('data-copy-url'), btn));
      });
    });
  }

  // Feature 3.1: Event listener for Test Admin Lead Webhook Button
  const testWebhookBtn = document.getElementById('rwTestAdminWebhookBtn');
  if (testWebhookBtn) {
    testWebhookBtn.addEventListener('click', async () => {
      const webhookInput = document.getElementById('rwAdminNotifyWebhookInput');
      const webhookUrl = webhookInput ? webhookInput.value.trim() : '';
      const hasSavedWebhook = webhookInput?.getAttribute('data-has-saved-webhook') === '1';

      if (!webhookUrl && !hasSavedWebhook) {
        showToast('กรุณากรอก Webhook URL สำหรับแจ้งเตือนแอดมินก่อนทดสอบ', true);
        if (webhookInput) webhookInput.focus();
        return;
      }
      if (webhookUrl && !isMaskedSecret(webhookUrl) && !isSafeUrl(webhookUrl)) {
        showToast(' Webhook URL ไม่ถูกต้อง (ต้องเป็น http:// หรือ https:// เท่านั้น)', true);
        if (webhookInput) webhookInput.focus();
        return;
      }

      const originalHtml = testWebhookBtn.innerHTML;
      testWebhookBtn.disabled = true;
      testWebhookBtn.innerHTML = `<span>กำลังยิงทดสอบ...</span>`;

      try {
        await adminApiFetch('/api/settings/test-webhook', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ webhookUrl: isMaskedSecret(webhookUrl) ? '' : webhookUrl }),
          timeoutMs: 12000
        });
        showToast('ยิงข้อความทดสอบสำเร็จ! โปรดตรวจสอบแชตแอดมินของคุณ', false);
      } catch (err) {
        showToast(`ทดสอบไม่สำเร็จ: ${err.message}`, true);
      } finally {
        testWebhookBtn.disabled = false;
        testWebhookBtn.innerHTML = originalHtml;
        if (window.lucide) window.lucide.createIcons();
      }
    });
  }
}

function syncBrainStateFromDom() {
  const greetEl = document.getElementById('rwGreetingMessage');
  const promptEl = document.getElementById('rwSystemPrompt');
  if (greetEl) cachedBrain.greetingMessage = greetEl.value;
  if (promptEl) cachedBrain.systemPrompt = promptEl.value;

  const cards = document.querySelectorAll('.rw-provider-card');
  if (cards.length > 0) {
    cachedBrain.providers = Array.from(cards).map((card, idx) => {
      const id = card.getAttribute('data-prov-id') || `prov_${Date.now()}_${idx}`;
      const customName = card.querySelector('[data-pfield="customName"]')?.value?.trim() || `AI Provider #${idx + 1}`;
      const type = card.querySelector('[data-pfield="type"]')?.value || 'openai_compat';
      const baseUrl = card.querySelector('[data-pfield="baseUrl"]')?.value?.trim() || '';
      const keyInput = card.querySelector('[data-pfield="apiKey"]');
      const apiKey = keyInput?.value?.trim() || '';
      const _hasSavedKey = keyInput?.getAttribute('data-has-saved-key') === '1';
      const _savedMask = keyInput?.getAttribute('data-saved-mask') || '';
      const model = card.querySelector('[data-pfield="model"]')?.value?.trim() || '';
      const isPrimary = Boolean(card.querySelector('[data-pfield="isPrimary"]')?.checked);
      const enabled = Boolean(card.querySelector('[data-pfield="enabled"]')?.checked);
      return { id, customName, type, baseUrl, apiKey, model, isPrimary, enabled, _hasSavedKey, _savedMask };
    });
  }
}

function renderBrainTab(container) {
  queueMicrotask(() => { if (window.lucide) window.lucide.createIcons(); });
  const providers = Array.isArray(cachedBrain.providers) ? cachedBrain.providers : [];

  const providersHtml =
    providers.length === 0
      ? `
        <div class="p-8 rounded-xl border border-dashed border-slate-700 bg-slate-950/60 text-center space-y-2">
          <div class="text-sm font-bold text-slate-300">ยังไม่มีการเชื่อมต่อ AI Provider</div>
          <p class="text-xs text-slate-400">คลิกปุ่ม <strong class="text-cyan-300">"+ เพิ่มการเชื่อมต่อ AI"</strong> ด้านบน เพื่อเพิ่ม Groq, Gemini, OpenAI, DeepSeek หรือ Ollama</p>
        </div>
      `
      : providers
          .map((p, idx) => {
            const pType = PROVIDER_TYPE_META[p.type] ? p.type : 'openai_compat';
            const meta = PROVIDER_TYPE_META[pType];
            const isLocal = pType === 'local';

            return `
              <div data-provider-card="${idx}" data-prov-id="${escapeHtml(p.id)}" class="rw-provider-card p-4 rounded-xl bg-slate-900/75 border ${
                p.isPrimary ? 'border-cyan-400/60 shadow-[0_0_20px_rgba(6,182,212,0.12)]' : 'border-slate-800'
              } space-y-3">
                <div class="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5">
                  <div class="flex items-center gap-2.5">
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      p.isPrimary
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }">
                      ${p.isPrimary ? '<i data-lucide="star" class="w-3 h-3 inline-block mr-1 -mt-0.5 shrink-0"></i>PRIMARY' : `BACKUP #${idx + 1}`}
                    </span>
                    <input type="text" data-pfield="customName" value="${escapeHtml(p.customName || '')}" placeholder="ตั้งชื่อบอท เช่น บอทหลักของร้าน"
                      class="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs font-bold text-white w-56" />
                  </div>

                  <div class="flex items-center gap-3 text-xs">
                    <label class="inline-flex items-center gap-1.5 cursor-pointer text-cyan-300 font-semibold">
                      <input type="radio" name="rwPrimaryProviderRadio" data-pfield="isPrimary" ${p.isPrimary ? 'checked' : ''} class="text-cyan-500 bg-slate-900 border-slate-600" />
                      <span>ตั้งเป็นตัวหลัก</span>
                    </label>
                    <label class="inline-flex items-center gap-1.5 cursor-pointer text-slate-300">
                      <input type="checkbox" data-pfield="enabled" ${p.enabled !== false ? 'checked' : ''} class="rounded text-emerald-500 bg-slate-900 border-slate-600" />
                      <span>เปิดใช้งาน</span>
                    </label>
                    <button type="button" data-remove-prov="${idx}" class="px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/35 text-[11px] font-semibold transition">
                      <i data-lucide="trash-2" class="w-3.5 h-3.5 inline-block mr-1"></i>ลบ
                    </button>
                  </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label class="block text-[11px] text-slate-400 mb-1">ประเภทผู้ให้บริการ (Provider Type)</label>
                    <select data-pfield="type" data-prov-idx="${idx}" class="rw-prov-type-select w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-100 focus:border-cyan-400 focus:outline-none">
                      <option value="openai_compat" ${pType === 'openai_compat' ? 'selected' : ''}>OpenAI-Compatible (Groq / OpenAI / DeepSeek / OpenRouter / Typhoon)</option>
                      <option value="gemini" ${pType === 'gemini' ? 'selected' : ''}>Google Gemini API</option>
                      <option value="local" ${pType === 'local' ? 'selected' : ''}>Local AI (Ollama / LM Studio)</option>
                    </select>
                  </div>
                  <div>
                    <div class="flex items-center justify-between mb-1">
                      <label class="block text-[11px] text-slate-400">ชื่อโมเดล (Model Name)</label>
                      <button type="button" data-discover-models="${idx}" class="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/15 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 transition"><i data-lucide="scan-search" class="w-3.5 h-3.5 inline-block mr-1"></i>สแกน &amp; จัดอันดับความฉลาด</button>
                    </div>
                    <input type="text" data-pfield="model" value="${escapeHtml(p.model || meta.defaultModel)}" placeholder="${escapeHtml(meta.defaultModel)}"
                      class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs font-mono text-emerald-300" />
                    <div id="localModelChips_${idx}" class="flex flex-wrap gap-1.5 mt-1.5"></div>
                  </div>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label class="block text-[11px] text-slate-400 mb-1">Base URL (Endpoint)</label>
                    <input type="text" data-pfield="baseUrl" value="${escapeHtml(p.baseUrl || meta.defaultBaseUrl)}" placeholder="${escapeHtml(meta.defaultBaseUrl)}"
                      class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs font-mono text-cyan-200" />
                  </div>
                  <div class="${isLocal ? 'hidden' : ''}" data-apikey-wrap>
                    <div class="flex items-center justify-between mb-1">
                      <label class="block text-[11px] text-slate-400">API Key</label>
                      <button type="button" class="rw-toggle-key text-[10px] text-cyan-300 hover:text-cyan-200">แสดงคีย์</button>
                    </div>
                    <div class="relative flex items-center">
                      <input
                        type="password"
                        autocomplete="new-password"
                        data-pfield="apiKey"
                        data-has-saved-key="${p._hasSavedKey || isMaskedSecret(p.apiKey) ? '1' : '0'}"
                        data-saved-mask="${escapeHtml(p._savedMask || (isMaskedSecret(p.apiKey) ? p.apiKey : ''))}"
                        value="${escapeHtml(isMaskedSecret(p.apiKey) ? '' : (p.apiKey || ''))}"
                        placeholder="${escapeHtml(p._hasSavedKey || isMaskedSecret(p.apiKey) ? `บันทึก API Key ไว้แล้ว (${p._savedMask || '••••••••'}) — เว้นว่างหากไม่เปลี่ยน` : 'กรอก API Key ของผู้ให้บริการ...')}"
                        class="w-full px-3 py-2 pr-8 rounded-lg bg-slate-950 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs font-mono text-slate-100"
                      />
                    </div>
                  </div>
                </div>
              </div>
            `;
          })
          .join('');

  container.innerHTML = `
    <!-- Universal Dynamic AI Provider List -->
    <div class="space-y-3">
      <div class="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 class="text-sm font-bold text-cyan-300"><i data-lucide="cpu" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>รายการเชื่อมต่อ AI Providers (Primary + Failover Chain)</h3>
          <p class="text-xs text-slate-400">รองรับ Groq, Gemini, OpenAI, DeepSeek, OpenRouter, Typhoon และ Local Ollama / LM Studio</p>
        </div>
        <button type="button" id="rwAddProviderBtn" class="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-600 hover:from-emerald-400 hover:to-cyan-500 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 transition">
          + เพิ่มการเชื่อมต่อ AI
        </button>
      </div>
      <div id="rwProvidersListContainer" class="space-y-3">
        ${providersHtml}
      </div>
    </div>

    <!-- System Prompt / Master Persona (Full Width) -->
    <div class="p-4 rounded-xl bg-slate-900/70 border border-slate-800 space-y-2">
      <div class="flex items-center justify-between">
        <label class="block text-xs font-bold text-cyan-300"><i data-lucide="sparkles" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>บุคลิกและคำสั่งหลักของ AI (System Prompt / Persona)</label>
        <span class="text-[11px] text-slate-400">ควบคุมทั้งการทักทาย, คำลงท้าย ค่ะ/ครับ, คำนวณราคา, รูปภาพ และฟอร์มเก็บ Lead ลูกค้าในจุดเดียว</span>
      </div>
      <textarea id="rwSystemPrompt" rows="12" placeholder="คุณคือผู้ช่วยฝ่ายขายมืออาชีพของร้าน..." class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-mono leading-relaxed text-slate-100 focus:border-cyan-400 focus:outline-none resize-y">${escapeHtml(cachedBrain.systemPrompt || '')}</textarea>
    </div>
  `;

  document.getElementById('rwAddProviderBtn')?.addEventListener('click', () => {
    syncBrainStateFromDom();
    const isFirst = cachedBrain.providers.length === 0;
    cachedBrain.providers.push({
      id: `prov_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      customName: isFirst ? 'บอทหลักของร้าน' : `บอทสำรอง #${cachedBrain.providers.length + 1}`,
      type: 'openai_compat',
      baseUrl: PROVIDER_TYPE_META.openai_compat.defaultBaseUrl,
      apiKey: '',
      model: PROVIDER_TYPE_META.openai_compat.defaultModel,
      isPrimary: isFirst,
      enabled: true
    });
    renderBrainTab(container);
  });

  container.querySelectorAll('[data-remove-prov]').forEach((btn) => {
    btn.addEventListener('click', () => {
      syncBrainStateFromDom();
      const idx = Number(btn.getAttribute('data-remove-prov'));
      cachedBrain.providers.splice(idx, 1);
      if (cachedBrain.providers.length > 0 && !cachedBrain.providers.some((p) => p.isPrimary)) {
        cachedBrain.providers[0].isPrimary = true;
      }
      renderBrainTab(container);
    });
  });

  container.querySelectorAll('.rw-prov-type-select').forEach((sel) => {
    sel.addEventListener('change', () => {
      syncBrainStateFromDom();
      const idx = Number(sel.getAttribute('data-prov-idx'));
      const nextType = sel.value;
      const meta = PROVIDER_TYPE_META[nextType] || PROVIDER_TYPE_META.openai_compat;
      if (cachedBrain.providers[idx]) {
        cachedBrain.providers[idx].type = nextType;
        cachedBrain.providers[idx].baseUrl = meta.defaultBaseUrl;
        cachedBrain.providers[idx].model = meta.defaultModel;
        if (nextType === 'local') {
          cachedBrain.providers[idx].apiKey = '';
        }
      }
      renderBrainTab(container);
    });
  });

  container.querySelectorAll('[data-pfield="isPrimary"]').forEach((radio) => {
    radio.addEventListener('change', () => {
      syncBrainStateFromDom();
      renderBrainTab(container);
    });
  });

  // Auto-detect & Rank AI Models handler (Groq, Gemini, OpenAI-Compat & Local AI)
  const renderRankedChips = (idx, rankedModels = [], currentModel = '') => {
    const chipsBox = document.getElementById(`localModelChips_${idx}`);
    if (!chipsBox) return;
    if (rankedModels.length === 0) {
      chipsBox.innerHTML = '<span class="text-[10px] text-slate-400">ไม่พบโมเดลที่พร้อมใช้งาน (กรุณาเช็ก API Key / Endpoint)</span>';
      return;
    }
    const headerLabel = rankedModels[0]?.score !== undefined
      ? '<span class="text-[10px] text-cyan-300 mr-1">เรียงตามความฉลาด:</span>'
      : '<span class="text-[10px] text-slate-400 mr-1">พบในเครื่อง:</span>';

    chipsBox.innerHTML = headerLabel + rankedModels.slice(0, 8).map((item, mIdx) => {
      const mId = typeof item === 'string' ? item : item.id;
      const isCurrent = currentModel && currentModel === mId;
      const trophy = mIdx === 0 && typeof item === 'object' ? ' ' : '';
      const titleTip = typeof item === 'object' ? `${item.badge || ''} (Score: ${item.score})` : mId;
      return `<button type="button" data-pick-local="${idx}" data-model-name="${escapeHtml(mId)}" title="${escapeHtml(titleTip)}" class="px-2 py-0.5 rounded text-[10px] font-mono border transition ${
        isCurrent
          ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200 font-bold'
          : mIdx === 0
          ? 'bg-amber-500/15 hover:bg-amber-500/30 border-amber-400/50 text-amber-200'
          : 'bg-slate-800 hover:bg-cyan-950 border-slate-700 text-cyan-300'
      }">${trophy}${escapeHtml(mId)}</button>`;
    }).join('');

    chipsBox.querySelectorAll('[data-pick-local]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const picked = btn.getAttribute('data-model-name');
        const currentCard = chipsBox.closest('.rw-provider-card') || container.querySelector(`[data-provider-card="${idx}"]`);
        const currentModelInput = currentCard?.querySelector('[data-pfield="model"]');
        if (currentModelInput && picked) {
          currentModelInput.value = picked;
          currentModelInput.dispatchEvent(new Event('input', { bubbles: true }));
          currentModelInput.dispatchEvent(new Event('change', { bubbles: true }));
          if (cachedBrain.providers && cachedBrain.providers[idx]) {
            cachedBrain.providers[idx].model = picked;
          }
          renderRankedChips(idx, rankedModels, picked);
        }
      });
    });
  };

  const discoverProviderModels = async (idx, autoSelectBest = false) => {
    const chipsBox = document.getElementById(`localModelChips_${idx}`);
    const card = chipsBox?.closest('.rw-provider-card') || container.querySelector(`[data-provider-card="${idx}"]`);
    const typeSelect = card?.querySelector('[data-pfield="type"]');
    const baseInput = card?.querySelector('[data-pfield="baseUrl"]');
    const keyInput = card?.querySelector('[data-pfield="apiKey"]');
    const modelInput = card?.querySelector('[data-pfield="model"]');
    const provId = card?.getAttribute('data-prov-id') || cachedBrain.providers?.[idx]?.id || '';
    if (!chipsBox) return;

    const pType = typeSelect?.value || cachedBrain.providers?.[idx]?.type || 'openai_compat';
    chipsBox.innerHTML = '<span class="text-[10px] text-cyan-300 animate-pulse">กำลังยิงเช็ก & จัดอันดับความฉลาดจากเซิร์ฟเวอร์...</span>';
    try {
      let rankedModels = [];
      const rawBaseUrl = baseInput?.value?.trim() || '';
      if (rawBaseUrl && !isSafeUrl(rawBaseUrl)) {
        chipsBox.innerHTML = '<span class="text-[10px] text-rose-400"> Base URL ไม่ถูกต้อง (ต้องเป็น http:// หรือ https://)</span>';
        return;
      }
      if (pType === 'local') {
        const baseUrl = rawBaseUrl || 'http://host.docker.internal:11434';
        const data = await adminApiFetch(`/api/local-ai/models?baseUrl=${encodeURIComponent(baseUrl)}`, {
          timeoutMs: 5000
        });
        rankedModels = Array.isArray(data?.models) ? data.models : [];
      } else {
        const rawKey = keyInput?.value?.trim() || '';
        const data = await adminApiFetch('/api/settings/brain/discover-models', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            providerId: provId,
            type: pType,
            baseUrl: rawBaseUrl,
            apiKey: isMaskedOrEmptySecret(rawKey) ? '' : rawKey
          }),
          timeoutMs: 12000
        });
        rankedModels = Array.isArray(data.models) ? data.models : [];
        if (autoSelectBest && data.bestModel && modelInput) {
          modelInput.value = data.bestModel;
          if (cachedBrain.providers?.[idx]) cachedBrain.providers[idx].model = data.bestModel;
          showToast(` เลือกโมเดลที่ฉลาดที่สุด: ${data.bestModel}`);
        }
      }
      renderRankedChips(idx, rankedModels, modelInput?.value || '');
    } catch (err) {
      chipsBox.innerHTML = `<span class="text-[10px] text-rose-400"> ${escapeHtml(err.message || 'ไม่สามารถสแกนได้')}</span>`;
    }
  };

  container.querySelectorAll('[data-discover-models]').forEach((btn) => {
    const idx = Number(btn.getAttribute('data-discover-models'));
    btn.addEventListener('click', () => discoverProviderModels(idx, true));
    if (cachedBrain.providers?.[idx]?.type === 'local') {
      discoverProviderModels(idx, false);
    }
  });

  // Toggle API Key visibility
  container.querySelectorAll('.rw-toggle-key').forEach((btn) => {
    btn.addEventListener('click', () => {
      const wrap = btn.closest('[data-apikey-wrap]');
      const input = wrap?.querySelector('input[data-pfield="apiKey"]');
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = 'ซ่อนคีย์';
      } else {
        input.type = 'password';
        btn.textContent = 'แสดงคีย์';
      }
    });
  });
}

async function handleSaveCurrentTab() {
  const saveBtn = document.getElementById('rwSaveSettingsBtn');
  if (saveBtn) {
    saveBtn.disabled = true;
    saveBtn.textContent = 'กำลังบันทึก...';
  }

  try {
    if (activeTab === 'theme') {
      if (typeof window.saveOmniTheme === 'function') {
        window.saveOmniTheme();
      }
      return;
    }
    if (activeTab === 'channels') {
      if (!tabLoadState.channels || !document.getElementById('rwBusinessNameInput')) {
        showToast('ไม่สามารถบันทึกได้ เนื่องจากยังโหลดข้อมูลช่องทางไม่สำเร็จ กรุณากด "โหลดค่าใหม่"', true);
        return;
      }

      const rawPublicBase = document.getElementById('rwPublicBaseInput')?.value?.trim() || '';
      if (rawPublicBase && !isSafeUrl(rawPublicBase)) {
        showToast(' Public Host URL ไม่ถูกต้อง (ต้องเป็น http:// หรือ https:// เท่านั้น)', true);
        return;
      }

      const payload = {
        business: {
          businessName: document.getElementById('rwBusinessNameInput')?.value?.trim() || 'Aether AI Commerce',
          businessTagline: document.getElementById('rwBusinessTaglineInput')?.value?.trim() || ''
        },
        publicBaseUrl: rawPublicBase,
        channels: {}
      };

      const webhookEl = document.getElementById('rwAdminNotifyWebhookInput');
      const webhookVal = webhookEl?.value?.trim() || '';
      const hadSavedWebhook = webhookEl?.getAttribute('data-has-saved-webhook') === '1';
      if (webhookVal && !isMaskedSecret(webhookVal)) {
        if (!isSafeUrl(webhookVal)) {
          showToast(' Admin Notify Webhook URL ไม่ถูกต้อง (ต้องเป็น http:// หรือ https:// เท่านั้น)', true);
          return;
        }
        payload.business.adminNotifyWebhookUrl = webhookVal;
      } else if (!webhookVal && !hadSavedWebhook) {
        payload.business.adminNotifyWebhookUrl = '';
      }

      const pinVal = document.getElementById('rwAdminPinInput')?.value?.trim() || '';
      if (!isMaskedOrEmptySecret(pinVal)) {
        if (pinVal.length < 4) {
          showToast('Admin PIN ต้องยาวอย่างน้อย 4 ตัวอักษร', true);
          return;
        }
        payload.security = { adminPin: pinVal };
      }

      document.querySelectorAll('[data-ch-enabled]').forEach((enabledEl) => {
        const chId = enabledEl.getAttribute('data-ch-enabled');
        if (chId) payload.channels[chId] = { enabled: Boolean(enabledEl.checked) };
      });

      document.querySelectorAll('.rw-ch-input').forEach((input) => {
        const chId = input.getAttribute('data-ch');
        const key = input.getAttribute('data-key');
        if (!chId || !key) return;
        if (!payload.channels[chId]) payload.channels[chId] = {};
        const val = input.value.trim();
        const isSecretInput = input.getAttribute('data-secret') === '1' || input.type === 'password';
        // ห้ามส่งค่า Masked ('••••'/'***') กลับไปทับ Secret จริง; ช่องรหัสผ่านที่เว้นว่างจะไม่ส่งเพื่อคงค่าเดิม
        if (isSecretInput) {
          if (!isMaskedOrEmptySecret(val)) payload.channels[chId][key] = val;
        } else if (!isMaskedSecret(val)) {
          payload.channels[chId][key] = val;
        }
      });

      await adminApiFetch('/api/settings/channels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      showToast(' บันทึกโปรไฟล์ร้านค้าและคีย์ช่องทางเรียบร้อยแล้ว');
      await loadTabContent('channels');
      if (typeof window.loadChannelRegistry === 'function') await window.loadChannelRegistry(true);
      if (typeof window.syncDynamicChannelFilters === 'function') window.syncDynamicChannelFilters();
      if (typeof window.syncBusinessAndDashboardTelemetry === 'function') window.syncBusinessAndDashboardTelemetry();
    } else if (activeTab === 'brain') {
      if (!tabLoadState.brain || !document.getElementById('rwSystemPrompt')) {
        showToast('ไม่สามารถบันทึกได้ เนื่องจากยังโหลดข้อมูลสมอง AI ไม่สำเร็จ กรุณากด "โหลดค่าใหม่"', true);
        return;
      }

      syncBrainStateFromDom();
      const sanitizedProviders = (cachedBrain.providers || []).map((p) => {
        const baseUrl = String(p.baseUrl || '').trim();
        if (baseUrl && !isSafeUrl(baseUrl)) {
          throw new Error(`Base URL ของ "${p.customName || p.id}" ไม่ถูกต้อง (ต้องเป็น http:// หรือ https://)`);
        }
        const rawKey = String(p.apiKey || '').trim();
        let resolvedApiKey = '';
        if (p.type !== 'local') {
          if (!isMaskedOrEmptySecret(rawKey)) {
            resolvedApiKey = rawKey;
          } else if (p._hasSavedKey) {
            // คงคีย์เดิมฝั่งเซิร์ฟเวอร์ด้วย Sentinel มาตรฐานของ settings-vault.mjs (กัน Data Loss และกันค่า '***' ทับคีย์จริง)
            resolvedApiKey = p._savedMask && p._savedMask.startsWith('••••••••') ? p._savedMask : '••••••••';
          }
        }
        return {
          id: p.id,
          customName: p.customName,
          type: p.type,
          baseUrl,
          apiKey: resolvedApiKey,
          model: p.model,
          isPrimary: Boolean(p.isPrimary),
          enabled: p.enabled !== false
        };
      });

      const payload = {
        useBuiltInBrain: true,
        greetingMessage: cachedBrain.greetingMessage || '',
        systemPrompt: cachedBrain.systemPrompt || '',
        providers: sanitizedProviders
      };

      await adminApiFetch('/api/settings/brain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      showToast(' บันทึกการเชื่อมต่อ AI Providers และอัปเดต Runtime เรียบร้อยแล้ว');
      await loadTabContent('brain');
      if (typeof window.refreshAll === 'function') {
        window.refreshAll(false);
      }
    }
  } catch (err) {
    showToast(` ${err.message}`, true);
  } finally {
    if (saveBtn) {
      saveBtn.disabled = false;
      saveBtn.innerHTML = '<i data-lucide="save" class="w-3.5 h-3.5 inline-block mr-1"></i>บันทึกการตั้งค่า'; if (window.lucide) window.lucide.createIcons();
    }
  }
}

async function renderOtaTab(container, statusEl) {
  queueMicrotask(() => { if (window.lucide) window.lucide.createIcons(); });
  if (statusEl) {
    statusEl.textContent = 'Full-System OTA Update Engine • Auto-Backup (.bak) • Schema Migration • Safety Healthcheck + Auto-Rollback';
  }

  let latestCheckInfo = null;
  let pendingOfflineFile = null;

  container.innerHTML = `
    <div class="space-y-5">
      <!-- OTA Overview & 1-Click Remote Update Banner -->
      <div class="p-5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900/80 to-blue-950/50 border border-cyan-500/30 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-4">
          <div class="flex items-center gap-4">
            <div class="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-2xl">
              <i data-lucide="rocket" class="w-6 h-6 text-cyan-300 shrink-0"></i>
            </div>
            <div>
              <div class="flex flex-wrap items-center gap-2">
                <h3 class="text-base font-bold text-white">OmniFlow Standalone — Full-System OTA Engine</h3>
                <span id="otaVersionBadge" class="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-cyan-500/20 border border-cyan-400/40 text-cyan-300">
                  v1.0.0 (กำลังตรวจสอบ...)
                </span>
              </div>
              <p class="text-xs text-slate-400 mt-0.5">
                อัปเดตทั้งโค้ดระบบและ Schema ในคลิกเดียว สำรองข้อมูลอัตโนมัติก่อนทำ และ Auto-Rollback ทันทีหากไม่ผ่าน Healthcheck
              </p>
            </div>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <button type="button" id="otaCheckUpdateBtn" class="px-4 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/35 text-cyan-200 border border-cyan-400/40 text-xs font-bold flex items-center gap-1.5 transition">
              <span><i data-lucide="search" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>ตรวจหาอัปเดต</span>
            </button>
            <button type="button" id="otaApplyRemoteBtn" class="hidden px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 transition">
              <span class="inline-flex items-center gap-1.5"><i data-lucide="zap" class="w-4 h-4 shrink-0"></i><span>อัปเดตระบบทันที (1-Click Update)</span></span>
            </button>
            <button type="button" id="otaTriggerBackupBtn" class="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-600/80 text-xs font-semibold flex items-center gap-1.5 transition">
              <span><i data-lucide="save" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>สำรองข้อมูลตอนนี้ (.bak)</span>
            </button>
          </div>
        </div>

        <!-- Remote Manifest URL Config -->
        <div class="flex flex-col sm:flex-row sm:items-center gap-2 pt-3 border-t border-cyan-500/20">
          <label class="text-[11px] font-mono text-slate-300 shrink-0">Remote Release Manifest URL:</label>
          <input id="otaManifestUrlInput" type="url" placeholder="https://your-release-server.com/omniflow/manifest.json (เว้นว่างได้หากใช้อัปเดตแบบ Offline)"
            class="flex-1 px-3 py-1.5 rounded-lg bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs font-mono text-cyan-200 placeholder-slate-500" />
        </div>

        <!-- Remote Release Check Result Preview -->
        <div id="otaReleasePreview" class="hidden p-3.5 rounded-xl bg-slate-950/80 border border-emerald-500/35 text-xs space-y-1.5"></div>
      </div>

      <!-- Offline Patch Upload (Drag & Drop .zip / .json) -->
      <div class="p-5 rounded-2xl bg-slate-950/60 border border-indigo-500/30 space-y-3">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 class="text-sm font-bold text-indigo-300"><i data-lucide="package" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>ติดตั้งอัปเดตแบบออฟไลน์ (Offline Patch Upload)</h4>
            <p class="text-[11px] text-slate-400 mt-0.5">ลากวางไฟล์แพตช์ <code class="font-mono text-cyan-300">.zip</code> หรือ <code class="font-mono text-cyan-300">.json</code> เพื่ออัปเดตโมดูลระบบทันทีโดยไม่ต้องต่ออินเทอร์เน็ต</p>
          </div>
          <button type="button" id="otaInstallOfflineBtn" disabled
            class="px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold text-xs shadow-lg transition">
             อัปเดตระบบทันที (ติดตั้งไฟล์แพตช์)
          </button>
        </div>

        <div id="otaPatchDropZone"
          class="border-2 border-dashed border-slate-700 hover:border-cyan-400/70 rounded-xl p-5 text-center cursor-pointer transition bg-slate-900/50">
          <input id="otaPatchFileInput" type="file" accept=".zip,.json,application/zip,application/json" class="hidden" />
          <div class="flex justify-center text-cyan-400 mb-1"><i data-lucide="download" class="w-6 h-6 shrink-0"></i></div>
          <div id="otaPatchDropLabel" class="text-xs font-semibold text-slate-200">
            คลิกเลือกไฟล์ หรือ ลากวางไฟล์ Patch (.zip / .json) ที่นี่
          </div>
          <div class="text-[11px] text-slate-500 mt-1">
            ระบบจะสำรองข้อมูล (.bak) + ตรวจความปลอดภัยพาธ + ตรวจ Syntax อัตโนมัติ (หากไม่ผ่านจะ Auto-Rollback ทันที)
          </div>
        </div>

        <div id="otaExecutionLog" class="hidden p-3.5 rounded-xl bg-black/70 border border-slate-800 font-mono text-[11px] text-slate-200 whitespace-pre-wrap max-h-48 overflow-y-auto"></div>
      </div>

      <!-- Golden Rules Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div class="p-3.5 rounded-xl bg-slate-950/60 border border-emerald-500/30">
          <div class="text-xs font-bold text-emerald-300 flex items-center gap-1.5 mb-1">
            <span><i data-lucide="shield-check" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>กฎที่ 1: Zero Data Loss (.bak)</span>
          </div>
          <p class="text-[11px] text-slate-400">สำรอง config, catalog, orders และ code snapshot อัตโนมัติทุกครั้งก่อนเริ่มอัปเดต</p>
        </div>
        <div class="p-3.5 rounded-xl bg-slate-950/60 border border-cyan-500/30">
          <div class="text-xs font-bold text-cyan-300 flex items-center gap-1.5 mb-1">
            <span><i data-lucide="git-merge" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>กฎที่ 2: Schema Migration</span>
          </div>
          <p class="text-[11px] text-slate-400">ผสานฟิลด์ใหม่เข้ากับฐานข้อมูลเดิมแบบ Deep Merge ไม่ลบหรือทับข้อมูลลูกค้า</p>
        </div>
        <div class="p-3.5 rounded-xl bg-slate-950/60 border border-amber-500/30">
          <div class="text-xs font-bold text-amber-300 flex items-center gap-1.5 mb-1">
            <span><i data-lucide="rotate-ccw" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>กฎที่ 3: Healthcheck &amp; Auto-Rollback</span>
          </div>
          <p class="text-[11px] text-slate-400">ตรวจ JSON และ Syntax โค้ดหลังอัปเดต หากไม่ผ่านจะกู้คืนจุดสำรองล่าสุดทันที</p>
        </div>
      </div>

      <!-- Backup History Section -->
      <div class="p-5 rounded-2xl bg-slate-950/50 border border-slate-800/80 space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="text-sm font-bold text-slate-200"><i data-lucide="archive" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>รายการจุดสำรองข้อมูลย้อนหลัง (Retention Backups)</span>
            <span id="otaBackupCount" class="text-xs font-mono text-cyan-400"></span>
          </div>
          <button type="button" id="otaRefreshBackupsBtn" class="text-xs text-slate-400 hover:text-cyan-300 transition">
            <i data-lucide="refresh-cw" class="w-3.5 h-3.5 inline-block mr-1"></i>รีเฟรชรายการ
          </button>
        </div>
        <div id="otaBackupsList" class="space-y-2">
          <div class="text-center py-6 text-slate-500 text-xs">กำลังโหลดรายการสำรองข้อมูล...</div>
        </div>
      </div>
    </div>
  `;

  function appendOtaLog(line) {
    const logEl = document.getElementById('otaExecutionLog');
    if (!logEl) return;
    logEl.classList.remove('hidden');
    const ts = new Date().toLocaleTimeString('th-TH', { hour12: false });
    logEl.textContent += `[${ts}] ${line}\n`;
    logEl.scrollTop = logEl.scrollHeight;
  }

  function clearOtaLog() {
    const logEl = document.getElementById('otaExecutionLog');
    if (logEl) {
      logEl.textContent = '';
      logEl.classList.remove('hidden');
    }
  }

  async function refreshVersionBanner() {
    try {
      const vData = await adminApiFetch('/api/system/version');
      const badge = document.getElementById('otaVersionBadge');
      const urlInput = document.getElementById('otaManifestUrlInput');
      if (badge && vData.currentVersion) {
        badge.textContent = `v${vData.currentVersion} • ${vData.channel || 'stable'}`;
      }
      if (urlInput && !urlInput.value && vData.manifestUrl && isSafeUrl(vData.manifestUrl)) {
        urlInput.value = vData.manifestUrl;
      }
    } catch (err) {
      console.warn('[OTA] version check ignored:', err);
    }
  }

  async function loadBackups() {
    const listEl = document.getElementById('otaBackupsList');
    const countEl = document.getElementById('otaBackupCount');
    if (!listEl) return;

    try {
      const bData = await adminApiFetch('/api/system/backups');
      const backups = bData.backups || [];

      if (countEl) countEl.textContent = `(${backups.length}/5 ชุดล่าสุด)`;

      if (backups.length === 0) {
        listEl.innerHTML = '<div class="text-center py-6 text-slate-500 text-xs">ยังไม่มีชุดสำรองข้อมูล (กดปุ่ม "สำรองข้อมูลตอนนี้" ด้านบนเพื่อสร้างชุดแรก)</div>';
        return;
      }

      listEl.innerHTML = backups
        .map((bName, idx) => `
          <div class="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/30 transition">
            <div class="flex items-center gap-3">
              <span class="w-6 h-6 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-mono text-xs font-bold">
                ${idx + 1}
              </span>
              <div>
                <div class="text-xs font-mono font-bold text-slate-200">${escapeHtml(bName)}</div>
                <div class="text-[10px] text-slate-400">คุ้มครอง: gateway-config.json, catalog-db.json, orders-db.json + Code Snapshot</div>
              </div>
            </div>
            <button type="button" data-ota-rollback="${escapeHtml(bName)}" class="px-3 py-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/30 text-amber-300 hover:text-amber-200 text-xs font-semibold transition">
              ⏪ กู้คืนจุดนี้ (Rollback)
            </button>
          </div>
        `)
        .join('');

      listEl.querySelectorAll('[data-ota-rollback]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const target = btn.getAttribute('data-ota-rollback');
          if (!confirm(`ยืนยันการกู้คืนระบบและข้อมูลย้อนกลับไปยัง: ${target} ?`)) return;
          try {
            btn.disabled = true;
            btn.textContent = '⏳ กำลังกู้คืน...';
            await adminApiFetch('/api/system/rollback', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ targetVersion: target }),
              timeoutMs: 25000
            });
            showToast(` กู้คืนระบบสำเร็จ: ${target}`);
            await refreshVersionBanner();
            await loadBackups();
          } catch (rErr) {
            showToast(` ${rErr.message}`, true);
          } finally {
            btn.disabled = false;
            btn.textContent = '⏪ กู้คืนจุดนี้ (Rollback)';
          }
        });
      });
    } catch (err) {
      listEl.innerHTML = `<div class="p-3 text-xs text-rose-300 bg-rose-950/30 rounded-xl">${escapeHtml(err.message)}</div>`;
    }
  }

  // 1. Check for Updates Handler
  document.getElementById('otaCheckUpdateBtn')?.addEventListener('click', async () => {
    const btn = document.getElementById('otaCheckUpdateBtn');
    const previewEl = document.getElementById('otaReleasePreview');
    const applyBtn = document.getElementById('otaApplyRemoteBtn');
    const manifestUrl = document.getElementById('otaManifestUrlInput')?.value?.trim() || '';

    btn.disabled = true;
    btn.innerHTML = '<span>กำลังตรวจหาอัปเดต...</span>';

    if (manifestUrl && !isSafeUrl(manifestUrl)) {
      btn.disabled = false;
      btn.innerHTML = '<span><i data-lucide="search" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>ตรวจหาอัปเดต</span>';
      if (window.lucide) window.lucide.createIcons();
      showToast('Manifest URL ไม่ถูกต้อง (ต้องเป็น http:// หรือ https:// เท่านั้น)', true);
      return;
    }

    try {
      const qs = manifestUrl ? `?manifestUrl=${encodeURIComponent(manifestUrl)}` : '';
      const data = await adminApiFetch(`/api/system/ota/check${qs}`, { timeoutMs: 15000 });

      latestCheckInfo = data;
      previewEl.classList.remove('hidden');

      if (data.updateAvailable) {
        const changesHtml = (data.changelog || [])
          .map((c) => `<li class="text-slate-300">• ${escapeHtml(c)}</li>`)
          .join('');
        previewEl.className = 'p-3.5 rounded-xl bg-emerald-950/30 border border-emerald-500/40 text-xs space-y-1.5';
        previewEl.innerHTML = `
          <div class="font-bold text-emerald-300"> พบเวอร์ชันใหม่ v${escapeHtml(data.latestVersion)} (ปัจจุบัน v${escapeHtml(data.currentVersion)})</div>
          ${data.releaseDate ? `<div class="text-[11px] font-mono text-slate-400">Release Date: ${escapeHtml(data.releaseDate)}</div>` : ''}
          ${changesHtml ? `<ul class="space-y-0.5 pt-1">${changesHtml}</ul>` : ''}
        `;
        applyBtn?.classList.remove('hidden');
        showToast(` พบเวอร์ชันใหม่ v${data.latestVersion} พร้อมติดตั้ง`);
      } else {
        previewEl.className = 'p-3.5 rounded-xl bg-slate-950/80 border border-slate-700 text-xs space-y-1';
        previewEl.innerHTML = `
          <div class="font-bold text-cyan-300"> ระบบเป็นเวอร์ชันล่าสุดแล้ว (v${escapeHtml(data.currentVersion)})</div>
          <div class="text-[11px] text-slate-400">${escapeHtml(data.note || 'ไม่มีอัปเดตค้างอยู่ สามารถใช้โหมด Offline Patch Upload ด้านล่างได้ทุกเมื่อ')}</div>
        `;
        applyBtn?.classList.add('hidden');
      }
    } catch (err) {
      previewEl.classList.remove('hidden');
      previewEl.className = 'p-3.5 rounded-xl bg-rose-950/30 border border-rose-500/40 text-xs text-rose-200';
      previewEl.textContent = ` ตรวจหาอัปเดตไม่สำเร็จ: ${err.message}`;
      applyBtn?.classList.add('hidden');
      showToast(` ${err.message}`, true);
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<span><i data-lucide="search" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>ตรวจหาอัปเดต</span>';
      if (window.lucide) window.lucide.createIcons();
    }
  });

  // 2. 1-Click Remote Update Handler
  document.getElementById('otaApplyRemoteBtn')?.addEventListener('click', async () => {
    if (!latestCheckInfo) return;
    if (!confirm(`ยืนยันอัปเดตระบบเป็น v${latestCheckInfo.latestVersion} ?\n(ระบบจะสร้างจุดสำรอง .bak อัตโนมัติก่อนติดตั้ง)`)) return;

    const btn = document.getElementById('otaApplyRemoteBtn');
    btn.disabled = true;
    btn.innerHTML = '<span>กำลังสำรอง &amp; ติดตั้งอัปเดต...</span>';
    clearOtaLog();
    appendOtaLog(`เริ่มกระบวนการ 1-Click Remote OTA Update -> v${latestCheckInfo.latestVersion}`);

    try {
      const remoteManifest = latestCheckInfo.manifestUrl || document.getElementById('otaManifestUrlInput')?.value?.trim() || '';
      const remotePatch = latestCheckInfo.patchUrl || '';
      if ((remoteManifest && !isSafeUrl(remoteManifest)) || (remotePatch && !isSafeUrl(remotePatch))) {
        throw new Error('URL ของแพตช์ไม่ปลอดภัย (รองรับเฉพาะ http:// หรือ https://)');
      }
      const data = await adminApiFetch('/api/system/ota/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'remote',
          manifestUrl: remoteManifest,
          patchUrl: remotePatch
        }),
        timeoutMs: 30000
      });

      appendOtaLog(` Auto-Backup สำเร็จ: ${data.backupName}`);
      appendOtaLog(` อัปเดตไฟล์โค้ด (${data.updatedFiles.length} ไฟล์): ${data.updatedFiles.join(', ') || '-'}`);
      if (data.migratedSchemas?.length) {
        appendOtaLog(` Schema Migration: ${data.migratedSchemas.join(', ')}`);
      }
      appendOtaLog(` Safety Healthcheck ผ่าน ${data.healthcheck?.checks?.length || 0} จุด`);
      appendOtaLog(` ${data.message}`);
      showToast(` อัปเดตระบบเป็น v${data.newVersion} สำเร็จ!`);
      await refreshVersionBanner();
      await loadBackups();
    } catch (err) {
      appendOtaLog(` ${err.message}`);
      showToast(` ${err.message}`, true);
      await loadBackups();
    } finally {
      btn.disabled = false;
      btn.innerHTML = '<span class="inline-flex items-center gap-1.5"><i data-lucide="zap" class="w-4 h-4 shrink-0"></i><span>อัปเดตระบบทันที (1-Click Update)</span></span>';
      if (window.lucide) window.lucide.createIcons();
    }
  });

  // 3. Offline Patch Drag & Drop + Install Handler
  const dropZone = document.getElementById('otaPatchDropZone');
  const fileInput = document.getElementById('otaPatchFileInput');
  const dropLabel = document.getElementById('otaPatchDropLabel');
  const installOfflineBtn = document.getElementById('otaInstallOfflineBtn');

  const selectOfflinePatchFile = (file) => {
    if (!file) return;
    const check = validateUploadFile(file);
    if (!check.ok) {
      pendingOfflineFile = null;
      if (fileInput) fileInput.value = '';
      if (installOfflineBtn) installOfflineBtn.disabled = true;
      showToast(` ${check.error}`, true);
      return;
    }
    pendingOfflineFile = file;
    const kb = (file.size / 1024).toFixed(1);
    if (dropLabel) {
      dropLabel.innerHTML = `<span class="text-emerald-300"> พร้อมติดตั้ง: ${escapeHtml(file.name)} (${kb} KB)</span>`;
    }
    if (installOfflineBtn) installOfflineBtn.disabled = false;
  };

  dropZone?.addEventListener('click', () => fileInput?.click());
  dropZone?.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('border-cyan-400', 'bg-cyan-950/20');
  });
  dropZone?.addEventListener('dragleave', () => {
    dropZone.classList.remove('border-cyan-400', 'bg-cyan-950/20');
  });
  dropZone?.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('border-cyan-400', 'bg-cyan-950/20');
    const file = e.dataTransfer?.files?.[0];
    if (file) selectOfflinePatchFile(file);
  });
  fileInput?.addEventListener('change', (e) => {
    const file = e.target.files?.[0];
    if (file) selectOfflinePatchFile(file);
  });

  installOfflineBtn?.addEventListener('click', async () => {
    if (!pendingOfflineFile) return;
    if (!confirm(`ยืนยันติดตั้งไฟล์แพตช์ "${pendingOfflineFile.name}" ?\n(ระบบจะสำรองข้อมูล .bak และตรวจ Safety Healthcheck อัตโนมัติ)`)) return;

    installOfflineBtn.disabled = true;
    installOfflineBtn.textContent = 'กำลังติดตั้งแพตช์...';
    clearOtaLog();
    appendOtaLog(`กำลังอ่านไฟล์แพตช์ออฟไลน์: ${pendingOfflineFile.name}`);

    try {
      const contentBase64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('ไม่สามารถอ่านไฟล์แพตช์ได้'));
        reader.readAsDataURL(pendingOfflineFile);
      });

      const data = await adminApiFetch('/api/system/ota/apply', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode: 'offline',
          filename: pendingOfflineFile.name,
          contentBase64
        }),
        timeoutMs: 30000
      });

      appendOtaLog(` Auto-Backup สำเร็จ: ${data.backupName}`);
      appendOtaLog(` อัปเดตไฟล์โค้ด (${data.updatedFiles.length} ไฟล์): ${data.updatedFiles.join(', ') || '-'}`);
      if (data.migratedSchemas?.length) {
        appendOtaLog(` Schema Migration: ${data.migratedSchemas.join(', ')}`);
      }
      appendOtaLog(` Safety Healthcheck ผ่าน ${data.healthcheck?.checks?.length || 0} จุด`);
      appendOtaLog(` ${data.message}`);

      pendingOfflineFile = null;
      if (fileInput) fileInput.value = '';
      if (dropLabel) dropLabel.textContent = 'คลิกเลือกไฟล์ หรือ ลากวางไฟล์ Patch (.zip / .json) ที่นี่';
      showToast(` ติดตั้งแพตช์สำเร็จ (v${data.newVersion})`);
      await refreshVersionBanner();
      await loadBackups();
    } catch (err) {
      appendOtaLog(` ${err.message}`);
      showToast(` ${err.message}`, true);
      await loadBackups();
    } finally {
      installOfflineBtn.textContent = ' อัปเดตระบบทันที (ติดตั้งไฟล์แพตช์)';
      installOfflineBtn.disabled = !pendingOfflineFile;
    }
  });

  // 4. Manual Backup Trigger
  document.getElementById('otaTriggerBackupBtn')?.addEventListener('click', async () => {
    const btn = document.getElementById('otaTriggerBackupBtn');
    try {
      if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span>กำลังสำรองข้อมูล...</span>';
      }
      const data = await adminApiFetch('/api/system/backup', { method: 'POST', timeoutMs: 20000 });
      showToast(`สร้างชุดสำรองข้อมูลสำเร็จ: ${data.backupName}`);
      await loadBackups();
    } catch (err) {
      showToast(`${err.message}`, true);
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = '<span><i data-lucide="save" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>สำรองข้อมูลตอนนี้ (.bak)</span>';
        if (window.lucide) window.lucide.createIcons();
      }
    }
  });

  document.getElementById('otaRefreshBackupsBtn')?.addEventListener('click', loadBackups);

  await refreshVersionBanner();
  await loadBackups();
}

// ==========================================
// Custom Tools Tab Implementation (Full Flowise Clone: Edit / Add / Delete / Schema / JS Code)
// ==========================================
let cachedCustomTools = [];
let activeEditingTool = null;
let customToolsDropdownOpen = false;

async function fetchCustomTools() {
  try {
    const data = await adminApiFetch('/api/custom-tools');
    if (data.ok && Array.isArray(data.tools)) {
      cachedCustomTools = data.tools;
    }
  } catch (e) {
    console.error('Error fetching custom tools:', e);
  }
}

async function renderCustomToolsTab(container) {
  await fetchCustomTools();
  renderCustomToolsListView(container);
}

function renderCustomToolsListView(container) {
  const toolsHtml = cachedCustomTools.map((t) => {
    let schemaCount = 0;
    try {
      const s = typeof t.schema === 'string' ? JSON.parse(t.schema) : t.schema;
      schemaCount = Array.isArray(s) ? s.length : 0;
    } catch (e) {
      console.warn('[CustomTools] invalid schema JSON:', e);
    }

    const safeToolColor = sanitizeCssColor(t.color, '#10b981');
    const colorStyle = safeToolColor.startsWith('linear-gradient')
      ? `background: ${safeToolColor}`
      : `background-color: ${safeToolColor}`;

    return `
      <div class="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 transition space-y-4">
        <div class="flex items-start justify-between gap-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg" style="${escapeHtml(colorStyle)}">
              <span class="text-base font-bold font-mono text-cyan-300 inline-flex items-center"><i data-lucide="wrench" class="w-4 h-4 shrink-0"></i></span>
            </div>
            <div>
              <div class="text-sm font-bold text-white font-mono flex items-center gap-2">
                ${escapeHtml(t.name)}
                <span class="px-1.5 py-0.5 rounded text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700">${schemaCount} inputs</span>
              </div>
              <div class="text-[11px] text-slate-400 font-mono mt-0.5">ID: ${escapeHtml(t.id || '-')}</div>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" data-edit-tool="${escapeHtml(t.id)}" class="rw-edit-tool-btn px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold transition flex items-center gap-1">
              <i data-lucide="pencil" class="w-3.5 h-3.5 inline-block mr-1"></i>แก้ไขโค้ด & Schema
            </button>
            <button type="button" data-del-tool="${escapeHtml(t.id)}" class="rw-del-tool-btn px-2.5 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-bold transition flex items-center justify-center" title="ลบ Tool นี้">
              <i data-lucide="trash-2" class="w-3.5 h-3.5 shrink-0"></i>
            </button>
          </div>
        </div>
        <p class="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-3 rounded-xl border border-slate-800/80">
          ${escapeHtml(t.description || 'ไม่มีคำอธิบาย')}
        </p>
      </div>
    `;
  }).join('');

  const toolCount = cachedCustomTools.length;
  const toggleBadgeText = customToolsDropdownOpen
    ? ` ซ่อนรายการ (${toolCount} เครื่องมือ)`
    : ` กดเพื่อเปิดดู (${toolCount} เครื่องมือ)`;

  container.innerHTML = `
    <div class="space-y-4">
      <div id="rwToggleCustomToolsDropdown" role="button" tabindex="0"
        class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-cyan-950/40 border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition select-none">
        <div>
          <h3 class="text-sm font-bold text-white flex flex-wrap items-center gap-2">
            <span class="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
            <span>Custom Tools Studio (โครงสร้างมาตรฐานแบบ Flowise)</span>
            <span id="rwCustomToolsChevron" class="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-800/90 border border-cyan-500/30 text-cyan-300">
              ${toggleBadgeText}
            </span>
          </h3>
          <p class="text-xs text-slate-400 mt-1">
            จัดการเครื่องมือ AI ครบวงจร ทั้งชื่อ คำอธิบาย Input Schema พารามิเตอร์ และโค้ด JavaScript ที่รันจริง
          </p>
        </div>
        <button type="button" id="rwCreateNewToolBtn" class="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs shadow-lg shadow-cyan-500/20 transition flex items-center gap-1.5 shrink-0">
          <span class="inline-flex items-center gap-1.5"><i data-lucide="plus" class="w-4 h-4 shrink-0"></i><span>สร้าง Custom Tool ใหม่</span></span>
        </button>
      </div>

      <div id="rwCustomToolsListBody" class="${customToolsDropdownOpen ? '' : 'hidden'} space-y-4">
        ${toolsHtml || '<div class="text-center py-8 text-slate-500 text-sm">ยังไม่มีเครื่องมือในระบบ</div>'}
      </div>
    </div>
  `;

  const toggleHeader = document.getElementById('rwToggleCustomToolsDropdown');
  const listBody = document.getElementById('rwCustomToolsListBody');
  const chevronEl = document.getElementById('rwCustomToolsChevron');
  toggleHeader?.addEventListener('click', (e) => {
    if (e.target.closest('#rwCreateNewToolBtn')) return;
    customToolsDropdownOpen = !customToolsDropdownOpen;
    if (listBody) listBody.classList.toggle('hidden', !customToolsDropdownOpen);
    if (chevronEl) {
      chevronEl.textContent = customToolsDropdownOpen
        ? ` ซ่อนรายการ (${toolCount} เครื่องมือ)`
        : ` กดเพื่อเปิดดู (${toolCount} เครื่องมือ)`;
    }
  });

  document.getElementById('rwCreateNewToolBtn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    customToolsDropdownOpen = true;
    openToolEditor({
      id: '',
      name: '',
      description: '',
      color: 'linear-gradient(rgb(19,181,134), rgb(132,226,196))',
      iconSrc: '',
      schema: JSON.stringify([{ id: 0, property: 'query', type: 'string', description: 'คำค้นหา', required: true }], null, 2),
      func: `// JavaScript Code for Custom Tool\nreturn "Hello from custom tool";`
    }, container);
  });

  container.querySelectorAll('.rw-edit-tool-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-edit-tool');
      const tool = cachedCustomTools.find((t) => t.id === id);
      if (tool) openToolEditor(tool, container);
    });
  });

  container.querySelectorAll('.rw-del-tool-btn').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-del-tool');
      if (id && confirm(`คุณต้องการลบ Tool นี้ใช่หรือไม่?`)) {
        try {
          await adminApiFetch(`/api/custom-tools/${encodeURIComponent(id)}`, { method: 'DELETE' });
          showToast('ลบ Tool สำเร็จ');
          renderCustomToolsTab(container);
        } catch (e) {
          showToast(`${e.message}`, true);
        }
      }
    });
  });
}

function openToolEditor(tool, container) {
  const isNew = !tool || !tool.id;
  let lastTestRunPassed = false;
  let lastTestRunDurationMs = 0;
  const parsedSchema = (() => {
    if (Array.isArray(tool?.schema)) return structuredClone(tool.schema);
    if (typeof tool?.schema === 'string' && tool.schema.trim()) {
      try {
        const p = JSON.parse(tool.schema);
        return Array.isArray(p) ? p : [];
      } catch {
        return [];
      }
    }
    return [];
  })();

  activeEditingTool = {
    id: tool?.id || '',
    name: tool?.name || '',
    description: tool?.description || '',
    color: tool?.color || 'linear-gradient(135deg, #06b6d4, #2563eb)',
    schema: parsedSchema,
    func:
      tool?.func ||
      `// ตัวอย่างโค้ด Custom Tool (รองรับ async/await, fetch, OmniFlowTools และตัวแปร $<property>)\nconst kw = typeof $keyword !== 'undefined' ? $keyword : ($input?.keyword || '');\nconst items = await OmniFlowTools.lookupPrice(kw);\nconsole.log('Matched items:', items.length);\nreturn { ok: true, count: items.length, sample: items.slice(0, 3) };`
  };

  const buildDefaultTestArgs = (schemaArr) => {
    const sample = {};
    for (const row of schemaArr) {
      const key = String(row?.property || '').trim();
      if (!key) continue;
      if (row.type === 'number') {
        sample[key] = key === 'width' ? 1.2 : key === 'length' ? 2.4 : 1;
      } else if (row.type === 'boolean') {
        sample[key] = true;
      } else if (key === 'phone' || key === 'contactNumber') {
        sample[key] = '0812345678';
      } else if (key === 'productKeyword' || key === 'keyword' || key === 'productQuery') {
        sample[key] = 'ขาวจีน';
      } else if (key === 'productName' || key === 'inquiryDetail') {
        sample[key] = 'หินอ่อนขาวจีน (China White)';
      } else if (key === 'customerName') {
        sample[key] = 'คุณลูกค้าทดสอบ';
      } else if (key === 'purchaseMode') {
        sample[key] = 'both';
      } else {
        sample[key] = row.required ? 'ตัวอย่างข้อมูลทดสอบ' : '';
      }
    }
    if (activeEditingTool.name === 'send_to_activepieces') {
      sample.dryRun = true;
    }
    return sample;
  };

  const renderSchemaRowsHtml = () => {
    if (!activeEditingTool.schema.length) {
      return `<tr><td colspan="5" style="text-align:center;padding:14px;color:#94a3b8;font-size:12px;">ยังไม่มี Input Schema — กด "+ เพิ่มพารามิเตอร์" ด้านบนเพื่อกำหนดตัวแปรรับค่า</td></tr>`;
    }
    return activeEditingTool.schema
      .map(
        (item, idx) => `
      <tr data-schema-idx="${idx}" style="border-bottom:1px solid rgba(148,163,184,0.14);">
        <td style="padding:6px;">
          <input type="text" class="rw-schema-prop" data-idx="${idx}" value="${escapeHtml(item.property || '')}" placeholder="เช่น keyword" style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#f8fafc;font-size:12px;" />
        </td>
        <td style="padding:6px;">
          <select class="rw-schema-type" data-idx="${idx}" style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#f8fafc;font-size:12px;">
            ${['string', 'number', 'boolean', 'json']
              .map((t) => `<option value="${t}" ${item.type === t ? 'selected' : ''}>${t}</option>`)
              .join('')}
          </select>
        </td>
        <td style="padding:6px;">
          <input type="text" class="rw-schema-desc" data-idx="${idx}" value="${escapeHtml(item.description || '')}" placeholder="คำอธิบายพารามิเตอร์สำหรับ AI (White-Label)" style="width:100%;padding:6px 8px;border-radius:6px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#f8fafc;font-size:12px;" />
        </td>
        <td style="padding:6px;text-align:center;">
          <input type="checkbox" class="rw-schema-req" data-idx="${idx}" ${item.required ? 'checked' : ''} />
        </td>
        <td style="padding:6px;text-align:center;">
          <button type="button" class="rw-schema-del" data-idx="${idx}" style="background:rgba(239,68,68,0.15);color:#f87171;border:1px solid rgba(239,68,68,0.3);border-radius:6px;padding:4px 8px;cursor:pointer;font-size:12px;">ลบ</button>
        </td>
      </tr>`
      )
      .join('');
  };

  container.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:14px;">
      <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;padding-bottom:10px;border-bottom:1px solid rgba(148,163,184,0.2);">
        <div style="display:flex;align-items:center;gap:10px;">
          <button type="button" id="rwBackToToolsListBtn" style="padding:6px 12px;border-radius:8px;border:1px solid rgba(148,163,184,0.35);background:#1e293b;color:#e2e8f0;cursor:pointer;font-size:13px;">
            ← กลับหน้ารายการ
          </button>
          <strong style="font-size:15px;color:#f8fafc;">
            ${isNew ? ' สร้าง Custom Tool ใหม่' : ` แก้ไข Tool: ${escapeHtml(activeEditingTool.name)}`}
          </strong>
        </div>
        <div style="display:flex;align-items:center;gap:8px;">
          <button type="button" id="rwOpenTestRunDrawerBtn" style="padding:7px 14px;border-radius:8px;border:1px solid rgba(16,185,129,0.55);background:linear-gradient(135deg,#059669,#10b981);color:#ffffff;font-weight:600;cursor:pointer;font-size:13px;">
            ▶ Test Run (Sandbox)
          </button>
          <button type="button" id="rwSaveCustomToolBtn" style="padding:7px 16px;border-radius:8px;border:none;background:linear-gradient(135deg,#2563eb,#06b6d4);color:#ffffff;font-weight:600;cursor:pointer;font-size:13px;">
            <i data-lucide="save" class="w-3.5 h-3.5 inline-block mr-1"></i>บันทึก Tool
          </button>
        </div>
      </div>

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div>
          <label style="display:block;font-size:12px;color:#cbd5e1;margin-bottom:4px;">ชื่อฟังก์ชัน Tool (ภาษาอังกฤษ snake_case) *</label>
          <input type="text" id="rwToolNameInput" value="${escapeHtml(activeEditingTool.name)}" placeholder="เช่น lookup_price_memory" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#f8fafc;font-size:13px;" />
        </div>
        <div>
          <label style="display:block;font-size:12px;color:#cbd5e1;margin-bottom:4px;">แถบสีไอคอน (CSS Gradient / Hex)</label>
          <input type="text" id="rwToolColorInput" value="${escapeHtml(activeEditingTool.color)}" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#f8fafc;font-size:13px;" />
        </div>
      </div>

      <div>
        <label style="display:block;font-size:12px;color:#cbd5e1;margin-bottom:4px;">คำอธิบายหน้าที่ของ Tool สำหรับ AI (แนะนำใช้คำศัพท์กลาง White-Label) *</label>
        <textarea id="rwToolDescInput" rows="2" placeholder="อธิบายให้ชัดเจนว่า Tool นี้ทำหน้าที่อะไร เพื่อให้ AI เลือกใช้งานได้ถูกต้องทุกหมวดธุรกิจ" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#f8fafc;font-size:13px;">${escapeHtml(activeEditingTool.description)}</textarea>
      </div>

      <div style="background:rgba(15,23,42,0.65);border:1px solid rgba(148,163,184,0.2);border-radius:10px;padding:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
          <span style="font-size:13px;font-weight:600;color:#e2e8f0;"> Input Schema (เข้าถึงในโค้ดด้วย <code>$ชื่อตัวแปร</code> หรือ <code>$input.ชื่อตัวแปร</code>)</span>
          <button type="button" id="rwAddSchemaRowBtn" style="padding:5px 10px;border-radius:6px;border:1px solid rgba(56,189,248,0.4);background:rgba(56,189,248,0.12);color:#38bdf8;cursor:pointer;font-size:12px;">
            + เพิ่มพารามิเตอร์
          </button>
        </div>
        <div style="overflow-x:auto;">
          <table style="width:100%;border-collapse:collapse;font-size:12px;">
            <thead>
              <tr style="text-align:left;color:#94a3b8;border-bottom:1px solid rgba(148,163,184,0.2);">
                <th style="padding:6px;width:22%;">Property</th>
                <th style="padding:6px;width:15%;">Type</th>
                <th style="padding:6px;">Description</th>
                <th style="padding:6px;width:70px;text-align:center;">Required</th>
                <th style="padding:6px;width:60px;text-align:center;">จัดการ</th>
              </tr>
            </thead>
            <tbody id="rwToolSchemaTbody">
              ${renderSchemaRowsHtml()}
            </tbody>
          </table>
        </div>
      </div>

      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <label style="font-size:13px;font-weight:600;color:#e2e8f0;"> JavaScript Function Body (Node VM Sandbox)</label>
          <span style="font-size:11px;color:#94a3b8;">รองรับ <code>OmniFlowTools.lookupPrice()</code>, <code>calculateQuotation()</code>, <code>recordOrderLead()</code>, <code>fetch()</code></span>
        </div>
        <textarea id="rwToolFuncInput" rows="11" spellcheck="false" style="width:100%;padding:10px 12px;border-radius:8px;border:1px solid rgba(148,163,184,0.3);background:#020617;color:#38bdf8;font-family:Consolas,Monaco,monospace;font-size:12.5px;line-height:1.5;">${escapeHtml(activeEditingTool.func)}</textarea>
      </div>

      <!-- Sandbox Test Run Panel -->
      <div id="rwToolTestRunPanel" style="background:rgba(6,78,59,0.18);border:1px solid rgba(16,185,129,0.35);border-radius:10px;padding:14px;display:flex;flex-direction:column;gap:10px;">
        <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
          <div>
            <strong style="color:#34d399;font-size:13.5px;"> Studio Sandbox Test Runner (Isolated VM + Timeout Guard)</strong>
            <div style="font-size:11.5px;color:#94a3b8;">ทดสอบรันโค้ดด้านบนได้ทันทีโดยไม่ต้องบันทึกทับระบบจริง</div>
          </div>
          <div style="display:flex;align-items:center;gap:8px;">
            <label style="font-size:12px;color:#cbd5e1;">Timeout (ms):</label>
            <input type="number" id="rwTestTimeoutInput" value="5000" min="300" max="15000" step="500" style="width:85px;padding:5px 8px;border-radius:6px;border:1px solid rgba(148,163,184,0.35);background:#0f172a;color:#f8fafc;font-size:12px;" />
            <button type="button" id="rwSyncTestJsonBtn" style="padding:6px 10px;border-radius:6px;border:1px solid rgba(148,163,184,0.35);background:#1e293b;color:#cbd5e1;cursor:pointer;font-size:12px;">
              รีเซ็ต JSON ตาม Schema
            </button>
            <button type="button" id="rwExecuteTestRunBtn" style="padding:6px 14px;border-radius:6px;border:none;background:#10b981;color:#022c22;font-weight:700;cursor:pointer;font-size:12.5px;">
              ▶ รันทดสอบตอนนี้
            </button>
          </div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
          <div>
            <label style="display:block;font-size:11.5px;color:#cbd5e1;margin-bottom:4px;">Test Input Arguments (JSON):</label>
            <textarea id="rwTestArgsJsonInput" rows="6" spellcheck="false" style="width:100%;padding:8px 10px;border-radius:8px;border:1px solid rgba(148,163,184,0.3);background:#0f172a;color:#fde68a;font-family:Consolas,Monaco,monospace;font-size:12px;">${escapeHtml(JSON.stringify(buildDefaultTestArgs(activeEditingTool.schema), null, 2))}</textarea>
          </div>
          <div>
            <label style="display:block;font-size:11.5px;color:#cbd5e1;margin-bottom:4px;">ผลลัพธ์ & Console Logs:</label>
            <pre id="rwTestRunOutputPre" style="margin:0;height:132px;overflow:auto;padding:8px 10px;border-radius:8px;border:1px solid rgba(148,163,184,0.25);background:#020617;color:#cbd5e1;font-family:Consolas,Monaco,monospace;font-size:12px;white-space:pre-wrap;">กดปุ่ม "▶ Test Run" หรือ "▶ รันทดสอบตอนนี้" เพื่อดูผลลัพธ์จาก Sandbox...</pre>
          </div>
        </div>
      </div>
    </div>
  `;

  const syncSchemaFromDom = () => {
    const rows = container.querySelectorAll('#rwToolSchemaTbody tr[data-schema-idx]');
    const nextSchema = [];
    rows.forEach((tr, i) => {
      const property = tr.querySelector('.rw-schema-prop')?.value.trim() || '';
      const type = tr.querySelector('.rw-schema-type')?.value || 'string';
      const description = tr.querySelector('.rw-schema-desc')?.value.trim() || '';
      const required = Boolean(tr.querySelector('.rw-schema-req')?.checked);
      nextSchema.push({ id: i + 1, property, type, description, required });
    });
    activeEditingTool.schema = nextSchema;
    return nextSchema;
  };

  const bindSchemaTableEvents = () => {
    container.querySelectorAll('.rw-schema-del').forEach((btn) => {
      btn.addEventListener('click', () => {
        syncSchemaFromDom();
        const idx = Number(btn.getAttribute('data-idx'));
        activeEditingTool.schema.splice(idx, 1);
        const tbody = container.querySelector('#rwToolSchemaTbody');
        if (tbody) tbody.innerHTML = renderSchemaRowsHtml();
        bindSchemaTableEvents();
      });
    });
  };
  bindSchemaTableEvents();

  container.querySelector('#rwAddSchemaRowBtn')?.addEventListener('click', () => {
    syncSchemaFromDom();
    activeEditingTool.schema.push({
      id: activeEditingTool.schema.length + 1,
      property: '',
      type: 'string',
      description: '',
      required: false
    });
    const tbody = container.querySelector('#rwToolSchemaTbody');
    if (tbody) tbody.innerHTML = renderSchemaRowsHtml();
    bindSchemaTableEvents();
  });

  container.querySelector('#rwBackToToolsListBtn')?.addEventListener('click', () => {
    activeEditingTool = null;
    renderCustomToolsListView(container);
  });

  container.querySelector('#rwSyncTestJsonBtn')?.addEventListener('click', () => {
    const schemaNow = syncSchemaFromDom();
    const argsEl = container.querySelector('#rwTestArgsJsonInput');
    if (argsEl) {
      argsEl.value = JSON.stringify(buildDefaultTestArgs(schemaNow), null, 2);
    }
  });

  const runSandboxTest = async () => {
    const schemaNow = syncSchemaFromDom();
    const toolName = container.querySelector('#rwToolNameInput')?.value.trim() || 'inline_tool';
    const funcCode = container.querySelector('#rwToolFuncInput')?.value || '';
    const timeoutMs = Number(container.querySelector('#rwTestTimeoutInput')?.value) || 5000;
    const rawArgsText = container.querySelector('#rwTestArgsJsonInput')?.value.trim() || '{}';
    const outputPre = container.querySelector('#rwTestRunOutputPre');
    const execBtn = container.querySelector('#rwExecuteTestRunBtn');
    const topTestBtn = container.querySelector('#rwOpenTestRunDrawerBtn');

    let parsedArgs = {};
    try {
      parsedArgs = rawArgsText ? JSON.parse(rawArgsText) : {};
    } catch (jsonErr) {
      if (outputPre) {
        outputPre.style.color = '#f87171';
        outputPre.textContent = ` รูปแบบ JSON ในช่อง Test Input ไม่ถูกต้อง:\n${jsonErr.message}`;
      }
      showToast('รูปแบบ JSON ในช่อง Test Input ไม่ถูกต้อง', true);
      return;
    }

    if (outputPre) {
      outputPre.style.color = '#93c5fd';
      outputPre.textContent = `⏳ กำลังรัน "${toolName}" ใน Isolated Sandbox (Timeout Guard: ${timeoutMs} ms)...`;
    }
    if (execBtn) execBtn.disabled = true;
    if (topTestBtn) topTestBtn.disabled = true;

    try {
      const data = await adminApiFetch('/api/tools/test-run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          toolId: activeEditingTool.id || '',
          toolName,
          func: funcCode,
          schema: schemaNow,
          args: parsedArgs,
          timeoutMs
        }),
        timeoutMs: Math.max(timeoutMs + 5000, 15000)
      });

      const logLines = Array.isArray(data.logs) && data.logs.length
        ? `\n\n--- Console Logs (${data.logs.length}) ---\n` +
          data.logs.map((l) => `[${String(l.level || 'log').toUpperCase()}] ${l.message}`).join('\n')
        : '';

      if (outputPre) {
        outputPre.style.color = '#34d399';
        const formattedResult =
          typeof data.result === 'string'
            ? data.result
            : JSON.stringify(data.result, null, 2);
        outputPre.textContent =
          ` สำเร็จภายใน ${data.durationMs} ms (Timeout Guard: ${data.timeoutMs} ms)\n` +
          `--- Return Output ---\n${formattedResult}${logLines}`;
      }
      lastTestRunPassed = true;
      lastTestRunDurationMs = Number(data.durationMs || 0);
      showToast(`Test Run สำเร็จ (${data.durationMs} ms)`);
    } catch (err) {
      const errData = err?.data && typeof err.data === 'object' ? err.data : null;
      const errLogs = Array.isArray(errData?.logs) && errData.logs.length
        ? `\n\n--- Console Logs (${errData.logs.length}) ---\n` +
          errData.logs.map((l) => `[${String(l.level || 'log').toUpperCase()}] ${l.message}`).join('\n')
        : '';
      if (outputPre) {
        outputPre.style.color = '#f87171';
        outputPre.textContent = errData
          ? ` รันไม่สำเร็จ (${errData.durationMs ?? 0} ms)\nError: ${errData.error || err.message || 'Unknown Error'}${errLogs}`
          : ` เชื่อมต่อ /api/tools/test-run ไม่สำเร็จ:\n${err.message}`;
      }
      showToast(errData?.error || `Test Run Error: ${err.message}`, true);
    } finally {
      if (execBtn) execBtn.disabled = false;
      if (topTestBtn) topTestBtn.disabled = false;
    }
  };

  container.querySelector('#rwExecuteTestRunBtn')?.addEventListener('click', runSandboxTest);
  container.querySelector('#rwOpenTestRunDrawerBtn')?.addEventListener('click', () => {
    container.querySelector('#rwToolTestRunPanel')?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    runSandboxTest();
  });

  container.querySelector('#rwSaveCustomToolBtn')?.addEventListener('click', async () => {
    const schemaNow = syncSchemaFromDom().filter((r) => r.property);
    const nameVal = container.querySelector('#rwToolNameInput')?.value.trim() || '';
    const descVal = container.querySelector('#rwToolDescInput')?.value.trim() || '';
    const colorVal = container.querySelector('#rwToolColorInput')?.value.trim() || '';
    const funcVal = container.querySelector('#rwToolFuncInput')?.value || '';

    if (!nameVal || !descVal) {
      showToast('กรุณาระบุชื่อ Tool และคำอธิบายให้ครบถ้วน', true);
      return;
    }

    const payload = {
      id: activeEditingTool.id || undefined,
      name: nameVal,
      description: descVal,
      color: sanitizeCssColor(colorVal, 'linear-gradient(135deg, #06b6d4, #2563eb)'),
      schema: JSON.stringify(schemaNow),
      func: funcVal,
      testRunPassed: lastTestRunPassed,
      testRunDurationMs: lastTestRunDurationMs
    };

    try {
      const method = activeEditingTool.id ? 'PUT' : 'POST';
      const url = activeEditingTool.id
        ? `/api/custom-tools/${encodeURIComponent(activeEditingTool.id)}`
        : '/api/custom-tools';

      await adminApiFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      showToast(`บันทึก Custom Tool "${nameVal}" สำเร็จ`);
      activeEditingTool = null;
      await renderCustomToolsTab(container);
    } catch (saveErr) {
      showToast(`บันทึกไม่สำเร็จ: ${saveErr.message}`, true);
    }
  });
}
function initAdminSettingsUI() {
  injectHeaderButton();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAdminSettingsUI);
} else {
  initAdminSettingsUI();
}

// =============================================================================
// LAYER 2: ON-DEMAND BUSINESS PRESET PACKS + MERGED CUSTOM TOOLS STUDIO UI
// =============================================================================
let cachedPresetsState = { activePreset: null, presets: [], selectedPackId: '', customRequests: [] };
let pendingPresetUpload = null;

function renderCustomBizRequestsHtml(requests = []) {
  if (!Array.isArray(requests) || requests.length === 0) {
    return '<div class="text-[11px] text-slate-500 py-2">ยังไม่มีคำขอสายธุรกิจเพิ่มเติมในระบบ</div>';
  }
  return requests
    .slice(0, 10)
    .map(
      (r) => `
      <div class="p-3 rounded-xl bg-slate-950/75 border border-slate-800 space-y-1">
        <div class="flex items-center justify-between gap-2">
          <span class="text-xs font-bold text-cyan-300">${escapeHtml(r.businessType)}</span>
          <span class="text-[10px] font-mono text-slate-400">${escapeHtml((r.createdAt || '').slice(0, 10))}</span>
        </div>
        <p class="text-[11px] text-slate-300 leading-relaxed whitespace-pre-wrap">${escapeHtml(r.pricingLogic)}</p>
        ${r.requiredTools ? `<div class="text-[10px] text-emerald-300/90"> เครื่องมือที่ต้องการ: ${escapeHtml(r.requiredTools)}</div>` : ''}
        ${r.contactInfo ? `<div class="text-[10px] text-slate-400"> ติดต่อ: ${escapeHtml(r.contactInfo)}</div>` : ''}
      </div>`
    )
    .join('');
}

async function renderPresetsTab(container, statusEl) {
  queueMicrotask(() => { if (window.lucide) window.lucide.createIcons(); });
  container.innerHTML = `<div class="text-center py-12 text-cyan-300/80 text-sm animate-pulse">กำลังโหลดข้อมูลชุดธุรกิจและ Custom Tools Studio...</div>`;

  try {
    const [data, reqData] = await Promise.all([
      adminApiFetch('/api/presets'),
      adminApiFetch('/api/presets/request-custom').catch((err) => {
        console.warn('[Presets] custom requests fetch ignored:', err);
        return null;
      })
    ]);

    const customRequests = reqData?.ok && Array.isArray(reqData.requests) ? reqData.requests : [];

    const presets = Array.isArray(data.presets) ? data.presets : [];
    const active = data.activePreset || { packId: 'core-default', layer: 1, name: 'OmniFlow Clean Core (Default)', icon: '' };

    let selectedPackId = cachedPresetsState.selectedPackId;
    if (!selectedPackId || !presets.some((p) => p.packId === selectedPackId)) {
      selectedPackId =
        active.packId && presets.some((p) => p.packId === active.packId)
          ? active.packId
          : (presets[0]?.packId || 'stone-materials');
    }

    cachedPresetsState = { activePreset: active, presets, selectedPackId, customRequests };

    const selectedPack = presets.find((p) => p.packId === selectedPackId) || presets[0];
    const isCoreOnly = !active || active.packId === 'core-default';

    if (statusEl) {
      statusEl.textContent = isCoreOnly
        ? 'Layer 1 Clean Core + เครื่องมือ Flowise ปัจจุบัน • เลือกสายธุรกิจด้านบนหรือปรับแต่ง Custom Tools ด้านล่างได้ทันที'
        : `ชุดธุรกิจที่ใช้งาน: ${active.name} (v${active.version || '1.0.0'}) • พร้อม Custom Tools Studio`;
    }

    const dropdownOptionsHtml = presets
      .map((p) => {
        const mark = p.isInstalled ? ' (● กำลังใช้งาน)' : '';
        return `<option value="${escapeHtml(p.packId)}">${escapeHtml(`${p.icon || ''} ${p.name}${mark}`)}</option>`;
      })
      .join('');

    const renderSelectedCardHtml = (p) => {
      if (!p) {
        return '<div class="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 text-xs text-slate-400">ไม่พบข้อมูลชุดธุรกิจ</div>';
      }
      const isCurrent = Boolean(p.isInstalled);
      const supportedList = Array.isArray(p.supportedIndustries) ? p.supportedIndustries : [];
      const highlightsList = Array.isArray(p.highlights) ? p.highlights : [];
      const toolNamesList = Array.isArray(p.toolNames) ? p.toolNames : [];

      const supportedPillsHtml = supportedList
        .map(
          (ind) =>
            `<span class="px-2.5 py-1 rounded-lg text-[11px] font-medium bg-cyan-950/50 text-cyan-200 border border-cyan-500/35">${escapeHtml(ind)}</span>`
        )
        .join('');

      const highlightsHtml = highlightsList
        .map(
          (h) =>
            `<span class="px-2 py-0.5 rounded-md text-[10px] font-medium bg-slate-950/90 text-slate-300 border border-slate-700/80"> ${escapeHtml(h)}</span>`
        )
        .join('');

      const toolBadgesHtml = toolNamesList
        .map(
          (tn) =>
            `<code class="px-2 py-0.5 rounded-md text-[11px] font-mono bg-slate-950 text-emerald-300 border border-emerald-500/30"> ${escapeHtml(tn)}</code>`
        )
        .join('');

      return `
        <div class="p-5 rounded-2xl border transition space-y-4 ${
          isCurrent
            ? 'bg-gradient-to-br from-slate-900/95 via-cyan-950/25 to-slate-900/95 border-cyan-400/70 shadow-[0_0_24px_rgba(6,182,212,0.14)]'
            : 'bg-slate-900/80 border-slate-800'
        }">
          <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
            <div class="flex items-start gap-3">
              <div class="w-11 h-11 rounded-xl bg-slate-950 border border-slate-700/90 flex items-center justify-center text-2xl shrink-0">
                ${escapeHtml(p.icon || '')}
              </div>
              <div>
                <div class="flex flex-wrap items-center gap-2">
                  <h4 class="text-sm font-bold text-white leading-snug">${escapeHtml(p.name)}</h4>
                  ${
                    isCurrent
                      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">● กำลังใช้งาน</span>`
                      : `<span class="px-2 py-0.5 rounded-full text-[10px] font-mono bg-slate-800 text-cyan-300 border border-slate-700">v${escapeHtml(p.version)}</span>`
                  }
                  ${
                    p.preserveExistingEngine
                      ? `<span class="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/35"> ใช้ตรรกะจริงร้านหิน &amp; คง Tools เดิม</span>`
                      : ''
                  }
                </div>
                <div class="text-[11px] font-mono text-cyan-300/80 mt-0.5">${escapeHtml(p.subtitle || p.packId)}</div>
              </div>
            </div>
            <div class="text-[11px] font-mono text-slate-400 shrink-0">${escapeHtml(p.source)}</div>
          </div>

          <p class="text-xs text-slate-300 leading-relaxed">${escapeHtml(p.description)}</p>

          ${
            supportedPillsHtml
              ? `<div class="p-3.5 rounded-xl bg-slate-950/75 border border-cyan-500/25 space-y-2">
                  <div class="text-[11px] font-bold text-cyan-300"><i data-lucide="target" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>กลุ่มธุรกิจที่ใช้โมเดลคำนวณและเครื่องมือชุดนี้ร่วมกันได้ทันที (Compatible Industries):</div>
                  <div class="flex flex-wrap gap-1.5">${supportedPillsHtml}</div>
                </div>`
              : ''
          }

          <div class="flex flex-wrap items-center gap-1.5">
            ${highlightsHtml}
          </div>

          ${
            toolBadgesHtml
              ? `<div class="flex flex-wrap items-center gap-2 pt-1">
                  <span class="text-[11px] font-semibold text-slate-400">เครื่องมือที่ผูกกับชุดธุรกิจนี้ (${toolNamesList.length}):</span>
                  ${toolBadgesHtml}
                </div>`
              : ''
          }

          <div class="pt-3 border-t border-slate-800/90 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
            <div class="flex flex-wrap items-center gap-3">
              <div class="flex items-center gap-2">
                <label for="rwPresetCatalogMode" class="text-[11px] font-semibold text-slate-300">จัดการคลังสินค้า:</label>
                <select id="rwPresetCatalogMode" class="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-[11px] text-slate-100 focus:border-cyan-400 focus:outline-none">
                  <option value="keep" selected>คงคลังสินค้าเดิมทั้งหมดไว้ครบ (Keep — แนะนำ)</option>
                  <option value="merge">ผสานตัวอย่างเพิ่ม (Merge)</option>
                  <option value="replace">แทนที่ด้วยตัวอย่างของแพ็ก (Replace)</option>
                </select>
              </div>
              <label class="inline-flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer">
                <input type="checkbox" id="rwPresetUpdateTaglineChk" checked class="rounded bg-slate-900 border-slate-600 text-cyan-500" />
                <span>อัปเดตคำโปรยร้าน (Tagline)</span>
              </label>
            </div>

            <button
              type="button"
              id="rwInstallSelectedPackBtn"
              data-install-preset="${escapeHtml(p.packId)}"
              data-preset-name="${escapeHtml(p.name)}"
              class="px-4 py-2 rounded-xl text-xs font-bold transition shrink-0 ${
                isCurrent
                  ? 'bg-slate-800 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-md shadow-cyan-500/20'
              }"
            >
              <i data-lucide="zap" class="w-4 h-4 inline-block mr-1"></i>ติดตั้งและเริ่มใช้งานชุดธุรกิจนี้
            </button>
          </div>
        </div>
      `;
    };

    container.innerHTML = `
      <!-- 1. Active Layer Banner + Safe Core Reset -->
      <div class="p-4 rounded-2xl bg-gradient-to-r from-slate-900/90 via-cyan-950/30 to-slate-900/90 border border-cyan-500/35 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div class="flex items-start gap-3">
          <div class="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-xl shrink-0">
            ${escapeHtml(active.icon || '')}
          </div>
          <div>
            <div class="flex flex-wrap items-center gap-2">
              <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ${
                isCoreOnly
                  ? 'bg-slate-800 text-slate-300 border border-slate-600'
                  : 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/40'
              }">
                ${isCoreOnly ? 'Layer 1 • Clean Core' : 'Layer 1 Core + Layer 2 Business Pack'}
              </span>
              ${
                active.backupName
                  ? `<span class="text-[10px] font-mono text-emerald-300">Backup: ${escapeHtml(active.backupName)}</span>`
                  : ''
              }
            </div>
            <h3 class="text-sm font-bold text-white mt-0.5">${escapeHtml(active.name || 'OmniFlow Clean Core')}</h3>
            <p class="text-[11px] text-slate-400">
              โมเดลหลักที่พัฒนาสำหรับกลุ่มวัสดุสั่งตัดตามขนาด (คำนวณ กว้าง×ยาว / ตร.ม. + เผื่อเศษ) คงคีย์และข้อมูลลูกค้า 100% ทุกครั้งที่สลับ
            </p>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-2 shrink-0">
          <label class="inline-flex items-center gap-1.5 text-[11px] text-slate-300 px-2.5 py-1.5 rounded-lg bg-slate-950/70 border border-slate-800 cursor-pointer">
            <input type="checkbox" id="rwResetClearCatalogChk" class="rounded bg-slate-900 border-slate-600 text-rose-500" />
            <span>ล้างตัวอย่างแพ็ก</span>
          </label>
          <button type="button" id="rwResetToCoreBtn" class="px-3 py-1.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-200 border border-rose-500/40 text-[11px] font-bold transition">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5 inline-block mr-1"></i>รีเซ็ตกลับ Clean Core
          </button>
        </div>
      </div>

      <!-- 2. Dark-Mode Business Category Dropdown Selector -->
      <div class="p-4 rounded-2xl bg-slate-900/75 border border-slate-800 space-y-2.5">
        <div class="flex flex-wrap items-center justify-between gap-2">
          <label for="rwBusinessCategoryDropdown" class="text-xs font-bold text-cyan-300">
            <i data-lucide="target" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>เลือกประเภทธุรกิจของคุณ (Select Business Category)
          </label>
          <span class="text-[11px] text-slate-400">กลุ่มธุรกิจที่ใช้โมเดลคำนวณพื้นที่/สั่งตัดชุดเดียวกัน</span>
        </div>
        <select
          id="rwBusinessCategoryDropdown"
          class="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 hover:border-cyan-500/50 focus:border-cyan-400 focus:outline-none text-xs sm:text-sm font-medium text-white transition cursor-pointer"
        >
          ${dropdownOptionsHtml}
        </select>
      </div>

      <!-- 3. Single Full-Width Summary Card -->
      <div id="rwSelectedPackCardHost">
        ${renderSelectedCardHtml(selectedPack)}
      </div>

      <!-- Result / Safety Log Box -->
      <div id="rwPresetResultBox" class="hidden p-4 rounded-xl border text-xs space-y-2"></div>

      <!-- 4. Flowise Custom Tools Studio Zone (Merged Directly Below Selected Business Pack) -->
      <div id="rwCustomToolsStudioZone" class="pt-2 border-t border-slate-800/90"></div>

      <!-- 4.5 Workflow Routing Map & Simulate Smart Ops Flow (Moved from Main Dashboard) -->
      <div class="p-5 rounded-2xl bg-slate-900/75 border border-cyan-500/25 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 class="text-sm font-bold text-white flex items-center gap-2">
              <span class="text-cyan-400"><i data-lucide="git-branch" class="w-3.5 h-3.5 inline-block mr-1 -mt-0.5 shrink-0"></i>WORKFLOW ROUTING MAP</span>
              <span class="text-[10px] font-mono text-cyan-300 bg-cyan-950/70 border border-cyan-500/30 px-2 py-0.5 rounded">OMNIFLOW SMART OPS SUITE</span>
            </h4>
            <p class="text-[11px] text-slate-400 mt-0.5">ตีราคาด่วน Native Math → คลังรูปสินค้าค้นหาตามหมวดหมู่ → ป้ายสถานะลูกค้า Kanban 4 ขั้นตอน → กรองแชทตามสินค้า/บริการ</p>
          </div>
          <button type="button" onclick="window.simulateTrafficPulse && window.simulateTrafficPulse()"
            class="text-xs font-mono px-3 py-1.5 rounded-lg bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/35 transition flex items-center gap-1.5">
            <span class="inline-flex items-center gap-1.5"><i data-lucide="zap" class="w-4 h-4 shrink-0"></i><span>Simulate Smart Ops Flow</span></span>
          </button>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div onclick="window.selectPipelineNode && window.selectPipelineNode(0)" id="pipeNode-0"
            class="cursor-pointer rounded-xl bg-slate-950/90 border border-cyan-400/50 p-3.5 transition-all hover:scale-[1.01]">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">MODULE 01</span>
              <span class="text-[10px] font-mono text-cyan-300">&lt; 1 ms</span>
            </div>
            <h5 class="font-bold text-xs text-white mb-1">Safe Quotation &amp; Order Summary</h5>
            <p class="text-[11px] text-slate-400 leading-relaxed">คำนวณยอดรวมด้วย JS Math ส่งเข้าแชทหรือคัดลอกส่งทีมงานทันที</p>
          </div>

          <div onclick="window.selectPipelineNode && window.selectPipelineNode(1)" id="pipeNode-1"
            class="cursor-pointer rounded-xl bg-slate-950/90 border border-indigo-500/40 hover:border-cyan-400/50 p-3.5 transition-all hover:scale-[1.01]">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">MODULE 02</span>
              <span class="text-[10px] font-mono text-emerald-400">LOCAL DB</span>
            </div>
            <h5 class="font-bold text-xs text-white mb-1">Product &amp; Service Gallery</h5>
            <p class="text-[11px] text-slate-400 leading-relaxed">ค้นหารูปสินค้าและบริการในคลังตามชื่อหรือหมวดหมู่ คลิกส่งเข้าแชททันที</p>
          </div>

          <div onclick="window.selectPipelineNode && window.selectPipelineNode(2)" id="pipeNode-2"
            class="cursor-pointer rounded-xl bg-slate-950/90 border border-purple-500/50 hover:border-purple-400 p-3.5 transition-all hover:scale-[1.01]">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40">MODULE 03</span>
              <span class="text-[10px] font-mono text-purple-300">KANBAN CRM</span>
            </div>
            <h5 class="font-bold text-xs text-white mb-1">Customer Kanban Tagging</h5>
            <p class="text-[11px] text-slate-400 leading-relaxed">ติดป้ายสีสถานะ 4 ขั้นตอน: ถามราคา → รอตัดสินใจ → โอนมัดจำ → ปิดจ็อบ</p>
          </div>

          <div onclick="window.selectPipelineNode && window.selectPipelineNode(3)" id="pipeNode-3"
            class="cursor-pointer rounded-xl bg-slate-950/90 border border-emerald-500/40 hover:border-emerald-400 p-3.5 transition-all hover:scale-[1.01]">
            <div class="flex items-center justify-between mb-1.5">
              <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">MODULE 04</span>
              <span class="text-[10px] font-mono text-amber-300">INBOX FILTER</span>
            </div>
            <h5 class="font-bold text-xs text-white mb-1">Smart Product Filter</h5>
            <p class="text-[11px] text-slate-400 leading-relaxed">พิมพ์ชื่อสินค้าหรือกดปุ่มกรองด่วนเพื่อค้นหาลูกค้าที่ถามหานั้นทันที</p>
          </div>
        </div>

        <div id="pipelineInspector" class="rounded-xl bg-[#060b1c] border border-cyan-500/20 px-4 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div class="flex items-center gap-2 text-cyan-300 font-mono">
            <span id="inspectorTitle" class="font-semibold">[MODULE 01] SAFE QUOTATION &amp; ORDER SUMMARY:</span>
            <span id="inspectorDesc" class="text-slate-300 font-sans">คำนวณราคาสินค้าตามจำนวนชิ้น/คอร์ส หรือพื้นที่ (กว้าง x ยาว) ด้วย Pure JavaScript Math ป้องกัน AI คำนวณราคาผิด</span>
          </div>
          <span id="packetTraceBadge" class="font-mono text-[11px] text-emerald-400">READY</span>
        </div>
      </div>

      <!-- 5. Compact Trigger for Request Custom Business Logic Popup Modal -->
      <div class="p-4 rounded-2xl bg-slate-900/75 border border-indigo-500/35 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h4 class="text-xs sm:text-sm font-bold text-indigo-300"><i data-lucide="file-edit" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>แจ้งความต้องการพัฒนาสายธุรกิจใหม่ (สำหรับธุรกิจอื่นนอกเหนือจากกลุ่มวัสดุสั่งตัด)</h4>
          <p class="text-[11px] text-slate-400 mt-0.5">
            ส่งข้อมูลวิธีคิดราคาและเครื่องมือหน้างานจริง เพื่อให้ทีมงานพัฒนาสายธุรกิจใหม่ตรงงานจริง 100% (บันทึกแล้ว <span id="rwCustomBizReqCount">${customRequests.length}</span> รายการ)
          </p>
        </div>
        <button type="button" id="rwOpenCustomBizModalBtn"
          class="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white text-xs font-bold shadow-md transition shrink-0">
          <i data-lucide="file-edit" class="w-3.5 h-3.5 inline-block mr-1"></i>แจ้งพัฒนาสายธุรกิจใหม่
        </button>
      </div>

      <!-- Custom Business Requirement Popup Modal -->
      <div id="rwCustomBizModalOverlay" class="hidden fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <div class="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-slate-950 border border-indigo-500/45 p-6 shadow-2xl space-y-4">
          <div class="flex items-start justify-between gap-3">
            <div>
              <h4 class="text-sm sm:text-base font-bold text-indigo-300"><i data-lucide="file-edit" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>แจ้งความต้องการพัฒนาสายธุรกิจใหม่ (สำหรับธุรกิจอื่นนอกเหนือจากกลุ่มวัสดุสั่งตัด)</h4>
              <p class="text-[11px] text-slate-400 mt-1">
                หากต้องการใช้งานกับสายธุรกิจอื่น (เช่น คลินิก, ร้านอาหาร, อู่ซ่อมรถ, ทัวร์, ขายส่งเฉพาะทาง) ให้ผู้ทำงานหน้างานจริงระบุวิธีคิดราคาและเครื่องมือที่ต้องการ เพื่อพัฒนาได้ตรงงานจริง 100% โดยไม่เดาสุ่ม
              </p>
            </div>
            <button type="button" id="rwCloseCustomBizModalBtn" class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold shrink-0"> ปิด</button>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label class="block text-[11px] font-semibold text-slate-300 mb-1">ชื่อประเภทธุรกิจ <span class="text-rose-400">*</span></label>
              <input id="rwCustomReqBusinessType" type="text" placeholder="เช่น คลินิกทันตกรรม, ร้านผ้าม่านเฉพาะทาง, ขายส่งอาหารทะเล" class="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-indigo-400 focus:outline-none text-xs text-white" />
            </div>
            <div>
              <label class="block text-[11px] font-semibold text-slate-300 mb-1">ชื่อผู้ติดต่อ / เบอร์ / Line (ไม่บังคับ)</label>
              <input id="rwCustomReqContact" type="text" placeholder="เช่น คุณเอ / Line: @shopname" class="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-indigo-400 focus:outline-none text-xs text-white" />
            </div>
          </div>

          <div>
            <label class="block text-[11px] font-semibold text-slate-300 mb-1">วิธีคิดราคา / ตรรกะและขั้นตอนหน้างานจริง <span class="text-rose-400">*</span></label>
            <textarea id="rwCustomReqPricingLogic" rows="4" placeholder="อธิบายกติกาจริงหน้าร้าน เช่น คิดราคาตามน้ำหนักหรือตารางเมตร, ต้องถามข้อมูลอะไรจากลูกค้าก่อนเสนอราคา, มีเงื่อนไขมัดจำหรือหักส่วนลดอย่างไร..." class="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-indigo-400 focus:outline-none text-xs text-white leading-relaxed"></textarea>
          </div>

          <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div class="flex-1">
              <label class="block text-[11px] font-semibold text-slate-300 mb-1">เครื่องมือคำนวณ / ระบบที่อยากให้บอทเชื่อมต่อ (ไม่บังคับ)</label>
              <input id="rwCustomReqTools" type="text" placeholder="เช่น เช็คคิว Google Calendar, คำนวณค่าขนส่งห้องเย็น, ส่งบิลเข้า Line Notify" class="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 focus:border-indigo-400 focus:outline-none text-xs text-white" />
            </div>
            <button type="button" id="rwSubmitCustomBizReqBtn" class="px-4 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white text-xs font-bold shadow-md transition shrink-0">
              <i data-lucide="send" class="w-3.5 h-3.5 inline-block mr-1"></i>บันทึกความต้องการสายธุรกิจใหม่
            </button>
          </div>

          <div class="pt-2 border-t border-slate-800/80 space-y-2">
            <div class="text-[11px] font-bold text-slate-300"> รายการคำขอพัฒนาสายธุรกิจที่บันทึกไว้ (<span id="rwCustomBizModalListCount">${customRequests.length}</span>)</div>
            <div id="rwCustomBizReqList" class="space-y-2 max-h-48 overflow-y-auto">
              ${renderCustomBizRequestsHtml(customRequests)}
            </div>
          </div>
        </div>
      </div>

      <!-- 6. Custom / Offline Business Pack Uploader (OTA Engine) -->
      <div class="p-4 rounded-2xl bg-slate-900/60 border border-dashed border-cyan-500/35 space-y-3">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h4 class="text-xs font-bold text-cyan-300"><i data-lucide="download" class="w-4 h-4 inline-block mr-1.5 -mt-0.5 shrink-0"></i>ติดตั้ง Business Pack แบบกำหนดเอง (.json / .zip ผ่าน OTA Engine)</h4>
            <p class="text-[11px] text-slate-400">อัปโหลดไฟล์แพ็กธุรกิจเฉพาะทาง เช่น stone-materials-pack.json หรือแพ็กเกจ .zip</p>
          </div>
          <button type="button" id="rwInstallUploadedPackBtn" disabled class="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold opacity-50 cursor-not-allowed transition">
            <i data-lucide="upload" class="w-3.5 h-3.5 inline-block mr-1"></i>ติดตั้งไฟล์ที่อัปโหลด
          </button>
        </div>
        <div class="flex flex-col sm:flex-row items-center gap-3">
          <input type="file" id="rwPresetFileInput" accept=".json,.zip" class="block w-full text-xs text-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border file:border-cyan-500/40 file:text-xs file:font-semibold file:bg-cyan-500/15 file:text-cyan-200 hover:file:bg-cyan-500/25 cursor-pointer" />
          <span id="rwPresetFileLabel" class="text-[11px] font-mono text-slate-400 shrink-0">ยังไม่ได้เลือกไฟล์</span>
        </div>
      </div>
    `;

    const dropdownEl = document.getElementById('rwBusinessCategoryDropdown');
    if (dropdownEl) {
      dropdownEl.value = selectedPack ? selectedPack.packId : '';
    }

    const bindCardInstallBtn = () => {
      const btn = document.getElementById('rwInstallSelectedPackBtn');
      btn?.addEventListener('click', async () => {
        const presetId = btn.getAttribute('data-install-preset');
        const presetName = btn.getAttribute('data-preset-name') || presetId;
        const catalogMode = document.getElementById('rwPresetCatalogMode')?.value || 'keep';
        const updateTagline = Boolean(document.getElementById('rwPresetUpdateTaglineChk')?.checked);

        if (
          !confirm(
            `ยืนยันใช้งานชุดธุรกิจ "${presetName}"?\n\nระบบจะสำรองข้อมูลเดิม (.bak) อัตโนมัติ (โหมดแคตตาล็อก: ${catalogMode}) และรักษา System Prompt / Custom Tools / คีย์แชตของคุณไว้ครบถ้วน`
          )
        ) {
          return;
        }

        await executePresetInstall(
          { presetId, catalogMode, updateTagline },
          btn,
          container,
          statusEl
        );
      });
    };

    dropdownEl?.addEventListener('change', (e) => {
      const nextId = e.target.value;
      cachedPresetsState.selectedPackId = nextId;
      const nextPack = presets.find((p) => p.packId === nextId) || presets[0];
      const host = document.getElementById('rwSelectedPackCardHost');
      if (host) {
        host.innerHTML = renderSelectedCardHtml(nextPack);
        bindCardInstallBtn();
      }
      if (statusEl && nextPack) {
        statusEl.textContent = `กำลังดูชุดธุรกิจ: ${nextPack.name} • แก้ไข Custom Tools ด้านล่างได้ทันที`;
      }
    });

    bindCardInstallBtn();

    // Render merged Custom Tools Studio directly below Summary Card
    const studioZone = document.getElementById('rwCustomToolsStudioZone');
    if (studioZone) {
      await renderCustomToolsTab(studioZone);
    }

    // Bind Custom Business Requirement Popup Modal & Submit
    const bizModal = document.getElementById('rwCustomBizModalOverlay');
    document.getElementById('rwOpenCustomBizModalBtn')?.addEventListener('click', () => {
      bizModal?.classList.remove('hidden');
    });
    document.getElementById('rwCloseCustomBizModalBtn')?.addEventListener('click', () => {
      bizModal?.classList.add('hidden');
    });
    bizModal?.addEventListener('click', (e) => {
      if (e.target === bizModal) bizModal.classList.add('hidden');
    });

    const reqSubmitBtn = document.getElementById('rwSubmitCustomBizReqBtn');
    reqSubmitBtn?.addEventListener('click', async () => {
      const businessType = document.getElementById('rwCustomReqBusinessType')?.value.trim() || '';
      const contactInfo = document.getElementById('rwCustomReqContact')?.value.trim() || '';
      const pricingLogic = document.getElementById('rwCustomReqPricingLogic')?.value.trim() || '';
      const requiredTools = document.getElementById('rwCustomReqTools')?.value.trim() || '';

      if (!businessType || !pricingLogic) {
        showToast(' กรุณากรอก "ชื่อประเภทธุรกิจ" และ "วิธีคิดราคา/ตรรกะหน้างานจริง"', true);
        return;
      }

      const origText = reqSubmitBtn.textContent;
      reqSubmitBtn.disabled = true;
      reqSubmitBtn.textContent = '⏳ กำลังบันทึก...';

      try {
        const rData = await adminApiFetch('/api/presets/request-custom', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ businessType, contactInfo, pricingLogic, requiredTools })
        });

        showToast(` ${rData.message}`);
        cachedPresetsState.customRequests = rData.requests || [];
        document.getElementById('rwCustomReqBusinessType').value = '';
        document.getElementById('rwCustomReqPricingLogic').value = '';
        document.getElementById('rwCustomReqTools').value = '';
        const listEl = document.getElementById('rwCustomBizReqList');
        if (listEl) listEl.innerHTML = renderCustomBizRequestsHtml(cachedPresetsState.customRequests);
        const cnt1 = document.getElementById('rwCustomBizReqCount');
        const cnt2 = document.getElementById('rwCustomBizModalListCount');
        if (cnt1) cnt1.textContent = cachedPresetsState.customRequests.length;
        if (cnt2) cnt2.textContent = cachedPresetsState.customRequests.length;
      } catch (err) {
        showToast(` ${err.message}`, true);
      } finally {
        reqSubmitBtn.disabled = false;
        reqSubmitBtn.textContent = origText;
      }
    });

    // Bind File Upload Input
    const fileInput = document.getElementById('rwPresetFileInput');
    const fileLabel = document.getElementById('rwPresetFileLabel');
    const uploadInstallBtn = document.getElementById('rwInstallUploadedPackBtn');
    pendingPresetUpload = null;

    fileInput?.addEventListener('change', () => {
      const file = fileInput.files?.[0];
      const resetUploadUi = () => {
        pendingPresetUpload = null;
        if (fileLabel) fileLabel.textContent = 'ยังไม่ได้เลือกไฟล์';
        if (uploadInstallBtn) {
          uploadInstallBtn.disabled = true;
          uploadInstallBtn.classList.add('opacity-50', 'cursor-not-allowed');
          uploadInstallBtn.classList.remove('hover:bg-emerald-500/30', 'cursor-pointer');
        }
      };
      if (!file) {
        resetUploadUi();
        return;
      }
      const check = validateUploadFile(file);
      if (!check.ok) {
        fileInput.value = '';
        resetUploadUi();
        showToast(` ${check.error}`, true);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        pendingPresetUpload = {
          filename: file.name,
          contentBase64: String(reader.result || '')
        };
        if (fileLabel) fileLabel.textContent = `พร้อมติดตั้ง: ${file.name} (${Math.ceil(file.size / 1024)} KB)`;
        if (uploadInstallBtn) {
          uploadInstallBtn.disabled = false;
          uploadInstallBtn.classList.remove('opacity-50', 'cursor-not-allowed');
          uploadInstallBtn.classList.add('hover:bg-emerald-500/30', 'cursor-pointer');
        }
      };
      reader.onerror = () => {
        fileInput.value = '';
        resetUploadUi();
        showToast(' ไม่สามารถอ่านไฟล์ที่อัปโหลดได้', true);
      };
      reader.readAsDataURL(file);
    });

    uploadInstallBtn?.addEventListener('click', async () => {
      if (!pendingPresetUpload) return;
      const catalogMode = document.getElementById('rwPresetCatalogMode')?.value || 'keep';
      const updateTagline = Boolean(document.getElementById('rwPresetUpdateTaglineChk')?.checked);
      await executePresetInstall(
        {
          filename: pendingPresetUpload.filename,
          contentBase64: pendingPresetUpload.contentBase64,
          catalogMode,
          updateTagline
        },
        uploadInstallBtn,
        container,
        statusEl
      );
    });

    // Bind Reset to Core Button
    const resetBtn = document.getElementById('rwResetToCoreBtn');
    resetBtn?.addEventListener('click', async () => {
      const clearPresetCatalog = Boolean(document.getElementById('rwResetClearCatalogChk')?.checked);
      if (
        !confirm(
          `ยืนยันรีเซ็ตระบบกลับเป็น Layer 1 Clean Core?\n\n- ระบบจะ Auto-Backup ข้อมูลเดิม (.bak) ก่อนดำเนินการ\n- คงคีย์ช่องทางแชต, AI Providers, ออเดอร์ และ Custom Tools ที่คุณสร้างเองไว้ทั้งหมด`
        )
      ) {
        return;
      }

      const origText = resetBtn.textContent;
      resetBtn.disabled = true;
      resetBtn.textContent = '⏳ กำลัง Auto-Backup & รีเซ็ต...';

      try {
        const rData = await adminApiFetch('/api/presets/reset-core', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ clearPresetCatalog }),
          timeoutMs: 25000
        });

        showToast(` ${rData.message}`);
        await renderPresetsTab(container, statusEl);
        if (typeof window.refreshAll === 'function') window.refreshAll(false);
      } catch (err) {
        showToast(` ${err.message}`, true);
        resetBtn.disabled = false;
        resetBtn.textContent = origText;
      }
    });
  } catch (err) {
    container.innerHTML = `<div class="p-4 rounded-xl bg-rose-950/50 border border-rose-500/40 text-rose-200 text-sm">เกิดข้อผิดพลาดในการโหลด Business Packs: ${escapeHtml(err.message)}</div>`;
  }
}

async function executePresetInstall(payload, triggerBtn, container, statusEl) {
  const resultBox = document.getElementById('rwPresetResultBox');
  const origHtml = triggerBtn ? triggerBtn.innerHTML : '';
  if (triggerBtn) {
    triggerBtn.disabled = true;
    triggerBtn.innerHTML = '⏳ กำลัง Auto-Backup (.bak) & ติดตั้ง...';
  }

  try {
    const data = await adminApiFetch('/api/presets/install', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      timeoutMs: 30000
    });

    if (data.activePreset?.packId) {
      cachedPresetsState.selectedPackId = data.activePreset.packId;
    }

    showToast(` ${data.message}`);
    await renderPresetsTab(container, statusEl);

    const refreshedBox = document.getElementById('rwPresetResultBox');
    if (refreshedBox) {
      refreshedBox.className = 'p-4 rounded-xl border bg-emerald-950/35 border-emerald-500/45 text-emerald-100 text-xs space-y-1.5';
      refreshedBox.innerHTML = `
        <div class="font-bold text-emerald-300"> ติดตั้งชุดธุรกิจสำเร็จ &amp; ผ่าน OTA Safety Healthcheck 100%</div>
        <div>• แพ็กเกจที่ใช้งานอยู่: <strong>${escapeHtml(data.activePreset?.name)}</strong> (v${escapeHtml(data.activePreset?.version)})</div>
        <div>• จุดสำรองข้อมูลเดิม (.bak): <span class="font-mono text-cyan-300">${escapeHtml(data.backupName)}</span></div>
        <div>• เครื่องมือพร้อมใช้งาน: <strong>${Number(data.stats?.toolsInstalled ?? 0)}</strong> รายการ ${data.stats?.promptPreserved ? '( คง System Prompt เดิมของร้านไว้ 100%)' : ''} | เพิ่มสินค้า Catalog: <strong>${Number(data.stats?.catalogAdded ?? 0)}</strong> รายการ</div>
        ${data.requiresRestart ? '<div class="text-amber-300 font-semibold"> แพ็กเกจนี้มีการติดตั้งปลั๊กอินฝั่ง Backend แนะนำให้รีสตาร์ทเซอร์วิสเพื่อให้โค้ดใหม่ทำงานสมบูรณ์</div>' : ''}
      `;
    }

    if (typeof window.refreshAll === 'function') {
      window.refreshAll(false);
    }
  } catch (err) {
    showToast(` ${err.message}`, true);
    if (resultBox) {
      resultBox.className = 'p-4 rounded-xl border bg-rose-950/45 border-rose-500/45 text-rose-200 text-xs';
      resultBox.textContent = ` ${err.message}`;
    }
    if (triggerBtn) {
      triggerBtn.disabled = false;
      triggerBtn.innerHTML = origHtml;
    }
  }
}