// Phase 8.6 Modular UI Plugin: Gallery Multi-Select Checkboxes & Batch Send (with Enter Key)
(function initGalleryMultiSelectPlugin() {
  const selectedImages = new Map(); // imageUrl -> { imageUrl, stoneName, priceStr }

  function getBatchBtn() {
    return document.getElementById('galleryBatchSendBtn');
  }

  function getCountBadge() {
    return document.getElementById('gallerySelectedCountBadge');
  }

  function getStatusEl() {
    return document.getElementById('gallerySendStatus');
  }

  function updateSelectionUI() {
    const btn = getBatchBtn();
    const badge = getCountBadge();
    const count = selectedImages.size;

    if (badge) {
      if (count > 0) {
        badge.classList.remove('hidden');
        badge.textContent = `เลือก ${count} รูป`;
      } else {
        badge.classList.add('hidden');
      }
    }

    if (btn) {
      btn.disabled = count === 0;
      btn.innerHTML = count > 0 
        ? `<span class="inline-flex items-center gap-1.5"><i data-lucide="send" class="w-4 h-4 shrink-0"></i><span>ส่ง ${count} รูปที่เลือกให้ลูกค้า (Enter)</span></span>`
        : `<span class="inline-flex items-center gap-1.5"><i data-lucide="send" class="w-4 h-4 shrink-0"></i><span>ส่งรูปที่เลือกให้ลูกค้า (Enter)</span></span>`;
      if (window.lucide) window.lucide.createIcons();
    }

    // Update Card border highlight
    document.querySelectorAll('.gallery-item-card').forEach((card) => {
      const chk = card.querySelector('.gallery-item-chk');
      if (chk && chk.dataset.url) {
        if (selectedImages.has(chk.dataset.url)) {
          card.classList.add('ring-2', 'ring-cyan-400', 'border-cyan-400');
          chk.checked = true;
        } else {
          card.classList.remove('ring-2', 'ring-cyan-400', 'border-cyan-400');
          chk.checked = false;
        }
      }
    });
  }

  window.toggleGalleryItemSelection = function (chkEl, e) {
    if (e) e.stopPropagation();
    const url = chkEl.dataset.url;
    const name = chkEl.dataset.name;
    const price = chkEl.dataset.price;

    if (chkEl.checked) {
      selectedImages.set(url, { imageUrl: url, stoneName: name, priceStr: price });
    } else {
      selectedImages.delete(url);
    }
    updateSelectionUI();
  };

  window.sendSelectedGalleryImages = async function () {
    if (!state.selectedUserKey || selectedImages.size === 0) return;
    const btn = getBatchBtn();
    const statusEl = getStatusEl();
    const items = Array.from(selectedImages.values());
    const includeCaption = document.getElementById('galleryIncludeCaptionChk')?.checked;

    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<span>⏳ กำลังทยอยส่ง...</span>';
    }

    let successCount = 0;
    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (statusEl) {
        statusEl.textContent = `⏳ กำลังส่งรูปที่ ${i + 1}/${items.length}: ${item.stoneName}...`;
      }
      const caption = includeCaption ? `ตัวอย่างลายหิน: ${item.stoneName} (${item.priceStr})` : '';

      try {
        const res = await fetch(`${GATEWAY_BASE}/api/chat/send-image-direct`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userKey: state.selectedUserKey,
            imageUrl: item.imageUrl,
            caption,
          }),
          signal: AbortSignal.timeout(20000),
        });
        const data = await res.json();
        if (res.ok && data.ok) {
          successCount++;
          if (Array.isArray(data.conversations)) state.conversations = data.conversations;
        }
      } catch (err) {
        console.error('Failed to send image:', item.stoneName, err);
      }
      // Small pause between multiple sends
      if (i < items.length - 1) {
        await new Promise((r) => setTimeout(r, 600));
      }
    }

    selectedImages.clear();
    updateSelectionUI();

    if (statusEl) {
      statusEl.textContent = ` ส่งรูปภาพสำเร็จเรียบร้อย ${successCount}/${items.length} รูป!`;
    }
    if (typeof refreshAll === 'function') refreshAll(false);
  };

  // Keyboard Enter Shortcut to send
  document.addEventListener('keydown', (e) => {
    const modal = document.getElementById('stoneGalleryModal');
    if (!modal || modal.classList.contains('hidden')) return;

    // If focused inside search input, pressing Enter doesn't submit unless Ctrl/Cmd or no text search
    if (e.target && e.target.id === 'gallerySearchInput') {
      if (e.key === 'Enter' && selectedImages.size > 0 && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        window.sendSelectedGalleryImages();
      }
      return;
    }

    if (e.key === 'Enter' && selectedImages.size > 0) {
      e.preventDefault();
      window.sendSelectedGalleryImages();
    }
  });

  // Inject checkbox and card class when gallery renders
  const origFilter = window.filterStoneGallery;
  window.filterStoneGallery = function () {
    if (typeof origFilter === 'function') {
      origFilter();
    }
    enhanceGalleryCards();
  };

  function enhanceGalleryCards() {
    const grid = document.getElementById('stoneGalleryGrid');
    if (!grid) return;

    const cards = grid.children;
    for (const card of cards) {
      if (card.classList.contains('col-span-full')) continue;
      card.classList.add('gallery-item-card', 'relative');

      const imgContainer = card.querySelector('.gvm-img-frame, .gallery-img-container, [class*="aspect-"]') || card.querySelector('img')?.parentElement;
      if (imgContainer && !imgContainer.querySelector('.gallery-item-chk-wrapper')) {
        const sendBtn = card.querySelector('button[onclick*="sendGalleryImageToCustomer"]');
        let imgUrl = '', name = '', price = '';
        if (sendBtn) {
          const match = sendBtn.getAttribute('onclick')?.match(/sendGalleryImageToCustomer\(this,\s*'([^']*)',\s*'([^']*)',\s*'([^']*)'\)/);
          if (match) {
            imgUrl = match[1];
            name = match[2];
            price = match[3];
          }
        }

        const chkWrapper = document.createElement('label');
        chkWrapper.className = 'gallery-item-chk-wrapper absolute top-2 right-2 z-20 flex items-center justify-center w-7 h-7 rounded-lg bg-black/80 hover:bg-cyan-950/90 border border-cyan-400/50 cursor-pointer shadow-md transition';
        chkWrapper.onclick = (e) => e.stopPropagation();
        chkWrapper.title = 'ติ๊กเลือกรูปนี้เพื่อส่งพร้อมกัน';
        chkWrapper.innerHTML = `
          <input type="checkbox" class="gallery-item-chk w-4 h-4 accent-cyan-400 cursor-pointer" 
            data-url="${imgUrl}" data-name="${name}" data-price="${price}"
            onchange="toggleGalleryItemSelection(this, event)" />
        `;
        imgContainer.appendChild(chkWrapper);
      }
    }
    updateSelectionUI();
  }

  // Clear selections when modal opens/closes
  const origClose = window.closeStoneGalleryModal;
  window.closeStoneGalleryModal = function () {
    selectedImages.clear();
    updateSelectionUI();
    if (typeof origClose === 'function') origClose();
  };
})();
