// gateway/public/modules/catalog-uploader-ui.js
// Phase 8.4 Modular UI Plugin: Live Catalog Uploader Modal (GitHub CDN + Price_List)
(function initCatalogUploaderPlugin() {
  if (document.getElementById('catalogUploaderModal')) return;

  const ALLOWED_MIMES = new Set(['image/png', 'image/jpeg', 'image/webp', 'image/gif']);
  const SAFE_DATA_IMG_RE = /^data:image\/(?:png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=\s]+$/i;
  const MAX_IMAGE_BYTES = 10 * 1024 * 1024; // 10 MB

  async function apiJson(path, options = {}) {
    const bridge =
      typeof window.apiFetch === 'function'
        ? window.apiFetch
        : typeof window.omniApiFetch === 'function'
        ? window.omniApiFetch
        : null;
    if (bridge) return bridge(path, options);
    const res = await fetch(path, { credentials: 'same-origin', ...options });
    const data = await res.json().catch(() => null);
    if (!res.ok || !data || data.ok === false) {
      throw new Error(data?.error || `HTTP ${res.status}`);
    }
    return data;
  }

  function isSafeDataImage(dataUrl) {
    const s = String(dataUrl ?? '').trim();
    if (!SAFE_DATA_IMG_RE.test(s)) return false;
    if (typeof window.isSafeUrl === 'function') {
      return window.isSafeUrl(s, { allowDataImage: true });
    }
    return true;
  }

  const modalHtml = `
    <div id="catalogUploaderModal" class="hidden fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div class="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700/90 shadow-2xl overflow-hidden">
        <div class="px-5 py-3.5 bg-slate-950/90 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <i data-lucide="gem" class="w-4 h-4 text-cyan-400 shrink-0"></i>
            <h3 class="text-sm font-bold text-white">เพิ่มหินใหม่เข้าคลัง (GitHub CDN + Price_List)</h3>
          </div>
          <button type="button" id="closeCatalogModalBtn" class="text-slate-400 hover:text-white text-sm inline-flex items-center gap-1"><i data-lucide="x" class="w-3.5 h-3.5 shrink-0"></i><span>ปิด</span></button>
        </div>
        <form id="catalogUploaderForm" class="p-5 space-y-3 text-xs">
          <div>
            <label class="block text-[11px] font-mono text-slate-300 mb-1">1. เลือกรูปภาพหิน (ไฟล์ .jpg / .png / .webp / .gif):</label>
            <input type="file" id="catImgInput" accept="image/png,image/jpeg,image/webp,image/gif" required class="w-full text-slate-300 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-cyan-500/20 file:text-cyan-300 hover:file:bg-cyan-500/30 cursor-pointer" />
            <img id="catImgPreview" class="hidden mt-2 max-h-32 rounded-lg border border-slate-700 object-cover" />
          </div>
          <div class="grid grid-cols-2 gap-2.5">
            <div>
              <label class="block text-[11px] font-mono text-slate-300 mb-1">2. ชนิดสินค้า:</label>
              <select id="catTypeInput" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white">
                <option value="1. หินแกรนิต">1. หินแกรนิต</option>
                <option value="2. หินอ่อน">2. หินอ่อน</option>
                <option value="3. หินเทียม / ควอตซ์">3. หินเทียม / ควอตซ์</option>
              </select>
            </div>
            <div>
              <label class="block text-[11px] font-mono text-slate-300 mb-1">3. ชื่อสินค้า / สี:</label>
              <input type="text" id="catNameInput" required placeholder="เช่น หินแกรนิตดำอินเดีย (Indian Black)" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white" />
            </div>
          </div>
          <div class="grid grid-cols-2 gap-2.5">
            <div>
              <label class="block text-[11px] font-mono text-slate-300 mb-1">4. ขนาด / เบอร์:</label>
              <input type="text" id="catSizeInput" value="แผ่นมาตรฐาน / สั่งตัด" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white" />
            </div>
            <div>
              <label class="block text-[11px] font-mono text-slate-300 mb-1">5. รหัสบล็อก (block_code):</label>
              <input type="text" id="catBlockInput" placeholder="เช่น BLK-6801" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white" />
            </div>
          </div>
          <div class="grid grid-cols-2 gap-2.5">
            <div>
              <label class="block text-[11px] font-mono text-slate-300 mb-1">6. ราคายกสแลป (บาท/ตร.ม.):</label>
              <input type="number" id="catSlabPriceInput" placeholder="เช่น 2090" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white" />
            </div>
            <div>
              <label class="block text-[11px] font-mono text-slate-300 mb-1">7. ราคาสั่งตัด (บาท/ตร.ม.):</label>
              <input type="number" id="catCutPriceInput" placeholder="เช่น 3800" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white" />
            </div>
          </div>
          <div>
            <label class="block text-[11px] font-mono text-slate-300 mb-1">8. เงื่อนไขเพิ่มเติม:</label>
            <input type="text" id="catNoteInput" value="ราคาเฉพาะแผ่นหิน" class="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white" />
          </div>
          <div id="catUploadStatus" class="hidden text-[11px] font-mono p-2 rounded-lg"></div>
          <div class="pt-2 flex justify-end gap-2">
            <button type="button" id="cancelCatalogModalBtn" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300">ยกเลิก</button>
            <button type="submit" id="submitCatalogModalBtn" class="px-4 py-1.5 rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-semibold inline-flex items-center gap-1.5"><i data-lucide="upload" class="w-4 h-4 shrink-0"></i><span>บันทึก &amp; อัปขึ้น GitHub + Price_List</span></button>
          </div>
        </form>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML('beforeend', modalHtml);
  if (window.lucide) window.lucide.createIcons();

  const modal = document.getElementById('catalogUploaderModal');
  const openModal = () => {
    const statusEl = document.getElementById('catUploadStatus');
    if (statusEl) statusEl.classList.add('hidden');
    modal.classList.remove('hidden');
  };

  const headerRight = document.querySelector('header .flex.items-center.gap-2\\.5');
  if (headerRight) {
    const headerBtn = document.createElement('button');
    headerBtn.id = 'openCatalogUploaderHeaderBtn';
    headerBtn.type = 'button';
    headerBtn.className =
      'text-xs px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/35 text-emerald-200 border border-emerald-400/45 font-semibold transition flex items-center gap-1.5';
    headerBtn.innerHTML = '<i data-lucide="gem" class="w-4 h-4 shrink-0"></i><span>+ เพิ่มหินเข้า Price_List</span>';
    headerBtn.onclick = openModal;
    headerRight.prepend(headerBtn);
  }

  const smartOpsRow = document.getElementById('inspectStoneBtn')?.parentElement;
  if (smartOpsRow) {
    const opsBtn = document.createElement('button');
    opsBtn.id = 'openCatalogUploaderOpsBtn';
    opsBtn.type = 'button';
    opsBtn.className =
      'text-[11px] font-semibold px-2.5 py-1 rounded-lg bg-teal-500/20 hover:bg-teal-500/35 text-teal-200 border border-teal-400/45 flex items-center gap-1.5 transition';
    opsBtn.innerHTML = '<i data-lucide="gem" class="w-3.5 h-3.5 shrink-0"></i><span>+ เพิ่มหินเข้า Price_List</span>';
    opsBtn.onclick = openModal;
    const statusPill = document.getElementById('inspectStatusPill');
    if (statusPill) {
      smartOpsRow.insertBefore(opsBtn, statusPill);
    } else {
      smartOpsRow.appendChild(opsBtn);
    }
  }
  if (window.lucide) window.lucide.createIcons();

  document.getElementById('closeCatalogModalBtn').onclick = () => modal.classList.add('hidden');
  document.getElementById('cancelCatalogModalBtn').onclick = () => modal.classList.add('hidden');

  let imageBase64DataUrl = '';
  document.getElementById('catImgInput').onchange = (e) => {
    const input = e.target;
    const file = input.files?.[0];
    const preview = document.getElementById('catImgPreview');
    const statusEl = document.getElementById('catUploadStatus');
    imageBase64DataUrl = '';
    if (preview) {
      preview.removeAttribute('src');
      preview.classList.add('hidden');
    }
    if (!file) return;

    const mime = String(file.type || '').toLowerCase();
    if (/\.svg$/i.test(file.name || '') || /svg/i.test(mime) || !ALLOWED_MIMES.has(mime)) {
      input.value = '';
      if (statusEl) {
        statusEl.textContent = ' ไม่อนุญาตให้อัปโหลดไฟล์ .svg (รองรับเฉพาะ PNG, JPG, WEBP, GIF)';
        statusEl.className = 'text-[11px] font-mono p-2 rounded-lg bg-rose-500/15 text-rose-200 border border-rose-400/30';
        statusEl.classList.remove('hidden');
      }
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      input.value = '';
      if (statusEl) {
        statusEl.textContent = ' ขนาดไฟล์รูปภาพต้องไม่เกิน 10 MB';
        statusEl.className = 'text-[11px] font-mono p-2 rounded-lg bg-rose-500/15 text-rose-200 border border-rose-400/30';
        statusEl.classList.remove('hidden');
      }
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      if (!isSafeDataImage(result)) {
        input.value = '';
        return;
      }
      imageBase64DataUrl = result;
      if (preview) {
        preview.src = imageBase64DataUrl;
        preview.classList.remove('hidden');
      }
    };
    reader.readAsDataURL(file);
  };

  document.getElementById('catalogUploaderForm').onsubmit = async (e) => {
    e.preventDefault();
    const statusEl = document.getElementById('catUploadStatus');
    const submitBtn = document.getElementById('submitCatalogModalBtn');
    if (!imageBase64DataUrl || !isSafeDataImage(imageBase64DataUrl)) {
      return alert('กรุณาเลือกรูปภาพที่รองรับ (PNG, JPG, WEBP, GIF) ก่อนครับ');
    }

    const stoneNameVal = document.getElementById('catNameInput').value.trim();

    submitBtn.disabled = true;
    statusEl.textContent = '⏳ กำลังเซฟรูปภาพ, อัปขึ้น GitHub และบันทึกลง Google Sheets Price_List...';
    statusEl.className =
      'text-[11px] font-mono p-2 rounded-lg bg-cyan-500/15 text-cyan-200 border border-cyan-400/30';
    statusEl.classList.remove('hidden');

    try {
      const data = await apiJson('/api/catalog/add-stone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: imageBase64DataUrl,
          category: document.getElementById('catTypeInput').value,
          stoneName: stoneNameVal,
          name: stoneNameVal,
          size: document.getElementById('catSizeInput').value.trim(),
          blockCode: document.getElementById('catBlockInput').value.trim(),
          slabPrice: document.getElementById('catSlabPriceInput').value.trim(),
          cutPrice: document.getElementById('catCutPriceInput').value.trim(),
          note: document.getElementById('catNoteInput').value.trim()
        })
      });

      statusEl.textContent = ` สำเร็จ! อัปโหลดเป็น ${data.fileName} และบันทึกลง Price_List เรียบร้อยแล้ว`;
      statusEl.className =
        'text-[11px] font-mono p-2 rounded-lg bg-emerald-500/15 text-emerald-200 border border-emerald-400/30';
      if (typeof window.ensureCatalogLoaded === 'function') {
        window.ensureCatalogLoaded(true);
      }
      setTimeout(() => modal.classList.add('hidden'), 2000);
    } catch (err) {
      statusEl.textContent = ` เกิดข้อผิดพลาด: ${err.message}`;
      statusEl.className =
        'text-[11px] font-mono p-2 rounded-lg bg-rose-500/15 text-rose-200 border border-rose-400/30';
    } finally {
      submitBtn.disabled = false;
    }
  };
})();
