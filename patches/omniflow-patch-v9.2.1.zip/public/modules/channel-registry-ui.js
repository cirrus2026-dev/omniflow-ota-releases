// gateway/public/modules/channel-registry-ui.js
// Dynamic Omnichannel Registry UI Bridge (2-Column Toggles, Inbox Filter Pills & Dynamic Badges)

import { PLATFORM_ICON_SVGS } from './channel-icons.js?v=23icons';

let registryCache = null;
let registryPromise = null;

function escHtml(str) {
  if (typeof window.escapeHtml === 'function') return window.escapeHtml(str);
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

const HEX_COLOR_RE = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/;
const RGB_COLOR_RE = /^rgba?\(\s*(?:\d{1,3}\s*,\s*){2}\d{1,3}(?:\s*,\s*(?:0|1|0?\.\d+))?\s*\)$/;

function sanitizeCssColor(val, fallback = '#38bdf8') {
  const s = String(val ?? '').trim();
  if (HEX_COLOR_RE.test(s) || RGB_COLOR_RE.test(s)) return s;
  return fallback;
}

function getSafeIconHtml(channelId) {
  const key = String(channelId || '').trim().toLowerCase();
  if (!key || !Object.hasOwn(PLATFORM_ICON_SVGS, key)) return '';
  return PLATFORM_ICON_SVGS[key];
}

export async function loadChannelRegistry(force = false) {
  if (!force && registryCache) return registryCache;
  if (!force && registryPromise) return registryPromise;

  const fetcher =
    typeof window.apiFetch === 'function'
      ? window.apiFetch('/api/channels/registry', { timeoutMs: 6000 })
      : fetch('/api/channels/registry', {
          credentials: 'same-origin',
          signal: AbortSignal.timeout(6000)
        }).then((res) => (res.ok ? res.json() : null));

  registryPromise = Promise.resolve(fetcher)
    .then((data) => {
      if (data?.ok && Array.isArray(data.channels)) {
        registryCache = data;
        window.__OMNIFLOW_CHANNEL_REGISTRY__ = data;
        return data;
      }
      return registryCache;
    })
    .catch((err) => {
      console.warn('[channel-registry-ui] Failed to load channel registry:', err?.message || err);
      return registryCache;
    })
    .finally(() => {
      registryPromise = null;
    });

  return registryPromise;
}

export function getChannelMap() {
  const list = registryCache?.channels || window.__OMNIFLOW_CHANNEL_REGISTRY__?.channels || [];
  return new Map(list.map((ch) => [String(ch.id || '').toLowerCase(), ch]));
}

export function getDynamicPlatformMeta(platformOrChannel) {
  const p = String(platformOrChannel || '').toLowerCase();
  if (p === 'sandbox') {
    return {
      key: 'sandbox',
      shortLabel: 'TEST',
      headerLabel: 'SANDBOX SIMULATOR',
      avatarChar: 'SIM',
      badgeIconHtml: '<i data-lucide="flask-conical" class="w-3.5 h-3.5 shrink-0"></i>',
      badgeCls: 'bg-purple-500/20 text-purple-400 border-purple-500/35',
      badgeStyle: '',
      avatarCls: 'w-10 h-10 rounded-full bg-purple-500/20 border border-purple-500/35 flex items-center justify-center font-bold text-purple-400',
      avatarStyle: '',
      bubbleCls: 'sh-subcard rounded-2xl rounded-tl-sm'
    };
  }

  const ch = getChannelMap().get(p);
  if (ch) {
    const color = sanitizeCssColor(ch.badgeColor, '#38bdf8');
    const bg = sanitizeCssColor(ch.badgeBg, 'rgba(56, 189, 248, 0.14)');
    const borderHex = HEX_COLOR_RE.test(color) && color.length === 7 ? `${color}55` : color;
    const avatarBorderHex = HEX_COLOR_RE.test(color) && color.length === 7 ? `${color}66` : color;
    const shortLabel = String(ch.shortLabel || p.toUpperCase());
    const avatarChar = p === 'email' ? '@' : shortLabel.slice(0, 1).toUpperCase();
    return {
      key: ch.id,
      shortLabel,
      headerLabel: String(ch.label || shortLabel),
      avatarChar,
      badgeIconHtml: getSafeIconHtml(ch.id),
      badgeCls: '',
      badgeStyle: `color:${color};background:${bg};border-color:${borderHex};`,
      avatarCls: 'w-10 h-10 rounded-full border flex items-center justify-center font-bold',
      avatarStyle: `color:${color};background:${bg};border-color:${avatarBorderHex};`,
      bubbleCls: 'sh-subcard rounded-2xl rounded-tl-sm'
    };
  }

  const fallbackLabel = p ? p.toUpperCase().slice(0, 8) : 'CHAT';
  return {
    key: p || 'unknown',
    shortLabel: fallbackLabel,
    headerLabel: fallbackLabel,
    avatarChar: fallbackLabel.slice(0, 1),
    badgeCls: 'bg-slate-500/20 text-slate-300 border-slate-500/35',
    badgeStyle: '',
    avatarCls: 'w-10 h-10 rounded-full bg-slate-500/20 border border-slate-500/35 flex items-center justify-center font-bold text-slate-300',
    avatarStyle: '',
    bubbleCls: 'sh-subcard rounded-2xl rounded-tl-sm'
  };
}

export async function renderEnt2ColChannelToggles(channelsData = {}) {
  const grid = document.getElementById('entDynamicChannelsGrid');
  if (!grid) return;
  const reg = await loadChannelRegistry(true);
  const channels = reg?.channels || [];
  if (channels.length === 0) {
    grid.innerHTML = '<div class="col-span-full text-xs opacity-60">ไม่พบข้อมูลช่องทางจาก Registry</div>';
    return;
  }

  grid.innerHTML = channels
    .map((ch) => {
      const saved = channelsData?.[ch.id];
      const enabled = saved !== undefined ? Boolean(saved.enabled) : Boolean(ch.enabled);
      const statusPill = ch.configured
        ? '<span class="text-[10px] font-mono text-emerald-400">พร้อมใช้</span>'
        : '<span class="text-[10px] font-mono opacity-60">รอคีย์</span>';
      const safeColor = sanitizeCssColor(ch.badgeColor, '#38bdf8');
      const iconHtml =
        getSafeIconHtml(ch.id) ||
        `<span class="w-2.5 h-2.5 rounded-full shrink-0" style="background:${escHtml(safeColor)};"></span>`;
      return `
        <label class="sh-subcard p-3 flex items-center justify-between gap-2 cursor-pointer hover:border-cyan-400/50 transition">
          <span class="flex items-center gap-2 min-w-0">
            ${iconHtml}
            <span class="font-semibold truncate">${escHtml(ch.label || ch.shortLabel)}</span>
            ${statusPill}
          </span>
          <input type="checkbox" data-ent-ch-toggle="${escHtml(ch.id)}" ${enabled ? 'checked' : ''} class="accent-cyan-500 w-4 h-4 shrink-0" />
        </label>`;
    })
    .join('');
}

export function collectEnt2ColChannelsPayload() {
  const out = {};
  document.querySelectorAll('[data-ent-ch-toggle]').forEach((el) => {
    const id = el.getAttribute('data-ent-ch-toggle');
    if (id) out[id] = { enabled: Boolean(el.checked) };
  });
  return out;
}

export async function renderInboxDynamicFilterPills(conversations = [], activeFilter = 'all') {
  const host = document.getElementById('dynamicChannelFilterPills');
  if (!host) return;
  const reg = await loadChannelRegistry(false);
  const channels = reg?.channels || [];
  const inboxSet = new Set(
    (Array.isArray(conversations) ? conversations : [])
      .map((c) => String(c?.platform || c?.channel || '').toLowerCase())
      .filter(Boolean)
  );

  const visibleChannels = channels.filter((ch) => (ch.enabled && ch.configured) || inboxSet.has(ch.id));
  host.innerHTML = visibleChannels
    .map((ch) => {
      const isActive = activeFilter === ch.id;
      const color = sanitizeCssColor(ch.badgeColor, '#38bdf8');
      const bg = sanitizeCssColor(ch.badgeBg, 'rgba(56, 189, 248, 0.14)');
      const borderHex = HEX_COLOR_RE.test(color) && color.length === 7 ? `${color}88` : color;
      const activeStyle = isActive ? `color:${color};background:${bg};border-color:${borderHex};` : '';
      const cls = isActive
        ? 'px-2.5 py-1 rounded-lg border font-bold transition'
        : 'px-2.5 py-1 rounded-lg bg-slate-900/90 text-slate-400 hover:text-white border border-slate-800 transition';
      const svgIcon = getSafeIconHtml(ch.id);
      const pillIcon = svgIcon
        ? `<span class="inline-flex align-middle mr-1 scale-90">${svgIcon}</span>`
        : `<span class="inline-block w-2 h-2 rounded-full mr-1 align-middle" style="background:${escHtml(color)};"></span>`;
      return `<button type="button" data-dyn-filter="${escHtml(ch.id)}" style="${escHtml(activeStyle)}" class="${cls}">
        ${pillIcon}${escHtml(ch.shortLabel)}
      </button>`;
    })
    .join('');

  host.querySelectorAll('[data-dyn-filter]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const filterId = btn.getAttribute('data-dyn-filter');
      if (filterId && typeof window.setChatFilter === 'function') {
        window.setChatFilter(filterId);
      }
    });
  });

  return visibleChannels;
}

window.loadChannelRegistry = loadChannelRegistry;
window.getDynamicPlatformMeta = getDynamicPlatformMeta;
window.renderEnt2ColChannelToggles = renderEnt2ColChannelToggles;
window.collectEnt2ColChannelsPayload = collectEnt2ColChannelsPayload;
window.renderInboxDynamicFilterPills = renderInboxDynamicFilterPills;

loadChannelRegistry(false);
