// gateway/public/modules/orders-manager-ui.js
// Phase 10: Standalone Orders & Leads CRM UI (Replaces Activepieces :8080 & Google Sheets CRM)

const TAB_BTN_ID = 'tabBtnOrders';
const VIEW_ID = 'viewOrdersManager';

let allOrders = [];
let statusFilter = 'ALL';
let orderSearch = '';

const STATUS_META = {
  pending: {
    label: 'รอดำเนินการ',
    cls: 'bg-amber-500/15 text-amber-300 border-amber-500/40'
  },
  pending_unconfirmed: {
    label: 'รอทวนยอด (ยังไม่กดยืนยัน)',
    cls: 'bg-orange-500/15 text-orange-300 border-orange-500/40'
  },
  deposit_paid: {
    label: 'มัดจำแล้ว',
    cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40'
  },
  shipped: {
    label: 'ส่งของแล้ว',
    cls: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40'
  },
  completed: {
    label: 'ปิดงานแล้ว',
    cls: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/40'
  },
  cancelled: {
    label: 'ยกเลิก',
    cls: 'bg-slate-700/40 text-slate-400 border-slate-600/40'
  }
};

function escapeHtml(str) {
  if (typeof window.escapeHtml === 'function') return window.escapeHtml(str);
  return String(str ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function isSafeUrl(rawUrl) {
  if (typeof window.isSafeUrl === 'function') return window.isSafeUrl(rawUrl);
  const s = String(rawUrl ?? '').trim();
  if (!s || /^(?:javascript|vbscript|data):/i.test(s)) return false;
  if (/^\/(?!\/)/.test(s)) return true;
  try {
    const parsed = new URL(s, window.location.origin);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

async function apiJson(path, options = {}) {
  const bridge =
    typeof window.apiFetch === 'function'
      ? window.apiFetch
      : typeof window.omniApiFetch === 'function'
      ? window.omniApiFetch
      : null;
  if (bridge) return bridge(path, options);
  const res = await fetch(path, { credentials: 'same-origin', ...options });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data || data.ok === false) {
    throw new Error(data?.error || `HTTP ${res.status}`);
  }
  return data;
}

function notifyOrders(msg, isError = false) {
  const existing = document.getElementById('rwOrdersToast');
  if (existing) existing.remove();
  const el = document.createElement('div');
  el.id = 'rwOrdersToast';
  el.className = `fixed bottom-5 right-5 z-[10000] px-4 py-3 rounded-xl border text-xs font-semibold shadow-2xl transition ${
    isError
      ? 'bg-rose-950/95 border-rose-500/50 text-rose-200'
      : 'bg-cyan-950/95 border-cyan-400/50 text-cyan-100'
  }`;
  const clean = String(msg ?? '').replace(/^[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\s]+/u, '');
  el.innerHTML = `<span class="inline-flex items-center gap-2"><i data-lucide="${isError ? 'alert-circle' : 'check-circle-2'}" class="w-4 h-4 shrink-0"></i><span>${escapeHtml(clean)}</span></span>`;
  document.body.appendChild(el);
  if (window.lucide) window.lucide.createIcons();
  setTimeout(() => el.remove(), 3000);
}

function injectOrdersNavAndView() {
  const nav =
    document.querySelector('header nav') ||
    document.querySelector('nav.flex.items-center') ||
    document.querySelector('nav');
  if (nav && !document.getElementById(TAB_BTN_ID)) {
    const btn = document.createElement('button');
    btn.id = TAB_BTN_ID;
    btn.type = 'button';
    btn.className =
      'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition text-slate-400 hover:text-cyan-200 border border-transparent';
    btn.innerHTML = '<i data-lucide="clipboard-list" class="w-4 h-4 shrink-0"></i><span>ออเดอร์ &amp; ลูกค้า</span>';
    btn.addEventListener('click', () => {
      if (typeof window.switchView === 'function') {
        window.switchView('orders');
      } else {
        activateOrdersView();
      }
    });

    const settingsBtn = document.getElementById('rwOpenSettingsBtn');
    if (settingsBtn && settingsBtn.parentElement === nav) {
      nav.insertBefore(btn, settingsBtn);
    } else {
      nav.appendChild(btn);
    }
  }

  if (!document.getElementById(VIEW_ID)) {
    const section = document.createElement('section');
    section.id = VIEW_ID;
    section.className = 'hidden max-w-[1440px] mx-auto px-4 sm:px-6 py-6 space-y-5';
    section.innerHTML = `
      <div class="aether-panel rounded-2xl p-5 border-purple-500/25 space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 class="text-lg font-bold text-white flex items-center gap-2">
              <i data-lucide="clipboard-list" class="w-5 h-5 text-purple-400 shrink-0"></i>
              <span>ทะเบียนออเดอร์ &amp; รายชื่อลูกค้า (Local Orders &amp; Leads CRM)</span>
              <span id="ordTotalBadge" class="text-xs font-mono px-2.5 py-0.5 rounded-full bg-purple-500/15 text-purple-300 border border-purple-500/35">0 รายการ</span>
            </h2>
            <p class="text-xs text-slate-400 mt-0.5">บันทึกเบอร์โทร ที่อยู่ และคำสั่งซื้ออัตโนมัติในเครื่อง</p>
            <p class="text-xs font-semibold text-rose-400 mt-1 flex items-center gap-1.5"><i data-lucide="alert-triangle" class="w-3.5 h-3.5 shrink-0"></i><span>AI มีสิทธิ์ผิดพลาด แอดมินควรตรวจทานแชททุกออเดอร์</span></p>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <button type="button" id="btnOpenNewOrderModal" class="px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-500/20 transition inline-flex items-center gap-1.5">
              <i data-lucide="plus" class="w-4 h-4 shrink-0"></i><span>บันทึกออเดอร์ใหม่</span>
            </button>
            <a href="/api/local-db/orders-export.csv" download="omniflow-orders-crm.csv" class="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-emerald-300 border border-emerald-500/35 text-xs font-semibold transition inline-flex items-center gap-1.5">
              <i data-lucide="file-spreadsheet" class="w-4 h-4 shrink-0"></i><span>Export Excel (.csv)</span>
            </a>
          </div>
        </div>

        <!-- Status Filter Pills & Search -->
        <div class="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
          <div class="flex flex-wrap items-center gap-1.5 text-xs font-semibold">
            <button type="button" data-ord-filter="ALL" class="ord-filter-btn px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-200 border border-cyan-400/40">ทั้งหมด</button>
            <button type="button" data-ord-filter="pending" class="ord-filter-btn px-3 py-1.5 rounded-lg bg-slate-900 text-slate-400 border border-slate-800 hover:text-amber-300">รอดำเนินการ</button>
            <button type="button" data-ord-filter="pending_unconfirmed" class="ord-filter-btn px-3 py-1.5 rounded-lg bg-slate-900 text-slate-400 border border-slate-800 hover:text-orange-300">รอทวนยอด</button>
            <button type="button" data-ord-filter="deposit_paid" class="ord-filter-btn px-3 py-1.5 rounded-lg bg-slate-900 text-slate-400 border border-slate-800 hover:text-emerald-300">มัดจำแล้ว</button>
            <button type="button" data-ord-filter="shipped" class="ord-filter-btn px-3 py-1.5 rounded-lg bg-slate-900 text-slate-400 border border-slate-800 hover:text-cyan-300">ส่งของแล้ว</button>
            <button type="button" data-ord-filter="completed" class="ord-filter-btn px-3 py-1.5 rounded-lg bg-slate-900 text-slate-400 border border-slate-800 hover:text-indigo-300">ปิดงานแล้ว</button>
          </div>
          <input id="ordSearchInput" type="text" placeholder="ค้นหาชื่อลูกค้า, เบอร์โทร, สินค้า/บริการ..." class="w-full sm:w-72 px-3.5 py-1.5 rounded-xl bg-slate-950/90 border border-slate-700 focus:border-cyan-400 focus:outline-none text-xs text-slate-100" />
        </div>

        <!-- Orders Table -->
        <div class="overflow-x-auto rounded-xl border border-slate-800/90 max-h-[65vh]">
          <table class="w-full text-left border-collapse">
            <thead class="sticky top-0 z-10 bg-slate-950 text-[11px] font-mono uppercase text-slate-400 border-b border-slate-800">
              <tr>
                <th class="py-2.5 px-3">วันเวลา</th>
                <th class="py-2.5 px-3">ช่องทาง / ลูกค้า</th>
                <th class="py-2.5 px-3">สินค้า &amp; ขนาด</th>
                <th class="py-2.5 px-3">ยอดประเมิน (บาท)</th>
                <th class="py-2.5 px-3">เบอร์โทร</th>
                <th class="py-2.5 px-3">ที่อยู่จัดส่ง</th>
                <th class="py-2.5 px-3">รูปภาพแนบ</th>
                <th class="py-2.5 px-3">สถานะออเดอร์</th>
              </tr>
            </thead>
            <tbody id="ordTableBody" class="divide-y divide-slate-800/70 text-xs">
              <tr><td colspan="8" class="py-10 text-center text-slate-400">กำลังโหลดข้อมูลออเดอร์...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Manual Order Modal -->
      <div id="newOrderLocalModal" class="hidden fixed inset-0 z-[9995] items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
        <div class="w-full max-w-lg rounded-2xl bg-[#0a1024] border border-purple-500/35 p-6 space-y-4 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-base font-bold text-purple-300 flex items-center gap-2"><i data-lucide="plus-circle" class="w-4 h-4 shrink-0"></i><span>บันทึกออเดอร์ / ลูกค้าฝากเบอร์</span></h3>
            <button type="button" id="btnCloseNewOrderModal" class="text-slate-400 hover:text-rose-300 text-sm inline-flex items-center"><i data-lucide="x" class="w-4 h-4 shrink-0"></i></button>
          </div>
          <form id="formNewOrderLocal" class="space-y-3 text-xs">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block text-slate-300 mb-1">ชื่อลูกค้า *</label>
                <input name="customerName" type="text" required placeholder="คุณสมชาย" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">เบอร์โทรศัพท์ *</label>
                <input name="phone" type="text" required placeholder="081-234-5678" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-emerald-300 font-mono" />
              </div>
            </div>
            <div class="grid grid-cols-3 gap-3">
              <div>
                <label class="block text-slate-300 mb-1">สินค้า / บริการ *</label>
                <input name="productName" type="text" required placeholder="ระบุชื่อสินค้าหรือบริการ" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">จำนวน / รายละเอียด</label>
                <input name="dimensions" type="text" placeholder="เช่น 100 ตัว / 1 คอร์ส" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100" />
              </div>
              <div>
                <label class="block text-slate-300 mb-1">ยอดประเมิน (บาท)</label>
                <input name="estimatedTotal" type="text" inputmode="decimal" placeholder="เช่น 10000" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-emerald-300 font-mono" />
              </div>
            </div>
            <div>
              <label class="block text-slate-300 mb-1">ที่อยู่จัดส่ง / หน้างาน</label>
              <textarea name="address" rows="2" placeholder="ระบุที่อยู่จัดส่ง..." class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100"></textarea>
            </div>
            <div>
              <label class="block text-slate-300 mb-1">สถานะเริ่มต้น</label>
              <select name="status" class="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-slate-100">
                <option value="pending">รอดำเนินการ</option>
                <option value="deposit_paid">มัดจำแล้ว</option>
                <option value="shipped">ส่งของแล้ว</option>
                <option value="completed">ปิดงานแล้ว</option>
              </select>
            </div>
            <div class="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <button type="button" id="btnCancelNewOrder" class="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold">ยกเลิก</button>
              <button type="submit" class="px-5 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 text-white font-bold inline-flex items-center gap-1.5"><i data-lucide="save" class="w-4 h-4 shrink-0"></i><span>บันทึกออเดอร์</span></button>
            </div>
          </form>
        </div>
      </div>
    `;

    const mainAnchor = document.getElementById('viewCatalogManager') || document.getElementById('viewInbox') || document.getElementById('viewDashboard');
    if (mainAnchor && mainAnchor.parentElement) {
      mainAnchor.parentElement.insertBefore(section, mainAnchor.nextSibling);
    } else {
      document.body.appendChild(section);
    }
    if (window.lucide) window.lucide.createIcons();

    bindOrdersEvents();
  }
}

function bindOrdersEvents() {
  document.querySelectorAll('.ord-filter-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      statusFilter = btn.getAttribute('data-ord-filter');
      document.querySelectorAll('.ord-filter-btn').forEach((b) => {
        const active = b.getAttribute('data-ord-filter') === statusFilter;
        b.className = active
          ? 'ord-filter-btn px-3 py-1.5 rounded-lg bg-cyan-500/20 text-cyan-200 border border-cyan-400/40'
          : 'ord-filter-btn px-3 py-1.5 rounded-lg bg-slate-900 text-slate-400 border border-slate-800 hover:text-slate-200';
      });
      renderOrdersTable();
    });
  });

  document.getElementById('ordSearchInput')?.addEventListener('input', (e) => {
    orderSearch = e.target.value.trim().toLowerCase();
    renderOrdersTable();
  });

  const modal = document.getElementById('newOrderLocalModal');
  document.getElementById('btnOpenNewOrderModal')?.addEventListener('click', () => {
    modal?.classList.remove('hidden');
    modal?.classList.add('flex');
  });
  const closeModal = () => {
    modal?.classList.add('hidden');
    modal?.classList.remove('flex');
  };
  document.getElementById('btnCloseNewOrderModal')?.addEventListener('click', closeModal);
  document.getElementById('btnCancelNewOrder')?.addEventListener('click', closeModal);

  // แปลงยอดเงินจากช่องข้อความ ("10,000", "10,000 บาท", "฿10000.50") เป็น Number ถ้าค่าไม่ถูกต้องให้เป็น 0
  function parseMoneyInput(value) {
    const num = Number(String(value ?? '').replace(/[^\d.]/g, ''));
    return Number.isFinite(num) && num >= 0 ? num : 0;
  }

  document.getElementById('formNewOrderLocal')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = {
      channel: 'manual',
      customerName: fd.get('customerName'),
      phone: fd.get('phone'),
      productName: fd.get('productName'),
      dimensions: fd.get('dimensions'),
      estimatedTotal: parseMoneyInput(fd.get('estimatedTotal')),
      address: fd.get('address'),
      status: fd.get('status')
    };
    try {
      await apiJson('/api/local-db/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      e.target.reset();
      closeModal();
      notifyOrders(' บันทึกออเดอร์ลงฐานข้อมูลเรียบร้อยแล้ว');
      await loadOrdersData();
      if (typeof window.fetchDailyKpiSummary === 'function') window.fetchDailyKpiSummary();
    } catch (err) {
      notifyOrders(` ${err.message}`, true);
    }
  });
}

export async function loadOrdersData() {
  try {
    const data = await apiJson('/api/local-db/orders');
    allOrders = data.orders || [];
    renderOrdersTable();
  } catch (err) {
    notifyOrders(` ${err.message}`, true);
  }
}

function ensureAmendGlowStyles() {
  if (document.getElementById('rwAmendGlowStyle')) return;
  const st = document.createElement('style');
  st.id = 'rwAmendGlowStyle';
  st.textContent = `
    @keyframes rwAmendGlowPulse {
      0%, 100% { box-shadow: inset 0 0 0 1px rgba(34, 211, 238, 0.7), 0 0 14px rgba(34, 211, 238, 0.25); }
      50% { box-shadow: inset 0 0 0 2px rgba(168, 85, 247, 0.9), 0 0 22px rgba(34, 211, 238, 0.45); }
    }
    .rw-row-amended-glow {
      animation: rwAmendGlowPulse 2s ease-in-out infinite;
      background: linear-gradient(90deg, rgba(8, 145, 178, 0.16) 0%, rgba(88, 28, 135, 0.12) 100%);
    }
  `;
  document.head.appendChild(st);
}

function renderOrdersTable() {
  ensureAmendGlowStyles();
  const tbody = document.getElementById('ordTableBody');
  const badge = document.getElementById('ordTotalBadge');
  if (!tbody) return;

  const filtered = allOrders
    .filter((ord) => {
      if (statusFilter !== 'ALL' && ord.status !== statusFilter) return false;
      if (orderSearch) {
        const itemsText = Array.isArray(ord.items)
          ? ord.items.map((it) => `${it.name || ''} ${it.dimensions || ''}`).join(' ')
          : '';
        const hay = `${ord.customerName} ${ord.phone} ${ord.productName} ${ord.dimensions} ${itemsText} ${ord.address} ${ord.channel}`.toLowerCase();
        if (!hay.includes(orderSearch)) return false;
      }
      return true;
    })
    .sort((a, b) => {
      const aHot = a.amendedAtMs && !a.amendAcked ? 1 : 0;
      const bHot = b.amendedAtMs && !b.amendAcked ? 1 : 0;
      if (aHot !== bHot) return bHot - aHot;
      return Number(b.amendedAtMs || b.createdAtMs || 0) - Number(a.amendedAtMs || a.createdAtMs || 0);
    });

  if (badge) badge.textContent = `${filtered.length} / ${allOrders.length} รายการ`;

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="py-10 text-center text-slate-500">ยังไม่มีรายการออเดอร์ในหมวดหมู่นี้</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered
    .map((ord) => {
      const rawImgUrl = String(ord.imageUrl || '').trim();
      const safeImgUrl = isSafeUrl(rawImgUrl) ? rawImgUrl : '';
      const imgBtn = safeImgUrl
        ? `<a href="${escapeHtml(safeImgUrl)}" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-500/35 text-[11px]"><i data-lucide="image" class="w-3.5 h-3.5 shrink-0"></i><span>ดูรูปแนบ</span></a>`
        : `<span class="text-slate-600 text-[11px]">-</span>`;

      const isAmendedUnacked = Boolean(ord.amendedAtMs && !ord.amendAcked);
      const amendBadgeHtml = ord.amendedAtMs
        ? `<div class="mt-1 flex flex-wrap items-center gap-1">
            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-400/60 text-[10px] font-bold"><i data-lucide="refresh-cw" class="w-3 h-3 shrink-0"></i><span>อัปเดตเพิ่มเติม (${escapeHtml(ord.amendedAtLabel || '')})</span></span>
            ${
              isAmendedUnacked
                ? `<button type="button" data-ack-amend="${escapeHtml(ord.id)}" class="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-emerald-600/40 text-emerald-300 border border-emerald-500/40 text-[10px] font-semibold transition inline-flex items-center gap-1"><i data-lucide="check" class="w-3 h-3 shrink-0"></i><span>รับทราบ</span></button>`
                : ''
            }
          </div>`
        : '';

      const dimVal = ord.dimensions || (ord.quantity ? String(ord.quantity) : '');
      const hasMultiItems = Array.isArray(ord.items) && ord.items.length > 1;
      const itemsListHtml = hasMultiItems
        ? `<ul class="mt-1 mb-1 space-y-1 text-[11px] bg-slate-950/60 border border-purple-500/25 rounded-lg p-2">
            ${ord.items
              .map((it, idx) => {
                const subStr = Number.isFinite(Number(it.subtotal)) && Number(it.subtotal) > 0
                  ? ` <span class="text-emerald-300 font-mono">(${Number(it.subtotal).toLocaleString('en-US')} บ.)</span>`
                  : '';
                const specStr = [it.dimensions, it.qty ? `${it.qty} ${it.unit || 'หน่วย'}` : '']
                  .filter(Boolean)
                  .join(' • ');
                const isNew = Boolean(it.isNewItem);
                const liCls = isNew
                  ? 'text-cyan-200 bg-cyan-500/15 border border-cyan-400/40 rounded px-1.5 py-0.5 font-semibold leading-snug'
                  : 'text-slate-200 leading-snug';
                return `<li class="${liCls}"><span class="${isNew ? 'text-cyan-300' : 'text-purple-300'} font-bold">${idx + 1}.${isNew ? ' [เพิ่มใหม่]' : ''}</span> ${escapeHtml(it.name)}${specStr ? ` <span class="text-slate-400">[${escapeHtml(specStr)}]</span>` : ''}${subStr}</li>`;
              })
              .join('')}
          </ul>`
        : '';

      const productTitleHtml = hasMultiItems
        ? `<div class="font-semibold text-purple-200 flex items-center gap-1.5"><i data-lucide="package" class="w-3.5 h-3.5 shrink-0"></i><span>สั่งรวม ${ord.items.length} รายการ${ord.amendedAtMs ? ' (อัปเดตล่าสุด)' : ''}</span></div>${itemsListHtml}`
        : `<div class="font-semibold text-slate-200">${escapeHtml(ord.productName)}</div>`;

      return `
        <tr class="${isAmendedUnacked ? 'rw-row-amended-glow' : 'hover:bg-slate-900/50'} transition">
          <td class="py-2.5 px-3 font-mono text-[11px] text-slate-400 whitespace-nowrap">
            <div>${escapeHtml(ord.timestamp)}</div>
            ${amendBadgeHtml}
          </td>
          <td class="py-2.5 px-3">
            <span class="px-1.5 py-0.5 rounded text-[10px] font-mono uppercase bg-slate-800 text-cyan-300 mr-1">${escapeHtml(ord.channel)}</span>
            <span class="font-bold text-white">${escapeHtml(ord.customerName)}</span>
          </td>
          <td class="py-2.5 px-3">
            ${productTitleHtml}
            <textarea data-order-dim="${escapeHtml(ord.id)}" rows="2" placeholder="ระบุจำนวน/ขนาด (Shift+Enter ขึ้นบรรทัดใหม่)..." class="mt-1 w-56 px-2 py-1 rounded bg-slate-950/90 border border-slate-700/80 focus:border-cyan-400 focus:outline-none text-[11px] font-mono text-cyan-200 placeholder-slate-600 resize-y leading-relaxed" title="Shift+Enter ขึ้นบรรทัดใหม่, Enter เพื่อบันทึก">${escapeHtml(dimVal)}</textarea>
          </td>
          <td class="py-2.5 px-3">
            <input type="text" data-order-total="${escapeHtml(ord.id)}" value="${escapeHtml(ord.estimatedTotal || '')}" placeholder="ระบุยอดเงิน..." class="w-32 px-2.5 py-1 rounded-lg bg-slate-950/90 border border-slate-700/80 focus:border-emerald-400 focus:outline-none text-xs font-mono font-bold text-emerald-300 placeholder-slate-600" title="คลิกเพื่อแก้ไขยอดเงินประเมินแล้วกด Enter" />
          </td>
          <td class="py-2.5 px-3 font-mono font-bold text-emerald-300">${escapeHtml(ord.phone)}</td>
          <td class="py-2.5 px-3 text-slate-300 max-w-xs truncate" title="${escapeHtml(ord.address)}">${escapeHtml(ord.address || '-')}</td>
          <td class="py-2.5 px-3">${imgBtn}</td>
          <td class="py-2.5 px-3">
            <div class="flex items-center gap-1.5">
              <select data-order-status="${escapeHtml(ord.id)}" class="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 text-xs font-semibold text-slate-100 focus:border-cyan-400">
                <option value="pending" ${ord.status === 'pending' ? 'selected' : ''}>รอดำเนินการ</option>
                <option value="pending_unconfirmed" ${ord.status === 'pending_unconfirmed' ? 'selected' : ''}>รอทวนยอด (ยังไม่กดยืนยัน)</option>
                <option value="deposit_paid" ${ord.status === 'deposit_paid' ? 'selected' : ''}>มัดจำแล้ว</option>
                <option value="shipped" ${ord.status === 'shipped' ? 'selected' : ''}>ส่งของแล้ว</option>
                <option value="completed" ${ord.status === 'completed' ? 'selected' : ''}>ปิดงานแล้ว</option>
                <option value="cancelled" ${ord.status === 'cancelled' ? 'selected' : ''}>ยกเลิก</option>
              </select>
              <button type="button" data-order-delete="${escapeHtml(ord.id)}" title="ลบออเดอร์นี้" class="px-2 py-1 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 text-rose-300 border border-rose-500/35 text-[11px] font-semibold transition inline-flex items-center"><i data-lucide="trash-2" class="w-3.5 h-3.5 shrink-0"></i></button>
            </div>
          </td>
        </tr>
      `;
    })
    .join('');
  if (window.lucide) window.lucide.createIcons();

  tbody.querySelectorAll('[data-ack-amend]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-ack-amend');
      try {
        await apiJson(`/api/local-db/orders/${encodeURIComponent(id)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ amendAcked: true })
        });
        await loadOrdersData();
      } catch (err) {
        notifyOrders(` ${err.message}`, true);
      }
    });
  });

  tbody.querySelectorAll('[data-order-dim]').forEach((inp) => {
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        inp.blur();
      }
    });
    inp.addEventListener('change', async () => {
      const id = inp.getAttribute('data-order-dim');
      const dimensions = inp.value.trim();
      try {
        await apiJson(`/api/local-db/orders/${encodeURIComponent(id)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ dimensions })
        });
        notifyOrders(` บันทึกจำนวน/ขนาดเป็น "${dimensions || '-'}" แล้ว`);
        await loadOrdersData();
        if (typeof window.fetchDailyKpiSummary === 'function') window.fetchDailyKpiSummary();
      } catch (err) {
        notifyOrders(` ${err.message}`, true);
      }
    });
  });

  tbody.querySelectorAll('[data-order-total]').forEach((inp) => {
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        inp.blur();
      }
    });
    inp.addEventListener('change', async () => {
      const id = inp.getAttribute('data-order-total');
      const estimatedTotal = inp.value.trim();
      try {
        await apiJson(`/api/local-db/orders/${encodeURIComponent(id)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ estimatedTotal })
        });
        notifyOrders(` บันทึกยอดประเมินเป็น "${estimatedTotal || '0'}" แล้ว`);
        await loadOrdersData();
        if (typeof window.fetchDailyKpiSummary === 'function') window.fetchDailyKpiSummary();
      } catch (err) {
        notifyOrders(` ${err.message}`, true);
      }
    });
  });

  tbody.querySelectorAll('[data-order-status]').forEach((sel) => {
    sel.addEventListener('change', async () => {
      const id = sel.getAttribute('data-order-status');
      const status = sel.value;
      try {
        await apiJson(`/api/local-db/orders/${encodeURIComponent(id)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status })
        });
        notifyOrders(` อัปเดตสถานะเป็น "${STATUS_META[status]?.label || status}" แล้ว`);
        await loadOrdersData();
        if (typeof window.fetchDailyKpiSummary === 'function') window.fetchDailyKpiSummary();
      } catch (err) {
        notifyOrders(` ${err.message}`, true);
      }
    });
  });

  tbody.querySelectorAll('[data-order-delete]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.getAttribute('data-order-delete');
      if (!id || !confirm('ยืนยันการลบออเดอร์รายการนี้?')) return;
      try {
        await apiJson(`/api/local-db/orders/${encodeURIComponent(id)}`, { method: 'DELETE' });
        notifyOrders(' ลบออเดอร์เรียบร้อยแล้ว');
        await loadOrdersData();
        if (typeof window.fetchDailyKpiSummary === 'function') window.fetchDailyKpiSummary();
      } catch (err) {
        notifyOrders(` ${err.message}`, true);
      }
    });
  });
}

export function activateOrdersView() {
  injectOrdersNavAndView();
  ['viewDashboard', 'viewInbox', 'viewCatalogManager'].forEach((id) => {
    document.getElementById(id)?.classList.add('hidden');
  });
  document.getElementById(VIEW_ID)?.classList.remove('hidden');

  const activeCls =
    'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition bg-gradient-to-r from-cyan-500/25 to-indigo-500/25 text-cyan-200 border border-cyan-400/40 glow-cyan';
  const idleCls =
    'flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition text-slate-400 hover:text-white border border-transparent';

  ['tabBtnDashboard', 'tabBtnInbox', 'tabBtnCatalog'].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.className = idleCls;
  });
  const ordBtn = document.getElementById(TAB_BTN_ID);
  if (ordBtn) ordBtn.className = activeCls;

  loadOrdersData();
}

window.activateOrdersView = activateOrdersView;

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectOrdersNavAndView);
} else {
  injectOrdersNavAndView();
}
